package org.nemours.gaitlab.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.nemours.gaitlab.model.Patient;
import org.nemours.gaitlab.repository.PatientRepository;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.repository.VisitRepository.VideoVisitDate;

class VideoServiceTest {

    @TempDir
    Path temporaryDirectory;

    @Test
    void listsPatientVideosThroughSelectedVisitAndResolvesContentFile() throws Exception {
        PatientRepository patientRepository = mock(PatientRepository.class);
        VisitRepository visitRepository = mock(VisitRepository.class);
        Patient patient = new Patient();
        patient.setMrn("10000000");

        VideoVisitDate selectedVisit = visitDate(21, "2003-01-12");
        VideoVisitDate laterVisit = visitDate(22, "2003-02-20");
        when(patientRepository.findById(14)).thenReturn(Optional.of(patient));
        when(visitRepository.findVideoVisitDateByIdAndPatientId(21, 14))
                .thenReturn(Optional.of(selectedVisit));
        when(visitRepository.findVideoVisitDatesByPatientId(14))
                .thenReturn(List.of(laterVisit, selectedVisit));

        Path patientDirectory = temporaryDirectory.resolve("10000000");
        Path patientVideo = patientDirectory.resolve("video").resolve("Patient 10000000 011203.mov");
        Path selectedVisitVideo = patientDirectory.resolve("011203")
                .resolve("video")
                .resolve("Patient_SHUEE 10000000 011203.mov");
        Path laterVisitVideo = patientDirectory.resolve("022003")
                .resolve("video")
                .resolve("Patient 10000000 022003.mov");
        writeVideo(patientVideo);
        writeVideo(selectedVisitVideo);
        writeVideo(laterVisitVideo);

        VideoService service = new VideoService(
                patientRepository,
                visitRepository,
                temporaryDirectory.toString());

        List<VideoService.VideoMetadata> videos = service.findVideos(14, 21);

        assertEquals(2, videos.size());
        assertEquals(LocalDate.of(2003, 1, 12), videos.get(0).visitDate());
        assertEquals("Upper Extremity", videos.get(0).category());
        assertEquals(null, videos.get(1).visitDate());
        assertTrue(videos.get(0).contentUrl().contains("/api/patients/14/videos/"));
        assertNotNull(service.resolveVideo(14, videos.get(0).id()));
        assertEquals(selectedVisitVideo.toRealPath(), service.resolveVideo(14, videos.get(0).id()));
    }

    private static VideoVisitDate visitDate(int id, String date) {
        return new VideoVisitDate() {
            @Override
            public Integer getId() {
                return id;
            }

            @Override
            public String getVisitDate() {
                return date;
            }
        };
    }

    private static void writeVideo(Path path) throws Exception {
        Files.createDirectories(path.getParent());
        Files.write(path, new byte[] { 0, 1, 2, 3 });
    }
}
