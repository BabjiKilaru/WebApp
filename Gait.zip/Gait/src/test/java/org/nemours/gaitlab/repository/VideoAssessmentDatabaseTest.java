package org.nemours.gaitlab.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.function.UnaryOperator;
import javax.sql.DataSource;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import org.nemours.gaitlab.requests.VideoAssessmentSaveRequest;
import org.nemours.gaitlab.controller.VideoAssessmentController;
import org.nemours.gaitlab.response.VideoAssessmentResponse;
import org.nemours.gaitlab.response.VideoAssessmentResponse.Field;
import org.nemours.gaitlab.service.VideoAssessmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.server.ResponseStatusException;
import tools.jackson.databind.ObjectMapper;

@SpringJUnitConfig(VideoAssessmentDatabaseTest.Config.class)
@EnabledIfEnvironmentVariable(named = "GAITLAB_VIDEO_TEST_URL", matches = ".*gaitlab_video_test.*")
@Transactional
class VideoAssessmentDatabaseTest {
    @Configuration
    @EnableTransactionManagement
    static class Config {
        @Bean DataSource dataSource() {
            return new DriverManagerDataSource(System.getenv("GAITLAB_VIDEO_TEST_URL"), "postgres", "");
        }
        @Bean JdbcTemplate jdbc(DataSource ds) { return new JdbcTemplate(ds); }
        @Bean PlatformTransactionManager transactionManager(DataSource ds) { return new DataSourceTransactionManager(ds); }
        @Bean VideoAssessmentRepository repository(JdbcTemplate jdbc) { return new VideoAssessmentRepository(jdbc); }
        @Bean VideoAssessmentService service(VideoAssessmentRepository repository) {
            return new VideoAssessmentService(repository, new ObjectMapper());
        }
    }

    @Autowired JdbcTemplate jdbc;
    @Autowired VideoAssessmentService service;
    @Autowired VideoAssessmentRepository repository;
    @Autowired PlatformTransactionManager transactions;

    @BeforeAll
    static void schema(@Autowired JdbcTemplate jdbc) throws Exception {
        assertTrue(jdbc.queryForObject("SELECT current_database()", String.class).startsWith("gaitlab_video_test"));
        jdbc.execute("DROP SCHEMA IF EXISTS nmquestionnaire CASCADE");
        jdbc.execute("DROP SCHEMA public CASCADE");
        jdbc.execute("CREATE SCHEMA public");
        String sql = new ClassPathResource("video-assessment-fixture.sql").getContentAsString(StandardCharsets.UTF_8);
        for (String statement : sql.split(";")) if (!statement.isBlank()) jdbc.execute(statement);
    }

    @BeforeEach
    void fixture() {
        jdbc.update("INSERT INTO public.visits VALUES (1,42,1),(2,42,3),(3,42,2),(4,42,9),(5,42,NULL),(6,42,11)");
        jdbc.update("INSERT INTO public.users VALUES (7,'editor',true,NULL,'user'),(8,'denied',true,NULL,'NONE'),"
                + "(9,'inactive',false,NULL,'admin'),(10,'expired',true,now()-interval '1 day','admin'),"
                + "(11,'internal',true,NULL,'Internal'),(12,'admin',true,NULL,'admin')");
        for (int group = 0; group <= 13; group++) {
            jdbc.update("INSERT INTO public.video_interp_groups VALUES (?,?)", group, "Group " + group);
            if (group >= 2) {
                jdbc.update("INSERT INTO public.video_interp_fields VALUES (?,?,?,?,?,false)",
                        group * 10, group, "field" + group, "Field " + group, 1);
            }
        }
        jdbc.update("INSERT INTO public.video_interp_fields VALUES (121,12,'runOther','Other running',2,false)");
        jdbc.update("INSERT INTO public.video_interp_fields VALUES (999,2,'hidden','Hidden',2,true)");
        for (int i = 1; i <= 9; i++) {
            int group = 100 + i;
            String name = "RVA%02d".formatted(i);
            jdbc.update("INSERT INTO nmquestionnaire.question_group VALUES (?,?,NULL)", group, name);
            jdbc.update("INSERT INTO nmquestionnaire.questionnaire_question_link (questionnaire_id,group_id,next_group_id) VALUES (3,?,?)", group, group);
            question(group, group, name, i == 1 || i == 3 ? 3 : 2,
                    i == 2 || i >= 6 ? "@RVA+NRLB" : "@RVA", 1);
            answer(group * 10, group, "Answer " + i, i == 1 || i == 3, false,
                    i == 1 || i == 3 ? "comments" : null);
        }
        // Verify tag-driven text wins over an NRLB template and numeric metadata.
        answer(1021, 102, "Condition comments", true, false, "comments");
        answer(1031, 103, "Cadence", false, true, null);
        for (int i = 1; i <= 11; i++) {
            int group = 200 + i;
            String name = "UEVA%02d".formatted(i);
            jdbc.update("INSERT INTO nmquestionnaire.question_group VALUES (?,?,?)", group, name,
                    i == 1 ? "UEVAGroupContainer" : "UEVALRGroupContainer");
            jdbc.update("INSERT INTO nmquestionnaire.questionnaire_question_link (questionnaire_id,group_id,next_group_id) VALUES (6,?,?)", group, group);
            if (i == 1) {
                question(group, 201, name, 3, "NoCheckboxQuestionContainer", 1);
                answer(2010, 201, "", true, false, "TextAnswerContainer");
            } else {
                for (int side = 0; side < 2; side++) {
                    int question = 300 + i * 2 + side;
                    String item = name + (side == 0 ? "L" : "R");
                    int child = 400 + i * 2 + side;
                    jdbc.update("INSERT INTO nmquestionnaire.question_group VALUES (?,?,?)", child, item, "UEVALRGroupContainer");
                    question(child, question, item, 2, "MostlyOccasionallyQuestionContainer", side + 1);
                    // Some legacy canonical groups also contain the children directly.
                    jdbc.update("INSERT INTO nmquestionnaire.question_group_link (group_id,question_id,sortorder) VALUES (?,?,?)",
                            group, question, side + 1);
                    answer(question * 10, question, "Frequency", side == 0, false, side == 0 ? "L" : null);
                }
            }
        }
    }

    private void question(int group, int id, String name, int type, String template, int order) {
        jdbc.update("INSERT INTO nmquestionnaire.question VALUES (?,?,?,?,?)", id, name, type, template, "false");
        jdbc.update("INSERT INTO nmquestionnaire.question_group_link (group_id,question_id,sortorder) VALUES (?,?,?)", group, id, order);
        jdbc.update("INSERT INTO nmquestionnaire.question_text (question_id,language_id,text) VALUES (?,1,?)", id, name);
    }

    private void answer(int id, int question, String label, boolean text, boolean number, String tag) {
        jdbc.update("INSERT INTO nmquestionnaire.answer VALUES (?,?,NULL,1,?,?,NULL,?)", id, question, text, number, tag);
        jdbc.update("INSERT INTO nmquestionnaire.answer_text (answer_id,language_id,text) VALUES (?,1,?)", id, label);
    }

    @AfterEach
    void cleanCommittedConcurrencyFixture() {
        if (!org.springframework.transaction.support.TransactionSynchronizationManager.isActualTransactionActive()) {
            jdbc.execute("""
                    TRUNCATE public.visits, public.users, public.video_interp_groups,
                    public.video_interp_fields, public.video_interp_data, public.video_interp_comments,
                    nmquestionnaire.question_group, nmquestionnaire.question, nmquestionnaire.question_group_link,
                    nmquestionnaire.questionnaire_question_link, nmquestionnaire.question_text,
                    nmquestionnaire.answer, nmquestionnaire.answer_text, nmquestionnaire.session,
                    nmquestionnaire.patient_answer RESTART IDENTITY CASCADE
                    """);
        }
    }

    private static VideoAssessmentSaveRequest request(VideoAssessmentResponse response, UnaryOperator<Field> edit) {
        return new VideoAssessmentSaveRequest(response.revision(), response.groups().stream().map(g ->
                new VideoAssessmentSaveRequest.Group(g.id(), g.comments(), g.fields().stream().map(edit).map(f ->
                        new VideoAssessmentSaveRequest.Field(f.id(), f.choice())).toList())).toList());
    }

    private static Field changed(Field field, String choice) {
        return new Field(field.id(), field.paramName(), field.displayName(), field.order(), choice,
                field.controlType(), field.options(), field.side(), field.required());
    }

    private Field field(VideoAssessmentResponse response, int id) {
        return response.groups().stream().flatMap(g -> g.fields().stream()).filter(f -> f.id() == id).findFirst().orElseThrow();
    }

    private void status(HttpStatus status, org.junit.jupiter.api.function.Executable action) {
        assertEquals(status, assertThrows(ResponseStatusException.class, action).getStatusCode());
    }

    @Test
    void loadsEveryStandardGroupWithLegacyControlsAndNoFabricatedNegatives() {
        var standard = service.getAssessment(42, 1);
        assertEquals("STANDARD", standard.assessmentType());
        assertNull(standard.questionnaireId());
        assertEquals(14, standard.groups().size());
        assertEquals(List.of(0, 1), standard.groups().subList(0, 2).stream().map(VideoAssessmentResponse.Group::id).toList());
        assertTrue(standard.groups().getFirst().fields().isEmpty());
        assertEquals("CHECKBOX", field(standard, 20).controlType());
        assertEquals("SINGLE_SELECT", field(standard, 120).controlType());
        assertEquals("LATERALITY", field(standard, 130).controlType());
        assertTrue(standard.groups().stream().flatMap(g -> g.fields().stream()).allMatch(f -> f.choice() == null));
        assertEquals(14, service.getAssessment(42, 5).groups().size());
        assertNull(service.getAssessment(42, 5).visitTypeId());
        assertEquals(14, service.getAssessment(42, 4).groups().size());
        assertEquals(14, service.getAssessment(42, 6).groups().size());
    }

    @Test
    void savesLatestStandardHistoryWithoutAddingDuplicatesAndReloadsTwelveAndThirteen() {
        jdbc.update("INSERT INTO public.video_interp_data (visit_id,name,choice) VALUES (1,'field13','R'),(1,'field13','L')");
        jdbc.update("INSERT INTO public.video_interp_comments (visit_id,group_id,comments) VALUES (1,0,'old'),(1,0,'latest')");
        var initial = service.getAssessment(42, 1);
        assertEquals("L", field(initial, 130).choice());
        assertEquals("latest", initial.groups().getFirst().comments());
        var input = request(initial, f -> f.id() == 120 ? changed(f, "Y") : f.id() == 130 ? changed(f, "B") : f);
        var groups = new ArrayList<>(input.groups());
        groups.set(0, new VideoAssessmentSaveRequest.Group(0, "saved comments", List.of()));
        var saved = service.saveAssessment(42, 1, "editor", new VideoAssessmentSaveRequest(input.revision(), groups));
        assertEquals("Y", field(saved, 120).choice());
        assertEquals("B", field(saved, 130).choice());
        assertEquals("saved comments", saved.groups().getFirst().comments());
        assertEquals(2, jdbc.queryForObject("SELECT count(*) FROM public.video_interp_data WHERE name='field13'", Integer.class));
        assertEquals(2, jdbc.queryForObject("SELECT count(*) FROM public.video_interp_comments", Integer.class));
        assertNull(field(saved, 20).choice());
        assertEquals(saved, service.getAssessment(42, 1));
    }

    @Test
    void loadsAndPersistsRunningTextNrlbCheckboxAndNumberWithActiveHistory() {
        var initial = service.getAssessment(42, 2);
        assertEquals("RUNNING", initial.assessmentType());
        assertEquals(9, initial.groups().size());
        assertEquals(List.of("Comments", "Foot Wear Conditions", "Upper Extremity", "Trunk", "Pelvis",
                "Hips", "Knees", "Ankle", "Foot Progression"),
                initial.groups().stream().map(VideoAssessmentResponse.Group::name).toList());
        assertEquals(List.of("N", "R", "L", "B"), field(initial, 1020).options().stream().map(o -> o.code()).toList());
        assertEquals("TEXT", field(initial, 1021).controlType());
        assertEquals("NUMBER", field(initial, 1031).controlType());
        var saved = service.saveAssessment(42, 2, "editor", request(initial, f -> switch (f.id()) {
            case 1010 -> changed(f, "Current and past narrative");
            case 1020 -> changed(f, "L");
            case 1040 -> changed(f, "Y");
            case 1031 -> changed(f, "123.5");
            default -> f;
        }));
        assertEquals("Current and past narrative", field(saved, 1010).choice());
        assertEquals("L", field(saved, 1020).choice());
        assertEquals("123.5", field(saved, 1031).choice());
        assertEquals("Y", field(saved, 1040).choice());
        assertEquals(1, jdbc.queryForObject("SELECT language_id FROM nmquestionnaire.session", Integer.class));
        assertEquals(7, jdbc.queryForObject("SELECT auth_id FROM nmquestionnaire.session", Integer.class));
        assertEquals(3, jdbc.queryForObject("SELECT questionnaire_id FROM nmquestionnaire.session", Integer.class));
        var again = service.saveAssessment(42, 2, "editor", request(saved, f -> f.id() == 1020 ? changed(f, "R") : f));
        assertEquals("R", field(again, 1020).choice());
        assertEquals(1, jdbc.queryForObject("SELECT count(*) FROM nmquestionnaire.patient_answer WHERE answer_id=1020 AND active", Integer.class));
        assertEquals(2, jdbc.queryForObject("SELECT count(*) FROM nmquestionnaire.patient_answer WHERE answer_id=1020", Integer.class));
        assertEquals(again, service.getAssessment(42, 2));
    }

    @Test
    void upperExtremityIncludesBothSidesFrequencyAndSeparateQuestionCommentsWithoutCreatingMissingSide() {
        var initial = service.getAssessment(42, 3);
        assertEquals("UPPER_EXTREMITY", initial.assessmentType());
        assertEquals(6, initial.questionnaireId());
        assertEquals(11, initial.groups().size());
        assertEquals(List.of("Comments", "Hand Use", "Grasp", "Fingers", "Thumb", "Wrist", "Forearm",
                "Elbow", "Shoulder", "Scapula", "Trunk"),
                initial.groups().stream().map(VideoAssessmentResponse.Group::name).toList());
        assertEquals("L", field(initial, 3040).side());
        assertEquals("R", field(initial, 3050).side());
        assertEquals(List.of("None", "Mostly", "Occasionally"), field(initial, 3040).options().stream().map(o -> o.code()).toList());
        var saved = service.saveAssessment(42, 3, "editor", request(initial, f -> f.id() == 3040
                ? changed(f, "Mostly") : f.id() == -304 ? changed(f, "Left hand comments") : f));
        assertEquals("Mostly", field(saved, 3040).choice());
        assertEquals("Left hand comments", field(saved, -304).choice());
        assertNull(field(saved, 3050).choice());
        assertEquals(0, jdbc.queryForObject("SELECT count(*) FROM nmquestionnaire.patient_answer WHERE question_id=305", Integer.class));
        assertEquals(2, jdbc.queryForObject("SELECT count(*) FROM nmquestionnaire.patient_answer", Integer.class));
        assertEquals(saved, service.getAssessment(42, 3));
    }

    @Test
    void explicitUncheckedIsNotMissingAndLegacyDoesNotSeeItAsSelected() {
        var initial = service.getAssessment(42, 2);
        var saved = service.saveAssessment(42, 2, "editor", request(initial, f -> f.id() == 1040 ? changed(f, "N") : f));
        assertEquals("N", field(saved, 1040).choice());
        assertNull(field(saved, 1050).choice());
        assertEquals(0, jdbc.queryForObject("SELECT count(*) FROM nmquestionnaire.patient_answer WHERE active", Integer.class));
        var cleared = service.saveAssessment(42, 2, "editor", request(saved, f -> f.id() == 1040 ? changed(f, null) : f));
        assertNull(field(cleared, 1040).choice());
        assertEquals(cleared, service.getAssessment(42, 2));
    }

    @Test
    void unchangedSaveWritesNothingAndDoesNotPopulateMissingSides() {
        var initial = service.getAssessment(42, 3);
        assertEquals(initial, service.saveAssessment(42, 3, "editor", request(initial, UnaryOperator.identity())));
        assertEquals(0, jdbc.queryForObject("SELECT count(*) FROM nmquestionnaire.session", Integer.class));
    }

    @Test
    void rejectsUnknownDuplicateMissingFieldsAndMultipleRunningRadios() {
        var initial = service.getAssessment(42, 1);
        var input = request(initial, UnaryOperator.identity());
        var groups = new ArrayList<>(input.groups());
        groups.set(2, new VideoAssessmentSaveRequest.Group(2, null, List.of(new VideoAssessmentSaveRequest.Field(999, "Y"))));
        status(HttpStatus.BAD_REQUEST, () -> service.saveAssessment(42, 1, "editor", new VideoAssessmentSaveRequest(input.revision(), groups)));
        status(HttpStatus.BAD_REQUEST, () -> service.saveAssessment(42, 1, "editor", new VideoAssessmentSaveRequest(input.revision(), List.of())));
        var duplicateGroups = new ArrayList<>(input.groups());
        duplicateGroups.set(3, duplicateGroups.get(2));
        status(HttpStatus.BAD_REQUEST, () -> service.saveAssessment(42, 1, "editor",
                new VideoAssessmentSaveRequest(input.revision(), duplicateGroups)));
        var duplicateFields = new ArrayList<>(input.groups());
        duplicateFields.set(2, new VideoAssessmentSaveRequest.Group(2, null,
                List.of(new VideoAssessmentSaveRequest.Field(20, "Y"), new VideoAssessmentSaveRequest.Field(20, "N"))));
        status(HttpStatus.BAD_REQUEST, () -> service.saveAssessment(42, 1, "editor",
                new VideoAssessmentSaveRequest(input.revision(), duplicateFields)));
        status(HttpStatus.BAD_REQUEST, () -> service.saveAssessment(42, 1, "editor", request(initial, f ->
                f.id() == 120 || f.id() == 121 ? changed(f, "Y") : f)));
    }

    @Test
    void validatesValuesAndQuestionnaireCommentsBeforeWriting() {
        var running = service.getAssessment(42, 2);
        status(HttpStatus.BAD_REQUEST, () -> service.saveAssessment(42, 2, "editor", request(running,
                f -> f.id() == 1020 ? changed(f, "Mostly") : f)));
        status(HttpStatus.BAD_REQUEST, () -> service.saveAssessment(42, 2, "editor", request(running,
                f -> f.id() == 1031 ? changed(f, "NaN") : f)));
        var upper = service.getAssessment(42, 3);
        status(HttpStatus.BAD_REQUEST, () -> service.saveAssessment(42, 3, "editor", request(upper,
                f -> f.id() == 3040 ? changed(f, "L") : f)));
        assertEquals(0, jdbc.queryForObject("SELECT count(*) FROM nmquestionnaire.session", Integer.class));
    }

    @Test
    void rejectsStaleRevisionsAndWrongPatient() {
        var initial = service.getAssessment(42, 1);
        service.saveAssessment(42, 1, "editor", request(initial, f -> f.id() == 130 ? changed(f, "B") : f));
        status(HttpStatus.CONFLICT, () -> service.saveAssessment(42, 1, "editor", request(initial, UnaryOperator.identity())));
        status(HttpStatus.NOT_FOUND, () -> service.getAssessment(43, 1));
        status(HttpStatus.NOT_FOUND, () -> service.saveAssessment(43, 1, "editor", request(initial, UnaryOperator.identity())));
    }

    @Test
    @Transactional(propagation = org.springframework.transaction.annotation.Propagation.NOT_SUPPORTED)
    void visitRowLockSerializesConcurrentSavesAndSecondWriterGetsConflict() throws Exception {
        var initial = service.getAssessment(42, 1);
        var locked = new java.util.concurrent.CountDownLatch(1);
        var release = new java.util.concurrent.CountDownLatch(1);
        var workers = java.util.concurrent.Executors.newFixedThreadPool(2);
        try {
            var first = workers.submit(() -> new TransactionTemplate(transactions).execute(status -> {
                repository.findVisit(42, 1, true);
                locked.countDown();
                try {
                    if (!release.await(10, java.util.concurrent.TimeUnit.SECONDS)) throw new IllegalStateException("Lock release timed out.");
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new IllegalStateException(e);
                }
                return service.saveAssessment(42, 1, "editor", request(initial, f -> f.id() == 130 ? changed(f, "B") : f));
            }));
            assertTrue(locked.await(10, java.util.concurrent.TimeUnit.SECONDS));
            var second = workers.submit(() -> service.saveAssessment(42, 1, "editor",
                    request(initial, f -> f.id() == 130 ? changed(f, "L") : f)));
            assertThrows(java.util.concurrent.TimeoutException.class,
                    () -> second.get(300, java.util.concurrent.TimeUnit.MILLISECONDS));
            release.countDown();
            assertEquals("B", field(first.get(10, java.util.concurrent.TimeUnit.SECONDS), 130).choice());
            var failure = assertThrows(java.util.concurrent.ExecutionException.class,
                    () -> second.get(10, java.util.concurrent.TimeUnit.SECONDS));
            assertEquals(HttpStatus.CONFLICT, ((ResponseStatusException) failure.getCause()).getStatusCode());
            assertEquals("B", field(service.getAssessment(42, 1), 130).choice());
        } finally {
            release.countDown();
            workers.shutdownNow();
            assertTrue(workers.awaitTermination(10, java.util.concurrent.TimeUnit.SECONDS));
        }
    }

    @Test
    void requiresAnAuthenticatedActivePermittedActor() {
        var initial = service.getAssessment(42, 1);
        var input = request(initial, UnaryOperator.identity());
        status(HttpStatus.UNAUTHORIZED, () -> service.saveAssessment(42, 1, null, input));
        for (String actor : List.of("denied", "inactive", "expired", "missing", "internal")) {
            status(HttpStatus.FORBIDDEN, () -> service.saveAssessment(42, 1, actor, input));
        }
        assertEquals(initial, service.saveAssessment(42, 1, "admin", input));
    }

    @Test
    void movementDisorderKeepsAllSectionsEditable() {
        var initial = service.getAssessment(42, 6);
        var saved = service.saveAssessment(42, 6, "editor",
                request(initial, f -> f.id() == 130 ? changed(f, "B") : f));
        assertEquals(14, saved.groups().size());
        assertEquals("B", field(saved, 130).choice());
        assertEquals(saved, service.getAssessment(42, 6));
    }

    @Test
    void leavesOtherQuestionnaireAnswersAndOtherFieldsUntouched() {
        int session = repository.startSession(2, 6, 7, 201);
        repository.saveAnswer(2, 6, session, 101, 1010, "Other questionnaire", null, null, true);
        var initial = service.getAssessment(42, 2);
        assertNull(field(initial, 1010).choice());
        service.saveAssessment(42, 2, "editor", request(initial, f -> f.id() == 1010 ? changed(f, "Running only") : f));
        assertEquals("Other questionnaire", repository.findAnswerStates(2, 6).getFirst().text());
        assertTrue(repository.findAnswerStates(2, 6).getFirst().active());
    }

    @Test
    void transactionRollsBackEarlierWritesWhenLaterFieldFails() {
        var initial = service.getAssessment(42, 2);
        // An actual database failure on the second changed field must also undo
        // the first answer and its newly created session.
        jdbc.execute("ALTER TABLE nmquestionnaire.patient_answer ADD CONSTRAINT fixture_failure CHECK (answer_id <> 1020)");
        TransactionTemplate nested = new TransactionTemplate(transactions);
        nested.setPropagationBehavior(org.springframework.transaction.TransactionDefinition.PROPAGATION_NESTED);
        assertThrows(RuntimeException.class, () -> nested.execute(status -> service.saveAssessment(42, 2, "editor",
                request(initial, f -> f.id() == 1010 ? changed(f, "must roll back")
                        : f.id() == 1020 ? changed(f, "L") : f))));
        assertEquals(0, jdbc.queryForObject("SELECT count(*) FROM nmquestionnaire.patient_answer", Integer.class));
        assertEquals(0, jdbc.queryForObject("SELECT count(*) FROM nmquestionnaire.session", Integer.class));
    }

    @Test
    void httpRoutesLoadSaveAndReloadAllThreeTypesAgainstPostgres() throws Exception {
        var mvc = org.springframework.test.web.servlet.setup.MockMvcBuilders
                .standaloneSetup(new VideoAssessmentController(service)).build();
        var json = new ObjectMapper();
        var principal = new org.springframework.security.authentication.UsernamePasswordAuthenticationToken("editor", null);
        for (int visit = 1; visit <= 3; visit++) {
            String url = "/api/patients/42/visits/" + visit + "/video-assessment";
            var before = service.getAssessment(42, visit);
            int target = visit == 1 ? 130 : visit == 2 ? 1010 : 3040;
            String value = visit == 1 ? "B" : visit == 2 ? "Persisted HTTP narrative" : "Occasionally";
            var saved = mvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put(url)
                    .principal(principal).contentType(org.springframework.http.MediaType.APPLICATION_JSON)
                    .content(json.writeValueAsString(request(before, f -> f.id() == target ? changed(f, value) : f))))
                    .andExpect(org.springframework.test.web.servlet.result.MockMvcResultMatchers.status().isOk())
                    .andReturn().getResponse().getContentAsString();
            var reloaded = mvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get(url))
                    .andExpect(org.springframework.test.web.servlet.result.MockMvcResultMatchers.status().isOk())
                    .andReturn().getResponse().getContentAsString();
            assertEquals(json.readTree(saved), json.readTree(reloaded));
            assertEquals(value, field(service.getAssessment(42, visit), target).choice());
            assertNotEquals(before.revision(), service.getAssessment(42, visit).revision());
        }
    }
}
