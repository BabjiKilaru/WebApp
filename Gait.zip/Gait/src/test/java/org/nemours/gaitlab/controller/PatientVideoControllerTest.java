package org.nemours.gaitlab.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.nio.file.Files;
import java.nio.file.Path;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.nemours.gaitlab.service.VideoService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

class PatientVideoControllerTest {

    @TempDir
    Path temporaryDirectory;

    @Test
    void servesMovVideoAsMp4ForChromePlayback() throws Exception {
        Path video = temporaryDirectory.resolve("sample.mov");
        Files.write(video, new byte[] { 0, 1, 2, 3 });

        VideoService videoService = mock(VideoService.class);
        when(videoService.resolveVideo(14, "video-id")).thenReturn(video);

        PatientVideoController controller = new PatientVideoController(videoService);
        ResponseEntity<StreamingResponseBody> response = controller.streamVideo(14, "video-id", null);

        assertEquals(MediaType.parseMediaType("video/mp4"), response.getHeaders().getContentType());
    }
}
