package org.nemours.gaitlab.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.DriverManager;
import java.util.Objects;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.env.StandardEnvironment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;

@EnabledIfEnvironmentVariable(named = "GAITLAB_DATABASE_TESTS", matches = "true")
class VideoAssessmentMetadataDatabaseTest {
    @Test
    void validatesProductionSchemaQueriesUsingOnlyNonClinicalQuestionnaireMetadata() throws Exception {
        var yaml = new YamlPropertiesFactoryBean();
        yaml.setResources(new ClassPathResource("application.yml"));
        var environment = new StandardEnvironment();
        environment.getPropertySources().addLast(
                new PropertiesPropertySource("application", Objects.requireNonNull(yaml.getObject())));
        try (var connection = DriverManager.getConnection(
                environment.getRequiredProperty("spring.datasource.url"),
                environment.getRequiredProperty("spring.datasource.username"),
                environment.getRequiredProperty("spring.datasource.password"))) {
            connection.setReadOnly(true);
            var repository = new VideoAssessmentRepository(new JdbcTemplate(new SingleConnectionDataSource(connection, true)));
            assertEquals(14, repository.findGroups().size());
            for (int questionnaire : new int[] {3, 6}) {
                var questions = repository.findQuestions(questionnaire);
                assertEquals(questionnaire == 3 ? 9 : 11, questions.stream().map(q -> q.groupId()).distinct().count());
                for (var question : questions) {
                    var answers = repository.findAnswers(question.questionId());
                    assertFalse(answers.isEmpty());
                    assertNotNull(question.template());
                    assertEquals("false", question.required());
                    if (questionnaire == 6 && !question.itemName().equals("UEVA01")) {
                        assertTrue(question.itemName().matches("UEVA\\d{2}[LR]"));
                        assertTrue(question.template().contains("MostlyOccasionally"));
                    }
                }
            }
        }
    }
}
