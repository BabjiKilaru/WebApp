package org.nemours.gaitlab.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.nemours.gaitlab.config.SecurityConfig;
import org.nemours.gaitlab.service.AuthService;
import org.nemours.gaitlab.service.InterpretationService;
import org.nemours.gaitlab.service.InterpretationService.Option;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

@WebMvcTest(InterpretationController.class)
@Import(SecurityConfig.class)
class InterpretationControllerTest {
    @Autowired MockMvc mvc;
    @MockitoBean InterpretationService service;
    @MockitoBean AuthService auth;

    private MockHttpSession session() {
        MockHttpSession session = new MockHttpSession();
        session.setAttribute(AuthService.SESSION_USERNAME, "test");
        session.setAttribute(AuthService.SESSION_ACCESS, "User");
        return session;
    }

    @Test
    void requiresAuthenticationForMenu() throws Exception {
        mvc.perform(get("/api/patients/42/visits/5/interpretation")).andExpect(status().isUnauthorized());
    }

    @Test
    void returnsDisabledEntriesInTheResponseInsteadOfHidingThem() throws Exception {
        when(service.options(42, 5)).thenReturn(List.of(new Option("kinematics", "Kinematics", false)));
        mvc.perform(get("/api/patients/42/visits/5/interpretation").session(session()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].key").value("kinematics"))
                .andExpect(jsonPath("$[0].enabled").value(false));
    }

    @Test
    void propagatesVisitOwnershipFailures() throws Exception {
        when(service.options(43, 5)).thenThrow(new ResponseStatusException(HttpStatus.NOT_FOUND));
        mvc.perform(get("/api/patients/43/visits/5/interpretation").session(session()))
                .andExpect(status().isNotFound());
    }

    @Test
    void doesNotExposeOptionContentEndpoints() throws Exception {
        mvc.perform(get("/api/patients/42/visits/5/interpretation/signatures").session(session()))
                .andExpect(status().isNotFound());
    }
}
