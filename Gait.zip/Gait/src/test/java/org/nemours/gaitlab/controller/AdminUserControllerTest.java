package org.nemours.gaitlab.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;

import java.time.LocalDateTime;

import tools.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.nemours.gaitlab.repository.AdminUserRepository;
import org.nemours.gaitlab.repository.AdminUserRepository.AdminUserDetails;
import org.nemours.gaitlab.requests.UpdateAdminUserRequest;
import org.nemours.gaitlab.service.LegacyPasswordHasher;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

class AdminUserControllerTest {
    private AdminUserRepository repository;
    private MockMvc mvc;

    @BeforeEach
    void setUp() {
        repository = mock(AdminUserRepository.class);
        mvc = MockMvcBuilders.standaloneSetup(new AdminUserController(repository)).build();
    }

    @Test
    void checksAvailabilityAgainstStoredUserIds() throws Exception {
        when(repository.userIdExists("jsmith")).thenReturn(true);
        mvc.perform(get("/api/admin/users/availability").param("userid", "jsmith"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userid").value("jsmith"))
                .andExpect(jsonPath("$.available").value(false));
        mvc.perform(get("/api/admin/users/availability").param("userid", "sjane"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.available").value(true));
    }

    @Test
    void rejectsInvalidAvailabilityQueries() throws Exception {
        for (String userid : new String[] {"", "a", "ab", "abc", "abcd", "bad id", "x".repeat(51), "../user"}) {
            mvc.perform(get("/api/admin/users/availability").param("userid", userid))
                    .andExpect(status().isBadRequest());
        }
        verifyNoInteractions(repository);
    }

    @Test
    void createsWithARandomTemporaryPasswordAndStoresOnlyItsHash() throws Exception {
        when(repository.createUser(eq("sjane"), any(), any())).thenReturn(1);
        when(repository.findUser("sjane")).thenReturn(details("sjane"));
        var result = mvc.perform(post("/api/admin/users").contentType(MediaType.APPLICATION_JSON)
                .content(createBody("sjane")))
                .andExpect(status().isCreated())
                .andExpect(header().string("Cache-Control", "no-store"))
                .andExpect(jsonPath("$.user.userid").value("sjane"))
                .andExpect(jsonPath("$.user.fname").value("Jane"))
                .andExpect(jsonPath("$.user.password").doesNotExist())
                .andExpect(jsonPath("$.temporaryPassword").isNotEmpty())
                .andReturn();
        String temporaryPassword = new ObjectMapper().readTree(result.getResponse().getContentAsString())
                .get("temporaryPassword").asString();
        ArgumentCaptor<String> hashedPassword = ArgumentCaptor.forClass(String.class);
        verify(repository).createUser(eq("sjane"), eq(new UpdateAdminUserRequest(
                "Jane", "Smith", "C", null, null, null, null, null, null, null,
                null, null, null, null, null, null, "user", false, true, null, null)),
                hashedPassword.capture());
        assertEquals(LegacyPasswordHasher.hash(temporaryPassword), hashedPassword.getValue());
        assertEquals(12, temporaryPassword.length());
    }

    @Test
    void rejectsInvalidIdsAndInvalidNestedFields() throws Exception {
        for (String body : new String[] {
                createBody(""), createBody("a"), createBody("ab"), createBody("abc"), createBody("abcd"),
                createBody("bad id"), createBody("x".repeat(51)),
                createBody("sjane").replace("\"fname\":\"Jane\"", "\"fname\":\" \""),
                createBody("sjane").replace("\"purpose\":\"C\"", "\"purpose\":\"Invalid\""),
                createBody("sjane").replace("\"access\":\"user\"", "\"access\":\"Manager\""),
                "{\"userid\":\"sjane\",\"details\":null}"
        }) {
            mvc.perform(post("/api/admin/users").contentType(MediaType.APPLICATION_JSON).content(body))
                    .andExpect(status().isBadRequest());
        }
        verifyNoInteractions(repository);
    }

    @Test
    void resetsWithARandomTemporaryPasswordAndReturnsItWithoutCaching() throws Exception {
        when(repository.resetTemporaryPassword(eq("jsmith"), any())).thenReturn(1);
        var result = mvc.perform(post("/api/admin/users/jsmith/temporary-password"))
                .andExpect(status().isOk())
                .andExpect(header().string("Cache-Control", "no-store"))
                .andExpect(jsonPath("$.temporaryPassword").isNotEmpty())
                .andExpect(jsonPath("$.password").doesNotExist())
                .andReturn();
        String temporaryPassword = new ObjectMapper().readTree(result.getResponse().getContentAsString())
                .get("temporaryPassword").asString();
        verify(repository).resetTemporaryPassword("jsmith", LegacyPasswordHasher.hash(temporaryPassword));
        assertEquals(12, temporaryPassword.length());
    }

    @Test
    void doesNotReturnATemporaryPasswordForAMissingUser() throws Exception {
        mvc.perform(post("/api/admin/users/missing/temporary-password"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.temporaryPassword").doesNotExist());
    }

    @Test
    void reportsDuplicateIdsWithoutUpdatingAnExistingUser() throws Exception {
        mvc.perform(post("/api/admin/users").contentType(MediaType.APPLICATION_JSON)
                .content(createBody("sjane")))
                .andExpect(status().isConflict());
        when(repository.createUser(eq("sjane"), any(), any())).thenThrow(new DuplicateKeyException("duplicate"));
        mvc.perform(post("/api/admin/users").contentType(MediaType.APPLICATION_JSON)
                .content(createBody("sjane")))
                .andExpect(status().isConflict());
    }

    private static String createBody(String userid) {
        return """
                {"userid":"%s","details":{
                  "fname":"Jane","lname":"Smith","purpose":"C","access":"user",
                  "userAdmin":false,"active":true,"expiration":null}}
                """.formatted(userid);
    }

    @Test
    void returnsAllEditableDetails() throws Exception {
        when(repository.findUser("jsmith")).thenReturn(details());
        mvc.perform(get("/api/admin/users/jsmith"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userid").value("jsmith"))
                .andExpect(jsonPath("$.address2").value("Suite 2"))
                .andExpect(jsonPath("$.specialty").value("Orthopedics"))
                .andExpect(jsonPath("$.phone2").value("555-0102"))
                .andExpect(jsonPath("$.credentials").value("PT, DPT"))
                .andExpect(jsonPath("$.userAdmin").value(true))
                .andExpect(jsonPath("$.mustChangePassword").value(true))
                .andExpect(jsonPath("$.password").doesNotExist())
                .andExpect(jsonPath("$.temporaryPassword").doesNotExist());
    }

    @Test
    void savesMappedFieldsUsingOnlyThePathUserId() throws Exception {
        when(repository.updateUser(eq("jsmith"), any())).thenReturn(1);
        when(repository.findUser("jsmith")).thenReturn(details());
        mvc.perform(put("/api/admin/users/jsmith").contentType(MediaType.APPLICATION_JSON).content("""
                {
                  "userid": "cannot-rename", "fname": "Jane", "lname": "Smith",
                  "purpose": "C", "category": "P", "clinType": "MD", "specialty": "Orthopedics",
                  "facility": "Main", "phone1": "555-0101", "phone2": "555-0102", "fax": "555-0103",
                  "email": "jane@example.com", "address1": "123 Main St", "address2": "Suite 2",
                  "city": "Wilmington", "state": "DE", "zip": "19801", "credentials": "PT, DPT", "access": "admin",
                  "userAdmin": true, "active": false, "expiration": "2027-12-31T17:30:45"
                }
                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userid").value("jsmith"));
        verify(repository).updateUser("jsmith", new UpdateAdminUserRequest(
                "Jane", "Smith", "C", "MD", "Orthopedics", "Main",
                "555-0101", "555-0102", "555-0103", "jane@example.com", "123 Main St", "Suite 2",
                "Wilmington", "DE", "19801", "PT, DPT", "admin", true, false,
                LocalDateTime.parse("2027-12-31T17:30:45"), "P"));
    }

    @Test
    void returnsNotFoundForMissingUserOnReadAndUpdate() throws Exception {
        mvc.perform(get("/api/admin/users/missing")).andExpect(status().isNotFound());
        mvc.perform(put("/api/admin/users/missing").contentType(MediaType.APPLICATION_JSON)
                .content(""" 
                        {"fname":"Jane","lname":"Smith","purpose":"C","userAdmin":false,"active":true,"expiration":null}
                        """))
                .andExpect(status().isNotFound());
    }

    @Test
    void rejectsInvalidEmailDatesAndMissingFlagsBeforeWriting() throws Exception {
        for (String body : new String[] {
                "{\"email\":\"invalid\", \"userAdmin\":false, \"active\":true}",
                "{\"expiration\":\"not-a-date\", \"userAdmin\":false, \"active\":true}",
                "{\"active\":true}",
                "{\"fname\":\" \",\"lname\":\"Smith\",\"purpose\":\"C\",\"userAdmin\":false,\"active\":true}",
                "{\"fname\":\"Jane\",\"lname\":\"\",\"purpose\":\"C\",\"userAdmin\":false,\"active\":true}",
                "{\"fname\":\"Jane\",\"lname\":\"Smith\",\"purpose\":null,\"userAdmin\":false,\"active\":true}"
        }) {
            mvc.perform(put("/api/admin/users/jsmith").contentType(MediaType.APPLICATION_JSON).content(body))
                    .andExpect(status().isBadRequest());
        }
        verifyNoInteractions(repository);
    }

    @Test
    void acceptsClearedExpirationAndFalseFlags() throws Exception {
        when(repository.updateUser(eq("jsmith"), any())).thenReturn(1);
        when(repository.findUser("jsmith")).thenReturn(details());
        mvc.perform(put("/api/admin/users/jsmith").contentType(MediaType.APPLICATION_JSON)
                .content("""
                        {"fname":"Jane","lname":"Smith","purpose":"C","userAdmin":false,"active":false,"expiration":null}
                        """))
                .andExpect(status().isOk());
        verify(repository).updateUser("jsmith", new UpdateAdminUserRequest(
                "Jane", "Smith", "C", null, null, null, null, null, null,
                null, null, null, null, null, null, null, null, false, false, null, null));
    }

    @ParameterizedTest
    @CsvSource({
            "purpose, Clinical", "purpose, X", "category, Physician", "category, X",
            "clinType, Nurse", "access, Manager", "access, User", "access, Internal(global read-only)"
    })
    void rejectsUnsupportedDropdownValues(String field, String value) throws Exception {
        mvc.perform(put("/api/admin/users/jsmith").contentType(MediaType.APPLICATION_JSON)
                .content("{\"userAdmin\":false,\"active\":true,\"" + field + "\":\"" + value + "\"}"))
                .andExpect(status().isBadRequest());
        verifyNoInteractions(repository);
    }

    @ParameterizedTest
    @CsvSource({
            "BIO, user, P, C", "BME, internal, T, R", "DO, admin, O, T",
            "MD, NONE, P, C", "OT, user, T, R", "PT, internal, O, T", "Other, NONE, O, C"
    })
    void acceptsDropdownCodes(String clinType, String access, String category, String purpose) throws Exception {
        when(repository.updateUser(eq("jsmith"), any())).thenReturn(1);
        when(repository.findUser("jsmith")).thenReturn(details());
        mvc.perform(put("/api/admin/users/jsmith").contentType(MediaType.APPLICATION_JSON)
                .content("""
                        {"fname":"Jane","lname":"Smith","userAdmin":false,"active":true,"clinType":"%s","access":"%s","category":"%s","purpose":"%s"}
                        """.formatted(clinType, access, category, purpose)))
                .andExpect(status().isOk());
        verify(repository).updateUser("jsmith", new UpdateAdminUserRequest(
                "Jane", "Smith", purpose, clinType, null, null, null, null, null,
                null, null, null, null, null, null, null, access, false, true, null, category));
    }

    private static AdminUserDetails details() {
        return details("jsmith");
    }

    private static AdminUserDetails details(String userid) {
        return new AdminUserDetails(userid, "Jane", "Smith", "C", "MD", "Orthopedics", "Main",
                "555-0101", "555-0102", "555-0103", "jane@example.com", "123 Main St", "Suite 2",
                "Wilmington", "DE", "19801", "PT, DPT", "Admin", true, false,
                LocalDateTime.parse("2027-12-31T17:30:45"), "P", true);
    }
}
