package org.nemours.gaitlab.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.request;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.file.Files;
import java.nio.file.Path;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.nemours.gaitlab.config.SecurityConfig;
import org.nemours.gaitlab.service.AuthService;
import org.nemours.gaitlab.service.VideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

@WebMvcTest(PatientVideoController.class)
@Import(SecurityConfig.class)
class PatientVideoStreamingSecurityTest {

    @Autowired
    MockMvc mvc;

    @MockitoBean
    VideoService videoService;

    @MockitoBean
    AuthService authService;

    @TempDir
    Path temporaryDirectory;

    @Test
    void streamsVideoForSignedInSession() throws Exception {
        Path video = temporaryDirectory.resolve("sample.mov");
        Files.write(video, new byte[] { 0, 1, 2, 3, 4, 5, 6, 7 });
        when(videoService.resolveVideo(14, "video-id")).thenReturn(video);

        MockHttpSession session = new MockHttpSession();
        session.setAttribute(AuthService.SESSION_USERNAME, "test");
        session.setAttribute(AuthService.SESSION_ACCESS, "User");

        MvcResult started = mvc.perform(get("/api/patients/14/videos/video-id/content")
                        .session(session)
                        .header("Range", "bytes=0-3"))
                .andExpect(request().asyncStarted())
                .andReturn();

        mvc.perform(asyncDispatch(started))
                .andExpect(status().isPartialContent())
                .andExpect(header().string("Content-Type", "video/mp4"))
                .andExpect(header().string("Content-Range", "bytes 0-3/8"))
                .andExpect(content().bytes(new byte[] { 0, 1, 2, 3 }));
    }

    @Test
    void rejectsVideoStreamWithoutSignedInSession() throws Exception {
        mvc.perform(get("/api/patients/14/videos/video-id/content"))
                .andExpect(status().isUnauthorized());
    }
}
