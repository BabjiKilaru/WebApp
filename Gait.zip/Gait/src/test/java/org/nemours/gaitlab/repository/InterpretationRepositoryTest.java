package org.nemours.gaitlab.repository;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.mockito.ArgumentCaptor;
import org.springframework.jdbc.core.JdbcTemplate;

class InterpretationRepositoryTest {
    private final JdbcTemplate jdbc = mock(JdbcTemplate.class);
    private final InterpretationRepository repository = new InterpretationRepository(jdbc);

    @ParameterizedTest
    @EnumSource(InterpretationRepository.Measurements.class)
    void availabilityChecksExistenceWithinSelectedConditionsNotCompletionOrTestAssignments(
            InterpretationRepository.Measurements measurements) {
        when(jdbc.queryForObject(anyString(), eq(Boolean.class), eq(5))).thenReturn(true);
        assertTrue(repository.hasMeasurements(5, measurements));
        ArgumentCaptor<String> sql = ArgumentCaptor.forClass(String.class);
        verify(jdbc).queryForObject(sql.capture(), eq(Boolean.class), eq(5));
        String query = sql.getValue().toLowerCase();
        assertTrue(query.startsWith("select exists"));
        assertTrue(query.contains("c.id = d.visit_condition_id"));
        assertTrue(query.contains("c.visit_id = ?"));
        assertFalse(query.contains("dataval is not null"));
        assertFalse(query.contains("d.interp"));
        assertFalse(query.contains("signed"));
        assertFalse(query.contains("final"));
        assertFalse(query.contains("test_group"));
        assertFalse(query.contains("active"));
    }

}
