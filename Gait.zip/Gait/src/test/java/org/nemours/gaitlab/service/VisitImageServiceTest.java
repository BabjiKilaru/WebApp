package org.nemours.gaitlab.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.nemours.gaitlab.model.Patient;
import org.nemours.gaitlab.repository.PatientRepository;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.repository.VisitRepository.VideoVisitDate;
import org.springframework.web.server.ResponseStatusException;

class VisitImageServiceTest {

    @TempDir
    Path temporaryDirectory;

    @Test
    void listsOnlyRequestedImageTypeForSelectedVisitAndResolvesImageContent() throws Exception {
        PatientRepository patientRepository = mock(PatientRepository.class);
        VisitRepository visitRepository = mock(VisitRepository.class);
        Patient patient = new Patient();
        patient.setMrn("10000000");
        when(patientRepository.findById(14)).thenReturn(Optional.of(patient));
        when(visitRepository.findVideoVisitDateByIdAndPatientId(21, 14))
                .thenReturn(Optional.of(visitDate(21, "2003-01-12")));

        Path visitDirectory = temporaryDirectory.resolve("10000000").resolve("011203");
        Path png = visitDirectory.resolve("gait.png");
        Path photo = visitDirectory.resolve("patient.jpg");
        Path videoFolderImage = visitDirectory.resolve("video").resolve("thumbnail.png");
        Files.createDirectories(videoFolderImage.getParent());
        Files.write(png, new byte[] { 1, 2 });
        Files.write(photo, new byte[] { 3, 4 });
        Files.write(videoFolderImage, new byte[] { 5, 6 });

        VisitImageService service = new VisitImageService(
                patientRepository,
                visitRepository,
                temporaryDirectory.toString());

        List<VisitImageService.ImageMetadata> pngs =
                service.findVisitImages(14, 21, VisitImageService.ImageType.PNG);
        List<VisitImageService.ImageMetadata> photos =
                service.findVisitImages(14, 21, VisitImageService.ImageType.PHOTO);

        assertEquals(List.of("gait.png"), pngs.stream().map(VisitImageService.ImageMetadata::fileName).toList());
        assertEquals(List.of("patient.jpg"), photos.stream().map(VisitImageService.ImageMetadata::fileName).toList());
        assertTrue(pngs.get(0).contentUrl().contains("/visits/21/images/"));
        assertEquals(png.toRealPath(), service.resolveImage(14, 21, pngs.get(0).id()));
    }

    @Test
    void interpretationFilesMatchTheirLegacyNamesAndDirectoriesOnly() throws Exception {
        PatientRepository patients = mock(PatientRepository.class);
        VisitRepository visits = mock(VisitRepository.class);
        Patient patient = new Patient();
        patient.setMrn("10000000");
        when(patients.findById(14)).thenReturn(Optional.of(patient));
        when(visits.findVideoVisitDateByIdAndPatientId(21, 14))
                .thenReturn(Optional.of(visitDate(21, "2003-01-12")));
        Path visitDirectory = temporaryDirectory.resolve("10000000").resolve("011203");
        for (String relative : List.of(
                "condition1\\10000000_011203_GroundReactionForces.png",
                "condition1\\10000000_011203_EmgWaveforms.png",
                "condition1\\10000000_011203_StepWatch.png",
                "comparison\\StepWatchReport.png",
                "condition2\\GroundReactionForces.png",
                "condition2\\EmgWaveforms.png",
                "condition2\\StepWatch.png",
                "condition1\\UnrelatedEmgWaveforms.png",
                "condition1\\StepWatchEmpty.png",
                "video\\StepWatch.png")) {
            Path file = visitDirectory.resolve(relative.replace('\\', java.io.File.separatorChar));
            Files.createDirectories(file.getParent());
            Files.write(file, relative.contains("Empty") ? new byte[0] : new byte[] { 1 });
        }
        Path anotherVisit = temporaryDirectory.resolve("10000000").resolve("022003").resolve("condition1");
        Files.createDirectories(anotherVisit);
        Files.write(anotherVisit.resolve("StepWatch.png"), new byte[] { 1 });

        VisitImageService service = new VisitImageService(patients, visits, temporaryDirectory.toString());
        assertEquals(List.of("10000000_011203_GroundReactionForces.png"),
                service.findInterpretationImages(14, 21, "GroundReactionForces")
                        .stream().map(VisitImageService.ImageMetadata::fileName).toList());
        assertEquals(List.of("10000000_011203_EmgWaveforms.png"),
                service.findInterpretationImages(14, 21, "EmgWaveforms")
                        .stream().map(VisitImageService.ImageMetadata::fileName).toList());
        assertEquals(List.of("10000000_011203_StepWatch.png", "StepWatchReport.png"),
                service.findInterpretationImages(14, 21, "StepWatch")
                        .stream().map(VisitImageService.ImageMetadata::fileName).toList());
    }

    @Test
    void doesNotResolveAnImageOutsideSelectedVisit() throws Exception {
        PatientRepository patientRepository = mock(PatientRepository.class);
        VisitRepository visitRepository = mock(VisitRepository.class);
        Patient patient = new Patient();
        patient.setMrn("10000000");
        when(patientRepository.findById(14)).thenReturn(Optional.of(patient));
        when(visitRepository.findVideoVisitDateByIdAndPatientId(21, 14))
                .thenReturn(Optional.of(visitDate(21, "2003-01-12")));

        Path otherVisitImage = temporaryDirectory.resolve("10000000")
                .resolve("022003")
                .resolve("other.png");
        Files.createDirectories(otherVisitImage.getParent());
        Files.write(otherVisitImage, new byte[] { 1 });
        String imageId = java.util.Base64.getUrlEncoder().withoutPadding()
                .encodeToString(Path.of("022003", "other.png").toString()
                        .getBytes(java.nio.charset.StandardCharsets.UTF_8));

        VisitImageService service = new VisitImageService(
                patientRepository,
                visitRepository,
                temporaryDirectory.toString());

        assertThrows(ResponseStatusException.class, () -> service.resolveImage(14, 21, imageId));
    }

    private static VideoVisitDate visitDate(int id, String date) {
        return new VideoVisitDate() {
            @Override
            public Integer getId() {
                return id;
            }

            @Override
            public String getVisitDate() {
                return date;
            }
        };
    }
}
