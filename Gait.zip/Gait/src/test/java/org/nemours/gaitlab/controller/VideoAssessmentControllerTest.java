package org.nemours.gaitlab.controller;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.List;
import jakarta.servlet.http.Cookie;
import org.junit.jupiter.api.Test;
import org.nemours.gaitlab.config.SecurityConfig;
import org.nemours.gaitlab.requests.VideoAssessmentSaveRequest;
import org.nemours.gaitlab.response.VideoAssessmentResponse;
import org.nemours.gaitlab.service.AuthService;
import org.nemours.gaitlab.service.VideoAssessmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.web.server.ResponseStatusException;

@WebMvcTest(VideoAssessmentController.class)
@Import(SecurityConfig.class)
class VideoAssessmentControllerTest {
    private static final String URL = "/api/patients/42/visits/5/video-assessment";
    private static final String BODY = """
            {"revision":"version","groups":[{"id":0,"comments":null,"fields":[{"id":1,"choice":null}]}]}
            """;
    @Autowired MockMvc mvc;
    @MockitoBean VideoAssessmentService service;
    @MockitoBean AuthService auth;

    private MockHttpSession session() {
        var session = new MockHttpSession();
        session.setAttribute(AuthService.SESSION_USERNAME, "editor");
        session.setAttribute(AuthService.SESSION_ACCESS, "User");
        return session;
    }

    private MockHttpServletRequestBuilder save(String body) {
        return put(URL).session(session()).cookie(new Cookie("XSRF-TOKEN", "csrf-token"))
                .header("X-XSRF-TOKEN", "csrf-token").contentType(MediaType.APPLICATION_JSON).content(body);
    }

    private VideoAssessmentResponse response() {
        return new VideoAssessmentResponse(42, 5, 2, "UPPER_EXTREMITY", 6, "updated", List.of());
    }

    @Test
    void requiresAuthentication() throws Exception {
        mvc.perform(get(URL)).andExpect(status().isUnauthorized());
        verifyNoInteractions(service);
    }

    @Test
    void loadsFullResponseAndUsesCamelCaseVisitType() throws Exception {
        when(service.getAssessment(42, 5)).thenReturn(response());
        mvc.perform(get(URL).session(session())).andExpect(status().isOk())
                .andExpect(jsonPath("$.visitTypeId").value(2))
                .andExpect(jsonPath("$.questionnaireId").value(6))
                .andExpect(jsonPath("$.revision").value("updated"));
    }

    @Test
    void saveRequiresCsrf() throws Exception {
        mvc.perform(put(URL).session(session()).contentType(MediaType.APPLICATION_JSON).content(BODY))
                .andExpect(status().isForbidden());
        verifyNoInteractions(service);
    }

    @Test
    void savesWithServerAuthenticatedActorAndReturnsReloadedResponse() throws Exception {
        when(service.saveAssessment(eq(42), eq(5), eq("editor"), any())).thenReturn(response());
        mvc.perform(save(BODY)).andExpect(status().isOk()).andExpect(jsonPath("$.revision").value("updated"));
        verify(service).saveAssessment(eq(42), eq(5), eq("editor"),
                eq(new VideoAssessmentSaveRequest("version", List.of(new VideoAssessmentSaveRequest.Group(0, null,
                        List.of(new VideoAssessmentSaveRequest.Field(1, null)))))));
    }

    @Test
    void rejectsUnknownPropertiesAndIncompletePayloads() throws Exception {
        for (String invalid : List.of(
                BODY.replace("\"revision\":", "\"actorId\":123,\"revision\":"),
                BODY.replace("\"comments\":null,", ""),
                BODY.replace("\"choice\":null", "\"choice\":null,\"table\":\"visits\""),
                BODY.replace("\"choice\":null", "\"other\":null"),
                BODY.replace("\"choice\":null", "\"choice\":123"),
                BODY.replace("\"id\":1,", "\"id\":\"1\","),
                "{\"revision\":\"version\",\"groups\":null}",
                "{\"revision\":\"\",\"groups\":[]}")) {
            mvc.perform(save(invalid)).andExpect(status().isBadRequest());
        }
        verifyNoInteractions(service);
    }

    @Test
    void preservesOwnershipPermissionAndConflictStatuses() throws Exception {
        for (HttpStatus status : List.of(HttpStatus.NOT_FOUND, HttpStatus.FORBIDDEN, HttpStatus.CONFLICT)) {
            when(service.saveAssessment(eq(42), eq(5), eq("editor"), any()))
                    .thenThrow(new ResponseStatusException(status));
            mvc.perform(save(BODY)).andExpect(status().is(status.value()));
        }
    }
}
