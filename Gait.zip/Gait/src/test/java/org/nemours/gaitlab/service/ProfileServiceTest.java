package org.nemours.gaitlab.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.nemours.gaitlab.repository.ProfileRepository;
import org.nemours.gaitlab.requests.ChangePasswordRequest;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

class ProfileServiceTest {
    private ProfileRepository repository;
    private ProfileService service;

    @BeforeEach
    void setUp() {
        repository = mock(ProfileRepository.class);
        service = new ProfileService(repository);
    }

    @ParameterizedTest
    @CsvSource({
            "Abcd1!, New password must be between 8 and 128 characters.",
            "Abcdefg!, New password must contain at least 1 number.",
            "abcdef1!, New password must contain at least 1 uppercase letter.",
            "Abcdef12, New password must contain at least 1 special character: !@#$%^&*.",
            "Abcdef1?, New password must contain at least 1 special character: !@#$%^&*."
    })
    void rejectsUnmetRequirements(String password, String reason) {
        assertRejected(new ChangePasswordRequest("Oldpass1!", password, password), reason);
    }

    @Test
    void rejectsMismatchedConfirmation() {
        assertRejected(new ChangePasswordRequest("Oldpass1!", "Abcdef1!", "Abcdef2!"),
                "New password and confirmation do not match.");
    }

    @Test
    void preservesExistingRestrictions() {
        assertRejected(null, "Current password, new password, and confirmation are required.");
        assertRejected(new ChangePasswordRequest("Oldpass1!", "", ""),
                "Current password, new password, and confirmation are required.");
        assertRejected(new ChangePasswordRequest("Abcdef1!", "Abcdef1!", "Abcdef1!"),
                "New password must be different from the current password.");
        String tooLong = "Abcdef1!" + "a".repeat(121);
        assertRejected(new ChangePasswordRequest("Oldpass1!", tooLong, tooLong),
                "New password must be between 8 and 128 characters.");
    }

    @Test
    void replacesATemporaryPasswordWithTheValidatedNewHash() {
        when(repository.passwordMatches("test", LegacyPasswordHasher.hash("Temporary1!"))).thenReturn(true);
        when(repository.updatePassword("test", LegacyPasswordHasher.hash("Replacement1!"))).thenReturn(1);

        service.changePassword("test",
                new ChangePasswordRequest("Temporary1!", "Replacement1!", "Replacement1!"));

        verify(repository).updatePassword("test", LegacyPasswordHasher.hash("Replacement1!"));
    }

    @ParameterizedTest
    @ValueSource(strings = { "!", "@", "#", "$", "%", "^", "&", "*" })
    void acceptsEveryListedSpecialCharacter(String special) {
        String password = "Abcdef1" + special;
        when(repository.passwordMatches("test", LegacyPasswordHasher.hash("Oldpass1!"))).thenReturn(true);
        when(repository.updatePassword("test", LegacyPasswordHasher.hash(password))).thenReturn(1);

        service.changePassword("test", new ChangePasswordRequest("Oldpass1!", password, password));

        verify(repository).updatePassword("test", LegacyPasswordHasher.hash(password));
    }

    @Test
    void acceptsMaximumLength() {
        String password = "Abcdef1!" + "a".repeat(120);
        when(repository.passwordMatches("test", LegacyPasswordHasher.hash("Oldpass1!"))).thenReturn(true);
        when(repository.updatePassword("test", LegacyPasswordHasher.hash(password))).thenReturn(1);

        service.changePassword("test", new ChangePasswordRequest("Oldpass1!", password, password));

        verify(repository).updatePassword("test", LegacyPasswordHasher.hash(password));
    }

    private void assertRejected(ChangePasswordRequest request, String reason) {
        ResponseStatusException error = assertThrows(ResponseStatusException.class,
                () -> service.changePassword("test", request));
        assertEquals(HttpStatus.BAD_REQUEST, error.getStatusCode());
        assertEquals(reason, error.getReason());
        verifyNoInteractions(repository);
    }
}
