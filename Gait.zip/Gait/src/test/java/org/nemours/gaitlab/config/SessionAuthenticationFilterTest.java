package org.nemours.gaitlab.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.nemours.gaitlab.service.AuthService;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.context.SecurityContextHolder;

class SessionAuthenticationFilterTest {
    @AfterEach
    void clearContext() {
        SecurityContextHolder.clearContext();
    }

    @ParameterizedTest
    @CsvSource({
            "GET, /api/patients", "GET, /api/admin/users", "GET, /api/forms",
            "PUT, /api/profile", "POST, /api/visits", "GET, /api/profile/password",
            "GET, /api/profile/other"
    })
    void blocksProtectedEndpointsEvenForAdministrators(String method, String path) throws Exception {
        AuthService auth = mock(AuthService.class);
        when(auth.mustChangePassword("test")).thenReturn(true);
        MockHttpServletRequest request = request(method, path);
        MockHttpServletResponse response = new MockHttpServletResponse();
        MockFilterChain chain = new MockFilterChain();

        new SessionAuthenticationFilter(auth).doFilter(request, response, chain);

        assertEquals(403, response.getStatus());
        assertEquals("application/json", response.getContentType());
        assertEquals("{\"code\":\"PASSWORD_CHANGE_REQUIRED\",\"message\":\"You must change your temporary password before continuing.\"}",
                response.getContentAsString());
        assertNull(chain.getRequest());
    }

    @ParameterizedTest
    @CsvSource({
            "GET, /api/profile", "PUT, /api/profile/password", "GET, /api/auth/me",
            "POST, /api/auth/logout", "POST, /api/auth/login", "GET, /api/health"
    })
    void allowsOnlyThePasswordChangeAndSessionFlow(String method, String path) throws Exception {
        AuthService auth = mock(AuthService.class);
        when(auth.mustChangePassword("test")).thenReturn(true);
        MockFilterChain chain = new MockFilterChain();

        new SessionAuthenticationFilter(auth).doFilter(
                request(method, path), new MockHttpServletResponse(), chain);

        assertNotNull(chain.getRequest());
    }

    @ParameterizedTest
    @CsvSource({"GET, /api/patients", "GET, /api/admin/users", "PUT, /api/profile"})
    void allowsNormalAccessAfterThePasswordIsChanged(String method, String path) throws Exception {
        MockFilterChain chain = new MockFilterChain();
        new SessionAuthenticationFilter(mock(AuthService.class)).doFilter(
                request(method, path), new MockHttpServletResponse(), chain);
        assertNotNull(chain.getRequest());
    }

    private static MockHttpServletRequest request(String method, String path) {
        MockHttpServletRequest request = new MockHttpServletRequest(method, path);
        request.setServletPath(path);
        request.getSession().setAttribute(AuthService.SESSION_USERNAME, "test");
        request.getSession().setAttribute(AuthService.SESSION_ACCESS, "Admin");
        return request;
    }
}
