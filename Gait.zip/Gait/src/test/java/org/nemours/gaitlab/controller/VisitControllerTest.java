package org.nemours.gaitlab.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.nemours.gaitlab.model.Visit;
import org.nemours.gaitlab.repository.VisitHomeRepository;
import org.nemours.gaitlab.repository.VisitRepository;

class VisitControllerTest {
    private final VisitRepository visitRepository = mock(VisitRepository.class);
    private final VisitController controller = new VisitController(
            visitRepository, mock(VisitHomeRepository.class));

    @Test
    void loadsVisitsWithLocalDatesReturnedByHibernate() {
        LocalDate date = LocalDate.of(2026, 10, 27);
        when(visitRepository.findVisitDisplayByPatientId(42)).thenReturn(
                Collections.singletonList(new Object[] { 55, 42, date, "Yes", "Gait", "Step Watch" }));

        List<Visit> visits = controller.getVisitsByPatient(42);

        assertEquals(1, visits.size());
        Visit visit = visits.getFirst();
        assertEquals(55, visit.getId());
        assertEquals(42, visit.getPatientId());
        assertEquals(date, visit.getDate());
        assertEquals("Yes", visit.getAttendance());
        assertEquals("Gait", visit.getVisitType());
        assertEquals("Step Watch", visit.getVisitSubType());
        verify(visitRepository).findVisitDisplayByPatientId(42);
    }

    @Test
    void loadsVisitsWithJdbcDates() {
        LocalDate date = LocalDate.of(2026, 10, 27);
        when(visitRepository.findVisitDisplayByPatientId(42)).thenReturn(
                Collections.singletonList(new Object[] { 55, 42, Date.valueOf(date), "", "Gait", null }));

        Visit visit = controller.getVisitsByPatient(42).getFirst();

        assertEquals(date, visit.getDate());
        assertEquals("", visit.getAttendance());
        assertNull(visit.getVisitSubType());
    }

    @Test
    void preservesNullDatesAndDisplayValues() {
        when(visitRepository.findVisitDisplayByPatientId(42)).thenReturn(
                Collections.singletonList(new Object[] { 55, 42, null, null, null, null }));

        Visit visit = controller.getVisitsByPatient(42).getFirst();

        assertNull(visit.getDate());
        assertNull(visit.getAttendance());
        assertNull(visit.getVisitType());
        assertNull(visit.getVisitSubType());
    }

    @Test
    void returnsAnEmptyListWhenThePatientHasNoVisits() {
        when(visitRepository.findVisitDisplayByPatientId(42)).thenReturn(List.of());

        assertEquals(List.of(), controller.getVisitsByPatient(42));
    }
}
