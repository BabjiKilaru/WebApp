package org.nemours.gaitlab.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.nemours.gaitlab.service.AuthService;
import org.nemours.gaitlab.service.LegacyPasswordHasher;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockHttpServletRequest;

class AuthRepositoryTest {
    private static final String LOGIN_SQL =
            "SELECT userid, access, fname, lname, "
                    + "(must_change_password OR password = ?) AS must_change_password FROM public.users "
                    + "WHERE userid = ? AND password = ? "
                    + "AND active = TRUE "
                    + "AND (expiration IS NULL OR expiration > CURRENT_TIMESTAMP)";
    private static final String MUST_CHANGE_SQL =
            "SELECT COUNT(*) FROM public.users WHERE userid = ? "
                    + "AND (must_change_password = TRUE OR password = ?)";

    private JdbcTemplate jdbc;
    private AuthRepository repository;

    @BeforeEach
    void setUp() {
        jdbc = mock(JdbcTemplate.class);
        repository = new AuthRepository(jdbc);
    }

    @Test
    void requiresBothActiveAndANullOrStrictlyFutureExpiration() {
        when(jdbc.queryForList(LOGIN_SQL, LegacyPasswordHasher.LEGACY_DEFAULT_PASSWORD_HASH,
                "jsmith", "hash")).thenReturn(List.of());
        assertNull(repository.findActiveUser("jsmith", "hash"));
        verify(jdbc).queryForList(LOGIN_SQL, LegacyPasswordHasher.LEGACY_DEFAULT_PASSWORD_HASH,
                "jsmith", "hash");
    }

    @Test
    void createsNoSessionWhenTheDatabaseRejectsLogin() {
        String hash = LegacyPasswordHasher.hash("password");
        when(jdbc.queryForList(LOGIN_SQL, LegacyPasswordHasher.LEGACY_DEFAULT_PASSWORD_HASH,
                "jsmith", hash)).thenReturn(List.of());
        MockHttpServletRequest request = new MockHttpServletRequest();

        assertNull(new AuthService(repository).login("jsmith", "password", request));
        assertNull(request.getSession(false));
        verify(jdbc).queryForList(LOGIN_SQL, LegacyPasswordHasher.LEGACY_DEFAULT_PASSWORD_HASH,
                "jsmith", hash);
    }

    @Test
    void allowsLoginWhenTheDatabaseReturnsAnEligibleUser() {
        String hash = LegacyPasswordHasher.hash("password");
        when(jdbc.queryForList(LOGIN_SQL, LegacyPasswordHasher.LEGACY_DEFAULT_PASSWORD_HASH,
                "jsmith", hash))
                .thenReturn(List.of(Map.of("userid", "jsmith", "access", "User", "fname", "Jane",
                        "lname", "Smith", "must_change_password", false)));
        MockHttpServletRequest request = new MockHttpServletRequest();

        assertEquals(new AuthService.LoginResult("jsmith", "User", "Jane", "Smith", false),
                new AuthService(repository).login("jsmith", "password", request));
        assertEquals("jsmith", request.getSession(false).getAttribute(AuthService.SESSION_USERNAME));
    }

    @Test
    void requiresPasswordChangeAtLoginAndWhenRestoringAnExistingSession() {
        String hash = LegacyPasswordHasher.hash("Temporary1!");
        when(jdbc.queryForList(LOGIN_SQL, LegacyPasswordHasher.LEGACY_DEFAULT_PASSWORD_HASH,
                "jsmith", hash))
                .thenReturn(List.of(Map.of("userid", "jsmith", "access", "User", "fname", "Jane",
                        "lname", "Smith", "must_change_password", true)));
        when(jdbc.queryForObject(MUST_CHANGE_SQL, Integer.class, "jsmith",
                LegacyPasswordHasher.LEGACY_DEFAULT_PASSWORD_HASH)).thenReturn(1, 0);
        MockHttpServletRequest request = new MockHttpServletRequest();
        AuthService service = new AuthService(repository);

        assertEquals(true, service.login("jsmith", "Temporary1!", request).mustChangePassword());
        assertEquals(true, service.currentUser(request).mustChangePassword());
        assertEquals(false, service.currentUser(request).mustChangePassword());
    }
}
