package org.nemours.gaitlab.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.DriverManager;
import java.util.Objects;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import org.nemours.gaitlab.service.InterpretationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.env.StandardEnvironment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest(properties = "logging.level.org.hibernate.SQL=off")
@EnabledIfEnvironmentVariable(named = "GAITLAB_DATABASE_TESTS", matches = "true")
class InterpretationRepositoryDatabaseTest {
    @Autowired InterpretationService service;
    @Autowired VisitRepository visits;
    @Autowired JdbcTemplate jdbc;

    @DynamicPropertySource
    static void databaseProperties(DynamicPropertyRegistry registry) {
        YamlPropertiesFactoryBean yaml = new YamlPropertiesFactoryBean();
        yaml.setResources(new ClassPathResource("application.yml"));
        var properties = Objects.requireNonNull(yaml.getObject());
        StandardEnvironment environment = new StandardEnvironment();
        environment.getPropertySources().addLast(new PropertiesPropertySource("application", properties));
        for (String key : properties.stringPropertyNames()) {
            registry.add(key, () -> environment.getProperty(key));
        }
    }

    @Test
    @Transactional(readOnly = true)
    void loadsMovementDisorderOptionsWithoutMappingUnrelatedLegacyDateFields() {
        var candidates = jdbc.query("""
                SELECT id, pt_id FROM public.visits
                WHERE visit_type_id = 9 AND TRIM(surgery_date) = ''
                ORDER BY id DESC LIMIT 1
                """, (rs, row) -> new int[] { rs.getInt("id"), rs.getInt("pt_id") });
        org.junit.jupiter.api.Assumptions.assumeFalse(candidates.isEmpty(),
                "Requires a Movement Disorder visit with a blank legacy surgery date.");
        var visit = candidates.getFirst();
        var options = service.options(visit[1], visit[0]);
        assertEquals(13, options.size());
        assertEquals("Movement Disorder Physical Examination", options.get(1).label());
        assertTrue(options.get(1).enabled());
        assertTrue(visits.findInterpretationVisitByIdAndPatientId(visit[0], Integer.MIN_VALUE).isEmpty());
    }

    @Test
    @Transactional(readOnly = true)
    void findsLegacyVisitsWithNoVisitTypeId() {
        var candidates = jdbc.query("""
                SELECT id, pt_id FROM public.visits
                WHERE visit_type_id IS NULL
                ORDER BY id LIMIT 1
                """, (rs, row) -> new int[] { rs.getInt("id"), rs.getInt("pt_id") });
        org.junit.jupiter.api.Assumptions.assumeFalse(candidates.isEmpty(),
                "Requires a legacy visit with no visit type ID.");
        var candidate = candidates.getFirst();

        var visit = visits.findInterpretationVisitByIdAndPatientId(candidate[0], candidate[1]);

        assertTrue(visit.isPresent());
        assertNull(visit.orElseThrow().getVisitTypeId());
    }

    @Test
    void validatesMenuAvailabilityQueriesAgainstTheConfiguredPostgresSchemaWithoutWritingData() throws Exception {
        YamlPropertiesFactoryBean yaml = new YamlPropertiesFactoryBean();
        yaml.setResources(new ClassPathResource("application.yml"));
        StandardEnvironment environment = new StandardEnvironment();
        environment.getPropertySources().addLast(
                new PropertiesPropertySource("application", Objects.requireNonNull(yaml.getObject())));
        try (var connection = DriverManager.getConnection(
                environment.getRequiredProperty("spring.datasource.url"),
                environment.getRequiredProperty("spring.datasource.username"),
                environment.getRequiredProperty("spring.datasource.password"))) {
            connection.setReadOnly(true);
            JdbcTemplate jdbc = new JdbcTemplate(new SingleConnectionDataSource(connection, true));
            InterpretationRepository repository = new InterpretationRepository(jdbc);
            int absentVisit = Integer.MIN_VALUE;
            assertEquals(0, jdbc.queryForObject("SELECT count(*) FROM public.visits WHERE id = ?",
                    Integer.class, absentVisit));
            for (var measurement : InterpretationRepository.Measurements.values()) {
                assertFalse(repository.hasMeasurements(absentVisit, measurement));
            }
            assertFalse(repository.hasFirstCondition(absentVisit));
        }
    }
}
