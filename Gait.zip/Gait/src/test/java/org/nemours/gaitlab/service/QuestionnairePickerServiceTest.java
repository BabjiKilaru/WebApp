package org.nemours.gaitlab.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.nemours.gaitlab.model.Patient;
import org.nemours.gaitlab.model.Visit;
import org.nemours.gaitlab.repository.PatientRepository;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.requests.AssembleQuestionnaireRequest;

class QuestionnairePickerServiceTest {
    @ParameterizedTest
    @CsvSource({
            "2013-10-15, 2024-10-12, en, PODCI_CH",
            "2013-10-15, 2024-10-14, en, PODCI_CH",
            "2013-10-15, 2024-10-15, en, PODCI_AP",
            "2013-10-15, 2024-10-16, en, PODCI_AP",
            "2013-03-01, 2024-02-29, en, PODCI_CH",
            "2013-03-01, 2024-03-01, en, PODCI_AP",
            "2012-02-29, 2023-02-28, en, PODCI_CH",
            "2012-02-29, 2023-03-01, en, PODCI_AP",
            "2013-10-15, 2024-10-14, sp, PODCI_CH",
            "2013-10-15, 2024-10-15, sp, PODCI_CH",
            "2013-10-15, 2024-10-16, sp, PODCI_CH"
    })
    void selectsParentPodciByCompletedCalendarYears(
            String birthDate, String visitDate, String language, String expectedCode) {
        PatientRepository patientRepository = mock(PatientRepository.class);
        VisitRepository visitRepository = mock(VisitRepository.class);
        QuestionnairePickerService service = new QuestionnairePickerService(patientRepository, visitRepository);

        Patient patient = new Patient();
        patient.setDateOfBirth(LocalDate.parse(birthDate));
        Visit visit = new Visit();
        visit.setId(10);
        visit.setPatientId(1);
        visit.setDate(LocalDate.parse(visitDate));
        visit.setVisitTypeId(1);

        when(patientRepository.findById(1)).thenReturn(Optional.of(patient));
        when(visitRepository.findById(10)).thenReturn(Optional.of(visit));
        when(visitRepository.findByPatientIdAndDateOrderByIdAsc(1, visit.getDate()))
                .thenReturn(List.of(visit));

        assertEquals(List.of(new QuestionnairePickerService.CodeAssignment(expectedCode, 10)),
                service.assemble(1, new AssembleQuestionnaireRequest(10, List.of("podci-parent"), language)));
    }
}
