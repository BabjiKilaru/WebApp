package org.nemours.gaitlab.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.nemours.gaitlab.model.Visit;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.requests.UpdateQuestionnaireResponseRequest;
import org.nemours.gaitlab.service.QuestionnaireResponseService;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

class QuestionnaireResponseControllerTest {
    @Test
    void rejectsDateBasedReadsAndUpdatesWhenMultipleVisitsExist() {
        QuestionnaireResponseService service = mock(QuestionnaireResponseService.class);
        VisitRepository visitRepository = mock(VisitRepository.class);
        QuestionnaireResponseController controller = new QuestionnaireResponseController(service, visitRepository);
        LocalDate date = LocalDate.parse("2026-10-13");
        Visit firstVisit = visit(55);
        Visit secondVisit = visit(56);
        when(visitRepository.findByPatientIdAndDateOrderByIdAsc(42, date))
                .thenReturn(List.of(firstVisit, secondVisit));

        ResponseStatusException readError = assertThrows(
                ResponseStatusException.class,
                () -> controller.getResponsesByDate(42, date));
        ResponseStatusException updateError = assertThrows(
                ResponseStatusException.class,
                () -> controller.updateResponsesByDate(42, date, "items",
                        new UpdateQuestionnaireResponseRequest(null, Map.of(), Map.of())));

        assertEquals(HttpStatus.CONFLICT, readError.getStatusCode());
        assertEquals(HttpStatus.CONFLICT, updateError.getStatusCode());
        verifyNoInteractions(service);
    }

    @Test
    void resolvesDateBasedRequestsWhenExactlyOneVisitExists() {
        QuestionnaireResponseService service = mock(QuestionnaireResponseService.class);
        VisitRepository visitRepository = mock(VisitRepository.class);
        QuestionnaireResponseController controller = new QuestionnaireResponseController(service, visitRepository);
        LocalDate date = LocalDate.parse("2026-10-13");
        when(visitRepository.findByPatientIdAndDateOrderByIdAsc(42, date)).thenReturn(List.of(visit(55)));
        when(service.getVisitResponses(42, 55)).thenReturn(Map.of("visitId", 55));

        assertEquals(Map.of("visitId", 55), controller.getResponsesByDate(42, date));
    }

    private static Visit visit(int id) {
        Visit visit = new Visit();
        visit.setId(id);
        return visit;
    }
}
