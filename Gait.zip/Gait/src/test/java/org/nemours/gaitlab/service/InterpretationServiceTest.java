package org.nemours.gaitlab.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.nemours.gaitlab.repository.InterpretationRepository;
import org.nemours.gaitlab.repository.InterpretationRepository.Measurements;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.service.InterpretationService.Option;
import org.nemours.gaitlab.service.InterpretationService.VisitKind;
import org.nemours.gaitlab.service.VisitImageService.ImageMetadata;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

class InterpretationServiceTest {
    private final VisitRepository visits = mock(VisitRepository.class);
    private final InterpretationRepository data = mock(InterpretationRepository.class);
    private final VisitImageService images = mock(VisitImageService.class);
    private final InterpretationService service = new InterpretationService(
            visits, data, images);

    private void visit(Integer type) {
        VisitRepository.InterpretationVisit visit = () -> type;
        when(visits.findInterpretationVisitByIdAndPatientId(5, 42)).thenReturn(Optional.of(visit));
    }

    @Test
    void runningOptionsMatchLegacyOrderEvenWithoutData() {
        visit(3);
        assertEquals(List.of("Video Assessment", "Running Physical Examination", "Kinematics", "Kinetics",
                "Pedobarograph", "Photographs", "Assessment Form", "Recommendations", "Signatures"),
                service.options(42, 5).stream().map(Option::label).toList());
        assertEquals(List.of("kinematics", "kinetics", "pedobarograph"),
                service.options(42, 5).stream().filter(option -> !option.enabled()).map(Option::key).toList());
    }

    @Test
    void upperExtremityOptionsMatchLegacyOrder() {
        visit(2);
        assertEquals(List.of("Video Assessment", "UE Physical Examination", "Kinematics", "Photographs",
                "Assessment Form", "Recommendations", "Signatures"),
                service.options(42, 5).stream().map(Option::label).toList());
        verify(data).hasMeasurements(5, Measurements.UPPER_EXTREMITY);
        verifyNoInteractions(images);
    }

    @ParameterizedTest
    @NullSource
    @ValueSource(ints = { 1, 4, 9, 99 })
    void defaultOptionsMatchLegacyWithOnlyMovementDisorderExamLabelChanged(Integer type) {
        visit(type);
        assertEquals(List.of("Video Assessment", type != null && type == 9
                        ? "Movement Disorder Physical Examination" : "Gait Physical Examination",
                "Kinematics", "Kinetics", "Foot Model", "EMG Assessment", "Pedobarograph",
                "Metabolic (O2) Assessment", "Step Watch", "Photographs", "Assessment Form",
                "Recommendations", "Signatures"),
                service.options(42, 5).stream().map(Option::label).toList());
    }

    @Test
    void anyMatchingMeasurementEnablesAnOptionWithoutSignaturesOrCompletedInterpretation() {
        visit(1);
        when(data.hasMeasurements(5, Measurements.BALANCE)).thenReturn(true);
        when(data.hasMeasurements(5, Measurements.METABOLIC)).thenReturn(true);
        when(data.hasMeasurements(5, Measurements.FOOT_PRESSURE)).thenReturn(true);
        assertTrue(option("kinematics").enabled());
        assertTrue(option("metabolic").enabled());
        assertTrue(option("pedobarograph").enabled());
        assertFalse(option("foot-model").enabled());
    }

    @Test
    void fileBasedOptionsNeedMatchingFilesAndKineticsAndEmgNeedConditionOne() {
        visit(1);
        ImageMetadata image = new ImageMetadata("id", "matching.png", 1, "/content");
        when(images.findInterpretationImages(42, 5, "GroundReactionForces")).thenReturn(List.of(image));
        when(images.findInterpretationImages(42, 5, "EmgWaveforms")).thenReturn(List.of(image));
        when(images.findInterpretationImages(42, 5, "StepWatch")).thenReturn(List.of(image));
        assertFalse(option("kinetics").enabled());
        assertFalse(option("emg").enabled());
        assertTrue(option("step-watch").enabled());
        when(data.hasFirstCondition(5)).thenReturn(true);
        assertTrue(option("kinetics").enabled());
        assertTrue(option("emg").enabled());
    }

    @Test
    void movementDisorderDoesNotEnableKineticsFromAnotherVisitType() {
        visit(9);
        when(data.hasFirstCondition(5)).thenReturn(true);
        when(images.findInterpretationImages(42, 5, "GroundReactionForces"))
                .thenReturn(List.of(new ImageMetadata("id", "forces.png", 1, "/content")));
        assertFalse(option("kinetics").enabled());
    }

    @Test
    void unknownVisitTypesUseGaitInterpretationAvailabilityRules() {
        visit(99);
        when(data.hasFirstCondition(5)).thenReturn(true);
        when(images.findInterpretationImages(42, 5, "GroundReactionForces"))
                .thenReturn(List.of(new ImageMetadata("id", "forces.png", 1, "/content")));

        assertTrue(option("kinetics").enabled());
        assertEquals(VisitKind.GAIT, VisitKind.fromId(99));
    }

    @Test
    void rejectsAnotherPatientsVisitBeforeQueryingAnyClinicalData() {
        visit(1);
        assertEquals(HttpStatus.NOT_FOUND,
                assertThrows(ResponseStatusException.class, () -> service.options(43, 5)).getStatusCode());
        verifyNoInteractions(data, images);
    }

    @Test
    void rejectsMissingVisitsBeforeQueryingAnyClinicalData() {
        assertThrows(ResponseStatusException.class, () -> service.options(42, 5));
        verifyNoInteractions(data, images);
    }

    private Option option(String key) {
        return service.options(42, 5).stream().filter(option -> option.key().equals(key)).findFirst().orElseThrow();
    }
}
