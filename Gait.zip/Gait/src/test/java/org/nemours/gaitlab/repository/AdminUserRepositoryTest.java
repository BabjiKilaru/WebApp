package org.nemours.gaitlab.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.never;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.nemours.gaitlab.repository.AdminUserRepository.AdminUserDetails;
import org.nemours.gaitlab.requests.UpdateAdminUserRequest;
import org.nemours.gaitlab.service.LegacyPasswordHasher;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

class AdminUserRepositoryTest {
    private JdbcTemplate jdbc;
    private AdminUserRepository repository;

    @BeforeEach
    void setUp() {
        jdbc = mock(JdbcTemplate.class);
        repository = new AdminUserRepository(jdbc);
    }

    @Test
    void checksIdsCaseInsensitively() {
        String sql = "SELECT EXISTS (SELECT 1 FROM public.users WHERE lower(userid) = lower(?))";
        when(jdbc.queryForObject(sql, Boolean.class, "SJane")).thenReturn(true);
        when(jdbc.queryForObject(sql, Boolean.class, "new")).thenReturn(false);
        assertTrue(repository.userIdExists("SJane"));
        assertFalse(repository.userIdExists("new"));
    }

    @Test
    void locksAndRechecksTheIdBeforeInsertingAllFieldsAndTheHashedPassword() {
        LocalDateTime expiration = LocalDateTime.parse("2027-12-31T17:30:45");
        UpdateAdminUserRequest request = new UpdateAdminUserRequest(
                "Jane", "Smith", "C", "MD", "Orthopedics", "Main",
                "555-0101", "555-0102", "555-0103", "jane@example.com", "123 Main St", "Suite 2",
                "Wilmington", "DE", "19801", "PT, DPT", "user", false, true, expiration, "P");
        when(jdbc.update(anyString(), any(Object[].class))).thenReturn(1);
        assertEquals(1, repository.createUser("sjane", request, "hashed-password"));
        var ordered = inOrder(jdbc);
        ordered.verify(jdbc).queryForObject(
                "SELECT pg_advisory_xact_lock(hashtext(lower(?)))", Object.class, "sjane");
        ordered.verify(jdbc).queryForObject(
                "SELECT EXISTS (SELECT 1 FROM public.users WHERE lower(userid) = lower(?))",
                Boolean.class, "sjane");
        ordered.verify(jdbc).update(
                """
                INSERT INTO public.users
                    (userid, password, fname, lname, purpose, clin_type, specialty, facility,
                     phone1, phone2, fax, email, address1, address2, city, state, zip, credentials,
                     access, user_admin, active, expiration, category, must_change_password)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, TRUE)
                """,
                "sjane", "hashed-password", "Jane", "Smith", "C", "MD", "Orthopedics", "Main",
                "555-0101", "555-0102", "555-0103", "jane@example.com", "123 Main St", "Suite 2",
                "Wilmington", "DE", "19801", "PT, DPT", "user", false, true, Timestamp.valueOf(expiration), "P");
    }

    @Test
    void doesNotInsertWhenTheIdIsAlreadyTaken() {
        when(jdbc.queryForObject(anyString(), eq(Boolean.class), eq("sjane"))).thenReturn(true);
        assertEquals(0, repository.createUser("sjane", null, "hashed-password"));
        verify(jdbc, never()).update(anyString(), any(Object[].class));
    }

    @Test
    void insertsSqlNullForNoExpiration() {
        repository.createUser("sjane", new UpdateAdminUserRequest(
                "Jane", "Smith", "C", null, null, null, null, null, null, null,
                null, null, null, null, null, null, "user", false, true, null, null), "hashed-password");
        verify(jdbc).update(anyString(), eq("sjane"), eq("hashed-password"),
                eq("Jane"), eq("Smith"), eq("C"), eq(null), eq(null), eq(null),
                eq(null), eq(null), eq(null), eq(null), eq(null), eq(null),
                eq(null), eq(null), eq(null), eq(null), eq("user"), eq(false), eq(true),
                eq(null), eq(null));
    }

    @Test
    void mapsEveryDatabaseColumnAndPreservesExpirationTime() throws Exception {
        ResultSet rs = mock(ResultSet.class);
        for (String column : List.of("userid", "fname", "lname", "purpose", "clin_type", "specialty",
                "facility", "phone1", "phone2", "fax", "email", "address1", "address2",
                "city", "state", "zip", "credentials", "access", "category")) {
            when(rs.getString(column)).thenReturn(column + "-value");
        }
        LocalDateTime expiration = LocalDateTime.parse("2027-12-31T17:30:45.123456");
        when(rs.getTimestamp("expiration")).thenReturn(Timestamp.valueOf(expiration));
        when(rs.getBoolean("user_admin")).thenReturn(true);
        when(rs.getBoolean("active")).thenReturn(false);
        when(rs.getBoolean("must_change_password")).thenReturn(true);
        when(jdbc.query(anyString(), org.mockito.ArgumentMatchers.<RowMapper<AdminUserDetails>>any(),
                eq(LegacyPasswordHasher.LEGACY_DEFAULT_PASSWORD_HASH), eq("jsmith")))
                .thenAnswer(invocation -> {
                    RowMapper<AdminUserDetails> mapper = invocation.getArgument(1);
                    return List.of(mapper.mapRow(rs, 0));
                });

        assertEquals(new AdminUserDetails(
                "userid-value", "fname-value", "lname-value", "purpose-value", "clin_type-value",
                "specialty-value", "facility-value", "phone1-value", "phone2-value", "fax-value",
                "email-value", "address1-value", "address2-value", "city-value", "state-value",
                "zip-value", "credentials-value", "access-value", true, false, expiration, "category-value", true), repository.findUser("jsmith"));
        verify(jdbc).query(org.mockito.ArgumentMatchers.contains(
                        "(must_change_password = TRUE OR password = ?) AS must_change_password"),
                org.mockito.ArgumentMatchers.<RowMapper<AdminUserDetails>>any(),
                eq(LegacyPasswordHasher.LEGACY_DEFAULT_PASSWORD_HASH), eq("jsmith"));

        when(rs.getTimestamp("expiration")).thenReturn(null);
        when(rs.getBoolean("must_change_password")).thenReturn(false);
        assertNull(repository.findUser("jsmith").expiration());
        assertFalse(repository.findUser("jsmith").mustChangePassword());
    }

    @Test
    void returnsNullWhenTheUserIsMissing() {
        when(jdbc.query(anyString(), org.mockito.ArgumentMatchers.<RowMapper<AdminUserDetails>>any(),
                eq(LegacyPasswordHasher.LEGACY_DEFAULT_PASSWORD_HASH), eq("missing")))
                .thenReturn(List.of());
        assertNull(repository.findUser("missing"));
    }

    @Test
    void resetsOnlyThePasswordAndRequiresAChange() {
        when(jdbc.update(anyString(), eq("hashed-password"), eq("jsmith"))).thenReturn(1);
        assertEquals(1, repository.resetTemporaryPassword("jsmith", "hashed-password"));
        verify(jdbc).update(
                "UPDATE public.users SET password = ?, must_change_password = TRUE WHERE userid = ?",
                "hashed-password", "jsmith");
        assertEquals(0, repository.resetTemporaryPassword("missing", "hashed-password"));
    }

    @Test
    void writesEveryFieldToItsColumnWithoutChangingUserIdOrPassword() {
        LocalDateTime expiration = LocalDateTime.parse("2027-12-31T17:30:45");
        UpdateAdminUserRequest request = new UpdateAdminUserRequest(
                "Jane", "Smith", "C", "MD", "Orthopedics", "Main",
                "555-0101", "555-0102", "555-0103", "jane@example.com", "123 Main St", "Suite 2",
                "Wilmington", "DE", "19801", "PT, DPT", "admin", true, false, expiration, "P");
        when(jdbc.update(anyString(), any(Object[].class))).thenReturn(1);

        assertEquals(1, repository.updateUser("jsmith", request));
        verify(jdbc).update(
                """
                UPDATE public.users
                SET fname = ?, lname = ?, purpose = ?, clin_type = ?, specialty = ?, facility = ?,
                    phone1 = ?, phone2 = ?, fax = ?, email = ?, address1 = ?, address2 = ?,
                    city = ?, state = ?, zip = ?, credentials = ?, access = ?, user_admin = ?, active = ?, expiration = ?, category = ?
                WHERE userid = ?
                """,
                "Jane", "Smith", "C", "MD", "Orthopedics", "Main",
                "555-0101", "555-0102", "555-0103", "jane@example.com", "123 Main St", "Suite 2",
                "Wilmington", "DE", "19801", "PT, DPT", "admin", true, false, Timestamp.valueOf(expiration), "P", "jsmith");
    }

    @Test
    void clearsExpirationWithSqlNull() {
        repository.updateUser("jsmith", new UpdateAdminUserRequest(
                null, null, null, null, null, null, null, null, null,
                null, null, null, null, null, null, null, null, false, false, null, null));
        verify(jdbc).update(anyString(),
                eq(null), eq(null), eq(null), eq(null), eq(null), eq(null),
                eq(null), eq(null), eq(null), eq(null), eq(null), eq(null),
                eq(null), eq(null), eq(null), eq(null), eq(null), eq(false), eq(false),
                eq(null), eq(null), eq("jsmith"));
    }
}
