package org.nemours.gaitlab.repository;

import org.nemours.gaitlab.model.PtHealthCondition;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PtHealthConditionRepository extends JpaRepository<PtHealthCondition, Integer> {
    List<PtHealthCondition> findByPatientIdOrderByCondition_CodeAsc(Integer patientId);
}

