package org.nemours.gaitlab.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.nemours.gaitlab.requests.UpdateAdminUserRequest;
import org.nemours.gaitlab.service.LegacyPasswordHasher;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class AdminUserRepository {
    private final JdbcTemplate jdbcTemplate;

    public AdminUserRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<AdminUserRow> findAllUsers() {
        return jdbcTemplate.query(
                """
                SELECT
                    userid,
                    fname,
                    lname,
                    facility,
                    access,
                    user_admin,
                    clin_type,
                    purpose,
                    active
                FROM public.users
                ORDER BY lname, fname, userid
                """,
                (rs, rowNum) ->
                        new AdminUserRow(
                                rs.getString("userid"),
                                rs.getString("fname"),
                                rs.getString("lname"),
                                rs.getString("facility"),
                                rs.getString("access"),
                                rs.getBoolean("user_admin"),
                                rs.getString("clin_type"),
                                rs.getString("purpose"),
                                rs.getBoolean("active")
                        )
        );
    }

    public record AdminUserRow(
            String userid,
            String fname,
            String lname,
            String facility,
            String access,
            boolean userAdmin,
            String clinType,
            String purpose,
            boolean active
    ) {
    }

    public AdminUserDetails findUser(String userid) {
        List<AdminUserDetails> users = jdbcTemplate.query(
                """
                SELECT userid, fname, lname, purpose, clin_type, specialty, facility,
                       phone1, phone2, fax, email, address1, address2, city, state, zip, credentials,
                       access, user_admin, active, expiration, category,
                       (must_change_password = TRUE OR password = ?) AS must_change_password
                FROM public.users
                WHERE userid = ?
                """,
                (rs, rowNum) -> {
                    Timestamp expiration = rs.getTimestamp("expiration");
                    return new AdminUserDetails(
                            rs.getString("userid"), rs.getString("fname"), rs.getString("lname"),
                            rs.getString("purpose"), rs.getString("clin_type"), rs.getString("specialty"),
                            rs.getString("facility"), rs.getString("phone1"), rs.getString("phone2"),
                            rs.getString("fax"), rs.getString("email"), rs.getString("address1"),
                            rs.getString("address2"), rs.getString("city"), rs.getString("state"),
                            rs.getString("zip"), rs.getString("credentials"), rs.getString("access"), rs.getBoolean("user_admin"),
                            rs.getBoolean("active"), expiration == null ? null : expiration.toLocalDateTime(),
                            rs.getString("category"), rs.getBoolean("must_change_password"));
                },
                LegacyPasswordHasher.LEGACY_DEFAULT_PASSWORD_HASH, userid);
        return users.isEmpty() ? null : users.get(0);
    }

    public int resetTemporaryPassword(String userid, String hashedPassword) {
        return jdbcTemplate.update(
                "UPDATE public.users SET password = ?, must_change_password = TRUE WHERE userid = ?",
                hashedPassword, userid);
    }

    public int updateUser(String userid, UpdateAdminUserRequest user) {
        return jdbcTemplate.update(
                """
                UPDATE public.users
                SET fname = ?, lname = ?, purpose = ?, clin_type = ?, specialty = ?, facility = ?,
                    phone1 = ?, phone2 = ?, fax = ?, email = ?, address1 = ?, address2 = ?,
                    city = ?, state = ?, zip = ?, credentials = ?, access = ?, user_admin = ?, active = ?, expiration = ?, category = ?
                WHERE userid = ?
                """,
                user.fname(), user.lname(), user.purpose(), user.clinType(), user.specialty(), user.facility(),
                user.phone1(), user.phone2(), user.fax(), user.email(), user.address1(), user.address2(),
                user.city(), user.state(), user.zip(), user.credentials(), user.access(), user.userAdmin(), user.active(),
                user.expiration() == null ? null : Timestamp.valueOf(user.expiration()), user.category(), userid);
    }

    public boolean userIdExists(String userid) {
        return Boolean.TRUE.equals(jdbcTemplate.queryForObject(
                "SELECT EXISTS (SELECT 1 FROM public.users WHERE lower(userid) = lower(?))",
                Boolean.class, userid));
    }

    public int createUser(String userid, UpdateAdminUserRequest user, String hashedPassword) {
        // Serialize creation of the same case-insensitive ID until the transaction commits.
        jdbcTemplate.queryForObject("SELECT pg_advisory_xact_lock(hashtext(lower(?)))", Object.class, userid);
        if (userIdExists(userid)) {
            return 0;
        }
        return jdbcTemplate.update(
                """
                INSERT INTO public.users
                    (userid, password, fname, lname, purpose, clin_type, specialty, facility,
                     phone1, phone2, fax, email, address1, address2, city, state, zip, credentials,
                     access, user_admin, active, expiration, category, must_change_password)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, TRUE)
                """,
                userid, hashedPassword, user.fname(), user.lname(), user.purpose(), user.clinType(),
                user.specialty(), user.facility(), user.phone1(), user.phone2(), user.fax(), user.email(),
                user.address1(), user.address2(), user.city(), user.state(), user.zip(), user.credentials(),
                user.access(), user.userAdmin(), user.active(),
                user.expiration() == null ? null : Timestamp.valueOf(user.expiration()), user.category());
    }

    public record AdminUserDetails(
            String userid,
            String fname,
            String lname,
            String purpose,
            String clinType,
            String specialty,
            String facility,
            String phone1,
            String phone2,
            String fax,
            String email,
            String address1,
            String address2,
            String city,
            String state,
            String zip,
            String credentials,
            String access,
            boolean userAdmin,
            boolean active,
            LocalDateTime expiration,
            String category,
            boolean mustChangePassword
    ) {
    }
}
