package org.nemours.gaitlab.repository;

import java.util.List;
import java.util.Optional;

import org.nemours.gaitlab.model.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface PatientRepository extends JpaRepository<Patient, Integer> {

        List<Patient> findByLastNameContainingIgnoreCase(String lastName);

        Optional<Patient> findByMrn(String mrn);

        @Query("""
                        SELECT p
                        FROM Patient p
                        WHERE LOWER(p.firstName) LIKE LOWER(CONCAT('%', :query, '%'))
                            OR LOWER(p.lastName) LIKE LOWER(CONCAT('%', :query, '%'))
                            OR LOWER(p.mrn) LIKE LOWER(CONCAT('%', :query, '%'))
                        ORDER BY p.lastName, p.firstName
                        """)
        List<Patient> searchPatients(@Param("query") String query);

        @Query(value = """
                        SELECT
                            p.id,
                            p.mrn,
                            i.code AS icd9_code,
                            i.diagnosis AS general_diagnosis,
                            l.description AS learning_description
                        FROM public.patients p
                        LEFT JOIN public.icd9 i ON p.gen_diag = i.id
                        LEFT JOIN public.learning l ON p.learning = l.code
                        WHERE p.id = :patientId
                        """, nativeQuery = true)
        List<Object[]> findDiagnosisByPatientId(
                        @Param("patientId") Integer patientId);

        @Query(value = """
                        SELECT i.id, i.code, i.diagnosis
                        FROM public.icd9 i
                        ORDER BY i.diagnosis
                        """, nativeQuery = true)
        List<Object[]> findAllGeneralDiagnoses();
}
