package org.nemours.gaitlab.model;

import java.time.LocalDate;
import java.util.List;

public class ScheduleVisit {

    private LocalDate schedulingDate;
    private LocalDate visitDate;

    private Integer visitTypeId;
    private Integer visitSubTypeId;

    private String startTime;
    private String endTime;

    private LocalDate surgeryDate;

    private Integer referringMdId;

    private List<String> selectedTests;

    public LocalDate getSchedulingDate() {
        return schedulingDate;
    }

    public void setSchedulingDate(LocalDate schedulingDate) {
        this.schedulingDate = schedulingDate;
    }

    public LocalDate getVisitDate() {
        return visitDate;
    }

    public void setVisitDate(LocalDate visitDate) {
        this.visitDate = visitDate;
    }

    public Integer getVisitTypeId() {
        return visitTypeId;
    }

    public void setVisitTypeId(Integer visitTypeId) {
        this.visitTypeId = visitTypeId;
    }

    public Integer getVisitSubTypeId() {
        return visitSubTypeId;
    }

    public void setVisitSubTypeId(Integer visitSubTypeId) {
        this.visitSubTypeId = visitSubTypeId;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public LocalDate getSurgeryDate() {
        return surgeryDate;
    }

    public void setSurgeryDate(LocalDate surgeryDate) {
        this.surgeryDate = surgeryDate;
    }

    public Integer getReferringMdId() {
        return referringMdId;
    }

    public void setReferringMdId(Integer referringMdId) {
        this.referringMdId = referringMdId;
    }

    public List<String> getSelectedTests() {
        return selectedTests;
    }

    public void setSelectedTests(List<String> selectedTests) {
        this.selectedTests = selectedTests;
    }
}