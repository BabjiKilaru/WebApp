package org.nemours.gaitlab.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class FormsRepository {

    private final JdbcTemplate jdbcTemplate;

    public FormsRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<ScheduledPatientRow> findScheduledPatients(
            LocalDate visitDate) {

        return jdbcTemplate.query("""
            SELECT
                v.id AS visit_id,
                p.id AS patient_id,
                p.mrn,
                p.fname,
                p.lname,
                COALESCE(vt.name, v.visit_type, '') AS visit_type,
                COALESCE(tg.name, '') AS visit_sub_type,
                v.date AS visit_date,
                v.appt_time,
                v.test_group_id
            FROM public.visits v
            INNER JOIN public.patients p
                ON p.id = v.pt_id
            LEFT JOIN public.new_visit_type vt
                ON vt.id = v.visit_type_id
            LEFT JOIN public.new_test_group tg
                ON tg.id = v.test_group_id
            WHERE v.date = ?
              AND (
                  v.attendance = 'Yes'
                                    OR v.attendance = ''
                  OR v.attendance IS NULL
              )
            ORDER BY
                v.appt_time NULLS LAST,
                p.lname,
                p.fname,
                v.id
            """,
            (resultSet, rowNumber) -> new ScheduledPatientRow(
                resultSet.getInt("visit_id"),
                resultSet.getInt("patient_id"),
                resultSet.getString("mrn"),
                resultSet.getString("fname"),
                resultSet.getString("lname"),
                resultSet.getString("visit_type"),
                resultSet.getString("visit_sub_type"),
                getNullableLocalDate(resultSet, "visit_date"),
                resultSet.getString("appt_time"),
                getNullableInteger(
                    resultSet,
                    "test_group_id"
                )
            ),
            visitDate
        );
    }

    public List<String> findRecommendedForms(
            Integer testGroupId) {

        if (testGroupId == null) {
            return List.of();
        }

        return jdbcTemplate.queryForList("""
            SELECT form
            FROM public.test_group_forms
            WHERE test_group_id = ?
            ORDER BY form
            """,
            String.class,
            testGroupId
        );
    }

    public Optional<PrintableVisitRow> findPrintableVisit(Integer visitId) {
        return jdbcTemplate.query("""
            SELECT 
                v.id AS visit_id,
                p.id AS patient_id,
                p.mrn,
                p.fname,
                p.lname,
                p.gender,
                p.dob,
                v.date AS visit_date,
                v.appt_time,
                i.diagnosis,
                u.fname AS referring_fname,
                u.lname AS referring_lname,
                u.clin_type AS referring_clin_type,
                u.facility AS referring_facility
            FROM public.visits v
            INNER JOIN public.patients p ON p.id = v.pt_id
            LEFT JOIN public.icd9 i ON i.id = p.gen_diag
            LEFT JOIN public.users u ON u.id = v.refer_md
            WHERE v.id = ?
            """,
            (resultSet, rowNumber) -> new PrintableVisitRow(
                resultSet.getInt("visit_id"),
                resultSet.getInt("patient_id"),
                resultSet.getString("mrn"),
                resultSet.getString("fname"),
                resultSet.getString("lname"),
                resultSet.getString("gender"),
                getNullableLocalDate(resultSet, "dob"),
                getNullableLocalDate(resultSet, "visit_date"),
                resultSet.getString("appt_time"),
                resultSet.getString("diagnosis"),
                resultSet.getString("referring_fname"),
                resultSet.getString("referring_lname"),
                resultSet.getString("referring_clin_type"),
                resultSet.getString("referring_facility")
            ),
            visitId
        )
        .stream()
        .findFirst();
    }

    public List<LocalDate> findPreviousVisitDates(
        Integer patientId,
        Integer currentVisitId,
        LocalDate currentVisitDate
    ){
        if(currentVisitDate == null){
            return List.of();
        }
        return jdbcTemplate.query("""
                SELECT DISTINCT v.date
                FROM public.visits v
                WHERE v.pt_id = ? AND v.id <> ? AND v.date < ? AND (v.attendance = 'Yes' OR v.attendance = '' OR v.attendance IS NULL)
                ORDER BY v.date DESC
                """,
                (resultSet, rowNumber) -> getNullableLocalDate(resultSet, "date"), patientId, currentVisitId, currentVisitDate
            )
            .stream()
            .filter(date -> date != null)
            .toList();
    }

    private Integer getNullableInteger(
            java.sql.ResultSet resultSet,
            String columnName) throws java.sql.SQLException {

        int value = resultSet.getInt(columnName);

        return resultSet.wasNull() ? null : value;
    }

    private LocalDate getNullableLocalDate(
        java.sql.ResultSet resultSet,
        String columnName
    ) throws java.sql.SQLException {
        java.sql.Date value = resultSet.getDate(columnName);
        return value == null ? null : value.toLocalDate();
    }

    public record ScheduledPatientRow(
        Integer visitId,
        Integer patientId,
        String mrn,
        String firstName,
        String lastName,
        String visitType,
        String visitSubType,
        LocalDate visitDate,
        String appointmentTime,
        Integer testGroupId
    ) {
    }

    public record PrintableVisitRow(
        Integer visitId,
        Integer patientId,
        String mrn,
        String firstName,
        String lastName,
        String gender,
        LocalDate dateOfBirth,
        LocalDate visitDate,
        String appointmentTime,
        String diagnosis,
        String referringFirstName,
        String referringLastName,
        String referringClinicianType,
        String referringFacility
    ){

    }
}
