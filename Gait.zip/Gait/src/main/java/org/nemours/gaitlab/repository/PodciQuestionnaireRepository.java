package org.nemours.gaitlab.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class PodciQuestionnaireRepository {

    private static final Set<String> EXCLUDED_COLUMNS = Set.of(
        "id", "visit_id", "q2_type",
        "uepf_std", "uepf_norm",
        "tbm_std", "tbm_norm",
        "spf_std", "spf_norm",
        "pain_std", "pain_norm",
        "happiness_std", "happiness_norm",
        "global_std", "global_norm");

    private final JdbcTemplate jdbc;

    public PodciQuestionnaireRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Integer findVisitPatientId(int visitId) {
        List<Integer> ids = jdbc.queryForList("SELECT pt_id FROM public.visits WHERE id = ?", Integer.class, visitId);
        return ids.isEmpty() ? null : ids.get(0);
    }

    public Map<String, String> findAnswerColumnTypes() {
        List<Map<String, Object>> rows = jdbc.queryForList(
            "SELECT column_name, data_type FROM information_schema.columns "
                + "WHERE table_schema = 'public' AND table_name = 'data_questionnaire'");

        Map<String, String> result = new HashMap<>();

        for (Map<String, Object> row : rows) {
            String name = (String) row.get("column_name");

            if (!EXCLUDED_COLUMNS.contains(name)) {
                result.put(name, (String) row.get("data_type"));
            }
        }

        return result;
    }

    private Integer findExistingRowId(int visitId, String variant) {
        List<Integer> ids = jdbc.queryForList("SELECT id FROM public.data_questionnaire WHERE visit_id = ? AND q2_type = ?", Integer.class, visitId, variant);
        return ids.isEmpty() ? null : ids.get(0);
    }

    public Map<String, Object> findAnswers(int visitId, String variant) {
        List<Map<String, Object>> rows = jdbc.queryForList("SELECT * FROM public.data_questionnaire WHERE visit_id = ? AND q2_type = ?", visitId, variant);

        if (rows.isEmpty()) {
            return Map.of();
        }

        Map<String, Object> row = rows.get(0);
        Map<String, Object> answers = new HashMap<>();

        for (Map.Entry<String, Object> entry : row.entrySet()) {
            if (!EXCLUDED_COLUMNS.contains(entry.getKey()) && entry.getValue() != null) {
                answers.put(entry.getKey(), entry.getValue());
            }
        }

        return answers;
    }

    public void upsert(int visitId, String variant, LinkedHashMap<String, Object> columns) {
        Integer existingId = findExistingRowId(visitId, variant);

        if (existingId == null) {
            List<String> names = new ArrayList<>();
            names.add("visit_id");
            names.add("q2_type");
            names.addAll(columns.keySet());

            List<Object> parameters = new ArrayList<>();
            parameters.add(visitId);
            parameters.add(variant);
            parameters.addAll(columns.values());

            String columnList = String.join(", ", names);
            String placeholders = names.stream().map(name -> "?").collect(Collectors.joining(", "));

            jdbc.update("INSERT INTO public.data_questionnaire (" + columnList + ") VALUES (" + placeholders + ")", parameters.toArray());

        } 
        
        else if (!columns.isEmpty()) {
            String assignments = columns.keySet().stream()
                .map(name -> name + " = ?")
                .collect(Collectors.joining(", "));

            List<Object> parameters = new ArrayList<>(columns.values());
            parameters.add(existingId);

            jdbc.update("UPDATE public.data_questionnaire SET " + assignments + " WHERE id = ?", parameters.toArray());
        }
    }
}
