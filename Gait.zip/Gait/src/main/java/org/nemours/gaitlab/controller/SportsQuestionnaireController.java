package org.nemours.gaitlab.controller;

import org.nemours.gaitlab.requests.SportsQuestionnaireRequest;
import org.nemours.gaitlab.service.SportsQuestionnaireService;
import org.nemours.gaitlab.service.SportsQuestionnaireService.SportsQuestionnaireResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/patients/{patientId}/sports-questionnaire")
public class SportsQuestionnaireController {

    private final SportsQuestionnaireService service;

    public SportsQuestionnaireController(SportsQuestionnaireService service) {
        this.service = service;
    }

    @GetMapping("/{visitId}")
    public SportsQuestionnaireResponse find(
            Authentication authentication,
            @PathVariable Integer patientId,
            @PathVariable Integer visitId,
            @RequestParam(defaultValue = "en") String language) {
        return service.find(patientId, visitId, language, authentication.getName());
    }

    @PostMapping
    public ResponseEntity<Void> save(
            @PathVariable Integer patientId,
            @RequestBody SportsQuestionnaireRequest request) {
        service.save(patientId, request);
        return ResponseEntity.noContent().build();
    }
}