package org.nemours.gaitlab.service;

import java.util.ArrayList;
import java.util.List;
import org.nemours.gaitlab.repository.InterpretationRepository;
import org.nemours.gaitlab.repository.InterpretationRepository.Measurements;
import org.nemours.gaitlab.repository.VisitRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class InterpretationService {
    public enum VisitKind {
        GAIT(1), UPPER_EXTREMITY(2), RUNNING(3), RESEARCH(4), MOVEMENT_DISORDER(9);

        private final Integer id;

        VisitKind(Integer id) {
            this.id = id;
        }

        public static VisitKind fromId(Integer id) {
            if (id == null) {
                return GAIT;
            }
            for (VisitKind kind : values()) {
                if (id.equals(kind.id)) {
                    return kind;
                }
            }
            return GAIT;
        }
    }

    public record Option(String key, String label, boolean enabled) {}

    private final VisitRepository visits;
    private final InterpretationRepository data;
    private final VisitImageService images;

    public InterpretationService(VisitRepository visits, InterpretationRepository data,
            VisitImageService images) {
        this.visits = visits;
        this.data = data;
        this.images = images;
    }

    public List<Option> options(int patientId, int visitId) {
        var visit = requireVisit(patientId, visitId);
        VisitKind kind = VisitKind.fromId(visit.getVisitTypeId());
        List<Option> options = new ArrayList<>();
        options.add(new Option("video", "Video Assessment", true));
        options.add(new Option("physical-exam", switch (kind) {
            case RUNNING -> "Running Physical Examination";
            case UPPER_EXTREMITY -> "UE Physical Examination";
            case MOVEMENT_DISORDER -> "Movement Disorder Physical Examination";
            default -> "Gait Physical Examination";
        }, true));
        options.add(new Option("kinematics", "Kinematics", hasKinematics(visitId, kind)));
        if (kind != VisitKind.UPPER_EXTREMITY) {
            // Legacy kinetics is file-based and applies only to gait, running and research visits.
            boolean kineticsType = kind == VisitKind.GAIT || kind == VisitKind.RUNNING
                    || kind == VisitKind.RESEARCH;
            options.add(new Option("kinetics", "Kinetics", kineticsType
                    && hasFirstConditionImage(patientId, visitId, "GroundReactionForces")));
            if (kind != VisitKind.RUNNING) {
                options.add(new Option("foot-model", "Foot Model",
                        data.hasMeasurements(visitId, Measurements.FOOT_MODEL)));
                options.add(new Option("emg", "EMG Assessment",
                        hasFirstConditionImage(patientId, visitId, "EmgWaveforms")));
            }
            options.add(new Option("pedobarograph", "Pedobarograph",
                    data.hasMeasurements(visitId, Measurements.FOOT_PRESSURE)));
            if (kind != VisitKind.RUNNING) {
                options.add(new Option("metabolic", "Metabolic (O2) Assessment",
                        data.hasMeasurements(visitId, Measurements.METABOLIC)));
                options.add(new Option("step-watch", "Step Watch",
                        !images.findInterpretationImages(patientId, visitId, "StepWatch").isEmpty()));
            }
        }
        options.add(new Option("photographs", "Photographs", true));
        options.add(new Option("assessment", "Assessment Form", true));
        options.add(new Option("recommendations", "Recommendations", true));
        options.add(new Option("signatures", "Signatures", true));
        return options;
    }

    private VisitRepository.InterpretationVisit requireVisit(int patientId, int visitId) {
        return visits.findInterpretationVisitByIdAndPatientId(visitId, patientId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    private boolean hasKinematics(int visitId, VisitKind kind) {
        if (kind == VisitKind.UPPER_EXTREMITY) {
            return data.hasMeasurements(visitId, Measurements.UPPER_EXTREMITY);
        }
        return data.hasMeasurements(visitId, Measurements.GAIT)
                || data.hasMeasurements(visitId, Measurements.BALANCE);
    }

    private boolean hasFirstConditionImage(int patientId, int visitId, String name) {
        return data.hasFirstCondition(visitId)
                && !images.findInterpretationImages(patientId, visitId, name).isEmpty();
    }
}
