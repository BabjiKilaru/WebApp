package org.nemours.gaitlab.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import org.nemours.gaitlab.service.VisitImageService;
import org.nemours.gaitlab.service.VisitImageService.ImageMetadata;
import org.nemours.gaitlab.service.VisitImageService.ImageType;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.MediaTypeFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/patients/{patientId}/visits/{visitId}/images")
public class VisitImageController {

    private final VisitImageService imageService;

    public VisitImageController(VisitImageService imageService) {
        this.imageService = imageService;
    }

    @GetMapping
    public List<ImageMetadata> getVisitImages(
            @PathVariable Integer patientId,
            @PathVariable Integer visitId,
            @RequestParam ImageType type) {
        return imageService.findVisitImages(patientId, visitId, type);
    }

    @GetMapping("/{imageId}/content")
    public ResponseEntity<Resource> getImageContent(
            @PathVariable Integer patientId,
            @PathVariable Integer visitId,
            @PathVariable String imageId) throws IOException {
        Path image = imageService.resolveImage(patientId, visitId, imageId);
        MediaType contentType = MediaTypeFactory.getMediaType(image.getFileName().toString())
                .orElse(MediaType.APPLICATION_OCTET_STREAM);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(contentType);
        headers.setContentLength(Files.size(image));
        headers.setCacheControl("private, no-store");
        headers.setContentDisposition(ContentDisposition.inline()
                .filename(image.getFileName().toString())
                .build());
        return ResponseEntity.ok().headers(headers).body(new FileSystemResource(image));
    }
}
