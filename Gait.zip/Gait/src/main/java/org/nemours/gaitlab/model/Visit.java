package org.nemours.gaitlab.model;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "visits", schema = "public")
public class Visit {

    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "pt_id")
    private Integer patientId;

    @Column(name = "date")
    private LocalDate date;

    @Column(name = "attendance")
    private String attendance;

    @Column(name = "bill_status")
    private String billStatus;

    @Column(name = "icd9")
    private Integer icd9;

    @Column(name = "cpt")
    private String cpt;

    @Column(name = "date_interp")
    private LocalDate interpretationDate;

    @Column(name = "refer_md")
    private Integer referringDoctorId;

    @Column(name = "date_scheduled")
    private LocalDate scheduledDate;

    @Column(name = "visit_type")
    private String visitType;

    @Column(name = "interp_md")
    private Integer interpretingDoctorId;

    @Column(name = "date_processed")
    private LocalDate processedDate;

    @Column(name = "date_dictated")
    private LocalDate dictatedDate;

    @Column(name = "date_printed")
    private LocalDate printedDate;

    @Column(name = "date_refer_md")
    private LocalDate referringDoctorDate;

    @Column(name = "date_billed")
    private LocalDate billedDate;

    @Column(name = "comment")
    private String comment;

    @Column(name = "internal_comment")
    private String internalComment;

    @Column(name = "visit_type_id")
    private Integer visitTypeId;

    @Column(name = "test_group_id")
    private Integer testGroupId;

    @Column(name = "appt_time")
    private String appointmentTime;

    @Column(name = "appt_time_end")
    private String appointmentTimeEnd;

    @Column(name ="surgery_date")
    private LocalDate surgeryDate;

    @Transient
    private String visitSubType;

    @Column(name = "height")
    private Float height;

    @Column(name = "weight")
    private Float weight;

    @Column(name = "left_evaluated")
    private Boolean leftEvaluated;

    @Column(name = "right_evaluated")
    private Boolean rightEvaluated;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getPatientId() {
        return patientId;
    }

    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getAttendance() {
        return attendance;
    }

    public void setAttendance(String attendance) {
        this.attendance = attendance;
    }

    public String getBillStatus() {
        return billStatus;
    }

    public void setBillStatus(String billStatus) {
        this.billStatus = billStatus;
    }

    public Integer getIcd9() {
        return icd9;
    }

    public void setIcd9(Integer icd9) {
        this.icd9 = icd9;
    }

    public String getCpt() {
        return cpt;
    }

    public void setCpt(String cpt) {
        this.cpt = cpt;
    }

    public LocalDate getInterpretationDate() {
        return interpretationDate;
    }

    public void setInterpretationDate(LocalDate interpretationDate) {
        this.interpretationDate = interpretationDate;
    }

    public Integer getReferringDoctorId() {
        return referringDoctorId;
    }

    public void setReferringDoctorId(Integer referringDoctorId) {
        this.referringDoctorId = referringDoctorId;
    }

    public LocalDate getScheduledDate() {
        return scheduledDate;
    }

    public void setScheduledDate(LocalDate scheduledDate) {
        this.scheduledDate = scheduledDate;
    }

    public LocalDate getSurgeryDate() {
        return surgeryDate;
    }

    public void setSurgeryDate(LocalDate surgeryDate) {
        this.surgeryDate = surgeryDate;
    }

    public String getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(String appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public String getAppointmentTimeEnd() {
        return appointmentTimeEnd;
    }

    public void setAppointmentTimeEnd(String appointmentTimeEnd) {
        this.appointmentTimeEnd = appointmentTimeEnd;
    }

    public String getVisitType() {
        return visitType;
    }

    public void setVisitType(String visitType) {
        this.visitType = visitType;
    }

    public Integer getInterpretingDoctorId() {
        return interpretingDoctorId;
    }

    public void setInterpretingDoctorId(Integer interpretingDoctorId) {
        this.interpretingDoctorId = interpretingDoctorId;
    }

    public LocalDate getProcessedDate() {
        return processedDate;
    }

    public void setProcessedDate(LocalDate processedDate) {
        this.processedDate = processedDate;
    }

    public LocalDate getDictatedDate() {
        return dictatedDate;
    }

    public void setDictatedDate(LocalDate dictatedDate) {
        this.dictatedDate = dictatedDate;
    }

    public LocalDate getPrintedDate() {
        return printedDate;
    }

    public void setPrintedDate(LocalDate printedDate) {
        this.printedDate = printedDate;
    }

    public LocalDate getReferringDoctorDate() {
        return referringDoctorDate;
    }

    public void setReferringDoctorDate(LocalDate referringDoctorDate) {
        this.referringDoctorDate = referringDoctorDate;
    }

    public LocalDate getBilledDate() {
        return billedDate;
    }

    public void setBilledDate(LocalDate billedDate) {
        this.billedDate = billedDate;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getInternalComment() {
        return internalComment;
    }

    public void setInternalComment(String internalComment) {
        this.internalComment = internalComment;
    }

    public Integer getVisitTypeId() {
        return visitTypeId;
    }

    public void setVisitTypeId(Integer visitTypeId) {
        this.visitTypeId = visitTypeId;
    }

    public Integer getTestGroupId() {
        return testGroupId;
    }

    public void setTestGroupId(Integer testGroupId) {
        this.testGroupId = testGroupId;
    }

    public String getVisitSubType() {
        return visitSubType;
    }

    public void setVisitSubType(String visitSubType) {
        this.visitSubType = visitSubType;
    }

    public Float getHeight() {
        return height;
    }

    public void setHeight(Float height) {
        this.height = height;
    }

    public Float getWeight() {
        return weight;
    }

    public void setWeight(Float weight) {
        this.weight = weight;
    }

    public Boolean getLeftEvaluated() {
        return leftEvaluated;
    }

    public void setLeftEvaluated(Boolean leftEvaluated) {
        this.leftEvaluated = leftEvaluated;
    }

    public Boolean getRightEvaluated() {
        return rightEvaluated;
    }

    public void setRightEvaluated(Boolean rightEvaluated) {
        this.rightEvaluated = rightEvaluated;
    }
}

