package org.nemours.gaitlab.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
// import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import org.nemours.gaitlab.model.Patient;
import org.nemours.gaitlab.repository.PatientRepository;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.repository.VisitRepository.VideoVisitDate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class VideoService {

    private static final Logger log = LoggerFactory.getLogger(VideoService.class);
    private static final DateTimeFormatter VISIT_DIRECTORY_DATE =
            DateTimeFormatter.ofPattern("MMddyy", Locale.ROOT);
    private static final Pattern VIDEO_EXTENSION =
            Pattern.compile("(?i)\\.(mov|mp4|ogv|mpg|mpeg|webm)$");

    private final PatientRepository patientRepository;
    private final VisitRepository visitRepository;
    private final Path videoRoot;

    public VideoService(
            PatientRepository patientRepository,
            VisitRepository visitRepository,
            @Value("${gaitlab.videos.root-path:./dev-data/PngFiles}") String videoRoot) {
        this.patientRepository = patientRepository;
        this.visitRepository = visitRepository;
        this.videoRoot = Path.of(videoRoot).toAbsolutePath().normalize();
    }

    public List<VideoMetadata> findVideos(Integer patientId, Integer selectedVisitId) {
        Patient patient = getPatient(patientId);
        Path patientDirectory = getPatientDirectory(patient);

        LocalDate selectedDate = null;
        if (selectedVisitId != null) {
            VideoVisitDate selectedVisit = visitRepository
                    .findVideoVisitDateByIdAndPatientId(selectedVisitId, patientId)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
            selectedDate = parseVisitDate(selectedVisit.getVisitDate());
        }

        Map<Path, VideoMetadata> videosByPath = new LinkedHashMap<>();
        if (Files.isDirectory(patientDirectory)) {
            addVideos(patientDirectory, patientDirectory.resolve("video"), null, patientId, videosByPath);
        }

        for (VideoVisitDate visit : visitRepository.findVideoVisitDatesByPatientId(patientId)) {
            LocalDate visitDate = parseVisitDate(visit.getVisitDate());
            if (visitDate == null || (selectedDate != null && visitDate.isAfter(selectedDate))) {
                continue;
            }

            Path visitVideoDirectory = patientDirectory
                    .resolve(visitDate.format(VISIT_DIRECTORY_DATE))
                    .resolve("video");
            addVideos(patientDirectory, visitVideoDirectory, visitDate, patientId, videosByPath);
        }

        List<VideoMetadata> videos = new ArrayList<>(videosByPath.values());
        videos.sort(Comparator
                .comparing(VideoMetadata::visitDate, Comparator.nullsLast(Comparator.reverseOrder()))
                .thenComparing(VideoMetadata::fileName, String.CASE_INSENSITIVE_ORDER));
        return videos;
    }

    private static LocalDate parseVisitDate(String visitDate) {
        if (visitDate == null || visitDate.isBlank() || "infinity".equalsIgnoreCase(visitDate)
                || "-infinity".equalsIgnoreCase(visitDate)) {
            if (visitDate != null && !visitDate.isBlank()) {
                log.warn("Skipping video lookup for visit with an unsupported date value.");
            }
            return null;
        }
        try {
            return LocalDate.parse(visitDate);
        } catch (DateTimeParseException ex) {
            log.warn("Skipping video lookup for visit with an unsupported date value.", ex);
            return null;
        }
    }

    public Path resolveVideo(Integer patientId, String videoId) {
        Patient patient = getPatient(patientId);
        Path patientDirectory = getPatientDirectory(patient);
        Path rootRealPath = toRealPath(videoRoot);
        Path patientRealPath = toRealPath(patientDirectory);

        if (!patientRealPath.startsWith(rootRealPath)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }

        final String relativePath;
        try {
            relativePath = new String(Base64.getUrlDecoder().decode(videoId), StandardCharsets.UTF_8);
        } catch (IllegalArgumentException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }

        Path candidate = patientDirectory.resolve(relativePath).normalize();
        if (!candidate.startsWith(patientDirectory)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }

        Path realCandidate = toRealPath(candidate);
        if (!realCandidate.startsWith(patientRealPath)
                || !Files.isRegularFile(realCandidate)
                || !isVideoFile(realCandidate)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        return realCandidate;
    }

    private Patient getPatient(Integer patientId) {
        return patientRepository.findById(patientId)
                .filter(patient -> patient.getMrn() != null && !patient.getMrn().isBlank())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    private Path getPatientDirectory(Patient patient) {
        Path patientDirectory = videoRoot.resolve(patient.getMrn()).normalize();
        if (!patientDirectory.startsWith(videoRoot)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        return patientDirectory;
    }

    private void addVideos(
            Path patientDirectory,
            Path directory,
            LocalDate visitDate,
            Integer patientId,
            Map<Path, VideoMetadata> videosByPath) {
        if (!Files.isDirectory(directory)) {
            return;
        }

        Path realPatientDirectory = toRealPath(patientDirectory);
        try (Stream<Path> files = Files.list(directory)) {
            files.filter(Files::isRegularFile)
                    .filter(VideoService::isVideoFile)
                    .filter(file -> !file.getFileName().toString().startsWith("._"))
                    .sorted(Comparator.comparing(
                            file -> file.getFileName().toString(),
                            String.CASE_INSENSITIVE_ORDER))
                    .forEach(file -> {
                        Path realFile = toRealPath(file);
                        if (!realFile.startsWith(realPatientDirectory)) {
                            return;
                        }
                        long sizeBytes;
                        try {
                            sizeBytes = Files.size(realFile);
                        } catch (IOException ex) {
                            throw new VideoFileReadException(ex);
                        }
                        if (sizeBytes == 0) {
                            return;
                        }
                        String relativePath = patientDirectory
                                .relativize(file.toAbsolutePath().normalize())
                                .toString();
                        String videoId = Base64.getUrlEncoder().withoutPadding()
                                .encodeToString(relativePath.getBytes(StandardCharsets.UTF_8));
                        VideoMetadata metadata = new VideoMetadata(
                                videoId,
                                file.getFileName().toString(),
                                visitDate,
                                classify(file.getFileName().toString()),
                                sizeBytes,
                                "/api/patients/" + patientId + "/videos/" + videoId + "/content");
                        videosByPath.putIfAbsent(realFile, metadata);
                    });
        } catch (IOException ex) {
            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR, "Unable to read patient video directory.", ex);
        } catch (VideoFileReadException ex) {
            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR, "Unable to read patient video metadata.", ex.getCause());
        }
    }

    private static Path toRealPath(Path path) {
        try {
            return path.toRealPath();
        } catch (IOException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
    }

    private static boolean isVideoFile(Path file) {
        return VIDEO_EXTENSION.matcher(file.getFileName().toString()).find();
    }

    private static String classify(String fileName) {
        String descriptor = fileName.replaceFirst("(?i)\\s+\\d+\\s+\\d+\\.[^.]+$", "")
                .toLowerCase(Locale.ROOT);
        if (descriptor.endsWith("_movement_disorder")) {
            return "Movement Disorder";
        }
        if (descriptor.endsWith("_running")) {
            return "Running";
        }
        if (descriptor.endsWith("_dystonia")) {
            return "Dystonia";
        }
        if (descriptor.endsWith("_shuee") || descriptor.endsWith("_ue")) {
            return "Upper Extremity";
        }
        if (descriptor.endsWith("_gait") || descriptor.endsWith("_s")) {
            return "Gait";
        }
        return "Gait";
    }

    public record VideoMetadata(
            String id,
            String fileName,
            LocalDate visitDate,
            String category,
            long sizeBytes,
            String contentUrl) {
    }

    private static final class VideoFileReadException extends RuntimeException {
        private VideoFileReadException(IOException cause) {
            super(cause);
        }
    }
}
