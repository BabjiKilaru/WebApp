package org.nemours.gaitlab.controller;
import org.nemours.gaitlab.model.Age;
import org.nemours.gaitlab.model.BodyLocation;
import org.nemours.gaitlab.model.Condition;
import org.nemours.gaitlab.model.HistoryCondition;
import org.nemours.gaitlab.model.Surgery;
import org.nemours.gaitlab.model.SeizureMedication;
import org.nemours.gaitlab.repository.AgeRepository;
import org.nemours.gaitlab.repository.BodyLocationRepository;
import org.nemours.gaitlab.repository.ConditionRepository;
import org.nemours.gaitlab.repository.FrequencyRepository;
import org.nemours.gaitlab.repository.HistoryConditionRepository;
import org.nemours.gaitlab.repository.SeizureMedicationRepository;
import org.nemours.gaitlab.repository.SurgeryRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reference")
public class ReferenceController {
    private final SurgeryRepository surgeryRepository;
    private final BodyLocationRepository bodyLocationRepository;
    private final AgeRepository ageRepository;
    private final ConditionRepository conditionRepository;
    private final FrequencyRepository frequencyRepository;
    private final HistoryConditionRepository historyConditionRepository;
    private final SeizureMedicationRepository seizureMedicationRepository;

    public ReferenceController(SurgeryRepository surgeryRepository, BodyLocationRepository bodyLocationRepository, AgeRepository ageRepository, ConditionRepository conditionRepository, FrequencyRepository frequencyRepository, HistoryConditionRepository historyConditionRepository, SeizureMedicationRepository seizureMedicationRepository) {
        this.surgeryRepository = surgeryRepository;
        this.bodyLocationRepository = bodyLocationRepository;
        this.ageRepository = ageRepository;
        this.conditionRepository = conditionRepository;
        this.frequencyRepository = frequencyRepository;
        this.historyConditionRepository = historyConditionRepository;
        this.seizureMedicationRepository = seizureMedicationRepository;
    }

    public record SideOption(String value, String label) {}

    @GetMapping("/surgeries")
    public List<Surgery> getSurgeries() {
        return surgeryRepository.findAllByOrderByNameAsc();
    }

    @GetMapping("surgery-sides")
    public List<SideOption> getSurgerySides() {
        return List.of(
            new SideOption("L", "Left"),
            new SideOption("R", "Right"),
            new SideOption("Both", "Both"),
            new SideOption("NA", "N/A")
        );
    }

    @GetMapping("/body-locations")
    public List<String> getBodyLocations() {
        return bodyLocationRepository.findAllByOrderByLocationAsc().stream().map(BodyLocation::getLocation).toList();
    }

    @GetMapping("/botox-sides")
    public List<SideOption> getBotoxSides() {
        return List.of(
            new SideOption("L", "Left"),
            new SideOption("R", "Right"),
            new SideOption("Both", "Both")
        );
    }

    @GetMapping("/history-conditions")
    public List<HistoryCondition> getHistoryConditions() {
        return historyConditionRepository.findAllByOrderByConditionAsc();
    }

    @GetMapping("/ages")
    public List<String> getAges() {
        return ageRepository.findAllByOrderByChronAsc().stream().map(Age::getAge).toList();
    }

    @GetMapping("/conditions")
    public List<Condition> getConditions() {
        return conditionRepository.findAllByOrderByConditionAsc();
    }

    @GetMapping("/frequencies")
    public List<Map<String, Object>> getFrequencies(@RequestParam(required = false) String language) {
        return frequencyRepository.findAllOrderByCodeDesc().stream().map(row -> {
            Map<String, Object> result = new LinkedHashMap<>();
            result.put("value", String.valueOf(row.get("code")));
            result.put("label", labelOf((String) row.get("freq"), (String) row.get("il8n_sp"), language));
            return result;
        })
        .toList();
    }

    @GetMapping("/seizure-meds")
    public List<String> getSeizureMedications() {
        return seizureMedicationRepository.findAllByOrderByMedAsc().stream().map(SeizureMedication::getMed).filter(med -> med != null && !med.isBlank()).toList();
    }

    private String labelOf(String english, String spanish, String language) {
        if("sp".equalsIgnoreCase(language) && spanish != null && !spanish.isBlank()) {
            return spanish;
        }
        return english;
    }
}
