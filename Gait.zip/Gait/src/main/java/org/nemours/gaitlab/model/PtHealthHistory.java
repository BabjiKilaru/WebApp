package org.nemours.gaitlab.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

@Entity
@Table(name = "pt_health_history", schema = "public")
public class PtHealthHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "healthHistSeqGen")
    @SequenceGenerator(name = "healthHistSeqGen", sequenceName = "health_hist_seq", allocationSize = 1)
    @Column(name = "id")
    private Integer id;

    @Column(name = "pt_id")
    private Integer patientId;

    @Column(name = "age")
    private String age;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "condition", referencedColumnName = "code")
    private HistoryCondition condition;

    public Integer getId() {
        return id;
    }

    @JsonIgnore
    public Integer getPatientId() {
        return patientId;
    }

    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getConditionCode() {
        return condition != null ? condition.getCode() : null;
    }

    public void setCondition(HistoryCondition condition) {
        this.condition = condition;
    }

    public String getConditionDescription() {
        return condition != null ? condition.getCondition() : null;
    }
}
