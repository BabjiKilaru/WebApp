package org.nemours.gaitlab.repository;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.web.server.ResponseStatusException;

@Repository
public class QuestionnaireResponseRepository {

    private final JdbcTemplate jdbc;

    public QuestionnaireResponseRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void requirePatient(int patientId, boolean lock) {
        one("SELECT id " + "FROM public.patients " + "WHERE id = ?" + (lock ? " FOR UPDATE" : ""), patientId);
    }

    public Map<String, Object> findOwnedVisit( int patientId, int visitId, boolean lock) {
        return one("SELECT id, date::text AS date " + "FROM public.visits " + "WHERE id = ? " + "AND pt_id = ?" + (lock ? " FOR UPDATE" : ""), visitId, patientId);
    }

    public Map<String, Object> findPatientFields(int patientId, Map<String, String> mapping) {
        return one("SELECT " + selectColumns(mapping, "") + " FROM public.patients " + "WHERE id = ?", patientId);
    }

    public Map<String, Object> findVisitFields(int patientId, int visitId, Map<String, String> mapping) {
        return one("SELECT " + selectColumns(mapping, "") + " FROM public.visits " + "WHERE id = ? " + "AND pt_id = ?", visitId, patientId);
    }

    public List<Map<String, Object>> findListRows(int visitId, String table, Map<String, String> columns) {
        return jdbc.queryForList( "SELECT id, " + selectColumns(columns, "") + " FROM public." + table + " WHERE visit_id = ? " + "ORDER BY id", visitId);
    }

    public List<Map<String, Object>> findEligibleVisits(int patientId) {
        return jdbc.queryForList(
                """
                        SELECT
                            v.id,
                            v.date::text AS date,
                            COALESCE(
                                vt.name,
                                v.visit_type
                            ) AS "visitType",
                            tg.name AS "visitSubType",
                            v.appt_time AS "appointmentTime",
                            v.appt_time_end AS "appointmentTimeEnd"

                        FROM public.visits v

                        LEFT JOIN public.new_visit_type vt
                            ON vt.id = v.visit_type_id

                        LEFT JOIN public.new_test_group tg
                            ON tg.id = v.test_group_id

                        WHERE v.pt_id = ?

                          AND (
                              v.attendance IS NULL
                              OR v.attendance = ''
                              OR v.attendance = 'Yes'
                          )

                        ORDER BY
                            v.date ASC NULLS LAST,
                            v.id ASC
                        """,
                patientId);
    }

    public List<Map<String, Object>> findSameDayAnswers(int patientId, int visitId, Map<String, String> mapping) {
        return jdbc.queryForList(
                "SELECT " +
                        selectColumns(mapping, "v.") +
                        " " +
                        """
                                FROM public.visits selected

                                JOIN public.visits v
                                  ON v.pt_id = selected.pt_id
                                 AND (
                                     v.id = selected.id
                                     OR v.date = selected.date
                                 )

                                WHERE selected.id = ?
                                  AND selected.pt_id = ?

                                ORDER BY
                                    CASE
                                        WHEN v.id = selected.id
                                        THEN 0
                                        ELSE 1
                                    END,
                                    v.id
                                """,
                visitId, patientId);
    }

    public List<String> findRelationships() {
        return jdbc.queryForList("SELECT DISTINCT rship " + "FROM public.relationships " + "WHERE rship IS NOT NULL " + "ORDER BY rship", String.class);
    }

    public List<Map<String, Object>> findRelationships(String language) {
        return jdbc.queryForList("SELECT DISTINCT rship AS value, " + labelColumn(language, "rship")
            + " FROM public.relationships WHERE rship IS NOT NULL ORDER BY rship");
    }

    public List<String> findPrematureOptions() {
        return jdbc.queryForList("SELECT premtime " + "FROM public.premature " + "WHERE premtime IS NOT NULL " + "ORDER BY chron, premtime", String.class);
    }

    public List<Map<String, Object>> findPrematureOptions(String language) {
        return jdbc.queryForList("SELECT premtime AS value, " + labelColumn(language, "premtime")
            + " FROM public.premature WHERE premtime IS NOT NULL ORDER BY chron, premtime");
    }

    public List<String> findBirthStayOptions() {
        return jdbc.queryForList("SELECT birthstay " + "FROM public.birthstay " + "WHERE birthstay IS NOT NULL " + "ORDER BY chron, birthstay", String.class);
    }

    public List<Map<String, Object>> findBirthStayOptions(String language) {
        return jdbc.queryForList("SELECT birthstay AS value, " + labelColumn(language, "birthstay")
            + " FROM public.birthstay WHERE birthstay IS NOT NULL ORDER BY chron, birthstay");
    }

    public List<String> findAgeOptions() {
        return jdbc.queryForList("SELECT age " + "FROM public.ages1 " + "WHERE age IS NOT NULL " + "AND (chron < 2 OR chron > 9) " + "ORDER BY chron, age", String.class);
    }

    // public.ages1 has no il8n_sp column live (unlike the legacy dump's schema) — label is
    // always the English value until that's added.
    public List<Map<String, Object>> findAgeOptions(String language) {
        return jdbc.queryForList("SELECT age AS value, age AS label "
            + "FROM public.ages1 WHERE age IS NOT NULL AND (chron < 2 OR chron > 9) ORDER BY chron, age");
    }

    public List<Map<String, Object>> findLearningOptions() {
        return jdbc.queryForList("SELECT " + "code AS value, " + "description AS label " + "FROM public.learning " + "WHERE code IS NOT NULL " + "ORDER BY code");
    }

    public List<Map<String, Object>> findLearningOptions(String language) {
        return jdbc.queryForList("SELECT code AS value, " + labelColumn(language, "description")
            + " FROM public.learning WHERE code IS NOT NULL ORDER BY code");
    }

    public List<Map<String, Object>> findWalkingSupportOptions() {
        return jdbc.queryForList("SELECT " + "code AS value, " + "description AS label " + "FROM public.walk_support " + "ORDER BY code");
    }

    public List<Map<String, Object>> findWalkingSupportOptions(String language) {
        return jdbc.queryForList("SELECT code AS value, " + labelColumn(language, "description")
            + " FROM public.walk_support ORDER BY code");
    }

    public List<Map<String, Object>> findFmsOptions() {
        return jdbc.queryForList("SELECT " + "id AS value, " + "label, " + "description " + "FROM public.fms_list " + "WHERE label <> '' " + "ORDER BY sortorder, id");
    }

    // "description" stays the English long-form text in both languages; only the short "label" is translated.
    public List<Map<String, Object>> findFmsOptions(String language) {
        return jdbc.queryForList("SELECT id AS value, " + labelColumn(language, "label") + ", description "
            + "FROM public.fms_list WHERE label <> '' ORDER BY sortorder, id");
    }

    public List<String> findMedicationOptions() {
        return jdbc.queryForList("SELECT med " + "FROM public.seizure_meds " + "ORDER BY med", String.class);
    }

    // seizure_meds has no il8n_sp column in legacy — label is always the English value.
    public List<Map<String, Object>> findMedicationOptions(String language) {
        return jdbc.queryForList("SELECT med AS value, med AS label FROM public.seizure_meds ORDER BY med");
    }

    public List<String> findDeviceOptions(){
        return jdbc.queryForList("SELECT device " + "FROM public.devices " + "ORDER BY device", String.class);
    }

    public List<Map<String, Object>> findDeviceOptions(String language) {
        return jdbc.queryForList("SELECT device AS value, " + labelColumn(language, "device")
            + " FROM public.devices ORDER BY device");
    }

    public List<Map<String, Object>> findGaitConcernOptions(){
        return jdbc.queryForList("SELECT " + "code AS value, " + "description AS label " + "FROM public.gait_concerns " + "ORDER BY code");
    }

    public List<Map<String, Object>> findGaitConcernOptions(String language) {
        return jdbc.queryForList("SELECT code AS value, " + labelColumn(language, "description")
            + " FROM public.gait_concerns ORDER BY code");
    }

    public List<String> findPainOptions(){
        return jdbc.queryForList("SELECT part " + "FROM public.pain " + "ORDER BY part", String.class);
    }

    public List<Map<String, Object>> findPainOptions(String language) {
        return jdbc.queryForList("SELECT part AS value, " + labelColumn(language, "part")
            + " FROM public.pain ORDER BY part");
    }

    // "sp" reads the legacy il8n_sp column, falling back to English when it's blank/unset;
    // anything else (including plain "en") reads the original English column directly.
    private static String labelColumn(String language, String englishColumn) {
        return ("sp".equals(language)
            ? "COALESCE(NULLIF(il8n_sp, ''), " + englishColumn + ")"
            : englishColumn) + " AS label";
    }

    public boolean validLookup(String key, Object value) {
        String sql = switch (key) {
                case "historyRelationship", "relationship" -> "SELECT COUNT(*) " + "FROM public.relationships " + "WHERE rship = ?";
                case "premature" -> "SELECT COUNT(*) " + "FROM public.premature " + "WHERE premtime = ?";
                case "birthStay" -> "SELECT COUNT(*) " + "FROM public.birthstay " + "WHERE birthstay = ?";
                case "ageWalk" -> "SELECT COUNT(*) " + "FROM public.ages1 " + "WHERE age = ?";
                case "learning" -> "SELECT COUNT(*) " + "FROM public.learning " + "WHERE code = ?";
                case "walkingSupportCode" -> "SELECT COUNT(*) " + "FROM public.walk_support " + "WHERE code = ?";
                case "fms5Id", "fms50Id", "fms500Id" -> "SELECT COUNT(*) " + "FROM public.fms_list " + "WHERE id = ? " + "AND label <> ''";
                default -> null;
        };

        if (sql == null) {
                return true;
        }

        Long count = jdbc.queryForObject(sql, long.class, value);

        return count != null && count > 0;
    }

    public boolean gaitConcernExists(Object value) {
        Long count = jdbc.queryForObject("SELECT COUNT(*) " + "FROM public.gait_concerns " + "WHERE code = ?", Long.class, value);

        return count != null && count > 0;
    }

    public void updatePatientFields(int patientId, LinkedHashMap<String, String> mapping, LinkedHashMap<String, Object> values) {
        String assignments = mapping.values().stream().map(column -> column + " =?").collect(Collectors.joining(", "));
        List<Object> parameters = new ArrayList<>(values.values());
        int dateIndex = new ArrayList<>(mapping.keySet()).indexOf("baselineDate");
        if(dateIndex >=0){
                Object date = parameters.get(dateIndex);
                parameters.set(dateIndex, date == null || "".equals(date) ? null : Date.valueOf((String) date));
        }
        parameters.add(patientId);

        jdbc.update("UPDATE public.patients " + "SET " + assignments + " WHERE id = ?", parameters.toArray());
    }

    public void updateVisitFields(int patientId, int visitId, LinkedHashMap<String, String> mapping, LinkedHashMap<String, Object> values){
        String assignments = mapping.values().stream().map(column -> column + " =?").collect(Collectors.joining(", "));
        
        List<Object> parameters = new ArrayList<>(values.values());
        parameters.add(visitId);
        parameters.add(patientId);

        jdbc.update("UPDATE public.visits " + "SET " + assignments + " WHERE id = ? " + "AND pt_id = ?", parameters.toArray());
    }

    public void insertListRow(int visitId, String table, LinkedHashMap<String, String> columns, Map<String, Object> row) {
        List<Object> parameters = new ArrayList<>();
        for(String key : columns.keySet()) {
                parameters.add(row.get(key));
        }

        parameters.add(visitId);

        String placeholders = String.join(", ", Collections.nCopies(parameters.size(), "?"));

        jdbc.update("INSERT INTO public." + table + " (" + String.join(", ", columns.values()) + ", visit_id) VALUES (" + placeholders + ")", parameters.toArray());
    }

    public void updateListRow(int visitId, int rowId, String table, LinkedHashMap<String, String> columns, Map<String, Object> row) {
        List<Object> parameters = new ArrayList<>();
        for(String key : columns.keySet()) {
                parameters.add(row.get(key));
        }

        parameters.add(visitId);
        parameters.add(rowId);

        String setters = columns.values().stream().map(column -> column + " =?").collect(Collectors.joining(", "));
        jdbc.update("UPDATE public." + table + " SET " + setters + " WHERE visit_id = ? " + "AND id = ?", parameters.toArray());
    }

    public void deleteListRow(int visitId, int rowId, String table) {
        jdbc.update("DELETE FROM public." + table + " WHERE visit_id = ? " + "AND id = ?", visitId, rowId);
    }

    private Map<String, Object> one(String sql, Object... parameters) {
        List<Map<String, Object>> rows = jdbc.queryForList(sql, parameters);

        if(rows.isEmpty()) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Patient or visit was not found.");
        }

        Map<String, Object> result = new LinkedHashMap<>(rows.get(0));

        result.replaceAll((key, value) -> value instanceof Date date ? date.toLocalDate().toString() : value);

        return result;
    }

    private String selectColumns(Map<String, String> columns, String prefix) {
        return columns.entrySet().stream().map(entry -> prefix + entry.getValue() + " AS \"" + entry.getKey() + "\"").collect(Collectors.joining(", "));
    }
}