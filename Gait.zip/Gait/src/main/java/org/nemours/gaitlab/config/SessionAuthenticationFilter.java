package org.nemours.gaitlab.config;

import java.io.IOException;
import java.util.List;

import org.nemours.gaitlab.service.AuthService;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class SessionAuthenticationFilter extends OncePerRequestFilter {
    private final AuthService authService;

    public SessionAuthenticationFilter(AuthService authService) {
        this.authService = authService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null) {
            String username = (String) session.getAttribute(AuthService.SESSION_USERNAME);

            if (username != null && !username.isBlank()) {
                String access = (String) session.getAttribute(AuthService.SESSION_ACCESS);
                String role = (access == null || access.isBlank()) ? "USER" : access.toUpperCase();

                var authentication = new UsernamePasswordAuthenticationToken(username, null, List.of(new SimpleGrantedAuthority("ROLE_" + role)));
                SecurityContextHolder.getContext().setAuthentication(authentication);
                if (!allowedDuringPasswordChange(request) && authService.mustChangePassword(username)) {
                    response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                    response.setContentType("application/json");
                    response.getWriter().write(
                            "{\"code\":\"PASSWORD_CHANGE_REQUIRED\",\"message\":\"You must change your temporary password before continuing.\"}");
                    return;
                }
            }
        }
        chain.doFilter(request, response);
    }

    private static boolean allowedDuringPasswordChange(HttpServletRequest request) {
        String path = request.getServletPath();
        String method = request.getMethod();
        return (method.equals("GET") && (path.equals("/api/profile")
                || path.equals("/api/auth/me") || path.equals("/api/health")))
                || (method.equals("PUT") && path.equals("/api/profile/password"))
                || (method.equals("POST") && (path.equals("/api/auth/login") || path.equals("/api/auth/logout")))
                || path.equals("/error");
    }
}
