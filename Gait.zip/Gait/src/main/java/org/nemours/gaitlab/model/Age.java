package org.nemours.gaitlab.model;

import jakarta.persistence.*;

@Entity
@Table(name = "ages2", schema = "public")
public class Age {
    @Id
    @Column(name = "age")
    private String age;

    @Column(name = "chron")
    private String chron;

    public String getAge() {
        return age;
    }
}
