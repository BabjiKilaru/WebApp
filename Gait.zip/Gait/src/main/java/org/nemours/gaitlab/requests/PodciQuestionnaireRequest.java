package org.nemours.gaitlab.requests;

import java.util.Map;

public record PodciQuestionnaireRequest(
    Integer visitId,
    String variant,
    Map<String, Object> answers
) {}
