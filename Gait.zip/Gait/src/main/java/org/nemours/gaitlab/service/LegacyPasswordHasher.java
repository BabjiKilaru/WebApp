package org.nemours.gaitlab.service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public final class LegacyPasswordHasher {
    public static final String LEGACY_DEFAULT_PASSWORD_HASH = ";1O182C1S1W101+1.1S1B2M2U1c1<272";

    private LegacyPasswordHasher() {

    }

    public static String hash(String rawPassword) {
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            byte[] digest = md5.digest(rawPassword.getBytes(StandardCharsets.UTF_8));

            StringBuilder result = new StringBuilder();

            for (int i = 0; i < 16; i++) {
                int b = digest[i];

                if (b < 0) {
                    b += 128;
                }

                char c1 = (char) ((b % 85) + 37);
                char c2 = (char) ((b / 85) + 49);

                result.append(c1);

                if (c1 == 39) {
                    result.append(c1);
                }

                result.append(c2);
            }
            return result.toString();
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("MD5 not available.", exception);
        }
    }
}