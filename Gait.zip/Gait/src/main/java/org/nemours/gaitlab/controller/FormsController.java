package org.nemours.gaitlab.controller;

import java.time.LocalDate;
import java.util.List;

import org.nemours.gaitlab.response.FormsResponse;
import org.nemours.gaitlab.requests.FormsPreviewRequest;
import org.nemours.gaitlab.service.FormsPdfService;
import org.nemours.gaitlab.service.FormsService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/forms")
public class FormsController {
    private final FormsService formsService;
    private final FormsPdfService formsPdfService;

    public FormsController(FormsService formsService, FormsPdfService formsPdfService) {
        this.formsService = formsService;
        this.formsPdfService = formsPdfService;
    }

    @GetMapping("/patients")
    public List<FormsResponse> getScheduledPatients(
            @RequestParam
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate date) {
        return formsService.getScheduledPatients(date);
    }

    @PostMapping(
        value = "/preview",
        produces = MediaType.APPLICATION_PDF_VALUE
    )
    public ResponseEntity<byte[]> previewForms(
            @Valid
            @RequestBody
            FormsPreviewRequest request) {

        byte[] pdf = formsPdfService.generatePreview(request);

        return ResponseEntity
            .ok()
            .contentType(MediaType.APPLICATION_PDF)
            .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"printable-visit-forms.pdf\"")
            .contentLength(pdf.length)
            .body(pdf);
    }
}
