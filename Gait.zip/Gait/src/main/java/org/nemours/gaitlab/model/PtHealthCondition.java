package org.nemours.gaitlab.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

@Entity
@Table(name = "pt_health_conditions", schema = "public")
public class PtHealthCondition {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "healthCondSeqGen")
    @SequenceGenerator(name = "healthCondSeqGen", sequenceName = "health_cond_seq", allocationSize = 1)
    @Column(name = "id")
    private Integer id;

    @Column(name = "pt_id")
    private Integer patientId;
    
    @JsonIgnore
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "condition", referencedColumnName = "code")
    private Condition condition;

    public Integer getId() {
        return id;
    }

    @JsonIgnore
    public Integer getPatientId() {
        return patientId;
    }

    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public void setCondition(Condition condition) {
        this.condition = condition;
    }

    public String getConditionCode() {
        return condition != null ? condition.getCode() : null;
    }

    public String getConditionDescription() {
        return condition != null ? condition.getCondition() : null;
    }
}
