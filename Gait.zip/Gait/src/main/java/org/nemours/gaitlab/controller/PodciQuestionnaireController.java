package org.nemours.gaitlab.controller;

import java.util.Map;

import org.nemours.gaitlab.requests.PodciQuestionnaireRequest;
import org.nemours.gaitlab.service.PodciQuestionnaireService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/patients/{patientId}/podci-questionnaire")
public class PodciQuestionnaireController {

    private final PodciQuestionnaireService service;

    public PodciQuestionnaireController(PodciQuestionnaireService service) {
        this.service = service;
    }

    @GetMapping("/{visitId}")
    public Map<String, Object> find(
            @PathVariable Integer patientId,
            @PathVariable Integer visitId,
            @RequestParam String variant) {
        return service.find(patientId, visitId, variant);
    }

    @PostMapping
    public ResponseEntity<Void> save(
            @PathVariable Integer patientId,
            @RequestBody PodciQuestionnaireRequest request) {
        service.save(patientId, request);
        return ResponseEntity.noContent().build();
    }
}