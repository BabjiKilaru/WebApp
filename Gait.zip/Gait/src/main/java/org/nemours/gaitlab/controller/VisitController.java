package org.nemours.gaitlab.controller;

import java.time.LocalDate;
import java.util.List;

import org.nemours.gaitlab.model.Visit;
import org.nemours.gaitlab.model.VisitHomeDetails;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.repository.VisitHomeRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class VisitController {

    private final VisitRepository visitRepository;
    private final VisitHomeRepository visitHomeRepository;

    public VisitController(
            VisitRepository visitRepository,
            VisitHomeRepository visitHomeRepository) {
        this.visitRepository = visitRepository;
        this.visitHomeRepository = visitHomeRepository;
    }

    @GetMapping("/visits/{id}")
    public ResponseEntity<Visit> getVisitById(@PathVariable Integer id) {
        return visitRepository
                .findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/visits/{id}/overview")
    public ResponseEntity<VisitHomeDetails> getVisitHomeDetails(@PathVariable Integer id) {
        return visitHomeRepository
                .findByVisitId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/patients/{patientId}/visits")
    public List<Visit> getVisitsByPatient(@PathVariable Integer patientId) {
        List<Object[]> rows = visitRepository .findVisitDisplayByPatientId(patientId);

        return rows.stream() .map(row -> {
            Visit visit = new Visit();
            visit.setId(((Number) row[0]).intValue());
            visit.setPatientId(((Number) row[1]).intValue());
            if (row[2] instanceof java.sql.Date date) {
                visit.setDate(date.toLocalDate());
            } else {
                visit.setDate((LocalDate) row[2]);
            }

            visit.setAttendance(
                row[3] != null ? row[3].toString() : null
            );

            visit.setVisitType(
                row[4] != null ? row[4].toString() : null
            );

            visit.setVisitSubType(
                row[5] != null ? row[5].toString() : null
            );
            return visit;
        })
        .toList();
    }
}
