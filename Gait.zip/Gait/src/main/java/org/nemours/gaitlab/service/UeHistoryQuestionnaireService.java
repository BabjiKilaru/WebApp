package org.nemours.gaitlab.service;

import java.util.List;

import org.nemours.gaitlab.repository.AuthRepository;
import org.nemours.gaitlab.repository.UeHistoryQuestionnaireRepository;
import org.nemours.gaitlab.requests.UeHistoryQuestionnaireRequest;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
public class UeHistoryQuestionnaireService {

    private static final int Q_HANDLES_OBJECTS = 54;
    private static final int Q_DRESSES = 55;
    private static final int Q_BATHES = 56;
    private static final int Q_TOILETS = 57;
    private static final int Q_ARM_HAND_CONCERNS = 58;

    private final UeHistoryQuestionnaireRepository repository;
    private final AuthRepository authRepository;

    public UeHistoryQuestionnaireService(
            UeHistoryQuestionnaireRepository repository,
            AuthRepository authRepository) {
        this.repository = repository;
        this.authRepository = authRepository;
    }

    @Transactional
    public void save(int patientId, UeHistoryQuestionnaireRequest request) {
        if (request.visitId() == null) {
            throw bad("visitId is required.");
        }

        Integer visitPatientId = repository.findVisitPatientId(request.visitId());

        if (visitPatientId == null) {
            throw bad("Visit not found.");
        }

        if (!visitPatientId.equals(patientId)) {
            throw bad("Visit does not belong to this patient.");
        }

        if (request.sessionId() == null || !repository.isSessionForVisit(request.visitId(), request.sessionId())) {
            throw bad("A valid questionnaire session is required.");
        }

        int sessionId = request.sessionId();
        int languageId = languageId(request.language());

        saveChoice(sessionId, request.visitId(), Q_HANDLES_OBJECTS, request.handlesObjects(), languageId);
        saveChoice(sessionId, request.visitId(), Q_DRESSES, request.dresses(), languageId);
        saveChoice(sessionId, request.visitId(), Q_BATHES, request.bathes(), languageId);
        saveChoice(sessionId, request.visitId(), Q_TOILETS, request.toilets(), languageId);
        saveMultiChoice(sessionId, request.visitId(), Q_ARM_HAND_CONCERNS, request.armHandConcerns(), languageId);
        repository.advanceSessionGroup(sessionId);
    }

    public record UeHistoryQuestionnaireResponse(
            int sessionId,
            String handlesObjects,
            String dresses,
            String bathes,
            String toilets,
            List<String> armHandConcerns) {}

    @Transactional
    public UeHistoryQuestionnaireResponse find(int patientId, int visitId, String language, String userid) {
        Integer visitPatientId = repository.findVisitPatientId(visitId);

        if (visitPatientId == null) {
            throw bad("Visit not found.");
        }

        if (!visitPatientId.equals(patientId)) {
            throw bad("Visit does not belong to this patient.");
        }

        Integer authId = authRepository.findUserId(userid);
        if (authId == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Signed-in user not found.");
        }

        int sessionId = repository.startSession(visitId, languageId(language), authId);

        return new UeHistoryQuestionnaireResponse(
            sessionId,
            firstOrNull(repository.findActiveAnswerLabels(visitId, Q_HANDLES_OBJECTS)),
            firstOrNull(repository.findActiveAnswerLabels(visitId, Q_DRESSES)),
            firstOrNull(repository.findActiveAnswerLabels(visitId, Q_BATHES)),
            firstOrNull(repository.findActiveAnswerLabels(visitId, Q_TOILETS)),
            repository.findActiveAnswerLabels(visitId, Q_ARM_HAND_CONCERNS));
    }

    private static String firstOrNull(List<String> values) {
        return values.isEmpty() ? null : values.get(0);
    }

    private void saveChoice(int sessionId, int visitId, int questionId, String value, int languageId) {
        repository.deactivateActiveAnswers(visitId, questionId);
        if (value == null || value.isBlank()) {
            return;
        }

        Integer answerId = repository.resolveAnswerId(questionId, value, languageId);

        if (answerId == null) {
            throw bad("Could not resolve answer for question " + questionId + ": " + value);
        }

        repository.insertAnswer(sessionId, questionId, answerId, null);
    }

    private void saveMultiChoice(int sessionId, int visitId, int questionId, List<String> values, int languageId) {
        repository.deactivateActiveAnswers(visitId, questionId);
        if (values == null || values.isEmpty()) {
            return;
        }

        for (String value : values) {
            Integer answerId = repository.resolveAnswerId(questionId, value, languageId);

            if (answerId == null) {
                throw bad("Could not resolve answer for question " + questionId + ": " + value);
            }

            repository.insertAnswer(sessionId, questionId, answerId, null);
        }
    }

    private static ResponseStatusException bad(String reason) {
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, reason);
    }

    private static int languageId(String language) {
        if (language == null || language.isBlank() || "en".equals(language)) {
            return 1;
        }
        if ("sp".equals(language)) {
            return 2;
        }
        throw bad("language must be 'en' or 'sp'.");
    }
}