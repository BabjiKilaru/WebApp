package org.nemours.gaitlab.response;

import java.util.List;

public record VideoAssessmentResponse(
    Integer patientId,
    Integer visitId,
    Integer visitTypeId,
    String assessmentType,
    Integer questionnaireId,
    String revision,
    List<Group> groups
) {
    public record Group(
        Integer id,
        String name,
        String comments,
        List<Field> fields
    ) {}

    public record Field(
        Integer id,
        String paramName,
        String displayName,
        Integer order,
        String choice,
        String controlType,
        List<Option> options,
        String side,
        boolean required
    ) {}

    public record Option(String code, String label) {}
}
