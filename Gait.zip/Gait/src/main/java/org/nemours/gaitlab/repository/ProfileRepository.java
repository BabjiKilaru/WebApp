package org.nemours.gaitlab.repository;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class ProfileRepository {
    private final JdbcTemplate jdbc;

    public ProfileRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public ProfileRow findProfile(String userid) {
        List<ProfileRow> rows = jdbc.query(
                """
                SELECT userid, fname, lname, facility, city, state,
                       phone1, phone2, fax, email, address1, zip
                FROM public.users
                WHERE userid = ?
                """,
                (rs, rowNum) -> new ProfileRow(
                        rs.getString("userid"),
                        rs.getString("fname"),
                        rs.getString("lname"),
                        rs.getString("facility"),
                        rs.getString("city"),
                        rs.getString("state"),
                        rs.getString("phone1"),
                        rs.getString("phone2"),
                        rs.getString("fax"),
                        rs.getString("email"),
                        rs.getString("address1"),
                        rs.getString("zip")),
                userid);

        return rows.isEmpty() ? null : rows.get(0);
    }

    public int updateProfile(String userid, ProfileRow profile) {
        return jdbc.update(
                """
                UPDATE public.users
                SET fname = ?, lname = ?, facility = ?, city = ?, state = ?,
                    phone1 = ?, phone2 = ?, fax = ?, email = ?, address1 = ?, zip = ?
                WHERE userid = ?
                """,
                profile.fname(),
                profile.lname(),
                profile.facility(),
                profile.city(),
                profile.state(),
                profile.phone1(),
                profile.phone2(),
                profile.fax(),
                profile.email(),
                profile.address1(),
                profile.zip(),
                userid);
    }

    public boolean passwordMatches(String userid, String hashedPassword) {
        Integer count = jdbc.queryForObject(
                "SELECT COUNT(*) FROM public.users WHERE userid = ? AND password = ?",
                Integer.class,
                userid, hashedPassword);
        return count != null && count > 0;
    }

    public int updatePassword(String userid, String hashedPassword) {
        return jdbc.update(
                "UPDATE public.users SET password = ?, must_change_password = FALSE WHERE userid = ?",
                hashedPassword, userid);
    }

    public record ProfileRow(
            String userid,
            String fname,
            String lname,
            String facility,
            String city,
            String state,
            String phone1,
            String phone2,
            String fax,
            String email,
            String address1,
            String zip
    ) {}
}
