package org.nemours.gaitlab.repository;

import org.nemours.gaitlab.model.Age;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AgeRepository extends JpaRepository<Age, String> {
    List<Age> findAllByOrderByChronAsc();
}
