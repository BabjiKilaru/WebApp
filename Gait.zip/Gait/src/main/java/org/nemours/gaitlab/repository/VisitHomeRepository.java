package org.nemours.gaitlab.repository;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.nemours.gaitlab.model.VisitHomeDetails;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class VisitHomeRepository {

    private static final String VISIT_HOME_QUERY = """
            SELECT
                v.id AS id,
                v.pt_id AS "patientId",
                p.fname AS "firstName",
                p.lname AS "lastName",
                p.mrn AS mrn,
                p.dob AS "dateOfBirth",
                p.gender AS gender,
                v.date AS "visitDate",
                v.attendance AS attendance,
                COALESCE(TO_CHAR(v.start_time, 'FMHH12:MI AM'), NULLIF(TRIM(v.appt_time), ''))
                    AS "startTime",
                COALESCE(TO_CHAR(v.end_time, 'FMHH12:MI AM'), NULLIF(TRIM(v.appt_time_end), ''))
                    AS "endTime",
                CASE
                    WHEN vt.name IS NULL THEN v.visit_type
                    ELSE vt.name
                END AS "visitType",
                tg.name AS "visitSubType",
                v.date_scheduled AS "scheduledDate",
                NULLIF(TRIM(v.surgery_date), '') AS "surgeryDate",
                diagnosis.diagnosis AS diagnosis,
                v.comment AS "reasonForAnalysis",
                v.internal_comment AS "internalComment",
                COALESCE(md_signature.signed_time::date, pt_signature.signed_time::date, v.date_interp)
                    AS "interpretationDate",
                COALESCE(
                    NULLIF(CONCAT_WS(' ', md_user.fname, md_user.lname), ''),
                    NULLIF(CONCAT_WS(' ', interp_md.fname, interp_md.lname), ''))
                    AS "interpretationMd",
                COALESCE(
                    NULLIF(CONCAT_WS(' ', pt_user.fname, pt_user.lname), ''),
                    NULLIF(CONCAT_WS(' ', interp_pt.fname, interp_pt.lname), ''))
                    AS "interpretationPt",
                NULLIF(CONCAT_WS(' ', referring_doctor.fname, referring_doctor.lname), '')
                    AS "referringDoctor",
                v.date_refer_md AS "dateSent",
                NULLIF(CONCAT_WS(' ', visit_pt.fname, visit_pt.lname), '') AS "visitPt",
                NULLIF(CONCAT_WS(' ', visit_pt2.fname, visit_pt2.lname), '') AS "visitPt2",
                NULLIF(CONCAT_WS(' ', biomech.fname, biomech.lname), '') AS "visitBiomech",
                NULLIF(CONCAT_WS(' ', biomech2.fname, biomech2.lname), '') AS "visitBiomech2",
                NOT EXISTS (
                    SELECT 1 FROM public.data_questionnaire dq
                    WHERE dq.visit_id = v.id AND dq.q2_type = 'ch' AND dq.q2_026 IS NULL)
                    AS "modemsChildParentAvailable",
                NOT EXISTS (
                    SELECT 1 FROM public.data_questionnaire dq
                    WHERE dq.visit_id = v.id AND dq.q2_type = 'ap' AND dq.q2_026 IS NULL)
                    AS "modemsAdolescentParentAvailable",
                NOT EXISTS (
                    SELECT 1 FROM public.data_questionnaire dq
                    WHERE dq.visit_id = v.id AND dq.q2_type = 'as' AND dq.q2_026 IS NULL)
                    AS "modemsAdolescentSelfAvailable"
            FROM public.visits v
            JOIN public.patients p ON p.id = v.pt_id
            LEFT JOIN public.new_visit_type vt ON vt.id = v.visit_type_id
            LEFT JOIN public.new_test_group tg ON tg.id = v.test_group_id
            LEFT JOIN public.icd9 diagnosis ON diagnosis.id = v.icd9
            LEFT JOIN public.users referring_doctor ON referring_doctor.id = v.refer_md
            LEFT JOIN public.users interp_md ON interp_md.id = v.interp_md
            LEFT JOIN public.users interp_pt ON interp_pt.id = v.interp_pt
            LEFT JOIN public.users visit_pt ON visit_pt.id = v.visit_pt
            LEFT JOIN public.users visit_pt2 ON visit_pt2.id = v.visit_pt2
            LEFT JOIN public.users biomech ON biomech.id = v.biomech
            LEFT JOIN public.users biomech2 ON biomech2.id = v.biomech2
            LEFT JOIN public.clinician_signatures md_signature
                ON md_signature.id = v.interp_md_signature
            LEFT JOIN public.users md_user ON md_user.userid = md_signature.userid
            LEFT JOIN public.clinician_signatures pt_signature
                ON pt_signature.id = v.interp_pt_signature
            LEFT JOIN public.users pt_user ON pt_user.userid = pt_signature.userid
            WHERE v.id = ?
            """;

    private final JdbcTemplate jdbcTemplate;

    public VisitHomeRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public Optional<VisitHomeDetails> findByVisitId(Integer visitId) {
        List<VisitHomeDetails> results = jdbcTemplate.query(
                VISIT_HOME_QUERY,
                (resultSet, rowNumber) -> mapVisitHome(resultSet),
                visitId);
        return results.stream().findFirst();
    }

    private static VisitHomeDetails mapVisitHome(ResultSet resultSet) throws SQLException {
        return new VisitHomeDetails(
                resultSet.getInt("id"),
                resultSet.getInt("patientId"),
                resultSet.getString("firstName"),
                resultSet.getString("lastName"),
                resultSet.getString("mrn"),
                getLocalDate(resultSet, "dateOfBirth"),
                resultSet.getString("gender"),
                getLocalDate(resultSet, "visitDate"),
                resultSet.getString("attendance"),
                resultSet.getString("startTime"),
                resultSet.getString("endTime"),
                resultSet.getString("visitType"),
                resultSet.getString("visitSubType"),
                getLocalDate(resultSet, "scheduledDate"),
                resultSet.getString("surgeryDate"),
                resultSet.getString("diagnosis"),
                resultSet.getString("reasonForAnalysis"),
                resultSet.getString("internalComment"),
                getLocalDate(resultSet, "interpretationDate"),
                resultSet.getString("interpretationMd"),
                resultSet.getString("interpretationPt"),
                resultSet.getString("referringDoctor"),
                getLocalDate(resultSet, "dateSent"),
                resultSet.getString("visitPt"),
                resultSet.getString("visitPt2"),
                resultSet.getString("visitBiomech"),
                resultSet.getString("visitBiomech2"),
                resultSet.getBoolean("modemsChildParentAvailable"),
                resultSet.getBoolean("modemsAdolescentParentAvailable"),
                resultSet.getBoolean("modemsAdolescentSelfAvailable"));
    }

    private static LocalDate getLocalDate(ResultSet resultSet, String columnName) throws SQLException {
        Date date = resultSet.getDate(columnName);
        return date == null ? null : date.toLocalDate();
    }
}
