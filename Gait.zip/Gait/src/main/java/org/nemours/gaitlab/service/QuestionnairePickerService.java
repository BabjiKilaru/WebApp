package org.nemours.gaitlab.service;

import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import org.nemours.gaitlab.model.Patient;
import org.nemours.gaitlab.model.Visit;
import org.nemours.gaitlab.repository.PatientRepository;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.requests.AssembleQuestionnaireRequest;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class QuestionnairePickerService {

    private static final Integer GAIT_VISIT_TYPE = 1;
    private static final Integer UE_VISIT_TYPE = 2;
    private static final Integer RUNNING_VISIT_TYPE = 3;
    private static final Integer RESEARCH_VISIT_TYPE = 4;

    public record CodeAssignment(String code, Integer visitId) {}

    private final PatientRepository patientRepository;
    private final VisitRepository visitRepository;

    public QuestionnairePickerService(PatientRepository patientRepository, VisitRepository visitRepository) {
        this.patientRepository = patientRepository;
        this.visitRepository = visitRepository;
    }

    public List<CodeAssignment> assemble(Integer patientId, AssembleQuestionnaireRequest request) {
        if (request.visitId() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "visitId is required.");
        }

        Visit referenceVisit = visitRepository.findById(request.visitId()).orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Visit not found."));

        if (!referenceVisit.getPatientId().equals(patientId)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Visit does not belong to this patient.");
        }

        Patient patient = patientRepository.findById(patientId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Patient not found."));

        List<Visit> coincidentVisits = visitRepository.findByPatientIdAndDateOrderByIdAsc(patientId, referenceVisit.getDate());

        Visit gaitVisit = lastMatch(coincidentVisits, GAIT_VISIT_TYPE);

        if (referenceVisit.getVisitTypeId() == null) {
            gaitVisit = referenceVisit;
        }

        Visit ueVisit = lastMatch(coincidentVisits, UE_VISIT_TYPE);

        Visit primaryVisit = (gaitVisit != null && !gaitVisit.getId().equals(referenceVisit.getId())) ? gaitVisit : referenceVisit;

        List<String> selections = request.selections() == null ? List.of() : request.selections();
        List<CodeAssignment> assignments = new ArrayList<>();

        if (selections.contains("history")) {
            String historyPerson = patient.getHistoryPerson();
            String historyCode = historyPerson == null || historyPerson.isEmpty() ? "NEW_HISTORY" : "HISTORY";
            assignments.add(new CodeAssignment(historyCode, primaryVisit.getId()));

            if (gaitVisit != null) {
                assignments.add(new CodeAssignment("HISTORY_GAIT", gaitVisit.getId()));
            } else if (ueVisit == null && RESEARCH_VISIT_TYPE.equals(referenceVisit.getVisitTypeId())) {
                assignments.add(new CodeAssignment("HISTORY_GAIT", primaryVisit.getId()));
            }

            if (ueVisit != null) {
                assignments.add(new CodeAssignment("UE_HISTORY", ueVisit.getId()));
            }

            assignments.add(new CodeAssignment("HISTORY_CONCERNS", primaryVisit.getId()));
        }

        if (selections.contains("podci-parent")) {
            long age = ChronoUnit.YEARS.between(patient.getDateOfBirth(), primaryVisit.getDate());

            if (age >= 11) {
                assignments.add(new CodeAssignment("sp".equals(request.language()) ? "PODCI_CH" : "PODCI_AP", primaryVisit.getId()));
            } else {
                assignments.add(new CodeAssignment("PODCI_CH", primaryVisit.getId()));
            }
        }

        if (selections.contains("sports")) {
            Visit runningVisit = lastAttendedMatch(coincidentVisits, RUNNING_VISIT_TYPE);
            assignments.add(new CodeAssignment("SPORTS", runningVisit != null ? runningVisit.getId() : primaryVisit.getId()));
        }

        if (selections.contains("hip")) {
            assignments.add(new CodeAssignment("HIP", primaryVisit.getId()));
        }

        if (selections.contains("podci-self")) {
            assignments.add(new CodeAssignment("PODCI_AS", primaryVisit.getId()));
        }

        assignments.sort((a, b) -> Boolean.compare("PODCI_AS".equals(a.code()), "PODCI_AS".equals(b.code())));

        return assignments;
    }

    private static Visit lastMatch(List<Visit> visits, Integer visitTypeId) {
        Visit match = null;

        for (Visit visit : visits) {
            if (visitTypeId.equals(visit.getVisitTypeId())) {
                match = visit;
            }
        }

        return match;
    }

    private static Visit lastAttendedMatch(List<Visit> visits, Integer visitTypeId) {
        Visit match = null;
        for (Visit visit : visits) {
            if(visitTypeId.equals(visit.getVisitTypeId()) && !isNotAttended(visit.getAttendance())) {
                match = visit;
            }
        }

        return match;
    }

    private static boolean isNotAttended(String attendance) {
        return "No".equals(attendance) || "Cancel".equals(attendance);
    }
}