package org.nemours.gaitlab.controller;

import org.nemours.gaitlab.repository.AdminUserRepository;
import org.nemours.gaitlab.repository.AdminUserRepository.AdminUserRow;
import org.nemours.gaitlab.repository.AdminUserRepository.AdminUserDetails;
import org.nemours.gaitlab.requests.UpdateAdminUserRequest;
import org.nemours.gaitlab.requests.CreateAdminUserRequest;
import org.nemours.gaitlab.service.LegacyPasswordHasher;
import jakarta.validation.Valid;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

@RestController
@RequestMapping("/api/admin/users")
public class AdminUserController {
    private static final SecureRandom SECURE_RANDOM = new SecureRandom();
    private final AdminUserRepository adminUserRepository;

    public AdminUserController(AdminUserRepository adminUserRepository) {
        this.adminUserRepository = adminUserRepository;
    }

    @GetMapping
    public List<AdminUserRow> getUsers() {
        return adminUserRepository.findAllUsers();
    }

    @GetMapping("/availability")
    public UserAvailability checkAvailability(@RequestParam String userid) {
        if (!userid.matches("[A-Za-z0-9._-]{5,50}")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Enter a valid User ID.");
        }
        return new UserAvailability(userid, !adminUserRepository.userIdExists(userid));
    }

    @PostMapping
    @Transactional
    public ResponseEntity<CreateAdminUserResponse> createUser(
            @Valid @RequestBody CreateAdminUserRequest request) {
        String temporaryPassword = generateTemporaryPassword();
        try {
            if (adminUserRepository.createUser(request.userid(), request.details(),
                    LegacyPasswordHasher.hash(temporaryPassword)) == 0) {
                throw new ResponseStatusException(HttpStatus.CONFLICT, "User ID is already taken.");
            }
        } catch (DuplicateKeyException exception) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "User ID is already taken.", exception);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .cacheControl(CacheControl.noStore())
                .body(new CreateAdminUserResponse(getUser(request.userid()), temporaryPassword));
    }

    private static String generateTemporaryPassword() {
        byte[] bytes = new byte[9];
        SECURE_RANDOM.nextBytes(bytes);
        String password = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
        Arrays.fill(bytes, (byte) 0);
        return password;
    }

    public record CreateAdminUserResponse(AdminUserDetails user, String temporaryPassword) {}

    @PostMapping("/{userid}/temporary-password")
    @Transactional
    public ResponseEntity<TemporaryPasswordResponse> resetTemporaryPassword(@PathVariable String userid) {
        String temporaryPassword = generateTemporaryPassword();
        if (adminUserRepository.resetTemporaryPassword(userid, LegacyPasswordHasher.hash(temporaryPassword)) == 0) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found.");
        }
        return ResponseEntity.ok()
                .cacheControl(CacheControl.noStore())
                .body(new TemporaryPasswordResponse(temporaryPassword));
    }

    public record TemporaryPasswordResponse(String temporaryPassword) {}

    public record UserAvailability(String userid, boolean available) {}

    @GetMapping("/{userid}")
    public AdminUserDetails getUser(@PathVariable String userid) {
        AdminUserDetails user = adminUserRepository.findUser(userid);
        if (user == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found.");
        }
        return user;
    }

    @PutMapping("/{userid}")
    @Transactional
    public AdminUserDetails updateUser(
            @PathVariable String userid, @Valid @RequestBody UpdateAdminUserRequest request) {
        if (adminUserRepository.updateUser(userid, request) == 0) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found.");
        }
        return getUser(userid);
    }
}