package org.nemours.gaitlab.controller;

import org.nemours.gaitlab.requests.HipQuestionnaireRequest;
import org.nemours.gaitlab.service.HipQuestionnaireService;
import org.nemours.gaitlab.service.HipQuestionnaireService.HipQuestionnaireResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/patients/{patientId}/hip-questionnaire")
public class HipQuestionnaireController {

    private final HipQuestionnaireService service;

    public HipQuestionnaireController(HipQuestionnaireService service) {
        this.service = service;
    }

    @GetMapping("/{visitId}")
    public HipQuestionnaireResponse find(
            @PathVariable Integer patientId,
            @PathVariable Integer visitId) {
        return service.find(patientId, visitId);
    }

    @PostMapping
    public ResponseEntity<Void> save(
            @PathVariable Integer patientId,
            @RequestBody HipQuestionnaireRequest request) {
        service.save(patientId, request);
        return ResponseEntity.noContent().build();
    }
}