package org.nemours.gaitlab.model;

import jakarta.persistence.*;

@Entity
@Table(
    name = "surgeries",
    schema = "public"
)
public class Surgery {
    @Id
    @Column(name = "code")
    private String code;

    @Column(name = "name")
    private String name;

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }
}
