package org.nemours.gaitlab.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class InterpretationRepository {
    private final JdbcTemplate jdbc;

    public InterpretationRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public enum Measurements {
        GAIT("non_pt_data", "1,3,6,10,23,24,27,28,33,37,44"),
        BALANCE("balance_data", "45"),
        UPPER_EXTREMITY("data_ue", "47,48,49,50,51,52,53,54,55,56,57"),
        FOOT_MODEL("data_footmodel", "46"),
        FOOT_PRESSURE("footp_data", "12"),
        METABOLIC("metabolic_data", "31");

        private final String table;
        private final String groups;

        Measurements(String table, String groups) {
            this.table = table;
            this.groups = groups;
        }

        private String fromClause() {
            return """
                    FROM public.%s d
                    JOIN public.visit_condition c ON c.id = d.visit_condition_id
                    JOIN public.non_pt_interp_fields f ON f.param_name = d.name
                    WHERE c.visit_id = ? AND f.hide = false AND f.group_id IN (%s)
                    """.formatted(table, groups)
                    + (this == BALANCE
                        ? " AND f.param_name NOT IN ('L_Gdi_Mean','R_Gdi_Mean','Overall_Rms_Mean')"
                        : this == GAIT ? " AND LOWER(f.param_name) NOT LIKE '%_null_%'" : "");
        }
    }

    public boolean hasMeasurements(int visitId, Measurements measurements) {
        return Boolean.TRUE.equals(jdbc.queryForObject(
                "SELECT EXISTS (SELECT 1 " + measurements.fromClause() + ")", Boolean.class, visitId));
    }

    public boolean hasFirstCondition(int visitId) {
        return Boolean.TRUE.equals(jdbc.queryForObject("""
                SELECT EXISTS (SELECT 1 FROM public.visit_condition WHERE visit_id = ? AND ordinal = 1)
                """, Boolean.class, visitId));
    }

}
