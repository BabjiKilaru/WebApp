package org.nemours.gaitlab.repository;

import org.nemours.gaitlab.model.VisitTest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface VisitTestRepository extends JpaRepository<VisitTest, Integer>{

}
