package org.nemours.gaitlab.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class QuestionnaireTrackingRepository {

    private final JdbcTemplate jdbc;

    public QuestionnaireTrackingRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void insert(int visitId, String descriptor, Integer sessionId) {
        jdbc.update(
            "INSERT INTO public.q_track (visit_id, descriptor, time, session_id) VALUES (?, ?, now(), ?)",
            visitId, descriptor, sessionId);
    }
}