package org.nemours.gaitlab.repository;

import java.util.List;
import java.util.Map;

import org.nemours.gaitlab.service.LegacyPasswordHasher;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class AuthRepository {
    private final JdbcTemplate jdbc;

    public AuthRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Map<String, Object> findActiveUser(String userid, String hashedPassword) {
        List<Map<String, Object>> rows = jdbc.queryForList(
            "SELECT userid, access, fname, lname, "
                + "(must_change_password OR password = ?) AS must_change_password FROM public.users "
                + "WHERE userid = ? AND password = ? "
                + "AND active = TRUE "
                + "AND (expiration IS NULL OR expiration > CURRENT_TIMESTAMP)",
            LegacyPasswordHasher.LEGACY_DEFAULT_PASSWORD_HASH,
            userid, hashedPassword);

        return rows.isEmpty() ? null : rows.get(0);
    }

    public boolean mustChangePassword(String userid) {
        Integer count = jdbc.queryForObject(
                "SELECT COUNT(*) FROM public.users WHERE userid = ? "
                        + "AND (must_change_password = TRUE OR password = ?)",
                Integer.class, userid,
                LegacyPasswordHasher.LEGACY_DEFAULT_PASSWORD_HASH);
        return count != null && count > 0;
    }

    public Integer findUserId(String userid) {
        List<Integer> ids = jdbc.queryForList(
            "SELECT id FROM public.users WHERE userid = ?",
            Integer.class,
            userid);

        return ids.isEmpty() ? null : ids.get(0);
    }

    public UserNames findUserNames(String userid) {
        List<UserNames> rows = jdbc.query(
            "SELECT fname, lname FROM public.users WHERE userid = ?",
            (rs, rowNum) -> new UserNames(rs.getString("fname"), rs.getString("lname")),
            userid);

        return rows.isEmpty() ? null : rows.get(0);
    }

    public record UserNames(String firstName, String lastName) {}
}