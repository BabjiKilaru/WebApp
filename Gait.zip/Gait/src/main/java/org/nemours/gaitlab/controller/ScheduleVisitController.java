package org.nemours.gaitlab.controller;

import org.nemours.gaitlab.model.ScheduleVisit;
import org.nemours.gaitlab.model.Visit;

import org.nemours.gaitlab.service.ScheduleVisitService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.security.Principal;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/schedule-visit")
public class ScheduleVisitController {

    private final ScheduleVisitService service;

    public ScheduleVisitController(ScheduleVisitService service) {
        this.service = service;
    }

    @GetMapping("/visit-types")
    public List<Map<String, Object>> getVisitTypes() {
        return service.getVisitTypes();
    }

    @GetMapping("/visit-sub-types")
    public List<Map<String, Object>> getVisitSubTypes() {
        return service.getVisitSubTypes();
    }

    @GetMapping("/tests")
    public List<Map<String, Object>> getTests() {
        return service.getTests();
    }

    @GetMapping("/referring-doctors")
    public List<Map<String, Object>> getReferringDoctors() {
        return service.getReferringDoctors();
    }

    @GetMapping("/visit-sub-types/{groupId}/default-tests")
    public List<String> getDefaultTestsForGroup(@PathVariable Integer groupId) {
        return service.getDefaultTestsForGroup(groupId);
    }

    @GetMapping("/scheduled-visits")
    public List<Map<String, Object>> getScheduledVisits(
            @RequestParam
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate date) {
        return service.getScheduledVisits(date);
    }

    @PostMapping("/patients/{patientId}")
    public Visit createVisit(
            @PathVariable Integer patientId,
            @RequestBody ScheduleVisit request,
            Principal principal) {
        return service.createVisit(patientId, request, principal.getName());
    }
}