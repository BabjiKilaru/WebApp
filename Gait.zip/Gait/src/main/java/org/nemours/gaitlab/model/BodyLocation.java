package org.nemours.gaitlab.model;

import jakarta.persistence.*;

@Entity
@Table(name = "body_loc", schema = "public")
public class BodyLocation {
    @Id
    @Column(name = "location")
    private String location;

    public String getLocation() {
        return location;
    }
}