package org.nemours.gaitlab.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

@Entity
@Table(name = "pt_surgeries", schema = "public")
public class PtSurgery {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "surgSeqGen")
    @SequenceGenerator(name = "surgSeqGen", sequenceName = "surg_seq", allocationSize = 1)
    @Column(name = "id")
    private Integer id;

    @Column(name = "pt_id")
    private Integer patientId;

    @Column(name = "date")
    private String date;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "procedure", referencedColumnName = "code")
    private Surgery procedure;

    @Column(name = "side")
    private String side;

    @Column(name = "md")
    private String surgeon;

    @Column(name = "facility")
    private String facility;

    @Column(name = "comment")
    private String comment;

    public Integer getId() {
        return id;
    }

    @JsonIgnore
    public Integer getPatientId() {
        return patientId;
    }

    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setProcedure(Surgery procedure) {
        this.procedure = procedure;
    }

    public String getProcedureCode() {
        return procedure != null ? procedure.getCode() : null;
    }

    public String getProcedureName() {
        return procedure != null ? procedure.getName() : null;
    }

    public String getSide() {
        return side;
    }

    public void setSide(String side) {
        this.side = side;
    }

    public String getSurgeon() {
        return surgeon;
    }

    public void setSurgeon(String surgeon) {
        this.surgeon = surgeon;
    }

    public String getFacility() {
        return facility;
    }

    public void setFacility(String facility) {
        this.facility = facility;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
