package org.nemours.gaitlab.controller;

import org.nemours.gaitlab.model.PtBotox;
import org.nemours.gaitlab.model.PtHealthCondition;
import org.nemours.gaitlab.model.PtHealthHistory;
import org.nemours.gaitlab.model.PtSurgery;
import org.nemours.gaitlab.model.Condition;
import org.nemours.gaitlab.model.HistoryCondition;
import org.nemours.gaitlab.model.Surgery;
import org.nemours.gaitlab.repository.ConditionRepository;
import org.nemours.gaitlab.repository.HistoryConditionRepository;
import org.nemours.gaitlab.repository.PtBotoxRepository;
import org.nemours.gaitlab.repository.PtHealthConditionRepository;
import org.nemours.gaitlab.repository.PtHealthHistoryRepository;
import org.nemours.gaitlab.repository.PtSurgeryRepository;
import org.nemours.gaitlab.repository.SurgeryRepository;
import org.nemours.gaitlab.requests.CreateBotoxRequest;
import org.nemours.gaitlab.requests.CreateHealthConditionRequest;
import org.nemours.gaitlab.requests.CreateHealthHistoryRequest;
import org.nemours.gaitlab.requests.CreateSurgeryRequest;
import org.nemours.gaitlab.response.PatientHistoryResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api")
public class PatientHistoryController {
    private final PtSurgeryRepository ptSurgeryRepository;
    private final PtBotoxRepository ptBotoxRepository;
    private final PtHealthHistoryRepository ptHealthHistoryRepository;
    private final PtHealthConditionRepository ptHealthConditionRepository;
    private final SurgeryRepository surgeryRepository;
    private final HistoryConditionRepository historyConditionRepository;
    private final ConditionRepository conditionRepository;

    public PatientHistoryController(
            PtSurgeryRepository ptSurgeryRepository,
            PtBotoxRepository ptBotoxRepository,
            PtHealthHistoryRepository ptHealthHistoryRepository,
            PtHealthConditionRepository ptHealthConditionRepository,
            SurgeryRepository surgeryRepository,
            HistoryConditionRepository historyConditionRepository,
            ConditionRepository conditionRepository) {
        this.ptSurgeryRepository = ptSurgeryRepository;
        this.ptBotoxRepository = ptBotoxRepository;
        this.ptHealthHistoryRepository = ptHealthHistoryRepository;
        this.ptHealthConditionRepository = ptHealthConditionRepository;
        this.surgeryRepository = surgeryRepository;
        this.historyConditionRepository = historyConditionRepository;
        this.conditionRepository = conditionRepository;
    }

    @GetMapping("/patients/{patientId}/history")
    public PatientHistoryResponse getPatientHistory(
            @PathVariable Integer patientId) {
        return new PatientHistoryResponse(
                ptSurgeryRepository.findByPatientIdOrderByDateDesc(patientId),
                ptBotoxRepository.findByPatientIdOrderByDateAsc(patientId),
                ptHealthHistoryRepository.findByPatientIdOrderByAgeAsc(patientId),
                ptHealthConditionRepository.findByPatientIdOrderByCondition_CodeAsc(patientId));
    }

    @PostMapping("/patients/{patientId}/history/surgeries")
    @ResponseStatus(HttpStatus.CREATED)
    public PtSurgery createSurgery(
            @PathVariable Integer patientId,
            @RequestBody CreateSurgeryRequest request) {
        Surgery procedure = surgeryRepository.findById(request.procedureCode())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.BAD_REQUEST, "Unknown procedure code: " + request.procedureCode()));

        PtSurgery surgery = new PtSurgery();
        surgery.setPatientId(patientId);
        surgery.setDate(request.date());
        surgery.setProcedure(procedure);
        surgery.setSide(request.side());
        surgery.setSurgeon(request.surgeon());
        surgery.setFacility(request.facility());
        surgery.setComment(request.comment());

        return ptSurgeryRepository.save(surgery);
    }

    @PutMapping("/patients/{patientId}/history/surgeries/{id}")
    public ResponseEntity<PtSurgery> updateSurgery(
            @PathVariable Integer patientId,
            @PathVariable Integer id,
            @RequestBody CreateSurgeryRequest request) {
        return ptSurgeryRepository.findById(id)
                .filter(surgery -> surgery.getPatientId().equals(patientId))
                .map(surgery -> {
                    Surgery procedure = surgeryRepository.findById(request.procedureCode())
                            .orElseThrow(() -> new ResponseStatusException(
                                    HttpStatus.BAD_REQUEST, "Unknown procedure code: " + request.procedureCode()));

                    surgery.setDate(request.date());
                    surgery.setProcedure(procedure);
                    surgery.setSide(request.side());
                    surgery.setSurgeon(request.surgeon());
                    surgery.setFacility(request.facility());
                    surgery.setComment(request.comment());

                    return ResponseEntity.ok(ptSurgeryRepository.save(surgery));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/patients/{patientId}/history/botox")
    @ResponseStatus(HttpStatus.CREATED)
    public PtBotox createBotox(
            @PathVariable Integer patientId,
            @RequestBody CreateBotoxRequest request) {
        PtBotox botox = new PtBotox();
        botox.setPatientId(patientId);
        botox.setDate(request.date());
        botox.setBodyLocation(request.bodyLocation());
        botox.setSide(request.side());
        botox.setFacility(request.facility());
        botox.setPhysician(request.physician());

        return ptBotoxRepository.save(botox);
    }

    @PutMapping("/patients/{patientId}/history/botox/{id}")
    public ResponseEntity<PtBotox> updateBotox(
            @PathVariable Integer patientId,
            @PathVariable Integer id,
            @RequestBody CreateBotoxRequest request) {
        return ptBotoxRepository.findById(id)
                .filter(botox -> botox.getPatientId().equals(patientId))
                .map(botox -> {
                    botox.setDate(request.date());
                    botox.setBodyLocation(request.bodyLocation());
                    botox.setSide(request.side());
                    botox.setFacility(request.facility());
                    botox.setPhysician(request.physician());

                    return ResponseEntity.ok(ptBotoxRepository.save(botox));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/patients/{patientId}/history/botox/{id}")
    public ResponseEntity<Void> deleteBotox(
            @PathVariable Integer patientId,
            @PathVariable Integer id) {
        return ptBotoxRepository.findById(id)
                .filter(botox -> botox.getPatientId().equals(patientId))
                .map(botox -> {
                    ptBotoxRepository.delete(botox);
                    return ResponseEntity.noContent().<Void>build();
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/patients/{patientId}/history/health-history")
    @ResponseStatus(HttpStatus.CREATED)
    public PtHealthHistory createHealthHistory(
            @PathVariable Integer patientId,
            @RequestBody CreateHealthHistoryRequest request) {
        HistoryCondition condition = historyConditionRepository.findById(request.conditionCode())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.BAD_REQUEST, "Unknown condition code: " + request.conditionCode()));

        PtHealthHistory healthHistory = new PtHealthHistory();
        healthHistory.setPatientId(patientId);
        healthHistory.setAge(request.age());
        healthHistory.setCondition(condition);

        return ptHealthHistoryRepository.save(healthHistory);
    }

    @PutMapping("/patients/{patientId}/history/health-history/{id}")
    public ResponseEntity<PtHealthHistory> updateHealthHistory(
            @PathVariable Integer patientId,
            @PathVariable Integer id,
            @RequestBody CreateHealthHistoryRequest request) {
        return ptHealthHistoryRepository.findById(id)
                .filter(healthHistory -> healthHistory.getPatientId().equals(patientId))
                .map(healthHistory -> {
                    HistoryCondition condition = historyConditionRepository.findById(request.conditionCode())
                            .orElseThrow(() -> new ResponseStatusException(
                                    HttpStatus.BAD_REQUEST, "Unknown condition code: " + request.conditionCode()));

                    healthHistory.setAge(request.age());
                    healthHistory.setCondition(condition);

                    return ResponseEntity.ok(ptHealthHistoryRepository.save(healthHistory));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/patients/{patientId}/history/health-history/{id}")
    public ResponseEntity<Void> deleteHealthHistory(
            @PathVariable Integer patientId,
            @PathVariable Integer id) {
        return ptHealthHistoryRepository.findById(id)
                .filter(healthHistory -> healthHistory.getPatientId().equals(patientId))
                .map(healthHistory -> {
                    ptHealthHistoryRepository.delete(healthHistory);
                    return ResponseEntity.noContent().<Void>build();
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/patients/{patientId}/history/health-conditions")
    @ResponseStatus(HttpStatus.CREATED)
    public PtHealthCondition createHealthCondition(
            @PathVariable Integer patientId,
            @RequestBody CreateHealthConditionRequest request) {
        Condition condition = conditionRepository.findById(request.conditionCode())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.BAD_REQUEST, "Unknown condition code: " + request.conditionCode()));

        PtHealthCondition healthCondition = new PtHealthCondition();
        healthCondition.setPatientId(patientId);
        healthCondition.setCondition(condition);

        return ptHealthConditionRepository.save(healthCondition);
    }

    @PutMapping("/patients/{patientId}/history/health-conditions/{id}")
    public ResponseEntity<PtHealthCondition> updateHealthCondition(
            @PathVariable Integer patientId,
            @PathVariable Integer id,
            @RequestBody CreateHealthConditionRequest request) {
        return ptHealthConditionRepository.findById(id)
                .filter(healthCondition -> healthCondition.getPatientId().equals(patientId))
                .map(healthCondition -> {
                    Condition condition = conditionRepository.findById(request.conditionCode())
                            .orElseThrow(() -> new ResponseStatusException(
                                    HttpStatus.BAD_REQUEST, "Unknown condition code: " + request.conditionCode()));

                    healthCondition.setCondition(condition);

                    return ResponseEntity.ok(ptHealthConditionRepository.save(healthCondition));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/patients/{patientId}/history/health-conditions/{id}")
    public ResponseEntity<Void> deleteHealthCondition(
            @PathVariable Integer patientId,
            @PathVariable Integer id) {
        return ptHealthConditionRepository.findById(id)
                .filter(healthCondition -> healthCondition.getPatientId().equals(patientId))
                .map(healthCondition -> {
                    ptHealthConditionRepository.delete(healthCondition);
                    return ResponseEntity.noContent().<Void>build();
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/patients/{patientId}/history/surgeries/{id}")
    public ResponseEntity<Void> deleteSurgery(
            @PathVariable Integer patientId,
            @PathVariable Integer id) {
        return ptSurgeryRepository.findById(id)
                .filter(surgery -> surgery.getPatientId().equals(patientId))
                .map(surgery -> {
                    ptSurgeryRepository.delete(surgery);
                    return ResponseEntity.noContent().<Void>build();
                })
                .orElse(ResponseEntity.notFound().build());
    }
}
