package org.nemours.gaitlab.controller;

import java.util.List;

import org.nemours.gaitlab.service.QuestionnairePickerService.CodeAssignment;
import org.nemours.gaitlab.service.QuestionnaireTrackingService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/patients/{patientId}/questionnaire-tracking")
public class QuestionnaireTrackingController {

    private final QuestionnaireTrackingService service;

    public QuestionnaireTrackingController(QuestionnaireTrackingService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Void> track(
            @PathVariable Integer patientId,
            @RequestBody List<CodeAssignment> assignments) {
        service.track(patientId, assignments);
        return ResponseEntity.noContent().build();
    }
}