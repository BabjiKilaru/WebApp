package org.nemours.gaitlab.requests;

import java.util.List;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public record FormsVisitRequest(
    @NotNull 
    Integer visitId,

    @NotEmpty 
    List<@NotBlank String> forms
) {

}
