package org.nemours.gaitlab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GaitlabApplication {

    public static void main(String[] args) {
        SpringApplication.run(GaitlabApplication.class, args);
    }
}
