package org.nemours.gaitlab.repository;

import org.nemours.gaitlab.model.PtSurgery;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PtSurgeryRepository extends JpaRepository<PtSurgery, Integer> {
    List<PtSurgery> findByPatientIdOrderByDateDesc(Integer patientId);
}
