package org.nemours.gaitlab.controller;

import org.nemours.gaitlab.requests.UeHistoryQuestionnaireRequest;
import org.nemours.gaitlab.service.UeHistoryQuestionnaireService;
import org.nemours.gaitlab.service.UeHistoryQuestionnaireService.UeHistoryQuestionnaireResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/patients/{patientId}/ue-history-questionnaire")
public class UeHistoryQuestionnaireController {

    private final UeHistoryQuestionnaireService service;

    public UeHistoryQuestionnaireController(UeHistoryQuestionnaireService service) {
        this.service = service;
    }

    @GetMapping("/{visitId}")
    public UeHistoryQuestionnaireResponse find(
            Authentication authentication,
            @PathVariable Integer patientId,
            @PathVariable Integer visitId,
            @RequestParam(defaultValue = "en") String language) {
        return service.find(patientId, visitId, language, authentication.getName());
    }

    @PostMapping
    public ResponseEntity<Void> save(
            @PathVariable Integer patientId,
            @RequestBody UeHistoryQuestionnaireRequest request) {
        service.save(patientId, request);
        return ResponseEntity.noContent().build();
    }
}
