package org.nemours.gaitlab.requests;

import java.time.LocalDateTime;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record UpdateAdminUserRequest(
        @NotBlank @Size(max = 50) String fname,
        @NotBlank @Size(max = 50) String lname,
        @NotBlank @Pattern(regexp = "C|R|T") String purpose,
        @Pattern(regexp = "BIO|BME|DO|MD|OT|PT|Other") String clinType,
        String specialty,
        @Size(max = 100) String facility,
        @Size(max = 25) String phone1,
        @Size(max = 25) String phone2,
        @Size(max = 25) String fax,
        @Email @Size(max = 254) String email,
        @Size(max = 200) String address1,
        String address2,
        @Size(max = 50) String city,
        @Size(max = 50) String state,
        @Size(max = 10) String zip,
        String credentials,
        @Pattern(regexp = "user|admin|internal|NONE") String access,
        @NotNull Boolean userAdmin,
        @NotNull Boolean active,
        LocalDateTime expiration,
        @Pattern(regexp = "P|T|O") String category
) {
}
