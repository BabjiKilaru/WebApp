package org.nemours.gaitlab.service;

import java.util.List;
import java.util.Map;

import org.nemours.gaitlab.repository.AuthRepository;
import org.nemours.gaitlab.repository.SportsQuestionnaireRepository;
import org.nemours.gaitlab.requests.SportsQuestionnaireRequest;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
public class SportsQuestionnaireService {

    private static final int Q_PHYSICAL_THERAPY = 1;
    private static final int Q_COMPETITIVE_SPORTS = 2;
    private static final int Q_YEARS_IN_SPORT = 3;
    private static final int Q_DAYS_PER_WEEK = 4;
    private static final int Q_ORTHOTICS = 5;
    private static final int Q_PAIN_LOCATIONS = 6;
    private static final int Q_MILE_TIME = 7;
    private static final int Q_GOALS = 8;
    private static final int Q_REPORTING_PERSON = 60;

    private final SportsQuestionnaireRepository repository;
    private final AuthRepository authRepository;

    public SportsQuestionnaireService(SportsQuestionnaireRepository repository, AuthRepository authRepository) {
        this.repository = repository;
        this.authRepository = authRepository;
    }

    @Transactional
    public void save(int patientId, SportsQuestionnaireRequest request) {
        if (request.visitId() == null) {
            throw bad("visitId is required.");
        }

        Integer visitPatientId = repository.findVisitPatientId(request.visitId());

        if (visitPatientId == null) {
            throw bad("Visit not found.");
        }

        if (!visitPatientId.equals(patientId)) {
            throw bad("Visit does not belong to this patient.");
        }

        if (request.sessionId() == null || !repository.isSessionForVisit(request.visitId(), request.sessionId())) {
            throw bad("A valid questionnaire session is required.");
        }

        int sessionId = request.sessionId();
        int languageId = languageId(request.language());

        saveFreeText(sessionId, request.visitId(), Q_REPORTING_PERSON, request.reportingPerson());
        saveChoice(sessionId, request.visitId(), Q_PHYSICAL_THERAPY, request.physicalTherapy(), languageId);
        saveFreeText(sessionId, request.visitId(), Q_COMPETITIVE_SPORTS, request.competitiveSports());
        saveChoice(sessionId, request.visitId(), Q_YEARS_IN_SPORT, request.yearsInSport(), languageId);
        saveChoice(sessionId, request.visitId(), Q_DAYS_PER_WEEK, request.daysPerWeek(), languageId);
        saveChoice(sessionId, request.visitId(), Q_ORTHOTICS, request.orthotics(), languageId);
        saveMultiChoice(sessionId, request.visitId(), Q_PAIN_LOCATIONS, request.painLocations(), languageId);
        saveMileTime(sessionId, request.visitId(), request.mileTimeKnown(), request.mileTime(), languageId);
        saveFreeText(sessionId, request.visitId(), Q_GOALS, request.goals());
        repository.advanceSessionGroup(sessionId);
    }

    public record SportsQuestionnaireResponse(
            int sessionId,
            String reportingPerson,
            String physicalTherapy,
            String competitiveSports,
            String yearsInSport,
            String daysPerWeek,
            String orthotics,
            List<String> painLocations,
            String mileTimeKnown,
            String mileTime,
            String goals) {}

    @Transactional
    public SportsQuestionnaireResponse find(int patientId, int visitId, String language, String userid) {
        Integer visitPatientId = repository.findVisitPatientId(visitId);

        if (visitPatientId == null) {
            throw bad("Visit not found.");
        }

        if (!visitPatientId.equals(patientId)) {
            throw bad("Visit does not belong to this patient.");
        }

        Integer authId = authRepository.findUserId(userid);
        if (authId == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Signed-in user not found.");
        }

        int sessionId = repository.startSession(visitId, languageId(language), authId);

        Map<String, Object> mileTimeAnswer = repository.findActiveChoiceWithText(visitId, Q_MILE_TIME);
        String mileTimeKnown = null;
        String mileTime = null;

        if (mileTimeAnswer != null) {
            String label = (String) mileTimeAnswer.get("label");

            if ("Unknown".equals(label)) {
                mileTimeKnown = "unknown";
            } else if ("Time".equals(label)) {
                mileTimeKnown = "known";
                mileTime = (String) mileTimeAnswer.get("free_text");
            }
        }

        return new SportsQuestionnaireResponse(
            sessionId,
            repository.findActiveFreeText(visitId, Q_REPORTING_PERSON),
            firstOrNull(repository.findActiveAnswerLabels(visitId, Q_PHYSICAL_THERAPY)),
            repository.findActiveFreeText(visitId, Q_COMPETITIVE_SPORTS),
            firstOrNull(repository.findActiveAnswerLabels(visitId, Q_YEARS_IN_SPORT)),
            firstOrNull(repository.findActiveAnswerLabels(visitId, Q_DAYS_PER_WEEK)),
            firstOrNull(repository.findActiveAnswerLabels(visitId, Q_ORTHOTICS)),
            repository.findActiveAnswerLabels(visitId, Q_PAIN_LOCATIONS),
            mileTimeKnown,
            mileTime,
            repository.findActiveFreeText(visitId, Q_GOALS));
    }

    private static String firstOrNull(List<String> values) {
        return values.isEmpty() ? null : values.get(0);
    }

    private void saveFreeText(int sessionId, int visitId, int questionId, String value) {
        repository.deactivateActiveAnswers(visitId, questionId);
        if (value == null || value.isBlank()) {
            return;
        }
        
        Integer answerId = repository.findTextAnswerId(questionId);

        repository.insertAnswer(sessionId, questionId, answerId, value);
    }

    private void saveChoice(int sessionId, int visitId, int questionId, String value, int languageId) {
        repository.deactivateActiveAnswers(visitId, questionId);
        if (value == null || value.isBlank()) {
            return;
        }

        Integer answerId = repository.resolveAnswerId(questionId, value, languageId);

        if (answerId == null) {
            throw bad("Could not resolve answer for question " + questionId + ": " + value);
        }

        repository.insertAnswer(sessionId, questionId, answerId, null);
    }

    private void saveMultiChoice(int sessionId, int visitId, int questionId, List<String> values, int languageId) {
        repository.deactivateActiveAnswers(visitId, questionId);
        if (values == null || values.isEmpty()) {
            return;
        }

        for (String value : values) {
            Integer answerId = repository.resolveAnswerId(questionId, value, languageId);

            if (answerId == null) {
                throw bad("Could not resolve answer for question " + questionId + ": " + value);
            }

            repository.insertAnswer(sessionId, questionId, answerId, null);
        }
    }

    private void saveMileTime(int sessionId, int visitId, String mileTimeKnown, String mileTime, int languageId) {
        repository.deactivateActiveAnswers(visitId, Q_MILE_TIME);
        if (mileTimeKnown == null || mileTimeKnown.isBlank()) {
            return;
        }

        String text;

        if ("unknown".equals(mileTimeKnown)) {
            text = "Unknown";
        } else if ("known".equals(mileTimeKnown)) {
            text = "Time";
        } else {
            throw bad("mileTimeKnown must be 'unknown' or 'known'.");
        }

        Integer answerId = repository.resolveAnswerId(Q_MILE_TIME, text, languageId);

        if (answerId == null) {
            throw bad("Could not resolve mile time answer: " + text);
        }

        String answerText = "known".equals(mileTimeKnown) ? mileTime : null;

        repository.insertAnswer(sessionId, Q_MILE_TIME, answerId, answerText);
    }

    private static ResponseStatusException bad(String reason) {
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, reason);
    }

    private static int languageId(String language) {
        if (language == null || language.isBlank() || "en".equals(language)) {
            return 1;
        }
        if ("sp".equals(language)) {
            return 2;
        }
        throw bad("language must be 'en' or 'sp'.");
    }
}