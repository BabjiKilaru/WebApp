package org.nemours.gaitlab.requests;

public record ChangePasswordRequest(
    String currentPassword,
    String newPassword,
    String confirmPassword
) {}
