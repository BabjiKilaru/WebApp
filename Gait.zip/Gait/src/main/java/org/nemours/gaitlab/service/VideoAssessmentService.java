package org.nemours.gaitlab.service;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.nemours.gaitlab.repository.VideoAssessmentRepository;
import org.nemours.gaitlab.repository.VideoAssessmentRepository.*;
import org.nemours.gaitlab.requests.VideoAssessmentSaveRequest;
import org.nemours.gaitlab.response.VideoAssessmentResponse;
import org.nemours.gaitlab.response.VideoAssessmentResponse.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import tools.jackson.databind.ObjectMapper;

@Service
public class VideoAssessmentService {
    private final VideoAssessmentRepository repository;
    private final ObjectMapper json;

    public VideoAssessmentService(VideoAssessmentRepository repository, ObjectMapper json) {
        this.repository = repository;
        this.json = json;
    }

    private record Binding(int questionId, Integer answerId) {}
    private record Snapshot(VideoAssessmentResponse response, Map<Integer, Binding> bindings) {}

    @Transactional(readOnly = true, isolation = Isolation.REPEATABLE_READ)
    public VideoAssessmentResponse getAssessment(int patientId, int visitId) {
        return load(patientId, requireVisit(patientId, visitId, false)).response();
    }

    @Transactional
    public VideoAssessmentResponse saveAssessment(int patientId, int visitId, String username,
            VideoAssessmentSaveRequest request) {
        if (username == null || username.isBlank()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Sign in to save an assessment.");
        }
        Integer actor = repository.findSavingActor(username);
        if (actor == null) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "This account cannot save assessments.");
        }
        VisitRow visit = requireVisit(patientId, visitId, true);
        Snapshot snapshot = load(patientId, visit);
        var current = snapshot.response();
        if (request == null || request.revision() == null || request.groups() == null) {
            throw bad("A revision and complete groups are required.");
        }
        if (!request.revision().equals(current.revision())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Assessment changed. Reload before saving.");
        }
        validate(current, request);
        Map<Integer, VideoAssessmentSaveRequest.Group> submitted = new HashMap<>();
        request.groups().forEach(g -> submitted.put(g.id(), g));
        Integer sessionId = null;
        for (Group group : current.groups()) {
            var input = submitted.get(group.id());
            if (!Objects.equals(group.comments(), input.comments())) {
                repository.saveComment(visitId, group.id(), input.comments());
            }
            Map<Integer, String> values = new HashMap<>();
            input.fields().forEach(f -> values.put(f.id(), f.choice()));
            for (Field field : group.fields()) {
                String value = values.get(field.id());
                if (Objects.equals(value, field.choice())) continue;
                if (current.questionnaireId() == null) {
                    repository.saveStandardField(visitId, field.paramName(), value);
                } else {
                    if (sessionId == null) {
                        sessionId = repository.startSession(visitId, current.questionnaireId(), actor, group.id());
                    }
                    Binding binding = snapshot.bindings().get(field.id());
                    boolean checkbox = field.controlType().equals("CHECKBOX");
                    boolean active = value != null && (!checkbox || value.equals("Y"));
                    repository.saveAnswer(visitId, current.questionnaireId(), sessionId,
                            binding.questionId(), binding.answerId(),
                            checkbox || field.controlType().equals("NUMBER") ? null : value,
                            field.controlType().equals("NUMBER") && value != null ? new BigDecimal(value) : null,
                            checkbox && value != null ? value.equals("Y") : null, active);
                }
            }
        }
        return load(patientId, visit).response();
    }

    private VisitRow requireVisit(int patientId, int visitId, boolean lock) {
        VisitRow visit = repository.findVisit(patientId, visitId, lock);
        if (visit == null) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Visit not found for this patient.");
        return visit;
    }

    private Snapshot load(int patientId, VisitRow visit) {
        Integer type = visit.visitTypeId();
        Integer questionnaire = Integer.valueOf(3).equals(type) ? Integer.valueOf(3)
                : Integer.valueOf(2).equals(type) ? Integer.valueOf(6) : null;
        Map<Integer, Binding> bindings = new HashMap<>();
        List<Group> groups = questionnaire == null ? standardGroups(visit.id())
                : questionnaireGroups(visit.id(), questionnaire, bindings);
        var response = new VideoAssessmentResponse(patientId, visit.id(), type,
                questionnaire == null ? "STANDARD" : questionnaire == 3 ? "RUNNING" : "UPPER_EXTREMITY",
                questionnaire, null, groups);
        return new Snapshot(new VideoAssessmentResponse(patientId, visit.id(), type, response.assessmentType(),
                questionnaire, revision(response), groups), bindings);
    }

    private List<Group> standardGroups(int visitId) {
        Map<Integer, List<Field>> fields = new HashMap<>();
        for (var row : repository.findFields(visitId)) {
            if (row.groupId() < 2 || row.groupId() > 13) continue;
            String control = row.groupId() == 12 ? "SINGLE_SELECT"
                    : Set.of(2, 4, 5, 6).contains(row.groupId()) ? "CHECKBOX" : "LATERALITY";
            fields.computeIfAbsent(row.groupId(), k -> new ArrayList<>()).add(new Field(row.id(), row.paramName(),
                    row.displayName(), row.order(), row.choice(), control, List.of(), null, false));
        }
        Map<Integer, String> comments = new HashMap<>();
        repository.findComments(visitId).forEach(c -> comments.put(c.groupId(), c.comments()));
        List<Group> groups = new ArrayList<>();
        for (var row : repository.findGroups()) {
            groups.add(new Group(row.id(), row.name(), comments.get(row.id()), fields.getOrDefault(row.id(), List.of())));
        }
        return groups;
    }

    private List<Group> questionnaireGroups(int visitId, int questionnaire, Map<Integer, Binding> bindings) {
        var questions = repository.findQuestions(questionnaire);
        if (questions.isEmpty()) throw new IllegalStateException("Video questionnaire metadata is not configured.");
        Map<String, AnswerState> states = new HashMap<>();
        repository.findAnswerStates(visitId, questionnaire).forEach(s -> states.put(key(s.questionId(), s.answerId()), s));
        Map<Integer, List<Field>> fields = new LinkedHashMap<>();
        Map<Integer, String> names = new HashMap<>();
        Set<String> seen = new HashSet<>();
        for (QuestionRow q : questions) {
            if (!seen.add(q.groupId() + ":" + q.questionId())) continue;
            var groupFields = fields.computeIfAbsent(q.groupId(), k -> new ArrayList<>());
            names.putIfAbsent(q.groupId(), groupLabel(q.groupName()));
            String side = q.itemName().matches("UEVA\\d{2}[LR]") ? q.itemName().substring(q.itemName().length() - 1) : null;
            List<AnswerRow> answers = repository.findAnswers(q.questionId());
            String template = q.template() == null ? "" : q.template();
            boolean frequency = template.contains("MostlyOccasionally");
            boolean nrlb = template.contains("NRLB");
            for (AnswerRow answer : answers) {
                String control = "comments".equals(answer.tag()) ? "TEXT" : frequency || nrlb ? "SINGLE_SELECT"
                        : answer.number() ? "NUMBER"
                        : answer.text() || "comments".equals(answer.tag()) || "TextAnswerContainer".equals(answer.tag())
                        || q.questionType() == 3 ? "TEXT" : "CHECKBOX";
                List<Option> options = !control.equals("SINGLE_SELECT") ? List.of()
                        : frequency ? options("None", "Mostly", "Occasionally") : options("N", "R", "L", "B");
                var state = states.get(key(q.questionId(), answer.id()));
                String value = value(state, control);
                String label = answer.label().isBlank() ? q.label() : answer.label();
                groupFields.add(new Field(answer.id(), q.itemName() + "." + answer.id(), label,
                        q.order() * 1000 + answer.order(), value, control, options, side, "true".equals(q.required())));
                bindings.put(answer.id(), new Binding(q.questionId(), answer.id()));
            }
            if (frequency || template.contains("NRLBQuestionContainer")) {
                int id = -q.questionId();
                groupFields.add(new Field(id, q.itemName() + ".comments", q.label() + " Comments",
                        q.order() * 1000 + 999, value(states.get(key(q.questionId(), null)), "TEXT"),
                        "TEXT", List.of(), side, false));
                bindings.put(id, new Binding(q.questionId(), null));
            }
        }
        return fields.entrySet().stream().map(e -> new Group(e.getKey(), names.get(e.getKey()), null, e.getValue())).toList();
    }

    private static String key(int question, Integer answer) { return question + ":" + answer; }

    private static String groupLabel(String name) {
        return switch (name) {
            case "RVA01", "UEVA01" -> "Comments";
            case "RVA02" -> "Foot Wear Conditions";
            case "RVA03" -> "Upper Extremity";
            case "RVA04", "UEVA11" -> "Trunk";
            case "RVA05" -> "Pelvis";
            case "RVA06" -> "Hips";
            case "RVA07" -> "Knees";
            case "RVA08" -> "Ankle";
            case "RVA09" -> "Foot Progression";
            case "UEVA02" -> "Hand Use";
            case "UEVA03" -> "Grasp";
            case "UEVA04" -> "Fingers";
            case "UEVA05" -> "Thumb";
            case "UEVA06" -> "Wrist";
            case "UEVA07" -> "Forearm";
            case "UEVA08" -> "Elbow";
            case "UEVA09" -> "Shoulder";
            case "UEVA10" -> "Scapula";
            default -> throw new IllegalStateException("Unknown video assessment group: " + name);
        };
    }

    private static String value(AnswerState state, String control) {
        if (state == null) return null;
        if (control.equals("CHECKBOX")) {
            return state.active() ? "Y" : Boolean.FALSE.equals(state.bool()) ? "N" : null;
        }
        if (!state.active()) return null;
        return control.equals("NUMBER") ? state.number() == null ? null : state.number().toPlainString() : state.text();
    }

    private static List<Option> options(String... codes) {
        return java.util.Arrays.stream(codes).map(c -> new Option(c, c)).toList();
    }

    private void validate(VideoAssessmentResponse current, VideoAssessmentSaveRequest request) {
        Map<Integer, Group> allowed = new HashMap<>();
        current.groups().forEach(g -> allowed.put(g.id(), g));
        Set<Integer> seen = new HashSet<>();
        for (var group : request.groups()) {
            if (group == null || group.id() == null || !seen.add(group.id()) || !allowed.containsKey(group.id())
                    || group.fields() == null) throw bad("Invalid or duplicate assessment group.");
            Group expected = allowed.get(group.id());
            if (group.comments() != null && (group.comments().length() > 100000 || current.questionnaireId() != null)) {
                throw bad("Invalid group comments.");
            }
            Map<Integer, Field> allowedFields = new HashMap<>();
            expected.fields().forEach(f -> allowedFields.put(f.id(), f));
            Set<Integer> seenFields = new HashSet<>();
            int selected = 0;
            for (var field : group.fields()) {
                if (field == null || field.id() == null || !seenFields.add(field.id()) || !allowedFields.containsKey(field.id())) {
                    throw bad("Invalid or duplicate assessment field.");
                }
                Field definition = allowedFields.get(field.id());
                validateValue(definition, field.choice());
                if (group.id() == 12 && current.questionnaireId() == null && "Y".equals(field.choice())) selected++;
            }
            if (seenFields.size() != allowedFields.size() || selected > 1) throw bad("Invalid assessment fields or radio selection.");
        }
        if (seen.size() != allowed.size()) throw bad("All assessment groups are required.");
    }

    private static void validateValue(Field field, String value) {
        if (value == null) {
            if (field.required() && field.choice() != null) throw bad("A required field cannot be cleared.");
            return;
        }
        if (value.length() > 100000) throw bad("Assessment value is too long.");
        boolean valid = switch (field.controlType()) {
            case "TEXT" -> true;
            case "CHECKBOX" -> Set.of("Y", "N").contains(value);
            case "LATERALITY" -> Set.of("N", "R", "L", "B").contains(value);
            case "SINGLE_SELECT" -> field.options().isEmpty() ? Set.of("Y", "N").contains(value)
                    : field.options().stream().anyMatch(o -> o.code().equals(value));
            case "NUMBER" -> value.matches("-?\\d{1,20}(\\.\\d{1,10})?");
            default -> false;
        };
        if (!valid) throw bad("Invalid assessment value.");
    }

    private String revision(VideoAssessmentResponse response) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256")
                    .digest(json.writeValueAsString(response).getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    private static ResponseStatusException bad(String reason) {
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, reason);
    }
}
