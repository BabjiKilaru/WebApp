package org.nemours.gaitlab.repository;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class UeHistoryQuestionnaireRepository {

    private static final int QUESTIONNAIRE_ID = 7;
    private static final String LAST_GROUP_NAME = "UEH05";

    private final JdbcTemplate jdbc;

    public UeHistoryQuestionnaireRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Integer findVisitPatientId(int visitId) {
        List<Integer> ids = jdbc.queryForList("SELECT pt_id FROM public.visits WHERE id = ?", Integer.class, visitId);

        return ids.isEmpty() ? null : ids.get(0);
    }

    public int startSession(int visitId, int languageId, int authId) {
        int initialGroupId = findInitialGroupId();
        return jdbc.queryForObject("INSERT INTO nmquestionnaire.session "
                + "(visit_id, questionnaire_id, language_id, auth_id, group_id, begin) "
                + "VALUES (?, ?, ?, ?, ?, now()) RETURNING id",
                Integer.class, visitId, QUESTIONNAIRE_ID, languageId, authId, initialGroupId);
    }

    public boolean isSessionForVisit(int visitId, int sessionId) {
        List<Integer> ids = jdbc.queryForList(
                "SELECT id FROM nmquestionnaire.session WHERE id = ? AND visit_id = ? AND questionnaire_id = ?",
                Integer.class, sessionId, visitId, QUESTIONNAIRE_ID);
        return !ids.isEmpty();
    }

    private int findInitialGroupId() {
        List<Integer> groupIds = jdbc.queryForList("SELECT next_group_id "
                + "FROM nmquestionnaire.questionnaire_question_link "
                + "WHERE questionnaire_id = ? AND group_id IS NULL "
                + "ORDER BY id LIMIT 1", Integer.class, QUESTIONNAIRE_ID);

        if (groupIds.isEmpty() || groupIds.get(0) == null) {
            throw new IllegalStateException("No initial group is configured for questionnaire " + QUESTIONNAIRE_ID);
        }

        return groupIds.get(0);
    }

    public void advanceSessionGroup(int sessionId) {
        List<Integer> groupIds = jdbc.queryForList(
                "SELECT qg.id FROM nmquestionnaire.question_group qg "
                        + "WHERE qg.item_name = ? AND qg.id IN ("
                        + "SELECT group_id FROM nmquestionnaire.questionnaire_question_link WHERE questionnaire_id = ? "
                        + "UNION SELECT next_group_id FROM nmquestionnaire.questionnaire_question_link WHERE questionnaire_id = ?) "
                        + "ORDER BY qg.id LIMIT 1",
                Integer.class, LAST_GROUP_NAME, QUESTIONNAIRE_ID, QUESTIONNAIRE_ID);
        if (groupIds.isEmpty()) {
            throw new IllegalStateException("Questionnaire group is not configured: " + LAST_GROUP_NAME);
        }

        jdbc.update("UPDATE nmquestionnaire.session SET group_id = ? WHERE id = ?", groupIds.get(0), sessionId);
    }

    public Integer findExistingSessionId(int visitId) {
        List<Integer> ids = jdbc.queryForList("SELECT id FROM nmquestionnaire.session "
                + "WHERE visit_id = ? AND questionnaire_id = ? ORDER BY id DESC LIMIT 1",
                Integer.class, visitId, QUESTIONNAIRE_ID);
        return ids.isEmpty() ? null : ids.get(0);
    }

    public Integer resolveAnswerId(int questionId, String text, int languageId) {
        List<Integer> ids = jdbc.queryForList("SELECT a.id FROM nmquestionnaire.answer a " + "JOIN nmquestionnaire.answer_text at ON at.answer_id = a.id "
                + "WHERE a.question_id = ? AND at.language_id IN (?, 1) AND at.text = ? "
                + "ORDER BY CASE WHEN at.language_id = ? THEN 0 ELSE 1 END LIMIT 1",
                Integer.class, questionId, languageId, text, languageId);

        return ids.isEmpty() ? null : ids.get(0);
    }

    public void deactivateActiveAnswers(int visitId, int questionId) {
        jdbc.update("UPDATE nmquestionnaire.patient_answer SET active = false "
                + "WHERE session_id IN (SELECT id FROM nmquestionnaire.session "
                + "WHERE visit_id = ? AND questionnaire_id = ?) AND question_id = ? AND active = true",
                visitId, QUESTIONNAIRE_ID, questionId);
    }

    public void insertAnswer(int sessionId, int questionId, Integer answerId, String answerText) {
        jdbc.update("INSERT INTO nmquestionnaire.patient_answer " + "(session_id, question_id, answer_id, answer_text, time, active) " + "VALUES (?, ?, ?, ?, now(), true)", sessionId, questionId, answerId, answerText);
    }

    public List<String> findActiveAnswerLabels(int visitId, int questionId) {
        return jdbc.queryForList("SELECT at.text FROM nmquestionnaire.patient_answer pa "
                + "JOIN nmquestionnaire.answer_text at ON at.answer_id = pa.answer_id AND at.language_id = 1 "
                + "WHERE pa.session_id IN (SELECT id FROM nmquestionnaire.session "
                + "WHERE visit_id = ? AND questionnaire_id = ?) AND pa.question_id = ? AND pa.active = true "
                + "ORDER BY pa.id DESC", String.class, visitId, QUESTIONNAIRE_ID, questionId);
    }

    public Map<String, Object> findQuestionBundle(int questionId) {
        List<Map<String, Object>> textRows = jdbc.queryForList("SELECT language_id, text FROM nmquestionnaire.question_text WHERE question_id = ?", questionId);

        String questionEn = null;
        String questionSp = null;

        for (Map<String, Object> row : textRows) {
            int languageId = ((Number) row.get("language_id")).intValue();
            String text = (String) row.get("text");

            if (languageId == 1) {
                questionEn = text;
            } else if (languageId == 2) {
                questionSp = text;
            }
        }

        List<Map<String, Object>> answerRows = jdbc.queryForList("SELECT a.id, at.language_id, at.text FROM nmquestionnaire.answer a " + "LEFT JOIN nmquestionnaire.answer_text at ON at.answer_id = a.id "
                + "WHERE a.question_id = ? " + "ORDER BY a.sortorder, a.id", questionId);

        LinkedHashMap<Integer, Map<String, Object>> optionsByAnswerId = new LinkedHashMap<>();

        for (Map<String, Object> row : answerRows) {
            int answerId = ((Number) row.get("id")).intValue();
            Object languageIdValue = row.get("language_id");
            String text = (String) row.get("text");

            Map<String, Object> option = optionsByAnswerId.computeIfAbsent(answerId, id -> new LinkedHashMap<>());

            if (languageIdValue == null) {
                continue;
            }

            int languageId = ((Number) languageIdValue).intValue();

            if (languageId == 1) {
                option.put("value", text);
                option.put("en", text);
            } else if (languageId == 2) {
                option.put("sp", text);
            }
        }

        Map<String, Object> question = new LinkedHashMap<>();
        question.put("en", questionEn);
        question.put("sp", questionSp);

        Map<String, Object> bundle = new LinkedHashMap<>();
        bundle.put("question", question);
        bundle.put("options", optionsByAnswerId.values().stream().filter(option -> option.get("value") != null).toList());

        return bundle;
    }
}
