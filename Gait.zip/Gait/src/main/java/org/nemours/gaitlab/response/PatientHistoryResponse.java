package org.nemours.gaitlab.response;

import java.util.List;

import org.nemours.gaitlab.model.PtBotox;
import org.nemours.gaitlab.model.PtHealthCondition;
import org.nemours.gaitlab.model.PtHealthHistory;
import org.nemours.gaitlab.model.PtSurgery;

public record PatientHistoryResponse (
    List<PtSurgery> surgeries,
    List<PtBotox> botox,
    List<PtHealthHistory> healthHistory,
    List<PtHealthCondition> healthConditions
) {}
