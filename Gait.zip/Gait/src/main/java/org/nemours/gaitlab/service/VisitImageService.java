package org.nemours.gaitlab.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import org.nemours.gaitlab.model.Patient;
import org.nemours.gaitlab.repository.PatientRepository;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.repository.VisitRepository.VideoVisitDate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class VisitImageService {

    private static final Pattern PHOTO_EXTENSION =
            Pattern.compile("(?i)\\.(jpg|jpeg|gif|bmp|webp|tif|tiff)$");

    private final PatientRepository patientRepository;
    private final VisitRepository visitRepository;
    private final Path imageRoot;

    public VisitImageService(
            PatientRepository patientRepository,
            VisitRepository visitRepository,
            @Value("${gaitlab.videos.root-path:./dev-data/PngFiles}") String imageRoot) {
        this.patientRepository = patientRepository;
        this.visitRepository = visitRepository;
        this.imageRoot = Path.of(imageRoot).toAbsolutePath().normalize();
    }

    public List<ImageMetadata> findVisitImages(Integer patientId, Integer visitId, ImageType type) {
        Path visitDirectory = getVisitDirectory(patientId, visitId);
        if (!Files.isDirectory(visitDirectory)) {
            return List.of();
        }

        Path patientDirectory = getPatientDirectory(patientId);
        Path rootRealPath = toRealPath(imageRoot);
        Path patientRealPath = toRealPath(patientDirectory);
        Path visitRealPath = toRealPath(visitDirectory);
        if (!patientRealPath.startsWith(rootRealPath)
                || !visitRealPath.startsWith(patientRealPath)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }

        List<ImageMetadata> images = new ArrayList<>();
        try (Stream<Path> files = Files.walk(visitDirectory)) {
            files.filter(Files::isRegularFile)
                    .filter(file -> !isInVideoDirectory(visitDirectory, file))
                    .filter(file -> matchesType(file, type))
                    .filter(file -> !file.getFileName().toString().startsWith("._"))
                    .forEach(file -> {
                        Path realFile = toRealPath(file);
                        if (!realFile.startsWith(visitRealPath)) {
                            return;
                        }

                        try {
                            long sizeBytes = Files.size(realFile);
                            if (sizeBytes == 0) {
                                return;
                            }
                            String relativePath = patientDirectory
                                    .relativize(file.toAbsolutePath().normalize())
                                    .toString();
                            String imageId = Base64.getUrlEncoder().withoutPadding()
                                    .encodeToString(relativePath.getBytes(StandardCharsets.UTF_8));
                            images.add(new ImageMetadata(
                                    imageId,
                                    file.getFileName().toString(),
                                    sizeBytes,
                                    "/api/patients/" + patientId + "/visits/" + visitId
                                            + "/images/" + imageId + "/content"));
                        } catch (IOException ex) {
                            throw new ImageFileReadException(ex);
                        }
                    });
        } catch (IOException ex) {
            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR, "Unable to read visit image directory.", ex);
        } catch (ImageFileReadException ex) {
            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR, "Unable to read visit image metadata.", ex.getCause());
        }

        images.sort(Comparator.comparing(ImageMetadata::fileName, String.CASE_INSENSITIVE_ORDER));
        return images;
    }

    public Path resolveImage(Integer patientId, Integer visitId, String imageId) {
        Path visitDirectory = getVisitDirectory(patientId, visitId);
        Path patientDirectory = getPatientDirectory(patientId);
        Path rootRealPath = toRealPath(imageRoot);
        Path patientRealPath = toRealPath(patientDirectory);
        Path visitRealPath = toRealPath(visitDirectory);
        if (!patientRealPath.startsWith(rootRealPath)
                || !visitRealPath.startsWith(patientRealPath)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }

        final String relativePath;
        try {
            relativePath = new String(Base64.getUrlDecoder().decode(imageId), StandardCharsets.UTF_8);
        } catch (IllegalArgumentException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }

        Path candidate = patientDirectory.resolve(relativePath).normalize();
        if (!candidate.startsWith(visitDirectory)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }

        Path realCandidate = toRealPath(candidate);
        if (!realCandidate.startsWith(visitRealPath)
                || !Files.isRegularFile(realCandidate)
                || !isImageFile(realCandidate)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        return realCandidate;
    }

    public List<ImageMetadata> findInterpretationImages(int patientId, int visitId, String name) {
        return findVisitImages(patientId, visitId, ImageType.PNG).stream().filter(image -> {
            Path relative = Path.of(new String(Base64.getUrlDecoder().decode(image.id()), StandardCharsets.UTF_8));
            Path parent = relative.getParent();
            if (parent == null || relative.getNameCount() != 3) {
                return false;
            }
            String directory = parent.getFileName().toString();
            String filename = image.fileName().toLowerCase(Locale.ROOT);
            if ("StepWatch".equals(name)) {
                return ("condition1".equalsIgnoreCase(directory) || "comparison".equalsIgnoreCase(directory))
                        && filename.contains("stepwatch");
            }
            return "condition1".equalsIgnoreCase(directory)
                    && (filename.equals(name.toLowerCase(Locale.ROOT) + ".png")
                        || filename.endsWith("_" + name.toLowerCase(Locale.ROOT) + ".png"));
        }).toList();
    }

    private Path getVisitDirectory(Integer patientId, Integer visitId) {
        VideoVisitDate visit = visitRepository.findVideoVisitDateByIdAndPatientId(visitId, patientId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        final java.time.LocalDate visitDate;
        if (visit.getVisitDate() == null || visit.getVisitDate().isBlank()
                || "infinity".equalsIgnoreCase(visit.getVisitDate())
                || "-infinity".equalsIgnoreCase(visit.getVisitDate())) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        try {
            visitDate = java.time.LocalDate.parse(visit.getVisitDate());
        } catch (java.time.format.DateTimeParseException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        return getPatientDirectory(patientId)
                .resolve(visitDate.format(java.time.format.DateTimeFormatter.ofPattern("MMddyy", Locale.ROOT)));
    }

    private Path getPatientDirectory(Integer patientId) {
        Patient patient = patientRepository.findById(patientId)
                .filter(value -> value.getMrn() != null && !value.getMrn().isBlank())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        Path directory = imageRoot.resolve(patient.getMrn()).normalize();
        if (!directory.startsWith(imageRoot)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        return directory;
    }

    private static boolean isInVideoDirectory(Path visitDirectory, Path file) {
        Path relativePath = visitDirectory.relativize(file);
        for (Path segment : relativePath) {
            if ("video".equalsIgnoreCase(segment.toString())) {
                return true;
            }
        }
        return false;
    }

    private static boolean matchesType(Path file, ImageType type) {
        String fileName = file.getFileName().toString();
        return type == ImageType.PNG
                ? fileName.toLowerCase(Locale.ROOT).endsWith(".png")
                : PHOTO_EXTENSION.matcher(fileName).find();
    }

    private static boolean isImageFile(Path file) {
        String fileName = file.getFileName().toString();
        return fileName.toLowerCase(Locale.ROOT).endsWith(".png")
                || PHOTO_EXTENSION.matcher(fileName).find();
    }

    private static Path toRealPath(Path path) {
        try {
            return path.toRealPath();
        } catch (IOException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
    }

    public enum ImageType {
        PNG,
        PHOTO
    }

    public record ImageMetadata(String id, String fileName, long sizeBytes, String contentUrl) {
    }

    private static final class ImageFileReadException extends RuntimeException {
        private ImageFileReadException(IOException cause) {
            super(cause);
        }
    }
}
