package org.nemours.gaitlab.repository;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class FrequencyRepository {

    private final JdbcTemplate jdbc;

    public FrequencyRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    // q-pt.jsp: SELECT * FROM frequencies ORDER BY code DESC
    public List<Map<String, Object>> findAllOrderByCodeDesc() {
        return jdbc.queryForList("SELECT code, freq, il8n_sp FROM public.frequencies ORDER BY code DESC");
    }
}