package org.nemours.gaitlab.controller;

import org.nemours.gaitlab.service.AuthService;
import org.nemours.gaitlab.service.AuthService.LoginResult;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService service;
    public AuthController(AuthService service) {
        this.service = service;
    }

    public record LoginRequest(String userid, String password) {}
        
    @PostMapping("/login")
    public ResponseEntity<LoginResult> login(@RequestBody LoginRequest request, HttpServletRequest httpRequest) {
        LoginResult result = service.login(request.userid(), request.password(), httpRequest);

        if (result == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        return ResponseEntity.ok(result);
    }

    @GetMapping("/me")
    public ResponseEntity<LoginResult> me(HttpServletRequest httpRequest) {
        LoginResult result = service.currentUser(httpRequest);
        if (result == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        return ResponseEntity.ok(result);
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logout(HttpServletRequest httpRequest) {
        service.logout(httpRequest);
        return ResponseEntity.noContent().build();
    }
}
    