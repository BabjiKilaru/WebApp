package org.nemours.gaitlab.repository;

import org.nemours.gaitlab.model.Surgery;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SurgeryRepository extends JpaRepository<Surgery, String> {
    List<Surgery> findAllByOrderByNameAsc();
}
