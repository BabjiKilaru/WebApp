package org.nemours.gaitlab.controller;

import java.util.List;

import org.nemours.gaitlab.service.InterpretationService;
import org.nemours.gaitlab.service.InterpretationService.Option;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/patients/{patientId}/visits/{visitId}/interpretation")
public class InterpretationController {
    private final InterpretationService service;

    public InterpretationController(InterpretationService service) {
        this.service = service;
    }

    @GetMapping
    public List<Option> options(@PathVariable int patientId, @PathVariable int visitId) {
        return service.options(patientId, visitId);
    }

}
