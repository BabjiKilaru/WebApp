package org.nemours.gaitlab.service;

import tools.jackson.core.JacksonException;
import tools.jackson.databind.ObjectMapper;

import java.nio.charset.StandardCharsets;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.nemours.gaitlab.repository.QuestionnaireResponseRepository;
import org.nemours.gaitlab.requests.UpdateQuestionnaireResponseRequest;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
public class QuestionnaireResponseService {

    private final QuestionnaireResponseRepository repository;
    private final ObjectMapper json;

    public QuestionnaireResponseService(QuestionnaireResponseRepository repository, ObjectMapper json) {
        this.repository = repository;
        this.json = json;
    }
    public record QuestionnaireResponseSection(Map<String, Object> fields, Map<String, List<Map<String, Object>>> lists, String version) { }

    private record ListSpec(String table, LinkedHashMap<String, String> columns) { }

    private static LinkedHashMap<String, String> columns(String... pairs) {

        LinkedHashMap<String, String> result = new LinkedHashMap<>();

        for (int i = 0; i < pairs.length; i += 2) {
            result.put(pairs[i], pairs[i + 1]);
        }
        return result;
    }

    private static final LinkedHashMap<String, String> BASELINE = columns(

            "historyPerson",
            "hist_person",

            "historyRelationship",
            "hist_rship",

            "baselineDate",
            "date_baseline",

            "premature",
            "premature",

            "birthStay",
            "birth_stay",

            "ageWalk",
            "age_walk",

            "ageTalk",
            "age_talk",

            "learning",
            "learning");

    private static final LinkedHashMap<String, String> ITEMS = columns(

            "reportingPerson",
            "status_name",

            "relationship",
            "status_rship",

            "walkingChange",
            "walk_change",

            "walkingSupportCode",
            "walk_support",

            "fms5Id",
            "quest_fms5",

            "fms50Id",
            "quest_fms50",

            "fms500Id",
            "quest_fms500");

    private static final LinkedHashMap<String, String> DETAILS = columns(

            "hospitalPt",
            "hosp_pt",

            "clinicPt",
            "clinic_pt",

            "schoolPt",
            "school_pt",

            "homePt",
            "home_pt",

            "hospitalOt",
            "hosp_ot",

            "clinicOt",
            "clinic_ot",

            "schoolOt",
            "school_ot",

            "homeOt",
            "home_ot",

            "followup",
            "followup",

            "generalConcerns",
            "concerns");

    private static final Set<String> NUMBERS = Set.of(
            "learning",
            "fms5Id",
            "fms50Id",
            "fms500Id");

    private static final Map<String, ListSpec> LISTS = Map.of(

            "medications", new ListSpec("pt_seizure_meds", columns("name", "seizure_med")),

            "devices", new ListSpec("pt_devices", columns("name", "device", "side", "side")),

            "gaitConcerns", new ListSpec("pt_gait_concerns", columns("code", "concern")),

            "pain", new ListSpec("pt_pain", columns("bodyPart", "part", "side", "side")));

    private static final List<Map<String, Object>> WALK_CHANGES = List.of(
            Map.of("value", "No Change", "label", "No Change"),
            Map.of("value", "Much Better", "label", "Walks Much Better"),
            Map.of("value", "Little Better", "label", "Walks a Little Better"),
            Map.of("value", "Little Worse", "label", "Walks a Little Worse"),
            Map.of("value", "Much Worse", "label", "Walks Much Worse"));

    private static final Set<String> WALK_CHANGE_VALUES = WALK_CHANGES.stream().map(option -> (String) option.get("value")).collect(Collectors.toSet());

    private static LinkedHashMap<String, String> fields(String section) {
        return switch (section) {

            case "baseline" -> BASELINE;

            case "items" -> ITEMS;

            case "details" -> DETAILS;

            case "medications" -> new LinkedHashMap<>();

            default -> throw bad("Unknown questionnaire response section.");
        };
    }

    private static List<String> listNames(String section) {
        return switch (section) {

            case "medications" -> List.of("medications");

            case "details" -> List.of("devices", "gaitConcerns", "pain");

            default -> List.of();
        };
    }

    private QuestionnaireResponseSection section(int patientId, Integer visitId, String name) {
        Map<String, Object> values = new LinkedHashMap<>();

        LinkedHashMap<String, String> mapping = fields(name);

        if (!mapping.isEmpty()) {
            values = name.equals("baseline") ? repository.findPatientFields(patientId, mapping) : repository.findVisitFields(patientId, visitId, mapping);
        }

        Map<String, List<Map<String, Object>>> lists = new LinkedHashMap<>();

        for (String listName : listNames(name)) {

            ListSpec spec = LISTS.get(listName);

            lists.put(listName, repository.findListRows(visitId, spec.table(), spec.columns()));
        }

        return new QuestionnaireResponseSection(values, lists, version(Arrays.asList(patientId, visitId, name, values, lists)));
    }

    private String version(Object value) {
        try {
            byte[] bytes = json.writeValueAsString(value).getBytes(StandardCharsets.UTF_8);

            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));

        } catch (JacksonException | NoSuchAlgorithmException exception) {
            throw new IllegalStateException("Unable to version questionnaire responses.", exception);
        }
    }

    @Transactional(readOnly = true, isolation = Isolation.REPEATABLE_READ)
    public Map<String, Object> getPatientResponses(int patientId) {
        repository.requirePatient(patientId, false);

        Map<String, Object> response = new LinkedHashMap<>();

        response.put("baseline", section(patientId, null, "baseline"));

        response.put("visits", repository.findEligibleVisits(patientId));

        return response;
    }

    @Transactional(readOnly = true, isolation = Isolation.REPEATABLE_READ)
    public Map<String, Object> getVisitResponses(int patientId, int visitId) {

        Map<String, Object> selectedVisit = repository.findOwnedVisit(patientId, visitId, false);

        LinkedHashMap<String, String> allScalarFields = new LinkedHashMap<>(ITEMS);

        allScalarFields.putAll(DETAILS);

        List<Map<String, Object>> sameDayAnswers = repository.findSameDayAnswers(patientId, visitId, allScalarFields);

        Map<String, Object> effective = new LinkedHashMap<>();

        for (String key : allScalarFields.keySet()) {
            effective.put(key, firstAnswer(sameDayAnswers, key));
        }

        Map<String, Object> response = new LinkedHashMap<>();

        response.put("visitId", visitId);

        response.put("visitDate", selectedVisit.get("date"));

        response.put("effective", effective);

        response.put("items", section(patientId, visitId, "items"));

        response.put("medications", section(patientId, visitId, "medications"));

        response.put("details", section(patientId, visitId, "details"));

        return response;
    }

    private static Object firstAnswer(List<Map<String, Object>> rows, String field) { 
        return rows.stream().map(row -> row.get(field))
                .filter(value -> value != null && !"".equals(value))
                .findFirst()
                .orElse(null);
    }

    @Transactional(readOnly = true)
    public Map<String, Object> getOptions(int patientId, String language) {

        repository.requirePatient(patientId, false);

        if (language != null && !Set.of("en", "sp").contains(language)) {
            throw bad("language must be en or sp.");
        }

        Map<String, Object> result = new LinkedHashMap<>();

        result.put("relationships", language == null ? repository.findRelationships() : repository.findRelationships(language));

        result.put("premature", language == null ? repository.findPrematureOptions() : repository.findPrematureOptions(language));

        result.put("birthStays", language == null ? repository.findBirthStayOptions() : repository.findBirthStayOptions(language));

        result.put("ages", language == null ? repository.findAgeOptions() : repository.findAgeOptions(language));

        result.put("learning", language == null ? repository.findLearningOptions() : repository.findLearningOptions(language));

        result.put("walkingSupport", language == null ? repository.findWalkingSupportOptions() : repository.findWalkingSupportOptions(language));

        result.put("walkingChanges", language == null ? WALK_CHANGES : localizedWalkChanges(language));

        result.put("fms", language == null ? repository.findFmsOptions() : repository.findFmsOptions(language));

        result.put("medications", language == null ? repository.findMedicationOptions() : repository.findMedicationOptions(language));

        result.put("devices", language == null ? repository.findDeviceOptions() : repository.findDeviceOptions(language));

        result.put("gaitConcerns", language == null ? repository.findGaitConcernOptions() : repository.findGaitConcernOptions(language));

        result.put("pain", language == null ? repository.findPainOptions() : repository.findPainOptions(language));

        return result;
    }


    private static List<Map<String, Object>> localizedWalkChanges(String language) {
        List<Map<String, Object>> result = new ArrayList<>();

        for (Map<String, Object> option : WALK_CHANGES) {
            Map<String, Object> copy = new LinkedHashMap<>();
            copy.put("value", option.get("value"));
            copy.put("label", "en".equals(language) ? option.get("label") : null);
            result.add(copy);
        }
        return result;
    }

    @Transactional
    public void updateResponses(int patientId, Integer visitId, String sectionName, UpdateQuestionnaireResponseRequest request) {
        LinkedHashMap<String, String> mapping = fields(sectionName);

        if (visitId != null && sectionName.equals("baseline")) {

            throw bad("Use the baseline questionnaire response endpoint.");
        }

        if (sectionName.equals("baseline")) {
            repository.requirePatient(patientId, true);
        } 
        else {
            if (visitId == null) {
                throw bad("A visit is required.");
            }
            repository.findOwnedVisit(patientId, visitId, true);
        }

        QuestionnaireResponseSection current = section(patientId, visitId, sectionName);

        if (request == null || request.version() == null || !request.version().equals(current.version())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "These questionnaire responses changed after this editor was opened. " + "Close and reopen the editor to load the latest responses.");
        }

        if (request.fields() == null || !request.fields().keySet().equals(mapping.keySet()) || request.lists() == null || !request.lists().keySet().equals(new HashSet<>(listNames(sectionName)))) {
            throw bad("The complete questionnaire response section is required. " + "Reload the page and retry.");
        }

        LinkedHashMap<String, Object> values = new LinkedHashMap<>();

        for (String key : mapping.keySet()) {
            Object value = normalize(key, request.fields().get(key));
            validateField(key, value, current.fields().get(key));
            values.put(key, value);
        }

        for (String listName : listNames(sectionName)) {
            validateRows(listName, request.lists().get(listName), current.lists().get(listName));
        }

        if (!mapping.isEmpty()) {
            if (sectionName.equals("baseline")) {
                repository.updatePatientFields(patientId, mapping, values);
            } 
            else {
                repository.updateVisitFields(patientId, visitId, mapping, values);
            }
        }

        for (String listName : listNames(sectionName)) {
            syncRows(visitId, LISTS.get(listName), request.lists().get(listName), current.lists().get(listName));
        }
    }

    private static Object normalize(String key, Object value) {
        if (value == null) {
            return null;
        }

        if (NUMBERS.contains(key)) {
            if ("".equals(value)) {
                return null;
            }

            if (!(value instanceof Number number) || number.doubleValue() != number.intValue()) {
                throw bad("Invalid numeric option: " + key);
            }
            return number.intValue();
        }

        if (!(value instanceof String)) {
            throw bad("Invalid text value: " + key);
        }
        return value;
    }

    private void validateField(String key, Object value, Object oldValue) {
        if (key.equals("baselineDate") && value != null && !"".equals(value)) {
            try {
                LocalDate.parse((String) value);
            } catch (DateTimeParseException exception) {
                throw bad("Enter a valid baseline date (YYYY-MM-DD).");
            }
        }

        if (value == null || "".equals(value) || Objects.equals(value, oldValue)) {
            return;
        }

        if (!repository.validLookup(key, value)) {
            throw bad("Invalid selection for " + key + ".");
        }

        if (key.equals("walkingChange") && !WALK_CHANGE_VALUES.contains(value)) {
            throw bad("Invalid walking change.");
        }

        if ((key.endsWith("Pt") || key.endsWith("Ot")) && !List.of("1", "2", "3", "4").contains(value)) {
            throw bad("Invalid therapy frequency.");
        }
    }

    private void validateRows(String name, List<Map<String, Object>> rows, List<Map<String, Object>> oldRows) {
        if (rows == null || rows.size() > Math.max(500, oldRows.size())) {
            throw bad("Invalid list of " + name + ".");
        }

        ListSpec spec = LISTS.get(name);

        Set<String> expected = new HashSet<>(spec.columns().keySet());

        expected.add("id");

        Map<Integer, Map<String, Object>> previous = new HashMap<>();

        for (Map<String, Object> old : oldRows) {
            previous.put(((Number) old.get("id")).intValue(), old);
        }

        Set<Integer> seen = new HashSet<>();

        for (Map<String, Object> row : rows) {

            if (row == null || !row.keySet().equals(expected)) {
                throw bad("Invalid row in " + name + ".");
            }

            Integer id = rowId(row.get("id"));

            if (id != null && (!previous.containsKey(id) || !seen.add(id))) {
                throw bad("A row does not belong to this visit, " + "or is repeated.");
            }

            Map<String, Object> old = id == null ? Map.of() : previous.get(id);

            for (String key : spec.columns().keySet()) {
                normalize(key, row.get(key));
            }

            String primary = spec.columns().keySet().iterator().next();

            Object value = row.get(primary);

            if (Objects.equals(value, old.get(primary)) && id != null) {
                continue;
            }

            if (!(value instanceof String text) || text.isBlank()) {
                throw bad("Complete or remove the empty row in " + name + ".");
            }

            if (name.equals("gaitConcerns") && !repository.gaitConcernExists(value)) {
                throw bad("Invalid gait concern.");
            }
        }
    }

    private static Integer rowId(Object value) {
        if (value == null) {
            return null;
        }

        if (!(value instanceof Number number) || number.doubleValue() != number.intValue()) {
            throw bad("Invalid row ID.");
        }
        return number.intValue();
    }

    private void syncRows(int visitId, ListSpec spec, List<Map<String, Object>> rows, List<Map<String, Object>> previous) {
        Set<Integer> retained = new HashSet<>();

        for (Map<String, Object> row : rows) {
            Integer id = rowId(row.get("id"));
            Map<String, Object> saveRow = normalizeListRow(spec, row);

            if (id == null) {
                repository.insertListRow(visitId, spec.table(), spec.columns(), saveRow);
            } else {
                retained.add(id);
                repository.updateListRow(visitId, id, spec.table(), spec.columns(), saveRow);
            }
        }

        for (Map<String, Object> old : previous) {
            int id = ((Number) old.get("id")).intValue();

            if (!retained.contains(id)) {
                repository.deleteListRow(visitId, id, spec.table());
            }
        }
    }

    private static Map<String, Object> normalizeListRow(ListSpec spec, Map<String, Object> row) {

        if (!"pt_devices".equals(spec.table()) || !"".equals(row.get("side"))) {
            return row;
        }

        Map<String, Object> normalized = new LinkedHashMap<>(row);
        normalized.put("side", null);
        return normalized;
    }

    private static ResponseStatusException bad(String reason) {
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, reason);
    }
}