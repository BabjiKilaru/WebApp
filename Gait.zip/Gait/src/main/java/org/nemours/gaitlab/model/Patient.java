package org.nemours.gaitlab.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "patients", schema = "public")
public class Patient {

    @Id
    @GeneratedValue(
        strategy = GenerationType.SEQUENCE, generator = "patients_seq_generator"
    )
    @SequenceGenerator(
        name = "patients_seq_generator",
        sequenceName = "patients_seq",
        schema = "public",
        allocationSize = 1
    )
    @Column(name = "id")
    private Integer id;

    @Column(name = "mrn")
    private String mrn;

    @Column(name = "fname")
    private String firstName;

    @Column(name = "lname")
    private String lastName;

    @Column(name = "old_lname")
    private String oldLastName;

    @Column(name = "nickname")
    private String nickname;

    @Column(name = "dob")
    private LocalDate dateOfBirth;

    @Column(name = "gender")
    private String gender;

    @Column(name = "gen_diag")
    private Integer generalDiagnosisCode;

    @Column(name = "label")
    private Boolean label;

    @Column(name = "comment")
    private String comment;

    @Column(name = "hist_person")
    private String historyPerson;

    @Column(name = "hist_rship")
    private String historyRelationship;

    @Column(name = "date_baseline")
    private LocalDate baselineDate;

    @Column(name = "premature")
    private String premature;

    @Column(name = "birth_stay")
    private String birthStay;

    @Column(name = "age_walk_ws")
    private String ageWalkWithSupport;

    @Column(name = "age_walk_wos")
    private String ageWalkWithoutSupport;

    @Column(name = "learning")
    private Integer learning;

    @Column(name = "age_walk")
    private String ageWalk;

    @Column(name = "age_talk")
    private String ageTalk;

    @Transient
    private String icd9Code;

    @Transient
    private String generalDiagnosis;

    @Transient
    private String learningDescription;

    public Integer getId() {
        return id;
    }

    public String getMrn() {
        return mrn;
    }

    public void setMrn(String mrn) {
        this.mrn = mrn;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getOldLastName() {
        return oldLastName;
    }

    public void setOldLastName(String oldLastName) {
        this.oldLastName = oldLastName;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Integer getGeneralDiagnosisCode() {
        return generalDiagnosisCode;
    }

    public void setGeneralDiagnosisCode(Integer generalDiagnosisCode) {
        this.generalDiagnosisCode = generalDiagnosisCode;
    }

    public Boolean getLabel() {
        return label;
    }

    public void setLabel(Boolean label) {
        this.label = label;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getHistoryPerson() {
        return historyPerson;
    }

    public String getHistoryRelationship() {
        return historyRelationship;
    }

    public LocalDate getBaselineDate() {
        return baselineDate;
    }

    public String getPremature() {
        return premature;
    }

    public String getBirthStay() {
        return birthStay;
    }

    public String getAgeWalkWithSupport() {
        return ageWalkWithSupport;
    }

    public String getAgeWalkWithoutSupport() {
        return ageWalkWithoutSupport;
    }

    public Integer getLearning() {
        return learning;
    }

    public String getAgeWalk() {
        return ageWalk;
    }

    public String getAgeTalk() {
        return ageTalk;
    }

    public String getIcd9Code(){
        return icd9Code;
    }

    public void setIcd9Code(String icd9Code){
        this.icd9Code = icd9Code;
    }

    public String getGeneralDiagnosis(){
        return generalDiagnosis;
    }

    public void setGeneralDiagnosis(String generalDiagnosis){
        this.generalDiagnosis = generalDiagnosis;
    }

    public String getLearningDescription() {
        return learningDescription;
    }

    public void setLearningDescription(String learningDescription) {
        this.learningDescription = learningDescription;
    }
}
