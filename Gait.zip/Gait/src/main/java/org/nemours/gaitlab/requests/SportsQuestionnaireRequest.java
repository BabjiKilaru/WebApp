package org.nemours.gaitlab.requests;

import java.util.List;

public record SportsQuestionnaireRequest(
    Integer visitId,
    Integer sessionId,
    String language,
    String reportingPerson,
    String physicalTherapy,
    String competitiveSports,
    String yearsInSport,
    String daysPerWeek,
    String orthotics,
    List<String> painLocations,
    String mileTimeKnown,
    String mileTime,
    String goals
) {}
