package org.nemours.gaitlab.service;

import java.util.Arrays;
import java.util.Optional;

public enum FormTemplate {

    PATIENT_VISIT(
        "patientform",
        "visit-forms/Appt3.pdf"
    ),

    ANALYSIS(
        "analysisform",
        "visit-forms/analysisform.pdf"
    ),

    PT_EVAL(
        "ptevalform",
        "visit-forms/PTEVAL.pdf"
    ),

    ENGINEER(
        "engineerform",
        "visit-forms/Engineer.pdf"
    ),

    PT_FOOT_EVAL(
        "footstudysurvey",
        "visit-forms/footstudysurvey.pdf"
    ),

    SHUEE(
        "shueeform",
        "visit-forms/shueeform.pdf"
    ),

    UE_ENGINEER(
        "ueengineerform",
        "visit-forms/ueengineerform.pdf"
    ),

    RUNNING_ENGINEER(
        "runningengineerform",
        "visit-forms/runningengineerform.pdf"
    ),

    UE_EVAL(
        "ptueform",
        "visit-forms/ptueform.pdf"
    );

    private final String key;
    private final String resourcePath;

    FormTemplate(
            String key,
            String resourcePath) {

        this.key = key;
        this.resourcePath = resourcePath;
    }

    public String getKey() {
        return key;
    }

    public String getResourcePath() {
        return resourcePath;
    }

    public static Optional<FormTemplate> fromKey(
            String key) {

        if (key == null) {
            return Optional.empty();
        }

        return Arrays.stream(values())
            .filter(template ->
                template.key.equals(key)
            )
            .findFirst();
    }
}
