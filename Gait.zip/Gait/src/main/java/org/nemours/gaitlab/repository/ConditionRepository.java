package org.nemours.gaitlab.repository;

import org.nemours.gaitlab.model.Condition;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ConditionRepository extends JpaRepository<Condition, String> {
    List<Condition> findAllByOrderByConditionAsc();
}
