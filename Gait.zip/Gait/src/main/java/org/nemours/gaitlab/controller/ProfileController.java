package org.nemours.gaitlab.controller;

import java.util.Map;

import org.nemours.gaitlab.repository.ProfileRepository.ProfileRow;
import org.nemours.gaitlab.requests.ChangePasswordRequest;
import org.nemours.gaitlab.requests.UpdateProfileRequest;
import org.nemours.gaitlab.service.ProfileService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Self-service profile endpoints. The user is always resolved from the authenticated
 * session, never from a request parameter or body, so users cannot read or modify
 * another user's profile.
 */
@RestController
@RequestMapping("/api/profile")
public class ProfileController {
    private final ProfileService service;

    public ProfileController(ProfileService service) {
        this.service = service;
    }

    @GetMapping
    public ProfileRow getProfile(Authentication authentication) {
        return service.getProfile(currentUserId(authentication));
    }

    @PutMapping
    public ProfileRow updateProfile(Authentication authentication, @RequestBody UpdateProfileRequest request) {
        return service.updateProfile(currentUserId(authentication), request);
    }

    @PutMapping("/password")
    public ResponseEntity<Void> changePassword(
            Authentication authentication,
            @RequestBody ChangePasswordRequest request,
            HttpServletRequest httpRequest) {
        service.changePassword(currentUserId(authentication), request);
        // Rotate the session id after a credential change to limit session fixation/hijack windows.
        if (httpRequest.getSession(false) != null) {
            httpRequest.changeSessionId();
        }
        return ResponseEntity.noContent().build();
    }

    private static String currentUserId(Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()
                || authentication.getName() == null || authentication.getName().isBlank()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Not signed in.");
        }
        return authentication.getName();
    }

    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<Map<String, String>> handleResponseStatus(ResponseStatusException exception) {
        String message = exception.getReason() == null ? "Request failed." : exception.getReason();
        return ResponseEntity.status(exception.getStatusCode()).body(Map.of("message", message));
    }
}
