package org.nemours.gaitlab.model;

import jakarta.persistence.*;

@Entity 
@Table(name = "seizure_meds", schema = "public")
public class SeizureMedication {
    @Id 
    @Column(name = "med")
    private String med;

    public String getMed() {
        return med;
    }
}
