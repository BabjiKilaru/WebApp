package org.nemours.gaitlab.requests;
public record CreateSurgeryRequest(
    String date,
    String procedureCode,
    String side,
    String surgeon,
    String facility,
    String comment
 ) {}