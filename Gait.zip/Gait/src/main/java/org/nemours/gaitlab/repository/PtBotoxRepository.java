package org.nemours.gaitlab.repository;

import org.nemours.gaitlab.model.PtBotox;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PtBotoxRepository extends JpaRepository<PtBotox, Integer> {
    List<PtBotox> findByPatientIdOrderByDateAsc(Integer patientId);
}

