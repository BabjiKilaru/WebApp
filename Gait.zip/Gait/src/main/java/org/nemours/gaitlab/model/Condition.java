package org.nemours.gaitlab.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

@Entity
@Table(
    name = "conditions",
    schema = "public"
)
public class Condition {
    @Id
    @Column(name = "code")
    private String code;

    @Column(name = "condition")
    private String condition;

    public String getCode() {
        return code;
    }

    @JsonIgnore
    public String getCondition() {
        return condition;
    }

    public String getName() {
        return condition;
    }
}
