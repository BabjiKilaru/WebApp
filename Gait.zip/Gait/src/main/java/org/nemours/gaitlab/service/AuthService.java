package org.nemours.gaitlab.service;

import java.util.Map;

import org.nemours.gaitlab.repository.AuthRepository;
import org.springframework.stereotype.Service;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Service
public class AuthService {
    public static final String SESSION_USERNAME = "MM_Username";
    public static final String SESSION_ACCESS = "MM_UserAuthorization";
    private static final String SESSION_FIRST_NAME = "MM_FirstName";
    private static final String SESSION_LAST_NAME = "MM_LastName";
    private final AuthRepository repository;

    public AuthService(AuthRepository repository) {
        this.repository = repository;
    }

    public record LoginResult(String userid, String access, String firstName, String lastName,
            boolean mustChangePassword) {
    }

    public LoginResult login(String userid, String password, HttpServletRequest request) {
        String hashed = LegacyPasswordHasher.hash(password);
        Map<String, Object> row = repository.findActiveUser(userid, hashed);
        if (row == null) {
            return null;
        }

        String access = ((String) row.get("access"));
        access = access == null ? "" : access.trim();
        String firstName = (String) row.get("fname");
        String lastName = (String) row.get("lname");

        HttpSession session = request.getSession(true);
        request.changeSessionId();
        session.setAttribute(SESSION_USERNAME, userid);

        session.setAttribute(SESSION_ACCESS, access);
        session.setAttribute(SESSION_FIRST_NAME, firstName);
        session.setAttribute(SESSION_LAST_NAME, lastName);

        return new LoginResult(userid, access, firstName, lastName,
                Boolean.TRUE.equals(row.get("must_change_password")));
    }

    public LoginResult currentUser(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return null;
        }

        String username = (String) session.getAttribute(SESSION_USERNAME);

        if (username == null || username.isBlank()) {
            return null;
        }

        String access = (String) session.getAttribute(SESSION_ACCESS);
        AuthRepository.UserNames userNames = repository.findUserNames(username);
        String firstName = userNames == null
                ? (String) session.getAttribute(SESSION_FIRST_NAME)
                : userNames.firstName();
        String lastName = userNames == null
                ? (String) session.getAttribute(SESSION_LAST_NAME)
                : userNames.lastName();
        return new LoginResult(username, access == null ? "" : access, firstName, lastName,
                mustChangePassword(username));
    }

    public boolean mustChangePassword(String userid) {
        return repository.mustChangePassword(userid);
    }

    public void logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
    }
}