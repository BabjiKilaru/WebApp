package org.nemours.gaitlab.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="new_visit_tests", schema="public")
public class VisitTest {
    @Id
    @GeneratedValue(
        strategy = GenerationType.SEQUENCE,
        generator = "new_visit_tests_seq"
    )
    @SequenceGenerator(
        name = "new_visit_tests_seq",
        sequenceName = "public.new_visit_tests_id_seq",
        allocationSize = 1
    )
    @Column(name = "id")
    private Integer id;

    @Column(name = "visit_id")
    private Integer visitId;

    @Column(name = "test_code")
    private String testCode;

    @Column(name = "comment")
    private String comment;

    @Column(name = "active")
    private Boolean active;

    @Column(name = "userid")
    private String userId;

    @Column(name = "created")
    private LocalDateTime created;

    public Integer getId(){
        return id;
    }

    public Integer getVisitId(){
        return visitId;
    }

    public void setVisitId(Integer visitId){
        this.visitId = visitId;
    }

    public String getTestCode(){
        return testCode;
    }

    public void setTestCode(String testCode){
        this.testCode = testCode;
    }

    public String getComment(){
        return comment;
    }

    public void setComment(String comment){
        this.comment = comment;
    }

    public Boolean getActive(){
        return active;
    }

    public void setActive(Boolean active){
        this.active = active;
    }

    public String getUserId(){
        return userId;
    }

    public void setUserId(String userId){
        this.userId = userId;
    }

    public LocalDateTime getCreated(){
        return created;
    }

    public void setCreated(LocalDateTime created){
        this.created = created;
    }
}
