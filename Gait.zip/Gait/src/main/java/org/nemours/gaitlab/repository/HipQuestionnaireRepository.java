package org.nemours.gaitlab.repository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class HipQuestionnaireRepository {

    private final JdbcTemplate jdbc;

    public HipQuestionnaireRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Integer findVisitPatientId(int visitId) {
        List<Integer> ids = jdbc.queryForList(
            "SELECT pt_id FROM public.visits WHERE id = ?",
            Integer.class, visitId);

        return ids.isEmpty() ? null : ids.get(0);
    }

    public Map<String, Object> findByVisitId(int visitId) {
        List<Map<String, Object>> rows = jdbc.queryForList(
            "SELECT * FROM public.hip_score WHERE visit_id = ?", visitId);

        return rows.isEmpty() ? null : rows.get(0);
    }

    public void upsert(int visitId, LinkedHashMap<String, Object> columns) {
        List<String> names = new ArrayList<>(columns.keySet());

        String columnList = String.join(", ", names);
        String placeholders = names.stream().map(name -> "?").collect(Collectors.joining(", "));
        String updateAssignments = names.stream()
            .map(name -> name + " = EXCLUDED." + name)
            .collect(Collectors.joining(", "));

        List<Object> parameters = new ArrayList<>();
        parameters.add(visitId);
        parameters.addAll(columns.values());

        jdbc.update(
            "INSERT INTO public.hip_score (visit_id, " + columnList + ") "
                + "VALUES (?, " + placeholders + ") "
                + "ON CONFLICT (visit_id) DO UPDATE SET " + updateAssignments,
            parameters.toArray());
    }
}
