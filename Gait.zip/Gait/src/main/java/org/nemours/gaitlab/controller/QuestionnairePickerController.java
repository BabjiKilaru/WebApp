package org.nemours.gaitlab.controller;

import java.util.List;

import org.nemours.gaitlab.requests.AssembleQuestionnaireRequest;
import org.nemours.gaitlab.service.QuestionnairePickerService;
import org.nemours.gaitlab.service.QuestionnairePickerService.CodeAssignment;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/patients/{patientId}/questionnaire-picker")
public class QuestionnairePickerController {

    private final QuestionnairePickerService service;

    public QuestionnairePickerController(QuestionnairePickerService service) {
        this.service = service;
    }

    @PostMapping("/assemble")
    public List<CodeAssignment> assemble(
            @PathVariable Integer patientId,
            @RequestBody AssembleQuestionnaireRequest request) {
        return service.assemble(patientId, request);
    }
}
