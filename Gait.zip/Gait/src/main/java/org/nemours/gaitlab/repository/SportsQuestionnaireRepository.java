package org.nemours.gaitlab.repository;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class SportsQuestionnaireRepository {

    private static final int QUESTIONNAIRE_ID = 1;
    private static final String LAST_GROUP_NAME = "SPORTS8";

    private final JdbcTemplate jdbc;

    public SportsQuestionnaireRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Integer findVisitPatientId(int visitId) {
        List<Integer> ids = jdbc.queryForList("SELECT pt_id FROM public.visits WHERE id = ?", Integer.class, visitId);

        return ids.isEmpty() ? null : ids.get(0);
    }

    public int startSession(int visitId, int languageId, int authId) {
        int initialGroupId = findInitialGroupId();
        return jdbc.queryForObject("INSERT INTO nmquestionnaire.session "
                + "(visit_id, questionnaire_id, language_id, auth_id, group_id, begin) "
                + "VALUES (?, ?, ?, ?, ?, now()) RETURNING id",
                Integer.class, visitId, QUESTIONNAIRE_ID, languageId, authId, initialGroupId);
    }

    public boolean isSessionForVisit(int visitId, int sessionId) {
        List<Integer> ids = jdbc.queryForList(
                "SELECT id FROM nmquestionnaire.session WHERE id = ? AND visit_id = ? AND questionnaire_id = ?",
                Integer.class, sessionId, visitId, QUESTIONNAIRE_ID);
        return !ids.isEmpty();
    }

    private int findInitialGroupId() {
        List<Integer> groupIds = jdbc.queryForList("SELECT next_group_id "
                + "FROM nmquestionnaire.questionnaire_question_link "
                + "WHERE questionnaire_id = ? AND group_id IS NULL "
                + "ORDER BY id LIMIT 1", Integer.class, QUESTIONNAIRE_ID);

        if (groupIds.isEmpty() || groupIds.get(0) == null) {
            throw new IllegalStateException("No initial group is configured for questionnaire " + QUESTIONNAIRE_ID);
        }

        return groupIds.get(0);
    }

    public Integer findExistingSessionId(int visitId) {
        List<Integer> ids = jdbc.queryForList("SELECT id FROM nmquestionnaire.session "
                + "WHERE visit_id = ? AND questionnaire_id = ? ORDER BY id DESC LIMIT 1",
                Integer.class, visitId, QUESTIONNAIRE_ID);

        return ids.isEmpty() ? null : ids.get(0);
    }

    public void advanceSessionGroup(int sessionId) {
        updateSessionGroup(sessionId, LAST_GROUP_NAME);
    }

    private void updateSessionGroup(int sessionId, String groupName) {
        List<Integer> groupIds = jdbc.queryForList(
                "SELECT qg.id FROM nmquestionnaire.question_group qg "
                        + "WHERE qg.item_name = ? AND qg.id IN ("
                        + "SELECT group_id FROM nmquestionnaire.questionnaire_question_link WHERE questionnaire_id = ? "
                        + "UNION SELECT next_group_id FROM nmquestionnaire.questionnaire_question_link WHERE questionnaire_id = ?) "
                        + "ORDER BY qg.id LIMIT 1",
                Integer.class, groupName, QUESTIONNAIRE_ID, QUESTIONNAIRE_ID);
        if (groupIds.isEmpty()) {
            throw new IllegalStateException("Questionnaire group is not configured: " + groupName);
        }

        jdbc.update("UPDATE nmquestionnaire.session SET group_id = ? WHERE id = ?", groupIds.get(0), sessionId);
    }

    public Integer findTextAnswerId(int questionId) {
        List<Integer> ids = jdbc.queryForList("SELECT id FROM nmquestionnaire.answer WHERE question_id = ? AND tag = 'TextAnswerContainer'", Integer.class, questionId);

        return ids.isEmpty() ? null : ids.get(0);
    }

    public Integer resolveAnswerId(int questionId, String text, int languageId) {
        List<Integer> ids = jdbc.queryForList("SELECT a.id FROM nmquestionnaire.answer a " + "JOIN nmquestionnaire.answer_text at ON at.answer_id = a.id "
                + "WHERE a.question_id = ? AND at.language_id IN (?, 1) AND at.text = ? "
                + "ORDER BY CASE WHEN at.language_id = ? THEN 0 ELSE 1 END LIMIT 1",
                Integer.class, questionId, languageId, text, languageId);

        return ids.isEmpty() ? null : ids.get(0);
    }

    public void deactivateActiveAnswers(int visitId, int questionId) {
        jdbc.update("UPDATE nmquestionnaire.patient_answer SET active = false "
                + "WHERE session_id IN (SELECT id FROM nmquestionnaire.session "
                + "WHERE visit_id = ? AND questionnaire_id = ?) AND question_id = ? AND active = true",
                visitId, QUESTIONNAIRE_ID, questionId);
    }

    public void insertAnswer(int sessionId, int questionId, Integer answerId, String answerText) {
        jdbc.update("INSERT INTO nmquestionnaire.patient_answer " + "(session_id, question_id, answer_id, answer_text, time, active) " + "VALUES (?, ?, ?, ?, now(), true)", sessionId, questionId, answerId, answerText);
    }

    public List<String> findActiveAnswerLabels(int visitId, int questionId) {
        return jdbc.queryForList("SELECT at.text FROM nmquestionnaire.patient_answer pa "
                + "JOIN nmquestionnaire.answer_text at ON at.answer_id = pa.answer_id AND at.language_id = 1 "
                + "WHERE pa.session_id IN (SELECT id FROM nmquestionnaire.session "
                + "WHERE visit_id = ? AND questionnaire_id = ?) AND pa.question_id = ? AND pa.active = true "
                + "ORDER BY pa.id DESC", String.class, visitId, QUESTIONNAIRE_ID, questionId);
    }

    public String findActiveFreeText(int visitId, int questionId) {
        List<String> texts = jdbc.queryForList("SELECT answer_text FROM nmquestionnaire.patient_answer "
                + "WHERE session_id IN (SELECT id FROM nmquestionnaire.session "
                + "WHERE visit_id = ? AND questionnaire_id = ?) AND question_id = ? AND active = true "
                + "ORDER BY id DESC LIMIT 1", String.class, visitId, QUESTIONNAIRE_ID, questionId);

        return texts.isEmpty() ? null : texts.get(0);
    }

    public Map<String, Object> findActiveChoiceWithText(int visitId, int questionId) {
        List<Map<String, Object>> rows = jdbc.queryForList("SELECT at.text AS label, pa.answer_text AS free_text " + "FROM nmquestionnaire.patient_answer pa "
                + "JOIN nmquestionnaire.answer_text at ON at.answer_id = pa.answer_id AND at.language_id = 1 "
                + "AND pa.session_id IN (SELECT id FROM nmquestionnaire.session WHERE visit_id = ? AND questionnaire_id = ?) "
                + "WHERE pa.question_id = ? AND pa.active = true "
                + "ORDER BY pa.id DESC LIMIT 1", visitId, QUESTIONNAIRE_ID, questionId);

        return rows.isEmpty() ? null : rows.get(0);
    }
}
