package org.nemours.gaitlab.requests;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record CreateAdminUserRequest(
        @NotBlank @Size(min = 5, max = 50) @Pattern(regexp = "[A-Za-z0-9._-]+") String userid,
        @NotNull @Valid UpdateAdminUserRequest details
) {
}
