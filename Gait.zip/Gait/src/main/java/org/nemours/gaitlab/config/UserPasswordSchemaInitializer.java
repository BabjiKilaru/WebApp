package org.nemours.gaitlab.config;

import org.nemours.gaitlab.service.LegacyPasswordHasher;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class UserPasswordSchemaInitializer implements ApplicationRunner {
    private final JdbcTemplate jdbc;

    public UserPasswordSchemaInitializer(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public void run(ApplicationArguments args) {
        jdbc.execute("""
                ALTER TABLE public.users
                ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN NOT NULL DEFAULT FALSE
                """);
        jdbc.update("""
                UPDATE public.users
                SET must_change_password = TRUE
                WHERE password = ? AND must_change_password = FALSE
                """, LegacyPasswordHasher.LEGACY_DEFAULT_PASSWORD_HASH);
    }
}
