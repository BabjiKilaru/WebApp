package org.nemours.gaitlab.controller;

import org.nemours.gaitlab.response.VideoAssessmentResponse;
import org.nemours.gaitlab.service.VideoAssessmentService;
import org.nemours.gaitlab.requests.VideoAssessmentSaveRequest;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping(
    "/api/patients/{patientId}/visits/{visitId}/video-assessment"
)
public class VideoAssessmentController {
    private final VideoAssessmentService service;
    public VideoAssessmentController(
        VideoAssessmentService service
    ) {
        this.service = service;
    }

    @GetMapping
    public VideoAssessmentResponse getAssessment(
        @PathVariable int patientId,
        @PathVariable int visitId
    ) {
        return service.getAssessment(
            patientId,
            visitId
        );
    }

    @PutMapping
    public VideoAssessmentResponse saveAssessment(
            @PathVariable int patientId,
            @PathVariable int visitId,
            Authentication authentication,
            @Valid @RequestBody VideoAssessmentSaveRequest request) {
        return service.saveAssessment(patientId, visitId, authentication == null ? null : authentication.getName(), request);
    }
}
