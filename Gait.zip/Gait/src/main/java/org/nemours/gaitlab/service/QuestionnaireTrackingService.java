package org.nemours.gaitlab.service;

import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.nemours.gaitlab.repository.QuestionnaireTrackingRepository;
import org.nemours.gaitlab.repository.SportsQuestionnaireRepository;
import org.nemours.gaitlab.repository.UeHistoryQuestionnaireRepository;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.service.QuestionnairePickerService.CodeAssignment;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

// Ports QuestionnaireServiceImpl.setDescriptor: legacy inserts one q_track row per wizard page
// reached. The current app tracks when a questionnaire step is opened, so instead of tracking
// per-page navigation we insert the full legacy page set for each visited code. Repeated visits
// intentionally create additional q_track rows, as in the legacy app. wasAsked() (the only consumer
// of this data — comp_report_view.jsp, include_history.jsp)
// pattern-matches "%:<pageName>" and never looks at the index prefix, so the index is cosmetic;
// the index is based on the submitted assignment list.
@Service
public class QuestionnaireTrackingService {

    private static final Map<String, List<String>> STATIC_PAGES = Map.ofEntries(
        Map.entry("HISTORY", List.of(
            "history_who", "history_history", "history_conditions", "history_seizures",
            "history_botox", "history_devices", "history_pain", "history_pt", "history_followup")),
        Map.entry("NEW_HISTORY", List.of(
            "new_history_who", "new_history_birth", "new_history_walking", "new_history_learning",
            "history_history", "history_conditions", "history_seizures", "history_botox",
            "history_devices", "history_pain", "history_pt", "history_followup")),
        Map.entry("HISTORY_GAIT", List.of(
            "history_walking_support", "history_fms5", "history_fms50", "history_fms500",
            "history_walking_change", "history_gait_concerns")),
        Map.entry("HISTORY_CONCERNS", List.of("history_concerns")),
        Map.entry("HIP", List.of("hip_womac", "hip_ucla", "hip_harris")));

    // Legacy's UE_HISTORY_ID Struts group chain is hardcoded to length 3 in QuestionnaireServiceImpl
    // (UEH03/04/06 are orphaned, matching what we built).
    private static final List<String> UE_HISTORY_GROUPS = List.of("UEH01", "UEH02", "UEH05");

    // Legacy's SPORTS_ID Struts chain, confirmed linear/no-branching in 01-sports.txt.
    private static final List<String> SPORTS_GROUPS = List.of(
        "SPORTS9", "SPORTS1", "SPORTS2", "SPORTS3", "SPORTS4", "SPORTS5", "SPORTS6", "SPORTS7", "SPORTS8");

    private final QuestionnaireTrackingRepository repository;
    private final VisitRepository visitRepository;
    private final SportsQuestionnaireRepository sportsRepository;
    private final UeHistoryQuestionnaireRepository ueHistoryRepository;

    public QuestionnaireTrackingService(
            QuestionnaireTrackingRepository repository,
            VisitRepository visitRepository,
            SportsQuestionnaireRepository sportsRepository,
            UeHistoryQuestionnaireRepository ueHistoryRepository) {
        this.repository = repository;
        this.visitRepository = visitRepository;
        this.sportsRepository = sportsRepository;
        this.ueHistoryRepository = ueHistoryRepository;
    }

    @Transactional
    public void track(int patientId, List<CodeAssignment> assignments) {
        if (assignments == null || assignments.isEmpty()) {
            throw bad("At least one assigned questionnaire code is required.");
        }

        for (CodeAssignment assignment : assignments) {
            if (assignment.visitId() == null) {
                throw bad("visitId is required for every code.");
            }

            var visit = visitRepository.findById(assignment.visitId())
                .orElseThrow(() -> bad("Visit not found."));

            if (!visit.getPatientId().equals(patientId)) {
                throw bad("Visit does not belong to this patient.");
            }
        }

        IntStream.range(0, assignments.size()).forEach(index -> track(assignments.get(index), index));
    }

    private void track(CodeAssignment assignment, int index) {
        String code = assignment.code();
        int visitId = assignment.visitId();

        if (STATIC_PAGES.containsKey(code)) {
            for (String page : STATIC_PAGES.get(code)) {
                repository.insert(visitId, index + ":" + page, null);
            }
            return;
        }

        if (code.startsWith("PODCI_")) {
            String suffix = code.substring("PODCI_".length()).toLowerCase();

            for (int question = 1; question <= 27; question++) {
                String page = String.format("q2_%s_%03d", suffix, question);
                repository.insert(visitId, index + ":" + page, null);
            }
            return;
        }

        if ("SPORTS".equals(code)) {
            Integer sessionId = sportsRepository.findExistingSessionId(visitId);

            for (String group : SPORTS_GROUPS) {
                repository.insert(visitId, index + ":" + group, sessionId);
            }
            return;
        }

        if ("UE_HISTORY".equals(code)) {
            Integer sessionId = ueHistoryRepository.findExistingSessionId(visitId);

            for (String group : UE_HISTORY_GROUPS) {
                repository.insert(visitId, index + ":" + group, sessionId);
            }
            return;
        }
    }

    private static ResponseStatusException bad(String reason) {
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, reason);
    }
}