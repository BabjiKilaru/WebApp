package org.nemours.gaitlab.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Repository
public class ScheduleVisitRepository {

    private final JdbcTemplate jdbcTemplate;

    public ScheduleVisitRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Map<String, Object>> findVisitTypes() {
        return jdbcTemplate.queryForList("""
                    SELECT id, name
                    FROM public.new_visit_type
                    WHERE active = true
                    ORDER BY sortorder
                """);
    }

    public List<Map<String, Object>> findVisitSubTypes() {
        return jdbcTemplate.queryForList("""
                    SELECT
                        id,
                        name,
                        visit_type_id
                    FROM public.new_test_group
                    WHERE active = true
                    ORDER BY sortorder
                """);
    }

    public List<Map<String, Object>> findTests() {
        return jdbcTemplate.queryForList("""
                    SELECT
                        code,
                        name,
                        description
                    FROM public.new_test
                    WHERE active = true
                    ORDER BY sortorder
                """);
    }

    public List<Map<String, Object>> findRefferingDoctors() {
        return jdbcTemplate.queryForList("""
                    SELECT
                        id,
                        fname,
                        lname,
                        facility,
                        clin_type
                    FROM public.users
                    WHERE active = TRUE
                      AND category = 'P'
                      AND clin_type IN ('MD', 'DO')
                    ORDER BY lname ASC, fname ASC
                """);
    }

    public List<String> findDefaultTestsForGroup(Integer groupId) {
        return jdbcTemplate.queryForList("""
                    SELECT nt.code
                    FROM public.new_tests_to_groups ntg
                    INNER JOIN public.new_test nt
                        ON nt.code = ntg.test_code
                    WHERE ntg.group_id = ?
                      AND COALESCE(nt.active, true) = true
                    ORDER BY
                        nt.sortorder,
                        nt.name
                """,
                String.class,
                groupId);
    }

    public List<Map<String, Object>> findScheduledVisits(LocalDate date) {
        return jdbcTemplate.queryForList("""
                    SELECT
                        v.id AS "id",

                        v.pt_id AS "patientId",

                        p.fname AS "firstName",
                        p.lname AS "lastName",
                        p.mrn AS "mrn",

                        v.date AS "visitDate",

                        v.appt_time AS "startTime",
                        v.appt_time_end AS "endTime",

                        CASE
                            WHEN vt.name IS NULL
                                THEN v.visit_type
                            ELSE vt.name
                        END AS "visitType",

                        tg.name AS "visitSubType"

                    FROM public.visits v

                    INNER JOIN public.patients p
                        ON p.id = v.pt_id

                    LEFT JOIN public.new_visit_type vt
                        ON vt.id = v.visit_type_id

                    LEFT JOIN public.new_test_group tg
                        ON tg.id = v.test_group_id

                    WHERE v.date = ?

                      AND (
                            v.attendance IS NULL
                            OR TRIM(v.attendance) = ''
                            OR v.attendance = 'Yes'
                            OR v.attendance = 'Rescheduled'
                      )

                    ORDER BY
                        v.appt_time NULLS LAST,
                        v.id
                """,
                date);
    }
}
