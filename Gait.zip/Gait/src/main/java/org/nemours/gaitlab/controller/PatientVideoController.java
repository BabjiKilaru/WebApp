package org.nemours.gaitlab.controller;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.nemours.gaitlab.service.VideoService;
import org.nemours.gaitlab.service.VideoService.VideoMetadata;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.MediaTypeFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

@RestController
@RequestMapping("/api/patients/{patientId}/videos")
public class PatientVideoController {

    private static final Pattern BYTE_RANGE = Pattern.compile("^bytes=(\\d*)-(\\d*)$");
    private static final int BUFFER_SIZE = 16 * 1024;

    private final VideoService videoService;

    public PatientVideoController(VideoService videoService) {
        this.videoService = videoService;
    }

    @GetMapping
    public List<VideoMetadata> getPatientVideos(
            @PathVariable Integer patientId,
            @RequestParam(required = false) Integer visitId) {
        return videoService.findVideos(patientId, visitId);
    }

    @GetMapping("/{videoId}/content")
    public ResponseEntity<StreamingResponseBody> streamVideo(
            @PathVariable Integer patientId,
            @PathVariable String videoId,
            @RequestHeader(value = HttpHeaders.RANGE, required = false) String rangeHeader) throws IOException {
        Path video = videoService.resolveVideo(patientId, videoId);
        long fileLength = Files.size(video);
        long start = 0;
        long end = fileLength - 1;
        HttpStatus status = HttpStatus.OK;

        if (rangeHeader != null) {
            Matcher matcher = BYTE_RANGE.matcher(rangeHeader);
            if (!matcher.matches() || rangeHeader.contains(",")) {
                return rangeNotSatisfiable(fileLength);
            }

            try {
                if (matcher.group(1).isEmpty()) {
                    long suffixLength = Long.parseLong(matcher.group(2));
                    if (suffixLength <= 0) {
                        return rangeNotSatisfiable(fileLength);
                    }
                    start = Math.max(0, fileLength - suffixLength);
                } else {
                    start = Long.parseLong(matcher.group(1));
                    if (!matcher.group(2).isEmpty()) {
                        end = Long.parseLong(matcher.group(2));
                    }
                }
            } catch (NumberFormatException ex) {
                return rangeNotSatisfiable(fileLength);
            }

            end = Math.min(end, fileLength - 1);
            if (start > end || start >= fileLength) {
                return rangeNotSatisfiable(fileLength);
            }
            status = HttpStatus.PARTIAL_CONTENT;
        }

        long contentLength = end - start + 1;
        long startOffset = start;
        MediaType contentType = MediaTypeFactory.getMediaType(video.getFileName().toString())
                .orElse(MediaType.APPLICATION_OCTET_STREAM);
        String extension = video.getFileName().toString().toLowerCase(java.util.Locale.ROOT);
        if (extension.endsWith(".mov")) {
            // The clinic MOV files use H.264, but Chrome does not recognize video/quicktime.
            contentType = MediaType.parseMediaType("video/mp4");
        } else if (extension.endsWith(".mp4")) {
            contentType = MediaType.parseMediaType("video/mp4");
        } else if (extension.endsWith(".ogv")) {
            contentType = MediaType.parseMediaType("video/ogg");
        } else if (extension.endsWith(".mpg") || extension.endsWith(".mpeg")) {
            contentType = MediaType.parseMediaType("video/mpeg");
        } else if (extension.endsWith(".webm")) {
            contentType = MediaType.parseMediaType("video/webm");
        }
        String fileName = video.getFileName().toString();
        StreamingResponseBody body = output -> {
            try (InputStream input = Files.newInputStream(video)) {
                input.skipNBytes(startOffset);
                byte[] buffer = new byte[BUFFER_SIZE];
                long remaining = contentLength;
                while (remaining > 0) {
                    int read = input.read(buffer, 0, (int) Math.min(buffer.length, remaining));
                    if (read == -1) {
                        break;
                    }
                    output.write(buffer, 0, read);
                    remaining -= read;
                }
            }
        };

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(contentType);
        headers.setContentLength(contentLength);
        headers.set(HttpHeaders.ACCEPT_RANGES, "bytes");
        headers.setCacheControl("private, no-store");
        headers.setContentDisposition(ContentDisposition.inline().filename(fileName).build());
        if (status == HttpStatus.PARTIAL_CONTENT) {
            headers.set(HttpHeaders.CONTENT_RANGE,
                    "bytes " + start + "-" + end + "/" + fileLength);
        }
        return new ResponseEntity<>(body, headers, status);
    }

    private static ResponseEntity<StreamingResponseBody> rangeNotSatisfiable(long fileLength) {
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.CONTENT_RANGE, "bytes */" + fileLength);
        headers.set(HttpHeaders.ACCEPT_RANGES, "bytes");
        return new ResponseEntity<>(headers, HttpStatus.REQUESTED_RANGE_NOT_SATISFIABLE);
    }
}
