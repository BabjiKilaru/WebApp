package org.nemours.gaitlab.requests;

// Intentionally has no userid: the profile owner always comes from the authenticated session.
public record UpdateProfileRequest(
    String fname,
    String lname,
    String facility,
    String city,
    String state,
    String phone1,
    String phone2,
    String fax,
    String email,
    String address1,
    String zip
) {}
