package org.nemours.gaitlab.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

@Entity
@Table(name = "pt_botox", schema = "public")
public class PtBotox {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "botoxSeqGen")
    @SequenceGenerator(name = "botoxSeqGen", sequenceName = "botox_seq", allocationSize = 1)
    @Column(name = "id")
    private Integer id;

    @Column(name = "pt_id")
    private Integer patientId;

    @Column(name = "date")
    private String date;

    @Column(name = "side")
    private String side;

    @Column(name = "body_loc")
    private String body_loc;

    @Column(name = "facility")
    private String facility;

    @Column(name = "botox_md")
    private String physician;

    public Integer getId() {
        return id;
    }
    
    @JsonIgnore
    public Integer getPatientId() {
        return patientId;
    }

    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getSide() {
        return side;
    }

    public void setSide(String side) {
        this.side = side;
    }

    public String getBodyLocation() {
        return body_loc;
    }

    public void setBodyLocation(String bodyLocation) {
        this.body_loc = bodyLocation;
    }

    public String getFacility() {
        return facility;
    }

    public void setFacility(String facility) {
        this.facility = facility;
    }

    public String getPhysician() {
        return physician;
    }

    public void setPhysician(String physician) {
        this.physician = physician;
    }
}
