package org.nemours.gaitlab.repository;

import org.nemours.gaitlab.model.HistoryCondition;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface HistoryConditionRepository extends JpaRepository<HistoryCondition, String> {
    List<HistoryCondition> findAllByOrderByConditionAsc();
}
