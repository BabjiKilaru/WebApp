package org.nemours.gaitlab.requests;

public record CreateBotoxRequest(
    String date,
    String bodyLocation,
    String side,
    String facility,
    String physician
 ) {}
