package org.nemours.gaitlab.response;

public record ScheduledVisitOption(
    Integer visitId,
    Integer patientId,
    String firstName,
    String lastName,
    String mrn,
    String visitType,
    String visitSubType
) {
}
