package org.nemours.gaitlab.requests;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public record FormsPreviewRequest(
    @NotEmpty 
    List<@NotNull @Valid FormsVisitRequest> visits
) {
    
}
