package org.nemours.gaitlab.service;

import java.util.regex.Pattern;

import org.nemours.gaitlab.repository.ProfileRepository;
import org.nemours.gaitlab.repository.ProfileRepository.ProfileRow;
import org.nemours.gaitlab.requests.ChangePasswordRequest;
import org.nemours.gaitlab.requests.UpdateProfileRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
public class ProfileService {
    private static final Pattern EMAIL = Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");
    private static final Pattern PHONE = Pattern.compile("^[0-9+()\\-.\\sxX]*$");
    private static final Pattern ZIP = Pattern.compile("^[A-Za-z0-9\\-\\s]*$");
    private static final int MIN_PASSWORD_LENGTH = 8;
    private static final int MAX_PASSWORD_LENGTH = 128;
    private static final Pattern PASSWORD_NUMBER = Pattern.compile("[0-9]");
    private static final Pattern PASSWORD_UPPERCASE = Pattern.compile("[A-Z]");
    private static final Pattern PASSWORD_SPECIAL = Pattern.compile("[!@#$%^&*]");

    private final ProfileRepository repository;

    public ProfileService(ProfileRepository repository) {
        this.repository = repository;
    }

    public ProfileRow getProfile(String userid) {
        ProfileRow profile = repository.findProfile(userid);
        if (profile == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Profile not found.");
        }
        return profile;
    }

    @Transactional
    public ProfileRow updateProfile(String userid, UpdateProfileRequest request) {
        if (request == null) {
            throw bad("Profile details are required.");
        }

        ProfileRow cleaned = new ProfileRow(
                userid,
                required(request.fname(), "First Name", 50),
                required(request.lname(), "Last Name", 50),
                optional(request.facility(), "Facility", 100),
                optional(request.city(), "City", 50),
                optional(request.state(), "State", 50),
                phone(request.phone1(), "Phone Number"),
                phone(request.phone2(), "Phone Number 2"),
                phone(request.fax(), "Fax"),
                email(request.email()),
                optional(request.address1(), "Address", 200),
                zip(request.zip()));

        if (repository.updateProfile(userid, cleaned) == 0) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Profile not found.");
        }
        return getProfile(userid);
    }

    @Transactional
    public void changePassword(String userid, ChangePasswordRequest request) {
        if (request == null
                || isBlank(request.currentPassword())
                || isBlank(request.newPassword())
                || isBlank(request.confirmPassword())) {
            throw bad("Current password, new password, and confirmation are required.");
        }
        if (!request.newPassword().equals(request.confirmPassword())) {
            throw bad("New password and confirmation do not match.");
        }
        if (request.newPassword().length() < MIN_PASSWORD_LENGTH
                || request.newPassword().length() > MAX_PASSWORD_LENGTH) {
            throw bad("New password must be between " + MIN_PASSWORD_LENGTH + " and "
                    + MAX_PASSWORD_LENGTH + " characters.");
        }
        if (!PASSWORD_NUMBER.matcher(request.newPassword()).find()) {
            throw bad("New password must contain at least 1 number.");
        }
        if (!PASSWORD_UPPERCASE.matcher(request.newPassword()).find()) {
            throw bad("New password must contain at least 1 uppercase letter.");
        }
        if (!PASSWORD_SPECIAL.matcher(request.newPassword()).find()) {
            throw bad("New password must contain at least 1 special character: !@#$%^&*.");
        }
        if (request.newPassword().equals(request.currentPassword())) {
            throw bad("New password must be different from the current password.");
        }
        if (LegacyPasswordHasher.hash(request.newPassword())
                .equals(LegacyPasswordHasher.LEGACY_DEFAULT_PASSWORD_HASH)) {
            throw bad("New password must not use the retired shared password.");
        }
        if (!repository.passwordMatches(userid, LegacyPasswordHasher.hash(request.currentPassword()))) {
            throw bad("Current password is incorrect.");
        }
        if (repository.updatePassword(userid, LegacyPasswordHasher.hash(request.newPassword())) == 0) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Profile not found.");
        }
    }

    private static String required(String value, String label, int maxLength) {
        String cleaned = optional(value, label, maxLength);
        if (cleaned == null) {
            throw bad(label + " is required.");
        }
        return cleaned;
    }

    private static String optional(String value, String label, int maxLength) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        if (trimmed.length() > maxLength) {
            throw bad(label + " must be " + maxLength + " characters or fewer.");
        }
        return trimmed;
    }

    private static String phone(String value, String label) {
        String cleaned = optional(value, label, 25);
        if (cleaned != null && !PHONE.matcher(cleaned).matches()) {
            throw bad(label + " may contain only digits, spaces, and + ( ) - . x characters.");
        }
        return cleaned;
    }

    private static String email(String value) {
        String cleaned = optional(value, "Email", 254);
        if (cleaned != null && !EMAIL.matcher(cleaned).matches()) {
            throw bad("Email address is not valid.");
        }
        return cleaned;
    }

    private static String zip(String value) {
        String cleaned = optional(value, "Zip Code", 10);
        if (cleaned != null && !ZIP.matcher(cleaned).matches()) {
            throw bad("Zip Code may contain only letters, digits, spaces, and hyphens.");
        }
        return cleaned;
    }

    private static boolean isBlank(String value) {
        return value == null || value.isBlank();
    }

    private static ResponseStatusException bad(String reason) {
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, reason);
    }
}
