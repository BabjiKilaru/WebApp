package org.nemours.gaitlab.model;

import java.time.LocalDate;

public record VisitHomeDetails(
        Integer id,
        Integer patientId,
        String firstName,
        String lastName,
        String mrn,
        LocalDate dateOfBirth,
        String gender,
        LocalDate visitDate,
        String attendance,
        String startTime,
        String endTime,
        String visitType,
        String visitSubType,
        LocalDate scheduledDate,
        String surgeryDate,
        String diagnosis,
        String reasonForAnalysis,
        String internalComment,
        LocalDate interpretationDate,
        String interpretationMd,
        String interpretationPt,
        String referringDoctor,
        LocalDate dateSent,
        String visitPt,
        String visitPt2,
        String visitBiomech,
        String visitBiomech2,
        boolean modemsChildParentAvailable,
        boolean modemsAdolescentParentAvailable,
        boolean modemsAdolescentSelfAvailable) {
}
