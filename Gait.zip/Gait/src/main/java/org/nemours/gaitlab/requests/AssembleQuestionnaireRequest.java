package org.nemours.gaitlab.requests;

import java.util.List;

public record AssembleQuestionnaireRequest(
    Integer visitId,
    List<String> selections,
    String language
) {}

