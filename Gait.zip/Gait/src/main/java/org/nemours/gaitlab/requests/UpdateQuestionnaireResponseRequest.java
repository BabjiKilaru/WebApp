package org.nemours.gaitlab.requests;

import java.util.List;
import java.util.Map;

public record UpdateQuestionnaireResponseRequest(
        String version,
        Map<String, Object> fields,
        Map<String, List<Map<String, Object>>> lists
) {
}