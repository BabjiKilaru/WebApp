package org.nemours.gaitlab.service;

import org.nemours.gaitlab.model.ScheduleVisit;
import org.nemours.gaitlab.model.Visit;
import org.nemours.gaitlab.model.VisitTest;

import org.nemours.gaitlab.repository.ScheduleVisitRepository;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.repository.VisitTestRepository;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import java.util.List;
import java.util.Locale;
import java.util.Map;

@Service
public class ScheduleVisitService {

    private final ScheduleVisitRepository scheduleRepository;
    private final VisitRepository visitRepository;
    private final VisitTestRepository visitTestRepository;

    public ScheduleVisitService(
            ScheduleVisitRepository scheduleRepository,
            VisitRepository visitRepository,
            VisitTestRepository visitTestRepository) {

        this.scheduleRepository = scheduleRepository;
        this.visitRepository = visitRepository;
        this.visitTestRepository = visitTestRepository;
    }

    public List<Map<String, Object>> getVisitTypes() {
        return scheduleRepository.findVisitTypes();
    }

    public List<Map<String, Object>> getVisitSubTypes() {
        return scheduleRepository.findVisitSubTypes();
    }

    public List<Map<String, Object>> getTests() {
        return scheduleRepository.findTests();
    }

    public List<Map<String, Object>> getReferringDoctors() {
        return scheduleRepository.findRefferingDoctors();
    }

    public List<String> getDefaultTestsForGroup(Integer groupId) {
        return scheduleRepository.findDefaultTestsForGroup(groupId);
    }

    public List<Map<String, Object>> getScheduledVisits(LocalDate date) {
        return scheduleRepository.findScheduledVisits(date);
    }

    private LocalTime parseAppointmentTime(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }

        try {
            return LocalTime.parse(value.trim().toUpperCase(Locale.US), DateTimeFormatter.ofPattern("h:mm a", Locale.US));

        } catch (DateTimeParseException ex) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid appointment time. Use a value such as 8:00 AM.");
        }
    }

    private void validateAppointmentTimes(ScheduleVisit request) {
        LocalTime start = parseAppointmentTime(request.getStartTime());
        LocalTime end = parseAppointmentTime(request.getEndTime());

        if (start != null && end != null && !end.isAfter(start)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "End time must be after start time.");
        }
    }

    @Transactional
    public Visit createVisit(Integer patientId, ScheduleVisit request, String userId) {

        validateAppointmentTimes(request);
        Visit visit = new Visit();
        Integer nextVisitId = visitRepository.getNextVisitId();
        visit.setId(nextVisitId);
        visit.setPatientId(patientId);
        visit.setDate(request.getVisitDate());
        visit.setScheduledDate(request.getSchedulingDate());
        visit.setVisitTypeId(request.getVisitTypeId());
        visit.setTestGroupId(request.getVisitSubTypeId());
        visit.setAppointmentTime(request.getStartTime());
        visit.setAppointmentTimeEnd(request.getEndTime());
        visit.setSurgeryDate(request.getSurgeryDate());
        visit.setReferringDoctorId( request.getReferringMdId());

        Visit savedVisit = visitRepository.save(visit);

        if (request.getSelectedTests() != null && !request.getSelectedTests().isEmpty()) {
            for (String testCode : request.getSelectedTests()) {
                VisitTest visitTest = new VisitTest();
                visitTest.setVisitId(savedVisit.getId());
                visitTest.setTestCode(testCode);
                visitTest.setActive(true);
                visitTest.setComment(null);
                visitTest.setUserId(userId);
                visitTest.setCreated(LocalDateTime.now());
                visitTestRepository.save(visitTest);
            }
        }

        return savedVisit;
    }
}
