package org.nemours.gaitlab.requests;

public record CreateHealthConditionRequest(
    String conditionCode
) {}
