package org.nemours.gaitlab.service;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.nemours.gaitlab.repository.PodciQuestionnaireRepository;
import org.nemours.gaitlab.requests.PodciQuestionnaireRequest;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class PodciQuestionnaireService {

    private static final Set<String> VALID_VARIANTS = Set.of("ch", "ap", "as");

    private static final Set<String> YES_NO_GRID_FIELDS = buildYesNoGridFields();

    private static Set<String> buildYesNoGridFields() {
        Set<String> fields = new HashSet<>();

        for (int question = 7; question <= 22; question++) {
            for (char suffix : new char[] {'a', 'b', 'c'}) {
                fields.add(String.format("q2_%03d%c", question, suffix));
            }
        }

        return fields;
    }

    private final PodciQuestionnaireRepository repository;

    public PodciQuestionnaireService(PodciQuestionnaireRepository repository) {
        this.repository = repository;
    }

    public Map<String, Object> find(int patientId, int visitId, String variant) {
        if (!VALID_VARIANTS.contains(variant)) {
            throw bad("variant must be one of ch, ap, as.");
        }

        Integer visitPatientId = repository.findVisitPatientId(visitId);

        if (visitPatientId == null) {
            throw bad("Visit not found.");
        }

        if (!visitPatientId.equals(patientId)) {
            throw bad("Visit does not belong to this patient.");
        }

        return repository.findAnswers(visitId, variant);
    }

    public void save(int patientId, PodciQuestionnaireRequest request) {
        if (request.variant() == null || !VALID_VARIANTS.contains(request.variant())) {
            throw bad("variant must be one of ch, ap, as.");
        }

        if (request.visitId() == null) {
            throw bad("visitId is required.");
        }

        Integer visitPatientId = repository.findVisitPatientId(request.visitId());

        if (visitPatientId == null) {
            throw bad("Visit not found.");
        }

        if (!visitPatientId.equals(patientId)) {
            throw bad("Visit does not belong to this patient.");
        }

        int visitId = request.visitId();

        Map<String, Object> answers = request.answers() == null ? Map.of() : request.answers();
        Map<String, String> columnTypes = repository.findAnswerColumnTypes();

        LinkedHashMap<String, Object> columns = new LinkedHashMap<>();

        for (Map.Entry<String, Object> entry : answers.entrySet()) {
            String key = entry.getKey();
            String dbType = columnTypes.get(key);

            if (dbType == null) {
                throw bad("Unknown field: " + key);
            }

            columns.put(key, coerce(key, dbType, entry.getValue()));
        }

        repository.upsert(visitId, request.variant(), columns);
    }

    private static Object coerce(String key, String dbType, Object value) {
        if (value == null) {
            return null;
        }

        if ("smallint".equals(dbType)) {
            if (value instanceof Boolean bool) {
                return bool ? 1 : (YES_NO_GRID_FIELDS.contains(key) ? 2 : 0);
            }

            if (value instanceof Number number) {
                return number.intValue();
            }

            throw bad("Invalid value for " + key);
        }

        if ("boolean".equals(dbType)) {
            if (value instanceof Boolean bool) {
                return bool;
            }

            throw bad("Invalid value for " + key);
        }

        if ("text".equals(dbType)) {
            if (value instanceof String text) {
                return text;
            }

            throw bad("Invalid value for " + key);
        }

        throw bad("Unsupported field: " + key);
    }

    private static ResponseStatusException bad(String reason) {
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, reason);
    }
}