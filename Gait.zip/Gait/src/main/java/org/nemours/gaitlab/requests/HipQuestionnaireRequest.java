package org.nemours.gaitlab.requests;

import java.util.Map;

public record HipQuestionnaireRequest(
    Integer visitId,
    Map<String, Integer> womac,
    Integer ucla,
    Map<String, Integer> harris
) {}
