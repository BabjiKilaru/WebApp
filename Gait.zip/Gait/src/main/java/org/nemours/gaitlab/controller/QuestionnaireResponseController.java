package org.nemours.gaitlab.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.nemours.gaitlab.model.Visit;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.requests.UpdateQuestionnaireResponseRequest;
import org.nemours.gaitlab.service.QuestionnaireResponseService;

import org.springframework.dao.DataIntegrityViolationException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping(
        "/api/patients/{patientId}/questionnaire-responses"
)
public class QuestionnaireResponseController {

    private final QuestionnaireResponseService service;
    private final VisitRepository visitRepository;

    public QuestionnaireResponseController(QuestionnaireResponseService service, VisitRepository visitRepository) {
        this.service = service;
        this.visitRepository = visitRepository;
    }

    @GetMapping
    public Map<String, Object> getPatientResponses(@PathVariable int patientId) {
        return service.getPatientResponses(patientId);
    }

    @GetMapping("/options")
    public Map<String, Object> getOptions(@PathVariable int patientId, @RequestParam(required = false) String language) {
        return service.getOptions(patientId, language);
    }

    @GetMapping("/visits/{visitId}")
    public Map<String, Object> getVisitResponses(@PathVariable int patientId, @PathVariable int visitId) {
        return service.getVisitResponses(patientId, visitId);
    }

    @PutMapping("/baseline")
    public ResponseEntity<Void> updateBaselineResponses(
            @PathVariable int patientId,
            @RequestBody
            UpdateQuestionnaireResponseRequest request
    ) {
        service.updateResponses(patientId, null, "baseline", request);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/visits/{visitId}/{section}")
    public ResponseEntity<Void> updateVisitResponses(
            @PathVariable int patientId,
            @PathVariable int visitId,
            @PathVariable String section,
            @RequestBody
            UpdateQuestionnaireResponseRequest request
    ) {
        service.updateResponses(patientId, visitId, section, request);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/by-date/{date}")
    public Map<String, Object> getResponsesByDate(@PathVariable int patientId, @PathVariable LocalDate date) {
        return service.getVisitResponses(patientId, resolveVisitId(patientId, date));
    }

    @PutMapping("/by-date/{date}/{section}")
    public ResponseEntity<Void> updateResponsesByDate(
            @PathVariable int patientId,
            @PathVariable LocalDate date,
            @PathVariable String section,
            @RequestBody
            UpdateQuestionnaireResponseRequest request
    ) {
        service.updateResponses(patientId, resolveVisitId(patientId, date), section, request);
        return ResponseEntity.noContent().build();
    }

    private int resolveVisitId(int patientId, LocalDate date) {
        List<Visit> visits = visitRepository.findByPatientIdAndDateOrderByIdAsc(patientId, date);
        if (visits.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No visit exists for that date.");
        }
        if (visits.size() > 1) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Multiple visits exist for that date. Select a visit by ID.");
        }
        return visits.get(0).getId();
    }

    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<Map<String, String>> handleResponseStatus(ResponseStatusException exception) {
        String message = exception.getReason() == null ? "Request failed." : exception.getReason();
        return ResponseEntity
                .status(exception.getStatusCode())
                .body(Map.of("message", message));
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<Map<String, String>> handleDataIntegrityViolation() {
        return ResponseEntity
                .status(409)
                .body(Map.of("message", "The database could not save these questionnaire response changes. " + "Close and reopen the editor, then retry."));
    }
}