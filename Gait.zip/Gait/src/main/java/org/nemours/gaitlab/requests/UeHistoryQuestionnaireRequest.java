package org.nemours.gaitlab.requests;

import java.util.List;

public record UeHistoryQuestionnaireRequest(
    Integer visitId,
    Integer sessionId,
    String language,
    String handlesObjects,
    String dresses,
    String bathes,
    String toilets,
    List<String> armHandConcerns
) {}
