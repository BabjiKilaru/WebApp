package org.nemours.gaitlab.repository;

import java.util.List;
import java.math.BigDecimal;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class VideoAssessmentRepository {
    private final JdbcTemplate jdbc;

    public VideoAssessmentRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public record VisitRow(int id, Integer visitTypeId) {}

    public VisitRow findVisit(int patientId, int visitId, boolean lock) {
        var rows = jdbc.query("SELECT id, visit_type_id FROM public.visits WHERE id = ? AND pt_id = ?"
                + (lock ? " FOR UPDATE" : ""), (rs, n) ->
                new VisitRow(rs.getInt("id"), rs.getObject("visit_type_id", Integer.class)), visitId, patientId);
        return rows.isEmpty() ? null : rows.getFirst();
    }

    public Integer findSavingActor(String username) {
        var rows = jdbc.queryForList("""
                SELECT id FROM public.users WHERE userid = ? AND active = true
                AND (expiration IS NULL OR expiration > CURRENT_TIMESTAMP)
                AND lower(access) IN ('admin', 'user')
                """, Integer.class, username);
        return rows.isEmpty() ? null : rows.getFirst();
    }

    public record QuestionRow(int groupId, String groupName, int questionId, String itemName,
            String label, int order, int questionType, String template, String required) {}
    public record AnswerRow(int id, int questionId, String label, int order, boolean text,
            boolean number, boolean bool, String tag) {}
    public record AnswerState(int id, int questionId, Integer answerId, String text,
            BigDecimal number, Boolean bool, boolean active) {}

    public List<QuestionRow> findQuestions(int questionnaireId) {
        // The link table also contains self-links for unrelated forms. Restrict to the
        // canonical navigation groups and their L/R children, not every linked group.
        return jdbc.query("""
                SELECT DISTINCT g.id AS group_id, g.item_name AS group_name, q.id,
                    q.item_name, COALESCE(t.text, q.item_name) AS label, l.sortorder,
                    q.question_type_id, q.custom_template, q.required
                FROM nmquestionnaire.question_group g
                JOIN nmquestionnaire.question_group child
                  ON child.item_name = g.item_name OR child.item_name IN (g.item_name || 'L', g.item_name || 'R')
                JOIN nmquestionnaire.question_group_link l ON l.group_id = child.id
                JOIN nmquestionnaire.question q ON q.id = l.question_id
                LEFT JOIN LATERAL (
                    SELECT text FROM nmquestionnaire.question_text
                    WHERE question_id = q.id AND language_id = 1 ORDER BY id DESC LIMIT 1
                ) t ON true
                WHERE g.item_name ~ ?
                  AND EXISTS (SELECT 1 FROM nmquestionnaire.questionnaire_question_link link
                    WHERE link.questionnaire_id = ? AND (link.group_id = g.id OR link.next_group_id = g.id))
                ORDER BY g.item_name, l.sortorder, q.id
                """, (rs, n) -> new QuestionRow(rs.getInt("group_id"), rs.getString("group_name"),
                rs.getInt("id"), rs.getString("item_name"), rs.getString("label"),
                rs.getInt("sortorder"), rs.getInt("question_type_id"), rs.getString("custom_template"),
                rs.getString("required")), questionnaireId == 3 ? "^RVA0[1-9]$" : "^UEVA(0[1-9]|1[01])$", questionnaireId);
    }

    public List<AnswerRow> findAnswers(int questionId) {
        return jdbc.query("""
                SELECT a.*, COALESCE(t.text, a.title, '') AS label FROM nmquestionnaire.answer a
                LEFT JOIN LATERAL (SELECT text FROM nmquestionnaire.answer_text
                    WHERE answer_id = a.id AND language_id = 1 ORDER BY id DESC LIMIT 1) t ON true
                WHERE a.question_id = ? ORDER BY a.sortorder, a.id
                """, (rs, n) -> new AnswerRow(rs.getInt("id"), rs.getInt("question_id"), rs.getString("label"),
                rs.getInt("sortorder"), rs.getBoolean("can_take_text"), rs.getBoolean("can_take_num"),
                rs.getBoolean("can_take_bool"), rs.getString("tag")), questionId);
    }

    public List<AnswerState> findAnswerStates(int visitId, int questionnaireId) {
        return jdbc.query("""
                SELECT DISTINCT ON (pa.question_id, pa.answer_id) pa.*
                FROM nmquestionnaire.patient_answer pa
                JOIN nmquestionnaire.session s ON s.id = pa.session_id
                WHERE s.visit_id = ? AND s.questionnaire_id = ?
                ORDER BY pa.question_id, pa.answer_id, pa.id DESC
                """, (rs, n) -> new AnswerState(rs.getInt("id"), rs.getInt("question_id"),
                rs.getObject("answer_id", Integer.class), rs.getString("answer_text"),
                rs.getBigDecimal("answer_num"), rs.getObject("answer_bool", Boolean.class),
                rs.getBoolean("active")), visitId, questionnaireId);
    }

    public int startSession(int visitId, int questionnaireId, int actorId, int groupId) {
        return jdbc.queryForObject("""
                INSERT INTO nmquestionnaire.session
                    (visit_id, questionnaire_id, language_id, auth_id, group_id, begin)
                VALUES (?, ?, 1, ?, ?, now()) RETURNING id
                """, Integer.class, visitId, questionnaireId, actorId, groupId);
    }

    public void saveAnswer(int visitId, int questionnaireId, int sessionId, int questionId,
            Integer answerId, String text, BigDecimal number, Boolean bool, boolean active) {
        jdbc.update("""
                UPDATE nmquestionnaire.patient_answer SET active = false
                WHERE question_id = ? AND answer_id IS NOT DISTINCT FROM ?
                  AND active = true AND session_id IN
                    (SELECT id FROM nmquestionnaire.session WHERE visit_id = ? AND questionnaire_id = ?)
                """, questionId, answerId, visitId, questionnaireId);
        // An inactive marker distinguishes an explicit unchecked/cleared value from
        // a never-answered field without appearing selected in the legacy renderer.
        jdbc.update("""
                INSERT INTO nmquestionnaire.patient_answer
                    (session_id, question_id, answer_id, answer_text, answer_num, answer_bool, time, active)
                VALUES (?, ?, ?, ?, ?, ?, now(), ?)
                """, sessionId, questionId, answerId, text, number, bool, active);
    }

    public void saveStandardField(int visitId, String name, String choice) {
        int updated = jdbc.update("""
                UPDATE public.video_interp_data SET choice = ?
                WHERE id = (SELECT id FROM public.video_interp_data WHERE visit_id = ? AND name = ?
                    ORDER BY id DESC LIMIT 1)
                """, choice, visitId, name);
        if (updated == 0) {
            jdbc.update("INSERT INTO public.video_interp_data (visit_id, name, choice) VALUES (?, ?, ?)",
                    visitId, name, choice);
        }
    }

    public void saveComment(int visitId, int groupId, String comments) {
        int updated = jdbc.update("""
                UPDATE public.video_interp_comments SET comments = ?
                WHERE id = (SELECT id FROM public.video_interp_comments WHERE visit_id = ? AND group_id = ?
                    ORDER BY id DESC LIMIT 1)
                """, comments, visitId, groupId);
        if (updated == 0) {
            jdbc.update("INSERT INTO public.video_interp_comments (visit_id, group_id, comments) VALUES (?, ?, ?)",
                    visitId, groupId, comments);
        }
    }

    public record GroupRow(
        Integer id,
        String name
    ) {}

    public record FieldRow(
        Integer id,
        Integer groupId,
        String paramName,
        String displayName,
        Integer order,
        String choice
    ) {}

    public record CommentRow(
        Integer groupId,
        String comments
    ) {}

    public List<GroupRow> findGroups() {
        String sql = """
            SELECT
                id,
                group_name
            FROM public.video_interp_groups
            WHERE id BETWEEN 0 AND 13
            ORDER BY id
            """;
        
        return jdbc.query(sql, (rs, rowNum) -> new GroupRow(
            rs.getInt("id"),
            rs.getString("group_name")
        ));
    }

    public List<FieldRow> findFields(int visitId) {
        String sql = """
            SELECT
                f.id,
                f.group_id,
                f.param_name,
                f.display_name,
                f.place_in_group,
                d.choice
            FROM public.video_interp_fields f
            LEFT JOIN LATERAL (
                SELECT vid.choice
                FROM public.video_interp_data vid
                WHERE vid.visit_id = ? AND vid.name = f.param_name
                ORDER BY vid.id DESC
                LIMIT 1
            ) d ON true
            WHERE f.hide = false
            ORDER BY f.group_id, f.place_in_group, f.id
            """;
        
        return jdbc.query(sql, (rs, rowNum) -> new FieldRow(
            rs.getInt("id"),
            rs.getInt("group_id"),
            rs.getString("param_name"),
            rs.getString("display_name"),
            rs.getInt("place_in_group"),
            rs.getString("choice")
        ), visitId);
    }

    public List<CommentRow> findComments(int visitId) {
        String sql = """
            SELECT DISTINCT ON (group_id)
                group_id,
                comments
            FROM public.video_interp_comments
            WHERE visit_id = ?
            ORDER BY group_id, id DESC
            """;

        return jdbc.query(sql, (rs, rowNum) -> new CommentRow(
            rs.getInt("group_id"),
            rs.getString("comments")
        ), visitId);
    }
}
