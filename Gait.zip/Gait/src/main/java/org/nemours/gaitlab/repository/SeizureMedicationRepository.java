package org.nemours.gaitlab.repository;

import org.nemours.gaitlab.model.SeizureMedication;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SeizureMedicationRepository extends JpaRepository<SeizureMedication, String> {
    List<SeizureMedication> findAllByOrderByMedAsc();
}
