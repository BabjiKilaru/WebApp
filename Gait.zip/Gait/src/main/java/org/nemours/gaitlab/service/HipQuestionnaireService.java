package org.nemours.gaitlab.service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.nemours.gaitlab.repository.HipQuestionnaireRepository;
import org.nemours.gaitlab.requests.HipQuestionnaireRequest;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class HipQuestionnaireService {

    private static final List<String> WOMAC_KEYS = IntStream.rangeClosed(1, 24).mapToObj(i -> String.format("womac_%02d", i)).toList();

    private static final List<String> HARRIS_KEYS = IntStream.rangeClosed(1, 8).mapToObj(i -> String.format("harris_%02d", i)).toList();

    public record HipQuestionnaireResponse(Map<String, Integer> womac, Map<String, Integer> harris, Integer ucla) {}

    private final HipQuestionnaireRepository repository;

    public HipQuestionnaireService(HipQuestionnaireRepository repository) {
        this.repository = repository;
    }

    public HipQuestionnaireResponse find(int patientId, int visitId) {
        Integer visitPatientId = repository.findVisitPatientId(visitId);

        if (visitPatientId == null) {
            throw bad("Visit not found.");
        }

        if (!visitPatientId.equals(patientId)) {
            throw bad("Visit does not belong to this patient.");
        }

        Map<String, Object> row = repository.findByVisitId(visitId);

        if (row == null) {
            return new HipQuestionnaireResponse(Map.of(), Map.of(), null);
        }

        LinkedHashMap<String, Integer> womac = new LinkedHashMap<>();

        for (String key : WOMAC_KEYS) {
            if (row.get(key) != null) {
                womac.put(key, (Integer) row.get(key));
            }
        }

        LinkedHashMap<String, Integer> harris = new LinkedHashMap<>();

        for (String key : HARRIS_KEYS) {
            if (row.get(key) != null) {
                harris.put(key, (Integer) row.get(key));
            }
        }

        Integer ucla = null;

        for (int i = 1; i <= 10; i++) {
            Object value = row.get(String.format("ucla_%02d", i));

            if (value != null && ((Integer) value) == 1) {
                ucla = i;
                break;
            }
        }

        return new HipQuestionnaireResponse(womac, harris, ucla);
    }

    public void save(int patientId, HipQuestionnaireRequest request) {
        if (request.visitId() == null) {
            throw bad("visitId is required.");
        }

        Integer visitPatientId = repository.findVisitPatientId(request.visitId());

        if (visitPatientId == null) {
            throw bad("Visit not found.");
        }

        if (!visitPatientId.equals(patientId)) {
            throw bad("Visit does not belong to this patient.");
        }

        int visitId = request.visitId();

        Map<String, Integer> womac = request.womac() == null ? Map.of() : request.womac();
        Map<String, Integer> harris = request.harris() == null ? Map.of() : request.harris();

        for (String key : womac.keySet()) {
            if (!WOMAC_KEYS.contains(key)) {
                throw bad("Unknown womac field: " + key);
            }
        }

        for (String key : harris.keySet()) {
            if (!HARRIS_KEYS.contains(key)) {
                throw bad("Unknown harris field: " + key);
            }
        }

        if (request.ucla() != null && (request.ucla() < 1 || request.ucla() > 10)) {
            throw bad("ucla must be between 1 and 10.");
        }

        LinkedHashMap<String, Object> columns = new LinkedHashMap<>();

        for (String key : WOMAC_KEYS) {
            if (!womac.containsKey(key)) {
                continue;
            }

            Integer value = womac.get(key);

            if (value != null && (value < 0 || value > 4)) {
                throw bad("Invalid value for " + key);
            }

            columns.put(key, value);
        }

        for (String key : HARRIS_KEYS) {
            if (harris.containsKey(key)) {
                columns.put(key, harris.get(key));
            }
        }

        if (request.ucla() != null) {
            for (int i = 1; i <= 10; i++) {
                columns.put(String.format("ucla_%02d", i), request.ucla() == i ? 1 : 0);
            }
        }

        if (!columns.isEmpty()) {
            repository.upsert(visitId, columns);
        }
    }

    private static ResponseStatusException bad(String reason) {
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, reason);
    }
}
