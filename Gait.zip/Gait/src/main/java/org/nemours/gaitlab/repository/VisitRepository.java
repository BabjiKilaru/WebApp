package org.nemours.gaitlab.repository;

import java.util.List;
import java.time.LocalDate;

import org.nemours.gaitlab.model.Visit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface VisitRepository extends JpaRepository<Visit, Integer> {

    @Query(value = """
            SELECT v.id AS "id", v.visit_type_id AS "visitTypeId"
            FROM public.visits v
            WHERE v.id = :visitId AND v.pt_id = :patientId
            """, nativeQuery = true)
    java.util.Optional<InterpretationVisit> findInterpretationVisitByIdAndPatientId(
            @Param("visitId") Integer visitId,
            @Param("patientId") Integer patientId);

    interface InterpretationVisit {
        Integer getVisitTypeId();
    }

    List<Visit> findByPatientId(Integer patientId);

    List<Visit> findByPatientIdOrderByDateDesc(Integer patientId);

    @Query(value = """
            SELECT v.id AS id, v.date::text AS "visitDate"
            FROM public.visits v
            WHERE v.pt_id = :patientId
            ORDER BY v.date DESC, v.id DESC
            """, nativeQuery = true)
    List<VideoVisitDate> findVideoVisitDatesByPatientId(@Param("patientId") Integer patientId);

    @Query(value = """
            SELECT v.id AS id, v.date::text AS "visitDate"
            FROM public.visits v
            WHERE v.pt_id = :patientId AND v.id = :visitId
            """, nativeQuery = true)
    java.util.Optional<VideoVisitDate> findVideoVisitDateByIdAndPatientId(
            @Param("visitId") Integer visitId,
            @Param("patientId") Integer patientId);

    List<Visit> findByPatientIdAndDateOrderByIdAsc(
        Integer patientId,
        LocalDate date
    );

    @Query(
        value = """
                SELECT COALESCE(MAX(id), 0) + 1
                FROM public.visits
                """,
            nativeQuery = true
    )
    Integer getNextVisitId();

    @Query(value = """
            SELECT 
	            v.id, 
	            v.pt_id, 
                v.date,
                v.attendance,
	            CASE WHEN vt.name IS NULL THEN v.visit_type ELSE vt.name END AS visit_type,
	            tg.name AS visitSubType
            FROM public.visits v
            LEFT JOIN public.new_visit_type vt ON v.visit_type_id = vt.id
            LEFT JOIN public.new_test_group tg ON v.test_group_id = tg.id
            WHERE v.pt_id = :patientId
            ORDER BY v.date DESC, v.id DESC;
            """, nativeQuery = true)
    List<Object[]> findVisitDisplayByPatientId( @Param("patientId") Integer patientId);

    @Query(value = """
            SELECT 
                v.id AS visit_id,
                p.id AS patient_id,
                p.fname,
                p.lname,
                p.mrn,
                CASE 
                    WHEN vt.name IS NULL
                    THEN v.visit_type
                    ELSE vt.name
                END AS visit_type,
                tg.name AS visit_sub_type
            FROM public.patients p
            JOIN public.visits v
                ON v.pt_id = p.id
            LEFT JOIN public.new_visit_type vt
                ON v.visit_type_id = vt.id
            LEFT JOIN public.new_test_group tg
                ON v.test_group_id = tg.id
            WHERE v.date = :date
                AND (v.attendance IS NULL
                    OR v.attendance = ''
                    OR v.attendance = 'Yes')
            ORDER BY p.lname, p.fname, v.id
            """,
            nativeQuery = true
        )
    List<Object[]> findScheduledVisitsByDate(@Param("date") LocalDate date);

    interface VideoVisitDate {
        Integer getId();

        String getVisitDate();
    }
}
