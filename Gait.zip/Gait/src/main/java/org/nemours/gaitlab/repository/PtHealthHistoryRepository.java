package org.nemours.gaitlab.repository;

import org.nemours.gaitlab.model.PtHealthHistory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PtHealthHistoryRepository extends JpaRepository<PtHealthHistory, Integer> {
    List<PtHealthHistory> findByPatientIdOrderByAgeAsc(Integer patientId);
}
