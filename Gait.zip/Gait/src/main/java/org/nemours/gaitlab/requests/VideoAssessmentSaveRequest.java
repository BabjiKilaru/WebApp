package org.nemours.gaitlab.requests;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import tools.jackson.core.JsonParser;
import tools.jackson.core.JsonToken;
import tools.jackson.databind.DeserializationContext;
import tools.jackson.databind.annotation.JsonDeserialize;
import tools.jackson.databind.deser.std.StdDeserializer;

public record VideoAssessmentSaveRequest(
        @NotBlank @Size(max = 64) @JsonDeserialize(using = StrictString.class) String revision,
        @NotNull @Size(max = 30) List<@NotNull @Valid Group> groups) {
    @JsonAnySetter
    public void rejectUnknown(String name, Object value) {
        throw new IllegalArgumentException("Unknown assessment property: " + name);
    }

    public record Group(
            @NotNull @JsonDeserialize(using = StrictInteger.class) Integer id,
            @JsonProperty(required = true) @Size(max = 100000) @JsonDeserialize(using = StrictString.class) String comments,
            @NotNull @Size(max = 1000) List<@NotNull @Valid Field> fields) {
        @JsonAnySetter
        public void rejectUnknown(String name, Object value) {
            throw new IllegalArgumentException("Unknown group property: " + name);
        }
    }

    public record Field(
            @NotNull @JsonDeserialize(using = StrictInteger.class) Integer id,
            @JsonProperty(required = true) @Size(max = 100000) @JsonDeserialize(using = StrictString.class) String choice) {
        @JsonAnySetter
        public void rejectUnknown(String name, Object value) {
            throw new IllegalArgumentException("Unknown field property: " + name);
        }
    }

    public static final class StrictString extends StdDeserializer<String> {
        public StrictString() { super(String.class); }
        @Override
        public String deserialize(JsonParser parser, DeserializationContext context) {
            if (parser.currentToken() != JsonToken.VALUE_STRING) {
                throw new IllegalArgumentException("Expected a string or null.");
            }
            return parser.getString();
        }
    }

    public static final class StrictInteger extends StdDeserializer<Integer> {
        public StrictInteger() { super(Integer.class); }
        @Override
        public Integer deserialize(JsonParser parser, DeserializationContext context) {
            if (parser.currentToken() != JsonToken.VALUE_NUMBER_INT) {
                throw new IllegalArgumentException("Expected an integer ID.");
            }
            return parser.getIntValue();
        }
    }
}
