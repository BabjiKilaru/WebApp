package org.nemours.gaitlab.requests;

public record CreateHealthHistoryRequest(
    String age,
    String conditionCode
) {}