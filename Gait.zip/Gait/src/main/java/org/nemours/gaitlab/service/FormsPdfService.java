package org.nemours.gaitlab.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.regex.Pattern;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.io.IOUtils;
import org.apache.pdfbox.io.RandomAccessReadBuffer;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationWidget;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.pdmodel.interactive.form.PDTextField;
import org.nemours.gaitlab.repository.FormsRepository;
import org.nemours.gaitlab.repository.FormsRepository.PrintableVisitRow;
import org.nemours.gaitlab.requests.FormsPreviewRequest;
import org.nemours.gaitlab.requests.FormsVisitRequest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class FormsPdfService {

    private static final DateTimeFormatter FULL_DATE = DateTimeFormatter.ofPattern("MM/dd/yyyy");

    private static final DateTimeFormatter SHORT_DATE = DateTimeFormatter.ofPattern("M/d/yy");

    private static final Pattern FONT_SIZE_PATTERN = Pattern.compile("-?\\d+(?:\\.\\d+)?(?=\\s+Tf)");

    private final FormsRepository formsRepository;

    public FormsPdfService(FormsRepository formsRepository) {
        this.formsRepository = formsRepository;
    }

    public byte[] generatePreview(FormsPreviewRequest request) {
        try {
            List<byte[]> completedForms = new ArrayList<>();

            for (FormsVisitRequest visitRequest : request.visits()) {
                PrintableVisitRow visit = formsRepository 
                        .findPrintableVisit(visitRequest.visitId())
                        .orElseThrow(() -> new ResponseStatusException(
                                HttpStatus.NOT_FOUND, "Visit not found: " + visitRequest.visitId()
                            )
                        );

                List<FormTemplate> templates = visitRequest.forms()
                        .stream()
                        .map(this::getTemplate)
                        .distinct()
                        .sorted(Comparator.comparingInt(FormTemplate::ordinal))
                        .toList();

                List<LocalDate> previousVisitDates = templates.contains(FormTemplate.ENGINEER) ? formsRepository
                            .findPreviousVisitDates(visit.patientId(), visit.visitId(), visit.visitDate()) : List.of();

                for (FormTemplate template : templates) {
                    completedForms.add(fillTemplate(template, visit, previousVisitDates));
                }
            }

            if (completedForms.isEmpty()) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No printable forms were selected.");
            }
            return mergeForms(completedForms);
        } catch (IOException exception) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to generate printable forms.", exception);
        }
    }

    private FormTemplate getTemplate(String formKey) {
        String normalizedKey = formKey.trim();

        return FormTemplate
            .fromKey(normalizedKey)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Unsupported form: " + normalizedKey));
    }

    private byte[] fillTemplate(
            FormTemplate template,
            PrintableVisitRow visit,
            List<LocalDate> previousVisitDates)
            throws IOException {

        byte[] templateBytes = loadTemplate(template);

        try (
            PDDocument document = Loader.loadPDF(templateBytes);
            ByteArrayOutputStream output = new ByteArrayOutputStream()
        ) {
            Map<String, String> values = getFieldValues(template, visit, previousVisitDates);

            PDAcroForm acroForm = document.getDocumentCatalog().getAcroForm();

            if (!values.isEmpty() && acroForm == null) {
                throw new IOException(
                    "PDF form fields are missing from "
                        + template.getResourcePath()
                );
            }

            if (acroForm != null) {
                acroForm.setNeedAppearances(false);

                for (Map.Entry<String, String> entry : values.entrySet()) {
                    setField(acroForm, entry.getKey(), entry.getValue(), template);
                }

                if (template == FormTemplate.ANALYSIS) {
                    setGender(acroForm, visit.gender(), template);
                }

                acroForm.refreshAppearances();
                acroForm.flatten();
            }
            document.save(output);
            return output.toByteArray();
        }
    }

    private byte[] loadTemplate(FormTemplate template) throws IOException {

        ClassPathResource resource = new ClassPathResource(template.getResourcePath());

        if (!resource.exists()) {
            throw new IOException("PDF template not found: " + template.getResourcePath());
        }

        try (InputStream input = resource.getInputStream()) {
            return input.readAllBytes();
        }
    }

    private void setField(
            PDAcroForm acroForm,
            String fieldName,
            String value,
            FormTemplate template)
            throws IOException {

        PDField field = acroForm.getField(fieldName);

        if (field == null) {
            throw new IOException(
                "Field "
                    + fieldName
                    + " was not found in "
                    + template.getResourcePath()
            );
        }

        if(field instanceof PDTextField textField) {
            configureFontSize(textField, template, fieldName);
        }

        field.setValue(safe(value));
    }

    private void configureFontSize(PDTextField textField, FormTemplate template, String fieldName) {
        String fontSize = "0";
        if ( template == FormTemplate.ANALYSIS && ("ClientName".equals(fieldName) || "ClientAge".equals(fieldName))) {
            fontSize = "7.5";
        }else if ( template == FormTemplate.ANALYSIS && ("ClientDOB".equals(fieldName) || "ClientID".equals(fieldName) || "EvalDate".equals(fieldName) || "InfoDiagnosis".equals(fieldName))) {
            fontSize = "8";
        }else if (template == FormTemplate.PT_EVAL) {
            fontSize = "8";
        }else if (template == FormTemplate.PT_FOOT_EVAL) {
            fontSize = "9";
        }else if ( template == FormTemplate.ENGINEER && ("EngName".equals(fieldName) || "EngID".equals(fieldName) || "EngTestDate".equals(fieldName) || "EngDOB".equals(fieldName)  || "EngAge".equals(fieldName))) {
            fontSize = "9";
        }

        String appearance = textField.getDefaultAppearance();

        if(appearance == null || appearance.isBlank()) {
            return;
        }

        String updatedAppearance = FONT_SIZE_PATTERN.matcher(appearance).replaceFirst(fontSize);

        textField.setDefaultAppearance(updatedAppearance);

        for (PDAnnotationWidget widget : textField.getWidgets()) {
            widget.getCOSObject().setString(COSName.DA, updatedAppearance);
        }
    }

    private void setGender(
            PDAcroForm acroForm,
            String gender,
            FormTemplate template)
            throws IOException {

        String normalizedGender =
            safe(gender)
                .trim()
                .toUpperCase(Locale.US);

        String genderValue = null;

        if (normalizedGender.startsWith("M")) {
            genderValue = "1";
        } else if (normalizedGender.startsWith("F")) {
            genderValue = "2";
        }

        if (genderValue != null) {
            setField(acroForm, "Gender", genderValue, template);
        }
    }

    private Map<String, String> getFieldValues(
            FormTemplate template,
            PrintableVisitRow visit,
            List<LocalDate> previousVisitDates) {

        Map<String, String> values = new LinkedHashMap<>();

        String patientName = joinWithSpace(visit.firstName(), visit.lastName());

        String visitDate = formatFullDate(visit.visitDate());

        String dateAndTime = combineDateAndTime(visitDate, visit.appointmentTime());

        String dateOfBirth = formatFullDate(visit.dateOfBirth());

        String age = calculateAge(visit.dateOfBirth(), visit.visitDate());

        String referringDoctor = formatReferringDoctor(visit);

        String oldVisits = previousVisitDates.stream().map(this::formatShortDate).collect(Collectors.joining(", "));

        switch (template) {
            case PATIENT_VISIT -> {
                values.put("PatientName", patientName);
                values.put("ApptDate", visitDate);
                values.put("ApptTime", safe(visit.appointmentTime()));
            }

            case ANALYSIS -> {
                values.put("ClientName", patientName);
                values.put("ClientID", safe(visit.mrn()));
                values.put("ClientDOB", dateOfBirth);
                values.put("ClientAge", age);
                values.put("EvalDate", dateAndTime);
                values.put("InfoDiagnosis", safe(visit.diagnosis()));
                values.put("InfoReferred", referringDoctor);
            }

            case PT_EVAL -> {
                values.put("PTName", patientName);
                values.put("MRN", safe(visit.mrn()));
                values.put("PTDate", visitDate);
            }

            case ENGINEER -> {
                values.put("EngName", patientName);
                values.put("EngID", safe(visit.mrn()));
                values.put("EngTestDate", visitDate);
                values.put("EngReferring", referringDoctor);
                values.put("EngDOB", dateOfBirth);
                values.put("EngAge", age);
                values.put("EngDiagnosis", safe(visit.diagnosis()));
                values.put("EngOldVisits", oldVisits);
            }

            case PT_FOOT_EVAL -> {
                values.put("PtName", patientName);
                values.put("MRN", safe(visit.mrn()));
            }

            case SHUEE -> {
            }

            case UE_ENGINEER, RUNNING_ENGINEER -> {
                values.put("PtName", patientName);
                values.put("MRN", safe(visit.mrn()));
                values.put("Date", visitDate);
                values.put("DOB", dateOfBirth);
                values.put("Age", age);
            }

            case UE_EVAL -> {
                values.put("MRN", safe(visit.mrn()));
                values.put("Diagnosis", safe(visit.diagnosis()));
                values.put("Age", age);
                values.put("PtName", patientName);
                values.put("Referring", referringDoctor);
                values.put("Date", visitDate);
                values.put("DOB", dateOfBirth);
            }
        }
        return values;
    }

    private byte[] mergeForms(List<byte[]> completedForms) throws IOException {
        PDFMergerUtility merger = new PDFMergerUtility();

        ByteArrayOutputStream output = new ByteArrayOutputStream();

        for (byte[] completedForm : completedForms) {
            merger.addSource(new RandomAccessReadBuffer(completedForm));
        }

        merger.setDestinationStream(output);

        merger.mergeDocuments(IOUtils.createMemoryOnlyStreamCache());

        return output.toByteArray();
    }

    private String calculateAge(LocalDate dateOfBirth, LocalDate visitDate) {
        if (dateOfBirth == null || visitDate == null || dateOfBirth.isAfter(visitDate)) {
            return "";
        }

        return String.valueOf(Period
                .between(dateOfBirth, visitDate)
                .getYears()
        );
    }

    private String formatFullDate(LocalDate date) {
        return date == null ? "" : date.format(FULL_DATE);
    }

    private String formatShortDate(LocalDate date) {
        return date == null ? "" : date.format(SHORT_DATE);
    }

    private String combineDateAndTime(String date, String time) {
        return Stream
            .of(safe(date), safe(time))
            .map(String::trim)
            .filter(value -> !value.isEmpty())
            .collect(Collectors.joining(" @ "));
    }

    private String formatReferringDoctor(PrintableVisitRow visit) {
        String doctorName = joinWithSpace(visit.referringFirstName(), visit.referringLastName());

        return Stream
            .of(doctorName, safe(visit.referringClinicianType()), safe(visit.referringFacility()))
            .map(String::trim)
            .filter(value -> !value.isEmpty())
            .collect(Collectors.joining(", "));
    }

    private String joinWithSpace(String firstValue, String secondValue) {
        return Stream
            .of(safe(firstValue), safe(secondValue))
            .map(String::trim)
            .filter(value -> !value.isEmpty())
            .collect(Collectors.joining(" "));
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }
}