package org.nemours.gaitlab.repository;

import org.nemours.gaitlab.model.BodyLocation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BodyLocationRepository extends JpaRepository<BodyLocation, String> {
    List<BodyLocation> findAllByOrderByLocationAsc();
}
