import { Injectable } from "@angular/core";
import { HttpClient, HttpParams } from "@angular/common/http";
import { Observable } from "rxjs";

import { Patient } from "./patient";

@Injectable({
  providedIn: "root",
})
export class PatientService {
  private readonly apiUrl = "/api/patients";
  constructor(private http: HttpClient) {}

  getPatientById(patientId: number) {
    return this.http.get<Patient>(`/api/patients/${patientId}`);
  }

  getGeneralDiagnoses(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/general-diagnoses`);
  }

  createPatient(patient: Partial<Patient>): Observable<Patient> {
    return this.http.post<Patient>(
      this.apiUrl, patient
    );
  }

  updatePatient(id: number, patient: Partial<Patient>): Observable<Patient>{
    return this.http.put<Patient>(`${this.apiUrl}/${id}`, patient);
  }

  getByMrn(mrn: string): Observable<Patient> {
    return this.http.get<Patient>(
      `${this.apiUrl}/mrn/${encodeURIComponent(mrn)}`,
    );
  }

  searchByLastName(lastName: string): Observable<Patient[]> {
    const params = new HttpParams().set("lastName", lastName);

    return this.http.get<Patient[]>(this.apiUrl, { params });
  }

  searchPatients(query: string): Observable<Patient[]> {
    const params = new HttpParams().set("query", query);

    return this.http.get<Patient[]>(`${this.apiUrl}/search`, { params });
  }
}
