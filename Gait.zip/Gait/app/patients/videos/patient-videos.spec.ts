import { ComponentFixture, TestBed } from "@angular/core/testing";
import { HttpClient, HttpParams } from "@angular/common/http";
import { of, throwError } from "rxjs";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { PatientVideos } from "./patient-videos";
import { Patient } from "../patient";
import { Visit } from "../visits/visits";

describe("PatientVideos", () => {
  let fixture: ComponentFixture<PatientVideos>;
  let component: PatientVideos;
  let httpMock: { get: ReturnType<typeof vi.fn> };
  let requestedVisitId: string | null = null;

  const patient: Patient = {
    id: 14,
    mrn: "10000000",
    firstName: "Alex",
    lastName: "Sample",
    dateOfBirth: "2010-01-01",
    gender: "F",
    label: false,
    historyRelationship: "",
    ageWalkWithSupport: null,
    ageWalkWithoutSupport: null,
    learning: null
  };

  const visit: Visit = {
    id: 21,
    patientId: patient.id,
    attendance: "Yes",
    date: "2003-01-12",
    visitType: "Gait",
    visitSubType: "Full"
  };

  beforeEach(async () => {
    requestedVisitId = null;
    httpMock = {
      get: vi.fn((url: string, options?: { params?: HttpParams }) => {
        if (url.endsWith("/visits")) {
          return of([visit]);
        }
        if (url.endsWith("/overview")) {
          return of({
            visitDate: visit.date,
            attendance: visit.attendance,
            startTime: "09:00",
            endTime: "10:00",
            visitType: visit.visitType,
            visitSubType: visit.visitSubType,
            diagnosis: "Sample diagnosis",
            reasonForAnalysis: "Video review",
            internalComment: "Internal visit note",
            referringDoctor: "Dr. Sample",
            interpretationDate: null
          });
        }
        if (url.endsWith("/videos")) {
          requestedVisitId = options?.params?.get("visitId") ?? null;
          return of([{
            id: "MDEyMDMvdmlkZW8vc2FtcGxlLm1vdg",
            fileName: "Sample_SHUEE 10000000 011203.mov",
            visitDate: visit.date,
            category: "Upper Extremity",
            sizeBytes: 2048,
            contentUrl: "/api/patients/14/videos/sample/content"
          }]);
        }
        return of([]);
      })
    };

    await TestBed.configureTestingModule({
      imports: [PatientVideos],
      providers: [{ provide: HttpClient, useValue: httpMock }]
    }).compileComponents();

    fixture = TestBed.createComponent(PatientVideos);
    component = fixture.componentInstance;
    fixture.componentRef.setInput("patient", patient);
    fixture.detectChanges();
  });

  it("shows the video list beside playback and visit information", () => {
    const rendered = fixture.nativeElement as HTMLElement;

    expect(rendered.querySelector(".video-library")).not.toBeNull();
    expect(rendered.querySelector(".player-panel video")).not.toBeNull();
    expect(rendered.querySelector(".download-button")).toBeNull();
    expect(rendered.querySelector(".player-panel video")?.getAttribute("src")).toBe(
      "/api/patients/14/videos/sample/content"
    );
    expect(rendered.querySelector(".video-thumbnail video")?.getAttribute("src")).toBe(
      "/api/patients/14/videos/sample/content"
    );
    expect(rendered.querySelector(".video-thumbnail video")?.getAttribute("preload")).toBe("metadata");
    expect(rendered.querySelector(".player-heading h2")?.textContent?.trim()).toBe(
      "Sample_SHUEE 10000000 011203.mov"
    );
    expect(rendered.textContent).not.toContain("Recorded on");
    expect(rendered.textContent).toContain("Sample_SHUEE 10000000 011203.mov");
    expect(rendered.textContent).toContain("2 KB");
    expect(rendered.querySelector(".video-item-copy")?.textContent?.trim()).toBe(
      "Sample_SHUEE 10000000 011203.mov · 2 KB"
    );
    expect(rendered.querySelector(".video-item-copy")?.textContent).not.toContain("Upper Extremity");
    expect(rendered.querySelector(".video-metadata")?.textContent).toContain("00:00");
    expect(rendered.querySelector(".video-metadata")?.textContent).toContain("2 KB");
    expect(rendered.textContent).toContain("Gait · Full");
    expect(rendered.textContent).toContain("Patient: Sample, Alex");
    expect(rendered.textContent).toContain("MRN: 10000000");
    expect(rendered.textContent).toContain("DOB: 2010-01-01");
    expect(rendered.textContent).toContain(`Age: ${component.patientAge}`);
    expect(rendered.textContent).toContain("Sex: Female");
    expect(rendered.textContent).not.toContain("Sample diagnosis");
    expect(rendered.textContent).not.toContain("Indication");
    expect(rendered.textContent).not.toContain("Video review");
    expect(rendered.textContent).toContain("Referring Physician");
    expect(rendered.textContent).toContain("Dr. Sample");
    expect(rendered.textContent).toContain("Internal Comment");
    expect(rendered.textContent).toContain("Internal visit note");
    const visitRows = rendered.querySelectorAll(".visit-details-table tr");
    expect(visitRows).toHaveLength(2);
    expect(visitRows[0].querySelectorAll(".visit-data")).toHaveLength(4);
    expect(visitRows[1].querySelectorAll(".visit-data")).toHaveLength(2);
    expect(visitRows[1].querySelector(".visit-notes")?.getAttribute("colspan")).toBe("3");
    expect(rendered.querySelectorAll(".visit-data-label .detail-icon")).toHaveLength(6);
    expect(rendered.querySelectorAll(".visit-data strong .detail-icon")).toHaveLength(0);
    expect(rendered.querySelector(".library-filter")).toBeNull();
    expect(rendered.querySelector(".category-filter")).toBeNull();
    expect(component.selectedVisitId).toBe(visit.id);
  });

  it("shows the video length beside its size after metadata loads", () => {
    const player = (fixture.nativeElement as HTMLElement)
      .querySelector<HTMLVideoElement>(".player-frame video");
    expect(player).not.toBeNull();
    Object.defineProperty(player, "duration", { configurable: true, value: 15 });
    player?.dispatchEvent(new Event("loadedmetadata"));
    fixture.detectChanges();

    expect((fixture.nativeElement as HTMLElement).querySelector(".video-metadata")?.textContent)
      .toContain("00:15");
  });

  it("opens the selected visit from the full-details button", () => {
    const openVisit = vi.fn();
    component.viewFullVisit.subscribe(openVisit);

    (fixture.nativeElement as HTMLElement)
      .querySelector<HTMLButtonElement>(".view-visit-button")
      ?.click();

    expect(openVisit).toHaveBeenCalledWith(visit);
  });

  it("loads all visits so videos can be grouped by date", () => {
    expect(requestedVisitId).toBeNull();
    expect(component.filteredVideoGroups).toHaveLength(1);
    expect(component.filteredVideoGroups[0].date).toBe(visit.date);
    expect(component.getVisitForDate("2003-01-12T00:00:00")).toEqual(visit);
  });

  it("loads videos from every date even when an earlier visit is selected", () => {
    const original = component.videos[0];
    const allVideos = [
      { ...original, id: "later", visitDate: "2004-02-20" },
      original,
      { ...original, id: "older", visitDate: "2002-01-01" }
    ];
    httpMock.get.mockImplementation((url: string, options?: { params?: HttpParams }) => {
      if (url.endsWith("/videos")) {
        requestedVisitId = options?.params?.get("visitId") ?? null;
        return of(requestedVisitId === null ? allVideos : [original]);
      }
      return of({ visitDate: visit.date });
    });

    fixture.componentRef.setInput("visit", visit);
    fixture.detectChanges();

    expect(requestedVisitId).toBeNull();
    expect(httpMock.get).toHaveBeenCalledWith("/api/patients/14/videos");
    expect(component.videos).toEqual(allVideos);
    expect(component.filteredVideoGroups.map((group) => group.date)).toEqual([
      "2004-02-20", visit.date, "2002-01-01"
    ]);

    component.onVisitChange(visit.id);
    expect(requestedVisitId).toBeNull();
    expect(component.videos).toEqual(allVideos);
  });

  it.each([
    "011203",
    "0112",
    "01/12/03",
    "01/12/2003",
    "2003-01-12",
    "2003-01",
    " sample_shuee ",
    ".MOV",
    "upper extremity",
    "UPPER",
    "",
    "   "
  ])("filters the grouped video list using %j", (query) => {
    component.searchQuery = query;
    expect(component.filteredVideoGroups).toEqual([
      { date: visit.date, videos: component.videos }
    ]);
  });

  it("excludes videos that do not match the search", () => {
    component.searchQuery = "101526";
    expect(component.filteredVideoGroups).toHaveLength(0);
  });

  it("filters individual videos while preserving their date groups", () => {
    const original = component.videos[0];
    const matchingVideo = { ...original, id: "matching", fileName: "Walking.mov" };
    const undatedVideo = {
      ...original, id: "undated", fileName: "Walking undated.mov", visitDate: null
    };
    component.videos = [original, matchingVideo, undatedVideo];

    component.searchQuery = "walking";
    expect(component.filteredVideoGroups).toEqual([
      { date: visit.date, videos: [matchingVideo] },
      { date: null, videos: [undatedVideo] }
    ]);

    component.searchQuery = "011203";
    expect(component.filteredVideoGroups).toEqual([
      { date: visit.date, videos: [original, matchingVideo] }
    ]);

    matchingVideo.visitDate = `${visit.date}T00:00:00`;
    component.videos = [matchingVideo];
    expect(component.filteredVideoGroups).toEqual([
      { date: matchingVideo.visitDate, videos: [matchingVideo] }
    ]);
  });

  it("updates search results as the user types and restores them when cleared", async () => {
    const rendered = fixture.nativeElement as HTMLElement;
    const input = rendered.querySelector<HTMLInputElement>('input[type="search"]')!;
    await fixture.whenStable();

    for (const [query, expectedCount] of [
      ["sample", 1],
      ["missing", 0],
      ["0112", 1],
      ["", 1]
    ] as const) {
      input.value = query;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      await fixture.whenStable();
      fixture.detectChanges();

      expect(component.searchQuery).toBe(query);
      expect(rendered.querySelectorAll(".video-item")).toHaveLength(expectedCount);
      expect(rendered.textContent?.includes("No matching videos")).toBe(expectedCount === 0);
    }
  });

  it("shows the API status when the video request fails", () => {
    httpMock.get.mockImplementation((url: string) => {
      if (url.endsWith("/visits")) {
        return of([visit]);
      }
      if (url.endsWith("/overview")) {
        return of(null);
      }
      return throwError(() => ({ status: 500 }));
    });

    component.onVisitChange(visit.id);
    fixture.detectChanges();

    expect(fixture.nativeElement.textContent).toContain(
      "Unable to load videos for this patient (HTTP 500)."
    );
  });
});
