import { CommonModule } from "@angular/common";
import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges
} from "@angular/core";
import { FormsModule } from "@angular/forms";
import { HttpClient } from "@angular/common/http";
import { Subscription } from "rxjs";

import { Patient } from "../patient";
import { Visit } from "../visits/visits";

interface PatientVideo {
  id: string;
  fileName: string;
  visitDate: string | null;
  category: string;
  sizeBytes: number;
  contentUrl: string;
}

interface VideoVisitDetails {
  visitDate: string | null;
  attendance: string | null;
  startTime: string | null;
  endTime: string | null;
  visitType: string | null;
  visitSubType: string | null;
  reasonForAnalysis: string | null;
  internalComment: string | null;
  referringDoctor: string | null;
  interpretationDate: string | null;
}

interface VideoGroup {
  date: string | null;
  videos: PatientVideo[];
}

@Component({
  selector: "app-patient-videos",
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: "./patient-videos.html",
  styleUrl: "./patient-videos.css"
})
export class PatientVideos implements OnChanges, OnDestroy {
  @Input({ required: true }) patient!: Patient;
  @Input() visit: Visit | null = null;
  @Output() viewFullVisit = new EventEmitter<Visit>();

  visits: Visit[] = [];
  videos: PatientVideo[] = [];
  selectedVisitId: number | null = null;
  selectedVideo: PatientVideo | null = null;
  visitDetails: VideoVisitDetails | null = null;
  searchQuery = "";
  collapsedGroups = new Set<string>();
  durationSeconds = 0;
  loadingVisits = false;
  loadingVideos = false;
  loadingVisitDetails = false;
  errorMessage = "";
  visitsError = "";
  visitDetailsError = "";
  playbackError = "";

  private visitsSubscription?: Subscription;
  private videosSubscription?: Subscription;
  private visitDetailsSubscription?: Subscription;

  constructor(
    private readonly http: HttpClient,
    private readonly cdr: ChangeDetectorRef
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes["patient"] && this.patient?.id) {
      this.selectedVisitId = this.visit?.id ?? null;
      this.selectedVideo = null;
      this.videos = [];
      this.searchQuery = "";
      this.collapsedGroups.clear();
      this.loadVisits();
      return;
    }

    if (changes["visit"]) {
      this.selectedVisitId = this.visit?.id ?? null;
      this.loadVideos();
      this.loadVisitDetails();
    }
  }

  ngOnDestroy(): void {
    this.visitsSubscription?.unsubscribe();
    this.videosSubscription?.unsubscribe();
    this.visitDetailsSubscription?.unsubscribe();
  }

  onVisitChange(visitId: number | null): void {
    this.selectedVisitId = visitId;
    this.loadVideos();
    this.loadVisitDetails();
  }

  selectVideo(video: PatientVideo): void {
    this.selectedVideo = video;
    this.playbackError = "";
    this.durationSeconds = 0;

    const visit = this.getVisitForDate(video.visitDate);
    this.selectedVisitId = visit?.id ?? null;
    this.loadVisitDetails();
  }

  onThumbnailMetadata(event: Event): void {
    const video = event.currentTarget as HTMLVideoElement;
    if (Number.isFinite(video.duration) && video.duration > 0) {
      video.currentTime = Math.min(1, video.duration / 2);
    }
  }

  onVideoMetadata(event: Event): void {
    const video = event.currentTarget as HTMLVideoElement;
    this.durationSeconds = Number.isFinite(video.duration) ? video.duration : 0;
    this.cdr.markForCheck();
  }

  toggleGroup(date: string | null): void {
    const key = this.groupKey(date);
    if (this.collapsedGroups.has(key)) {
      this.collapsedGroups.delete(key);
    } else {
      this.collapsedGroups.add(key);
    }
  }

  isGroupCollapsed(date: string | null): boolean {
    return this.collapsedGroups.has(this.groupKey(date));
  }

  get filteredVideoGroups(): VideoGroup[] {
    const query = this.searchQuery.trim().toLowerCase();
    const filteredVideos = this.videos.filter((video) => {
      const date = this.normalizeDate(video.visitDate);
      const compactDate = this.formatSearchDate(video.visitDate);
      return !query || [
        video.fileName,
        video.category,
        date ?? "",
        compactDate,
        compactDate.replace(/^(\d{2})(\d{2})(\d{2})$/, "$1/$2/$3"),
        date?.replace(/^(\d{4})-(\d{2})-(\d{2})$/, "$2/$3/$1") ?? ""
      ].some((value) => value.toLowerCase().includes(query));
    });
    const groups = new Map<string, VideoGroup>();

    for (const video of filteredVideos) {
      const key = this.groupKey(video.visitDate);
      const group = groups.get(key) ?? { date: video.visitDate, videos: [] };
      group.videos.push(video);
      groups.set(key, group);
    }

    return Array.from(groups.values());
  }

  onPlaybackError(): void {
    this.playbackError =
      "This video could not be played in this browser. The file may use an unsupported video codec.";
    this.cdr.markForCheck();
  }

  get formattedFileSize(): string {
    if (!this.selectedVideo) {
      return "";
    }
    return this.formatFileSize(this.selectedVideo.sizeBytes);
  }

  get formattedDuration(): string {
    const duration = Math.floor(this.durationSeconds);
    const minutes = Math.floor(duration / 60);
    const seconds = duration % 60;
    return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  }

  getVisitForDate(date: string | null): Visit | null {
    const normalizedDate = this.normalizeDate(date);
    return this.visits.find(
      (candidate) => this.normalizeDate(candidate.date) === normalizedDate
    ) ?? null;
  }

  get selectedVisit(): Visit | null {
    return this.visits.find((candidate) => candidate.id === this.selectedVisitId) ?? null;
  }

  openFullVisitDetails(): void {
    const visit = this.selectedVisit;
    if (visit) {
      this.viewFullVisit.emit(visit);
    }
  }

  get patientName(): string {
    return [this.patient?.lastName, this.patient?.firstName]
      .filter(Boolean)
      .join(", ") || "Not recorded";
  }

  get patientAge(): string {
    const value = this.patient?.dateOfBirth?.slice(0, 10);
    if (!value || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
      return "Not recorded";
    }

    const [year, month, day] = value.split("-").map(Number);
    const birth = new Date(year, month - 1, day);
    const today = new Date();
    let age = today.getFullYear() - year;
    if (
      today.getMonth() < month - 1 ||
      (today.getMonth() === month - 1 && today.getDate() < day)
    ) {
      age -= 1;
    }

    return `${age} ${age === 1 ? "year" : "years"}`;
  }

  get patientSex(): string {
    const value = this.patient?.gender;
    if (!value) {
      return "Not recorded";
    }
    if (value.toUpperCase() === "M") {
      return "Male";
    }
    if (value.toUpperCase() === "F") {
      return "Female";
    }
    return value;
  }

  private groupKey(date: string | null): string {
    return date ?? "undated";
  }

  private normalizeDate(date: string | null): string | null {
    return date?.slice(0, 10) ?? null;
  }

  private formatSearchDate(date: string | null): string {
    const normalizedDate = this.normalizeDate(date);
    const match = normalizedDate?.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    return match ? `${match[2]}${match[3]}${match[1].slice(-2)}` : "";
  }

  private loadVisits(): void {
    this.visitsSubscription?.unsubscribe();
    this.visitsError = "";
    this.loadingVisits = true;

    this.visitsSubscription = this.http
      .get<Visit[]>(`/api/patients/${this.patient.id}/visits`)
      .subscribe({
        next: (visits) => {
          this.visits = visits;
          if (this.selectedVisitId && !this.visits.some((visit) => visit.id === this.selectedVisitId)) {
            this.selectedVisitId = null;
          }
          this.loadingVisits = false;
          this.loadVideos();
          if (this.selectedVisitId === null && this.selectedVideo) {
            this.selectVideo(this.selectedVideo);
          } else {
            this.loadVisitDetails();
          }
          this.cdr.markForCheck();
        },
        error: (error) => {
          console.error("Unable to load visits for patient videos:", error);
          this.visits = [];
          this.loadingVisits = false;
          this.visitsError = "Visit dates could not be loaded.";
          this.loadVideos();
          this.loadVisitDetails();
          this.cdr.markForCheck();
        }
      });
  }

  private loadVideos(): void {
    this.videosSubscription?.unsubscribe();
    this.videos = [];
    this.selectedVideo = null;
    this.errorMessage = "";
    this.playbackError = "";
    this.loadingVideos = true;

    this.videosSubscription = this.http
      .get<PatientVideo[]>(`/api/patients/${this.patient.id}/videos`)
      .subscribe({
        next: (videos) => {
          this.videos = videos;
          this.selectedVideo = videos[0] ?? null;
          this.loadingVideos = false;
          if (this.selectedVideo && this.selectedVisitId === null) {
            const matchingVisit = this.visits.find(
              (visit) => visit.date === this.selectedVideo?.visitDate
            );
            this.selectedVisitId = matchingVisit?.id ?? null;
            this.loadVisitDetails();
          }
          this.cdr.markForCheck();
        },
        error: (error) => {
          console.error("Unable to load patient videos:", error);
          this.videos = [];
          this.selectedVideo = null;
          this.loadingVideos = false;
          this.errorMessage = error.status
            ? `Unable to load videos for this patient (HTTP ${error.status}).`
            : "Unable to load videos for this patient. Check your connection and try again.";
          this.cdr.markForCheck();
        }
      });
  }

  private loadVisitDetails(): void {
    this.visitDetailsSubscription?.unsubscribe();
    this.visitDetails = null;
    this.visitDetailsError = "";
    this.loadingVisitDetails = this.selectedVisitId !== null;

    if (this.selectedVisitId === null) {
      this.cdr.markForCheck();
      return;
    }

    this.visitDetailsSubscription = this.http
      .get<VideoVisitDetails>(`/api/visits/${this.selectedVisitId}/overview`)
      .subscribe({
        next: (details) => {
          this.visitDetails = details;
          this.loadingVisitDetails = false;
          this.cdr.markForCheck();
        },
        error: (error) => {
          console.error("Unable to load visit details for patient videos:", error);
          this.loadingVisitDetails = false;
          this.visitDetailsError = "Visit details could not be loaded.";
          this.cdr.markForCheck();
        }
      });
  }

  formatFileSize(sizeBytes: number): string {
    if (sizeBytes < 1024 * 1024) {
      return `${Math.max(1, Math.round(sizeBytes / 1024))} KB`;
    }
    return `${(sizeBytes / (1024 * 1024)).toFixed(1)} MB`;
  }
}
