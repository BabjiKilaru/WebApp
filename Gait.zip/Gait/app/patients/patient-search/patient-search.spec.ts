import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of, throwError } from 'rxjs';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

import { PatientSearch } from './patient-search';
import { PatientService } from '../patient.service';
import { Patient } from '../patient';

describe('PatientSearch', () => {
  let component: PatientSearch;
  let fixture: ComponentFixture<PatientSearch>;
  let testPatient: Patient;

  const patientServiceMock = {
    getGeneralDiagnoses: vi.fn(),
    searchPatients: vi.fn(),
    createPatient: vi.fn(),
    updatePatient: vi.fn()
  };

  beforeEach(async () => {
    vi.resetAllMocks();

    patientServiceMock.getGeneralDiagnoses.mockReturnValue(of([]));
    patientServiceMock.searchPatients.mockReturnValue(of([]));

    await TestBed.configureTestingModule({
      imports: [PatientSearch],
      providers: [
        provideRouter([]),
        {
          provide: PatientService,
          useValue: patientServiceMock
        }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(PatientSearch);
    component = fixture.componentInstance;

    testPatient = {
      ...component.patient,
      id: 1125,
      mrn: '123456',
      firstName: 'John',
      lastName: 'Smith',
      dateOfBirth: '2010-05-20',
      gender: 'Male'
    };

    fixture.detectChanges();
  });

  afterEach(() => {
    vi.clearAllTimers();
    vi.useRealTimers();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should not search with fewer than two characters', () => {
    component.onSearchInput('S');

    expect(patientServiceMock.searchPatients).not.toHaveBeenCalled();
    expect(component.loading).toBe(false);
  });

  it('should return patient suggestions after the delay', () => {
    vi.useFakeTimers();
    patientServiceMock.searchPatients.mockReturnValue(of([testPatient]));

    component.onSearchInput('Smi');

    expect(patientServiceMock.searchPatients).not.toHaveBeenCalled();

    vi.advanceTimersByTime(200);

    expect(patientServiceMock.searchPatients).toHaveBeenCalledWith('Smi');
    expect(component.suggestions).toEqual([testPatient]);
    expect(component.loading).toBe(false);
  });

  it('should search the same name again after clearing', () => {
    vi.useFakeTimers();
    patientServiceMock.searchPatients.mockReturnValue(of([testPatient]));

    component.onSearchInput('Smith');
    vi.advanceTimersByTime(200);

    component.clearPatient();

    component.onSearchInput('Smith');
    vi.advanceTimersByTime(200);

    expect(patientServiceMock.searchPatients).toHaveBeenCalledTimes(2);
    expect(component.suggestions).toEqual([testPatient]);
    expect(component.loading).toBe(false);
  });

  it('should handle a trailing space without getting stuck', () => {
    vi.useFakeTimers();
    patientServiceMock.searchPatients.mockReturnValue(of([testPatient]));

    component.onSearchInput('Smith');
    vi.advanceTimersByTime(200);

    component.onSearchInput('Smith ');
    vi.advanceTimersByTime(200);

    expect(component.suggestions).toEqual([testPatient]);
    expect(component.loading).toBe(false);
  });

  it('should select a patient', () => {
    component.selectPatient(testPatient);

    expect(component.patient).toEqual(testPatient);
    expect(component.patientFound).toBe(true);
    expect(component.searchQuery).toContain('Smith');
  });

  it('should show Visit Home after opening a visit', () => {
    const visit = {
      id: 5,
      patientId: testPatient.id,
      attendance: 'Yes',
      date: '2025-12-03',
      visitType: 'Gait',
      visitSubType: 'Step Watch'
    };

    component.selectPatient(testPatient);
    component.openVisitHome(visit);

    expect(component.selectedVisit).toEqual(visit);
    expect(component.activeTab).toBe('visit-home');
  });

  it('should clear the patient', () => {
    component.selectPatient(testPatient);
    component.openVisitHome({
      id: 5,
      patientId: testPatient.id,
      attendance: 'Yes',
      date: '2025-12-03',
      visitType: 'Gait',
      visitSubType: 'Step Watch'
    });
    component.clearPatient();

    expect(component.patientFound).toBe(false);
    expect(component.searchQuery).toBe('');
    expect(component.patient.id).toBe(0);
    expect(component.selectedVisit).toBeNull();
  });

  it('should change tabs', () => {
    component.selectTab('history');

    expect(component.activeTab).toBe('history');
  });

  it('should select the Visit Home and Videos tabs', () => {
    component.selectTab('visit-home');
    expect(component.activeTab).toBe('visit-home');

    component.selectTab('videos');
    expect(component.activeTab).toBe('videos');
  });

  it('should handle search errors', () => {
    vi.useFakeTimers();
    patientServiceMock.searchPatients.mockReturnValue(
      throwError(() => new Error('Database failure'))
    );

    component.onSearchInput('Smith');
    vi.advanceTimersByTime(200);

    expect(component.errorMessage).toBe('Unable to search patients.');
    expect(component.loading).toBe(false);
    expect(component.suggestions).toEqual([]);
  });
});