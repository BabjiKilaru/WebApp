import { CommonModule } from "@angular/common";
import { ChangeDetectorRef, Component, DestroyRef, HostListener, OnDestroy, OnInit } from "@angular/core";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { FormsModule } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";
import { Subject, of, timer } from "rxjs";
import { catchError, switchMap } from "rxjs/operators";

import { Header } from "../../header/header"
import { Patient } from "../patient";
import { PatientService } from "../patient.service";
import { Visits } from "../visits/visits";
import { History } from "../history/history";
import { QuestionnaireResponses } from "../quest-responses/quest-responses";
import { GeneralDiagnosisOption, NewPatient, NewPatientForm } from "../new-patient/new-patient";
import { Visit } from "../visits/visits";
import { VisitHome } from "../visit-home/visit-home";
import { PatientVideos } from "../videos/patient-videos";


@Component({
  selector: "app-patient-search",
  standalone: true,
  imports: [CommonModule, FormsModule, Visits, VisitHome, History, Header, NewPatient, QuestionnaireResponses, PatientVideos],
  templateUrl: "./patient-search.html",
  styleUrl: "./patient-search.css",
})
export class PatientSearch implements OnInit, OnDestroy {
  menuOpen = false;
  activeTab: "demographics" | "visit-home" | "history" | "quest-responses" | "videos" = "demographics";
  selectedVisit: Visit | null = null;

  searchQuery = "";
  suggestions: Patient[] = [];
  suggestionsOpen = false;
  loading = false;
  errorMessage = "";
  patientFound = false;
  showNewPatientDialog = false;

  generalDiagnoses: GeneralDiagnosisOption[] = [];

  patient: Patient = this.createEmptyPatient();
  private originalPatient: Patient | null = null;

  successMessage = "";
  private messageTimer: ReturnType<typeof setTimeout> | null = null;

  private showTimedMessage(
    type: "success" | "error",
    message: string
  ): void {
    if(this.messageTimer) {
      clearTimeout(this.messageTimer);
    }

    if(type === "success") {
      this.successMessage = message;
      this.errorMessage = "";
    } else {
      this.errorMessage = message;
      this.successMessage = "";
    }

    this.cdr.markForCheck();

    this.messageTimer = setTimeout(() => {
      this.successMessage = "";
      this.errorMessage = "";
      this.messageTimer = null;

      this.cdr.markForCheck();
    }, 5000);
  }

  showConfirmDialog= false;
  demographicChanges: {
    field: string;
    oldValue: string;
    newValue: string;
  }[] =[];

  private searchSubject = new Subject<string>();

  private loadGeneralDiagnoses() : void {
    this.patientService.getGeneralDiagnoses().subscribe({
      next: (diagnoses) => {
        this.generalDiagnoses = diagnoses;
        this.cdr.markForCheck();
      },
      error: () => {
        this.generalDiagnoses = [];
        this.cdr.markForCheck();
      }
    });
  }

  constructor(
    private patientService: PatientService,
    private cdr: ChangeDetectorRef,
    private route: ActivatedRoute,
    private destroyRef: DestroyRef
  ) {
    this.loadGeneralDiagnoses();
    this.searchSubject
      .pipe(
        switchMap((query) => {
          if (query.length <2) {
            return of([]);
          }

          return timer(200).pipe(
            switchMap(() => this.patientService.searchPatients(query)),
            catchError((error) => {
              console.error("Patient search error:", error);
              this.errorMessage = "Unable to search patients.";
              return of([]);
            }),
          );
        }),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((patients) => {
        this.suggestions = patients;
        this.loading = false;

        this.suggestionsOpen =
          patients.length > 0 && this.searchQuery.trim().length >= 2;
        this.cdr.markForCheck();
      });
  }

  ngOnInit(): void {
    this.route.queryParamMap.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(params => {
      const patientIdParam = params.get('patientId');
      if(!patientIdParam){
        return;
      }
      const patientId = Number(patientIdParam);
      if(!patientId || Number.isNaN(patientId)){
        return;
      }
      this.loadPatientById(patientId);
    });
  }

  ngOnDestroy(): void {
    if (this.messageTimer) {
      clearTimeout(this.messageTimer);
      this.messageTimer = null;
    }
  }

  private loadPatientById(patientId: number): void {
    this.selectedVisit = null;
    this.activeTab = "demographics";
    this.loading = true;
    this.errorMessage = '';
    this.patientService
      .getPatientById(patientId)
      .subscribe({
        next: patient => {
          this.patient = {...patient};
          this.originalPatient = {...patient};
          this.patientFound = true;
          this.searchQuery = `${patient.lastName ?? ''},` + `${patient.firstName ?? ''},` + ` - MRN ${patient.mrn ?? ''}`;
          this.suggestions = [];
          this.suggestionsOpen = false;
          this.activeTab = 'demographics';
          this.loading = false;
          this.cdr.markForCheck();
        },
        error: error => {
          console.error('Unable to load patient:', error);
          this.loading = false;
          this.patientFound = false;
          this.errorMessage = 'Unable to load patient.';
          this.cdr.markForCheck();
        }
      });
  }

  onSearchInput(value: string): void {
    this.searchQuery = value;
    const query = value.trim();

    this.suggestions = [];
    this.errorMessage = "";

    this.loading = query.length >= 2;
    this.suggestionsOpen = query.length >= 2;

    this.searchSubject.next(query);
    this.cdr.markForCheck();
  }

  selectPatient(patient: Patient): void {
    this.selectedVisit = null;
    this.activeTab = "demographics";
    this.patient = { ...patient };
    this.originalPatient = { ...patient };
    this.patientFound = true;
    this.searchQuery =
      `${patient.lastName ?? ""}, ` +
      `${patient.firstName ?? ""} ` +
      `- MRN ${patient.mrn ?? ""}`;

    this.suggestions = [];
    this.suggestionsOpen = false;
    this.showTimedMessage("success", "Patient loaded.")
  }

  openSuggestions(): void {
    if (this.searchQuery.trim().length >= 2 && this.suggestions.length > 0) {
      this.suggestionsOpen = true;
    }
  }

  closeSuggestions(): void {
    setTimeout(() => {
      this.suggestionsOpen = false;
    }, 150);
  }

  clearPatient(): void {
    this.searchSubject.next("");
    this.searchQuery = "";
    this.suggestions = [];
    this.suggestionsOpen = false;
    this.loading = false;
    this.errorMessage = "";
    this.patientFound = false;
    this.selectedVisit = null;
    this.patient = this.createEmptyPatient();
    this.originalPatient = null;

    this.showConfirmDialog = false;
    this.demographicChanges= [];

    this.activeTab = "demographics";

    this.successMessage = "";
    if(this.messageTimer) {
      clearTimeout(this.messageTimer);
      this.messageTimer = null;
    }
  }

  onQuestionnaireBaselineSaved(updatedPatient: Patient): void {
    if (this.patient.id !== updatedPatient.id) {
      return;
    }

    const updatedBaseline = {
      historyPerson: updatedPatient.historyPerson,
      historyRelationship: updatedPatient.historyRelationship,
      baselineDate: updatedPatient.baselineDate,
      premature: updatedPatient.premature,
      birthStay: updatedPatient.birthStay,
      ageWalk: updatedPatient.ageWalk,
      ageTalk: updatedPatient.ageTalk,
      learning: updatedPatient.learning,
      learningDescription: updatedPatient.learningDescription ?? null
    };

    this.patient = {
      ...this.patient, ...updatedBaseline
    };

    if(this.originalPatient?.id === updatedPatient.id) {
      this.originalPatient = { ...this.originalPatient, ...updatedBaseline};
    }
    this.cdr.markForCheck();
  }

  selectTab(tab: "demographics" | "visit-home" | "history" | "quest-responses" | "videos" ): void {
    this.activeTab = tab;
  }

  openVisitHome(visit: Visit): void {
    this.selectedVisit = visit;
    this.activeTab = "visit-home";
  }

  updateSelectedVisit(visit: Visit): void {
    this.selectedVisit = visit;
  }

  toggleMenu(): void {
    this.menuOpen = !this.menuOpen;
  }

  closeMenu(): void {
    this.menuOpen = false;
  }

  @HostListener('document:click')
  closeDiagnosisDropdown(): void {
    this.diagnosisDropdownOpen = false;
    this.genderDropdownOpen = false;
  }

  onGeneralDiagnosisChange(diagnosisId: number | null): void {
    if(!diagnosisId) {
      this.patient.generalDiagnosisCode = null;
      this.patient.icd9Code = '';
      this.patient.generalDiagnosis = '';
      return;
    }

    const diagnosis = this.generalDiagnoses.find(
      item => item.id === diagnosisId
    );

    if (!diagnosis) {
      return;
    }

    this.patient.generalDiagnosisCode = diagnosis.id;
    this.patient.icd9Code = diagnosis.code ?? '';
    this.patient.generalDiagnosis = diagnosis.diagnosis ?? diagnosis.description ?? '';
  }

  diagnosisDropdownOpen = false;
  genderDropdownOpen = false;

  toggleDiagnosisDropdown(): void {
    if (!this.patientFound) {
      return;
    }

    this.diagnosisDropdownOpen = !this.diagnosisDropdownOpen;
  }

  selectDiagnosis(diagnosis: GeneralDiagnosisOption): void {
    this.patient.generalDiagnosisCode = diagnosis.id;
    this.patient.icd9Code = diagnosis.code ?? '';
    this.patient.generalDiagnosis = diagnosis.diagnosis ?? diagnosis.description ?? '';
    this.diagnosisDropdownOpen = false;
    this.cdr.markForCheck(); 
  }

  toggleGenderDropdown(): void {
    if (!this.patientFound) return;
    this.genderDropdownOpen = !this.genderDropdownOpen;
  }

  selectGender(gender: string): void {
    this.patient.gender = gender;
    this.genderDropdownOpen = false;
    this.cdr.markForCheck();
  }

  newPatientErrorMessage = '';

  newPatient(): void {
    this.newPatientErrorMessage = '';
    if (this.generalDiagnoses.length === 0) {
      this.loadGeneralDiagnoses();
    }
    this.showNewPatientDialog = true;
  }

  closeNewPatient(): void {
    this.showNewPatientDialog = false;
  }

  handleNewPatient(form: NewPatientForm): void {
    const request = {
      firstName: form.firstName,
      lastName: form.lastName,
      nickname: form.nickname || null,
      mrn: form.mrn,
      gender: form.gender,
      dateOfBirth: form.dateOfBirth,
      generalDiagnosisCode: form.generalDiagnosisCode,
      comment: form.comment || null
    };

    this.loading = true;
    this.newPatientErrorMessage = '';

    this.patientService.createPatient(request).subscribe({
      next: (savedPatient) => {
        this.loading = false;
        this.patient = savedPatient;
        this.originalPatient = {...savedPatient};
        this.patientFound = true;
        this.searchQuery = `${savedPatient.lastName}, ${savedPatient.firstName}`;
        this.showNewPatientDialog = false;
        this.newPatientErrorMessage = '';
        this.activeTab = 'demographics';
        this.cdr.markForCheck();
      },
      error: (error) => {
        this.loading = false;
        this.newPatientErrorMessage = typeof error.error === 'string' ? error.error : 'Unable to add patient.';
        
        this.cdr.markForCheck();
      }
    });
  }

  savePatient(): void {
    if (!this.patientFound || !this.originalPatient) {
      return;
    }
    this.demographicChanges = this.getDemographicChanges();

    if (this.demographicChanges.length === 0){
      return;
    }
    this.showConfirmDialog = true;
  }

  private getDemographicChanges(): {
    field: string;
    oldValue: string;
    newValue: string;
  }[] {
    if (!this.originalPatient) {
      return [];
    }
    const changes: {
      field: string;
      oldValue: string;
      newValue: string;
    }[] =[];

    const fields: {
      key: keyof Patient;
      label: string;
    }[] = [
      { key : "firstName", label: "First Name" },
      { key : "mrn", label: "MRN" },
      { key : "lastName", label: "Last Name" },
      { key : "gender", label: "Gender" },
      { key : "nickname", label: "Preferred Name" },
      { key : "dateOfBirth", label: "Date of Birth" },
      { key : "oldLastName", label: "Former Last Name" },
      { key : "comment", label: "Comment" },
    ];

    for (const field of fields) {
      const oldValue = this.originalPatient[field.key] == null ? "" : String(this.originalPatient[field.key]);

      const newValue = this.patient[field.key] == null ? "" : String(this.patient[field.key]);

      if (oldValue !== newValue) {
        changes.push({
          field: field.label,
          oldValue,
          newValue,
        });
      }
    }
    if (
      this.originalPatient.generalDiagnosisCode !== this.patient.generalDiagnosisCode
    ) {
      changes.push({
        field: "General Diagnosis",
        oldValue: this.originalPatient.generalDiagnosis ?? "",
        newValue: this.patient.generalDiagnosis ?? "",
      });
      changes.push({
        field: "ICD9 Code",
        oldValue: this.originalPatient.icd9Code ?? "",
        newValue: this.patient.icd9Code ?? "",
      });
    }
    return changes;
  }

  cancelEdit(): void {
    if (!this.originalPatient) {
      return;
    }

    this.patient = { ...this.originalPatient };
    this.showConfirmDialog = false;
    this.demographicChanges = [];
  }

  closeConfirmDialog(): void {
    this.showConfirmDialog = false;
  }

  confirmPatientUpdate(): void {
    if (!this.patientFound || !this.patient.id) {
      return;
    }

    const updateRequest = {
      mrn: this.patient.mrn,
      firstName: this.patient.firstName,
      lastName: this.patient.lastName,
      oldLastName: this.patient.oldLastName,
      nickname: this.patient.nickname,
      dateOfBirth: this.patient.dateOfBirth,
      gender: this.patient.gender,
      comment: this.patient.comment,
      generalDiagnosisCode: this.patient.generalDiagnosisCode
    };
    this.loading = true;
    this.errorMessage= '';

    this.patientService .updatePatient(this.patient.id, updateRequest) .subscribe({
      next: (updatedPatient) => {
        this.patient = { ...updatedPatient };
        this.originalPatient = { ...updatedPatient };
        this.showConfirmDialog =false;
        this.demographicChanges = [];
        this.loading = false;

        this.showTimedMessage("success", "Patient demographics updated successfully.");
        this.cdr.markForCheck();
      },
      error: (error) => {
        console.error('Unable to update patient:', error);
        this.showTimedMessage("error", typeof error.error === 'string' ? error.error : 'Unable to update patient demographics.');
        this.loading = false;
        this.cdr.markForCheck();
      }
    });
  }

  addReferenceCode(): void {}

  private createEmptyPatient(): Patient {
    return {
      id: 0,
      mrn: null,
      firstName: null,
      lastName: null,
      oldLastName: null,
      nickname: null,
      dateOfBirth: null,
      gender: null,
      generalDiagnosisCode: null,
      label: false,
      comment: null,
      historyPerson: null,
      historyRelationship: null,
      baselineDate: null,
      premature: null,
      birthStay: null,
      ageWalkWithSupport: null,
      ageWalkWithoutSupport: null,
      learning: null,
      ageWalk: null,
      ageTalk: null,
      icd9Code: null,
      generalDiagnosis: null,
    };
  }
}
