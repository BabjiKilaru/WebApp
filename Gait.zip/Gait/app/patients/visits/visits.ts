import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges
} from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { HttpClient } from "@angular/common/http";
import { Subscription } from "rxjs";

export interface Visit {
  id: number;
  patientId: number;
  attendance: string | null;
  date: string | null;
  visitType: string | null;
  visitSubType: string | null;
}

@Component({
  selector: "app-visits",
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: "./visits.html",
  styleUrl: "./visits.css"
})
export class Visits implements OnChanges, OnDestroy {
  private visitsSubscription?: Subscription;

  @Input()
  patientId: number | null = null;

  @Output()
  visitSelected = new EventEmitter<Visit>();

  @Output()
  visitOpened = new EventEmitter<Visit>();

  attendanceFilter: "attended" | "cancelled" | "rescheduled" = "attended";

  dateFrom = "";
  dateTo = "";

  allVisits: Visit[] = [];
  visits: Visit[] = [];

  selectedVisitId: number | null = null;

  loading = false;
  errorMessage = "";

  constructor(
    private http: HttpClient,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes["patientId"]) {
      this.selectedVisitId = null;
      this.loadVisits();
    }
  }

  ngOnDestroy(): void {
    this.visitsSubscription?.unsubscribe();
  }

  loadVisits(): void {
    this.visitsSubscription?.unsubscribe();

    this.visits = [];
    this.allVisits = [];
    this.errorMessage = "";
    this.loading = false;

    if (!this.patientId) {
      this.cdr.markForCheck();
      return;
    }

    this.loading = true;

    this.visitsSubscription = this.http
      .get<Visit[]>(`/api/patients/${this.patientId}/visits`)
      .subscribe({
        next: (visits) => {
          this.allVisits = visits;
          this.applyFilters();
          this.loading = false;
          this.cdr.markForCheck();
        },

        error: (error) => {
          console.error("Unable to load visits:", error);

          this.visits = [];
          this.allVisits = [];
          this.loading = false;
          this.errorMessage = "Unable to load visits.";

          this.cdr.markForCheck();
        }
      });
  }

  applyFilters(): void {
    this.visits = this.allVisits.filter((visit) => {
      const attendance = visit.attendance?.trim() ?? "";
      const visitDate = this.normalizeDate(visit.date);

      let attendanceMatches = true;

      if (this.attendanceFilter === "attended") {
        attendanceMatches =
          attendance === "Yes" ||
          attendance === "";
      }

      if (this.attendanceFilter === "cancelled") {
        attendanceMatches =
          attendance === "Cancel" ||
          attendance === "Canceled" ||
          attendance === "Cancelled" ||
          attendance === "No Show";
      }

      if (this.attendanceFilter === "rescheduled") {
        attendanceMatches =
          attendance === "Rescheduled";
      }

      const fromMatches =
        !this.dateFrom ||
        (!!visitDate && visitDate >= this.dateFrom);

      const toMatches =
        !this.dateTo ||
        (!!visitDate && visitDate <= this.dateTo);

      return attendanceMatches && fromMatches && toMatches;
    });

    this.cdr.markForCheck();
  }

  clearFilters(): void {
    this.attendanceFilter = "attended";
    this.dateFrom = "";
    this.dateTo = "";

    this.applyFilters();
  }

  selectVisit(visit: Visit): void {
    this.selectedVisitId = visit.id;

    this.visitSelected.emit(visit);
  }

  openVisit(visit: Visit): void {
    this.selectedVisitId = visit.id;
    this.visitOpened.emit(visit);
  }

  private normalizeDate(value: string | null): string | null {
    if (!value) {
      return null;
    }

    const isoMatch = value.match(/^(\d{4}-\d{2}-\d{2})/);

    if (isoMatch) {
      return isoMatch[1];
    }

    const parsed = new Date(value);

    if (Number.isNaN(parsed.getTime())) {
      return null;
    }

    const year = parsed.getFullYear();
    const month = String(parsed.getMonth() + 1).padStart(2, "0");
    const day = String(parsed.getDate()).padStart(2, "0");

    return `${year}-${month}-${day}`;
  }
}
