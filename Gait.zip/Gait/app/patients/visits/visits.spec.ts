import { ComponentFixture, TestBed } from "@angular/core/testing";
import { provideHttpClient } from "@angular/common/http";
import { HttpTestingController, provideHttpClientTesting } from "@angular/common/http/testing";
import { vi } from "vitest";
import { Visits } from './visits';

describe(
    'Visits',
    () => {
        let component: Visits;
        let fixture: ComponentFixture<Visits>;
        let httpTesting: HttpTestingController;

        beforeEach(
            async () => {
                await TestBed .configureTestingModule({
                    imports:[
                        Visits
                    ],

                    providers: [
                        provideHttpClient(),
                        provideHttpClientTesting()
                    ]
                })
                .compileComponents();

                fixture = TestBed.createComponent(Visits);

                component = fixture.componentInstance;

                httpTesting = TestBed.inject(HttpTestingController);
            }
        );

        afterEach(
            () => {
                httpTesting.verify();
            }
        );

        it(
            'should create',
            () => {
                expect(component) .toBeTruthy();
            }
        );

        it('should default attendance filter to Yes / Blank', () => {
            expect(component.attendanceFilter).toBe('attended');
        });

        it('should open a visit when activated', () => {
            const visit = {
                id: 5,
                patientId: 1125,
                date: '2025-12-03',
                attendance: 'Yes',
                visitType: 'Gait',
                visitSubType: 'Step Watch'
            };
            const visitOpened = vi.spyOn(component.visitOpened, 'emit');

            component.openVisit(visit);

            expect(component.selectedVisitId).toBe(5);
            expect(visitOpened).toHaveBeenCalledWith(visit);
        });

        it('should reset attendance filter to Yes / Blank when clearing filters', () => {
            component.attendanceFilter = 'cancelled';
            component.dateFrom = '2025-01-01';
            component.dateTo = '2025-12-31';

            component.clearFilters();

            expect(component.attendanceFilter).toBe('attended');
            expect(component.dateFrom).toBe('');
            expect(component.dateTo).toBe('');
        });

        it(
            'should load visits for patients',
            () => {
                component.patientId = 1125;

                component.loadVisits();

                const request = httpTesting.expectOne(
                    '/api/patients/1125/visits'
                );

                expect(request.request.method) .toBe('GET');

                request.flush([
                    {
                        id:1,
                        patientId: 1125,
                        date: '2025-12-03',
                        visitType: 'Gait',
                        visitSubType: 'Step Watch'
                    },
                    {
                        id:2,
                        patientId: 1125,
                        date: '2025-11-20',
                        visitType: 'Foot',
                        visitSubType: 'Foot Evaluation'
                    },
                ]);

                expect(component.visits.length) .toBe(2);

                expect(component.visits[0] .visitType) .toBe('Gait');

                expect(component.loading) .toBeFalsy();

            }
        );

        it(
            'should handle backend error',
            () => {
                component.patientId = 1125;

                component.loadVisits();

                const request = httpTesting.expectOne('/api/patients/1125/visits');

                request.flush(
                    'Backend error',
                    {
                        status: 500,
                        statusText: 'Server Error'
                    }
                );

                expect(component.visits.length) .toBe(0);

                expect(component.errorMessage) .toBe('Unable to load visits.');

                expect(component.loading) .toBe(false);

            }
        );

        it('should not call backend when patientId is null', () => {
            component.patientId = null;
            component.loadVisits();
            expect(component.visits.length) .toBe(0);

            httpTesting.expectNone(() => true);
        });

        it('separates attended, canceled, no-show and rescheduled visits', () => {
            component.allVisits = [
              { id: 1, patientId: 42, attendance: 'Yes', date: '2026-10-01', visitType: null, visitSubType: null },
              { id: 2, patientId: 42, attendance: 'No Show', date: '2026-10-02', visitType: null, visitSubType: null },
              { id: 3, patientId: 42, attendance: 'Rescheduled', date: '2026-10-03', visitType: null, visitSubType: null },
              { id: 4, patientId: 42, attendance: null, date: '2026-10-04', visitType: null, visitSubType: null },
            ];
            component.applyFilters();
            expect(component.visits.map(visit => visit.id)).toEqual([1, 4]);
            component.attendanceFilter = 'cancelled';
            component.applyFilters();
            expect(component.visits.map(visit => visit.id)).toEqual([2]);
            component.attendanceFilter = 'rescheduled';
            component.applyFilters();
            expect(component.visits.map(visit => visit.id)).toEqual([3]);
            component.attendanceFilter = 'attended';
            component.dateFrom = '2026-10-02';
            component.applyFilters();
            expect(component.visits.map(visit => visit.id)).toEqual([4]);
        });
    }
);