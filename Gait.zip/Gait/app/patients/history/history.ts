import { ChangeDetectorRef, Component, HostListener, Input, OnChanges, OnDestroy, SimpleChanges } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { HttpClient } from "@angular/common/http";
import { forkJoin, Subscription } from "rxjs";
import { Patient } from "../patient";

export interface SurgeryHistory {
    id: number;
    date: string | null;
    procedureCode: string | null;
    procedureName: string | null;
    side: string | null;
    surgeon: string | null;
    facility: string | null;
    comment: string | null;
}

export interface SurgeryOption {
    code: string;
    name: string;
}

export interface NewSurgeryRequest {
    date: string;
    procedureCode: string;
    side: string;
    surgeon: string;
    facility: string;
    comment: string;
}

export interface BotoxHistory {
    id: number;
    date: string | null;
    side: string | null;
    bodyLocation: string | null;
    facility: string | null;
    physician: string | null;
}

export interface NewBotoxRequest {
    date: string;
    bodyLocation: string;
    side: string;
    facility: string;
    physician: string;
}

export interface HealthHistoryEntry {
    id: number;
    age: string | null;
    conditionCode: string | null;
    conditionDescription: string | null;
}

export interface HistoryConditionOption {
    code: string;
    name: string;
}

export interface NewHealthHistoryRequest {
    age: string;
    conditionCode: string;
}

export interface HealthConditionEntry {
    id: number;
    conditionCode: string | null;
    conditionDescription: string | null;
}

export interface ConditionOption {
    code: string;
    name: string;
}

export interface NewHealthConditionRequest {
    conditionCode: string;
}

export interface SideOption {
    value: string;
    label: string;
}

export interface PatientHistoryData {
    surgeries: SurgeryHistory[];
    botox: BotoxHistory[];
    healthHistory: HealthHistoryEntry[];
    healthConditions: HealthConditionEntry[];
}

@Component({
    selector: "app-history",
    standalone: true,
    imports: [FormsModule],
    templateUrl: "./history.html",
    styleUrl: "./history.css"
}) export class History implements OnChanges, OnDestroy {
    private historySubscription?: Subscription;

    @Input()
    patientId: number | null = null;
    @Input()
    patient: Patient | null = null;
    surgeries: SurgeryHistory[] = [];
    botox: BotoxHistory[] = [];
    healthHistory: HealthHistoryEntry[] = [];
    healthConditions: HealthConditionEntry[] = [];

    loading = false;
    errorMessage = "";

    showAddSurgery = false;
    addingSurgery = false;
    addSurgeryError = "";
    editingSurgeryId: number | null = null;
    surgeryOptions: SurgeryOption[] = [];
    sideOptions: SideOption[] = [];
    referenceDataLoading = false;
    referenceDataLoaded = false;
    newSurgery: NewSurgeryRequest = this.createEmptySurgeryForm();
    surgeryDropdownOpen: "procedure" | "side" | null = null;

    deletingSurgery: SurgeryHistory | null = null;
    deletingSurgeryInProgress = false;
    deleteSurgeryError = "";

    showBotoxForm = false;
    addingBotox = false;
    botoxFormError = "";
    editingBotoxId: number | null = null;
    bodyLocationOptions: string[] = [];
    botoxSideOptions: SideOption[] = [];
    botoxReferenceDataLoading = false;
    botoxReferenceDataLoaded = false;
    newBotox: NewBotoxRequest = this.createEmptyBotoxForm();

    deletingBotox: BotoxHistory | null = null;
    deletingBotoxInProgress = false;
    deleteBotoxError = "";

    showHealthHistoryForm = false;
    addingHealthHistory = false;
    healthHistoryFormError = "";
    editingHealthHistoryId: number | null = null;
    historyConditionOptions: HistoryConditionOption[] = [];
    ageOptions: string[] = [];
    healthHistoryReferenceDataLoading = false;
    healthHistoryReferenceDataLoaded = false;
    newHealthHistory: NewHealthHistoryRequest = this.createEmptyHealthHistoryForm();

    deletingHealthHistory: HealthHistoryEntry | null = null;
    deletingHealthHistoryInProgress = false;
    deleteHealthHistoryError = "";

    showHealthConditionForm = false;
    addingHealthCondition = false;
    healthConditionFormError = "";
    editingHealthConditionId: number | null = null;
    conditionOptions: ConditionOption[] = [];
    healthConditionReferenceDataLoading = false;
    healthConditionReferenceDataLoaded = false;
    newHealthCondition: NewHealthConditionRequest = this.createEmptyHealthConditionForm();

    deletingHealthCondition: HealthConditionEntry | null = null;
    deletingHealthConditionInProgress = false;
    deleteHealthConditionError = "";

    showPrintPreview = false;
    printSurgeries: SurgeryHistory[] = [];
    printHealthConditions: HealthConditionEntry[] = [];

    constructor(
        private http: HttpClient, private cdr: ChangeDetectorRef
    ) { }

    @HostListener("document:click")
    closeSurgeryDropdown(): void {
        this.surgeryDropdownOpen = null;
    }

    @HostListener("document:keydown.escape")
    closeSurgeryDropdownOnEscape(): void {
        this.surgeryDropdownOpen = null;
    }

    get patientName(): string {
        return [this.patient?.lastName, this.patient?.firstName].filter(Boolean).join(", ") || "Not recorded";
    }

    get patientAge(): string {
        const value = this.patient?.dateOfBirth?.slice(0, 10);
        if (!value || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return "Not recorded";
        const [year, month, day] = value.split("-").map(Number);
        const birth = new Date(year, month - 1, day);
        const today = new Date();
        if (birth.getFullYear() !== year || birth.getMonth() !== month - 1 || birth.getDate() !== day || birth > today) return "Not recorded";
        let age = today.getFullYear() - year;
        if (today.getMonth() < month - 1 || (today.getMonth() === month - 1 && today.getDate() < day)) age--;
        return `${age} ${age === 1 ? "year" : "years"}`;
    }

    get patientSex(): string {
        const value = this.patient?.gender;
        if (!value) return "Not recorded";
        if (value.toUpperCase() === "M") return "Male";
        if (value.toUpperCase() === "F") return "Female";
        return value;
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes["patientId"]) {
            this.closeAddSurgery();
            this.closeBotoxForm();
            this.closeHealthHistoryForm();
            this.closeHealthConditionForm();

            this.closeDeleteSurgery();
            this.closeDeleteBotox();
            this.closeDeleteHealthHistory();
            this.closeDeleteHealthCondition();

            this.closePrintPreview();
            this.printSurgeries = [];
            this.printHealthConditions = [];

            this.loadHistory();
        }
    }

    ngOnDestroy(): void {
        this.historySubscription?.unsubscribe();
        this.removePrintStyle();
    }

    private clear(): void {
        this.surgeries = [];
        this.botox = [];
        this.healthHistory = [];
        this.healthConditions = [];
        this.loading = false;
        this.errorMessage = "";
    }

    formatPair(
        a: string | null,
        b: string | null
    ): string {
        return [a, b].filter(part => !!part).join(" -- ");
    }

    sideLabel(value: string | null): string {
        return value === "L" ? "Left" : value === "R" ? "Right" : value || "";
    }

    loadHistory(): void {
        this.historySubscription?.unsubscribe();
        this.clear();
        
        if (!this.patientId) {
            this.cdr.markForCheck();
            return;
        }

        this.loading = true;
        
        this.historySubscription = this.http.get<PatientHistoryData>(`/api/patients/${this.patientId}/history`).subscribe({
            next: history => {
                this.surgeries = history.surgeries ?? [];
                this.botox = history.botox ?? [];
                this.healthHistory = history.healthHistory ?? [];
                this.healthConditions = history.healthConditions ?? [];
                this.loading = false;
                this.cdr.markForCheck();
            },

            error: () => {
                this.clear();
                this.errorMessage = "Unable to load history.";

                this.cdr.markForCheck();
            }
        });
    }

    private createEmptySurgeryForm(): NewSurgeryRequest {
        return { date: "", procedureCode: "", side: "", surgeon: "", facility: "", comment: "" };
    }

    openAddSurgery(): void {
        this.showAddSurgery = true;
        this.editingSurgeryId = null;
        this.addSurgeryError = "";
        this.newSurgery = this.createEmptySurgeryForm();
        this.surgeryDropdownOpen = null;

        if (!this.referenceDataLoaded) {
            this.loadReferenceData();
        }
    }

    openEditSurgery(item: SurgeryHistory): void {
        this.showAddSurgery = true;
        this.editingSurgeryId = item.id;
        this.addSurgeryError = "";
        this.newSurgery = {
            date: item.date ?? "",
            procedureCode: item.procedureCode ?? "",
            side: item.side ?? "",
            surgeon: item.surgeon ?? "",
            facility: item.facility ?? "",
            comment: item.comment ?? ""
        };
        this.surgeryDropdownOpen = null;

        if (!this.referenceDataLoaded) {
            this.loadReferenceData();
        }
    }

    closeAddSurgery(): void {
        this.showAddSurgery = false;
        this.editingSurgeryId = null;
        this.surgeryDropdownOpen = null;
    }

    toggleSurgeryDropdown(dropdown: "procedure" | "side", event: Event): void {
        event.stopPropagation();
        if (this.referenceDataLoading) return;
        this.surgeryDropdownOpen = this.surgeryDropdownOpen === dropdown ? null : dropdown;
    }

    selectSurgeryProcedure(code: string, event: Event): void {
        event.stopPropagation();
        this.newSurgery.procedureCode = code;
        this.surgeryDropdownOpen = null;
    }

    selectSurgerySide(side: string, event: Event): void {
        event.stopPropagation();
        this.newSurgery.side = side;
        this.surgeryDropdownOpen = null;
    }

    surgeryProcedureLabel(): string {
        const selected = this.surgeryOptions.find(option => String(option.code) === String(this.newSurgery.procedureCode));
        return selected?.name
            ?? (this.referenceDataLoading ? "Loading..." : this.newSurgery.procedureCode || "Select...");
    }

    surgerySideLabel(): string {
        const selected = this.sideOptions.find(option => String(option.value) === String(this.newSurgery.side));
        return selected?.label
            ?? (this.referenceDataLoading ? "Loading..." : this.sideLabel(this.newSurgery.side) || "Select...");
    }

    isSelectedSurgeryProcedure(code: string): boolean {
        return String(code) === String(this.newSurgery.procedureCode);
    }

    isSelectedSurgerySide(value: string): boolean {
        return String(value) === String(this.newSurgery.side);
    }

    private loadReferenceData(): void {
        this.referenceDataLoading = true;

        forkJoin({
            surgeries: this.http.get<SurgeryOption[]>("/api/reference/surgeries"),
            sides: this.http.get<SideOption[]>("/api/reference/surgery-sides")
        }).subscribe({
            next: ({ surgeries, sides }) => {
                this.surgeryOptions = surgeries ?? [];
                this.sideOptions = sides ?? [];
                this.referenceDataLoading = false;
                this.referenceDataLoaded = true;
                this.cdr.markForCheck();
            },
            error: () => {
                this.surgeryOptions = [];

                this.sideOptions = [];
                this.referenceDataLoading = false;
                this.addSurgeryError = "Unable to load form options.";
                this.cdr.markForCheck();
            }
        });
    }

    submitSurgeryForm(): void {
        if (!this.patientId) {
            return;
        }

        const requiredFields: { key: keyof NewSurgeryRequest; label: string }[] = [
            { key: "procedureCode", label: "Procedure" },
            { key: "side", label: "Side" },
        ];
        const missing = requiredFields.filter((field) => !this.newSurgery[field.key]);

        if (missing.length > 0) {
            this.addSurgeryError = `${missing.map((field) => field.label).join(", ")} ${missing.length > 1 ? "are" : "is"} required.`;
            return;
        }

        this.addingSurgery = true;
        this.addSurgeryError = "";

        const request$ = this.editingSurgeryId
            ? this.http.put<SurgeryHistory>(
                `/api/patients/${this.patientId}/history/surgeries/${this.editingSurgeryId}`,
                this.newSurgery
            )
            : this.http.post<SurgeryHistory>(
                `/api/patients/${this.patientId}/history/surgeries`,
                this.newSurgery
            );

        request$.subscribe({
            next: () => {
                this.addingSurgery = false;
                this.showAddSurgery = false;
                this.editingSurgeryId = null;
                this.loadHistory();
            },
            error: () => {
                this.addingSurgery = false;
                this.addSurgeryError = this.editingSurgeryId ? "Unable to save surgery." : "Unable to add surgery.";
                this.cdr.markForCheck();
            }
        });
    }

    openDeleteSurgery(item: SurgeryHistory): void {
        this.deletingSurgery = item;
        this.deleteSurgeryError = "";
    }

    closeDeleteSurgery(): void {
        this.deletingSurgery = null;
        this.deleteSurgeryError = "";
    }

    confirmDeleteSurgery(): void {
        if (!this.patientId || !this.deletingSurgery) {
            return;
        }

        this.deletingSurgeryInProgress = true;
        this.deleteSurgeryError = "";

        this.http.delete<void>(
            `/api/patients/${this.patientId}/history/surgeries/${this.deletingSurgery.id}`
        ).subscribe({
            next: () => {
                this.deletingSurgeryInProgress = false;
                this.deletingSurgery = null;
                this.loadHistory();
            },
            error: () => {
                this.deletingSurgeryInProgress = false;
                this.deleteSurgeryError = "Unable to delete surgery.";
                this.cdr.markForCheck();
            }
        });
    }

    private createEmptyBotoxForm(): NewBotoxRequest {
        return { date: "", bodyLocation: "", side: "", facility: "", physician: "" };
    }

    openAddBotox(): void {
        this.showBotoxForm = true;
        this.editingBotoxId = null;
        this.botoxFormError = "";
        this.newBotox = this.createEmptyBotoxForm();

        if (!this.botoxReferenceDataLoaded) {
            this.loadBotoxReferenceData();
        }
    }

    openEditBotox(item: BotoxHistory): void {
        this.showBotoxForm = true;
        this.editingBotoxId = item.id;
        this.botoxFormError = "";
        this.newBotox = {
            date: item.date ?? "",
            bodyLocation: item.bodyLocation ?? "",
            side: item.side ?? "",
            facility: item.facility ?? "",
            physician: item.physician ?? ""
        };

        if (!this.botoxReferenceDataLoaded) {
            this.loadBotoxReferenceData();
        }
    }

    closeBotoxForm(): void {
        this.showBotoxForm = false;
        this.editingBotoxId = null;
    }

    private loadBotoxReferenceData(): void {
        this.botoxReferenceDataLoading = true;

        forkJoin({
            bodyLocations: this.http.get<string[]>("/api/reference/body-locations"),
            sides: this.http.get<SideOption[]>("/api/reference/botox-sides")
        }).subscribe({
            next: ({ bodyLocations, sides }) => {
                this.bodyLocationOptions = bodyLocations ?? [];
                this.botoxSideOptions = sides ?? [];
                this.botoxReferenceDataLoading = false;
                this.botoxReferenceDataLoaded = true;
                this.cdr.markForCheck();
            },
            error: () => {
                this.bodyLocationOptions = [];
                this.botoxSideOptions = [];
                this.botoxReferenceDataLoading = false;
                this.botoxFormError = "Unable to load form options.";
                this.cdr.markForCheck();
            }
        });
    }

    submitBotoxForm(): void {
        if (!this.patientId) {
            return;
        }

        const requiredFields: { key: keyof NewBotoxRequest; label: string }[] = [
            { key: "bodyLocation", label: "Body Location" },
            { key: "side", label: "Side" }
        ];
        const missing = requiredFields.filter((field) => !this.newBotox[field.key]);

        if (missing.length > 0) {
            this.botoxFormError = `${missing.map((field) => field.label).join(", ")} ${missing.length > 1 ? "are" : "is"} required.`;
            return;
        }

        this.addingBotox = true;
        this.botoxFormError = "";

        const request$ = this.editingBotoxId
            ? this.http.put<BotoxHistory>(
                `/api/patients/${this.patientId}/history/botox/${this.editingBotoxId}`,
                this.newBotox
            )
            : this.http.post<BotoxHistory>(
                `/api/patients/${this.patientId}/history/botox`,
                this.newBotox
            );

        request$.subscribe({
            next: () => {
                this.addingBotox = false;
                this.showBotoxForm = false;
                this.editingBotoxId = null;
                this.loadHistory();
            },
            error: () => {
                this.addingBotox = false;
                this.botoxFormError = this.editingBotoxId ? "Unable to save botox shot." : "Unable to add botox shot.";
                this.cdr.markForCheck();
            }
        });
    }

    openDeleteBotox(item: BotoxHistory): void {
        this.deletingBotox = item;
        this.deleteBotoxError = "";
    }

    closeDeleteBotox(): void {
        this.deletingBotox = null;
        this.deleteBotoxError = "";
    }

    confirmDeleteBotox(): void {
        if (!this.patientId || !this.deletingBotox) {
            return;
        }

        this.deletingBotoxInProgress = true;
        this.deleteBotoxError = "";

        this.http.delete<void>(
            `/api/patients/${this.patientId}/history/botox/${this.deletingBotox.id}`
        ).subscribe({
            next: () => {
                this.deletingBotoxInProgress = false;
                this.deletingBotox = null;
                this.loadHistory();
            },
            error: () => {
                this.deletingBotoxInProgress = false;
                this.deleteBotoxError = "Unable to delete botox shot.";
                this.cdr.markForCheck();
            }
        });
    }

    private createEmptyHealthHistoryForm(): NewHealthHistoryRequest {
        return { age: "", conditionCode: "" };
    }

    openAddHealthHistory(): void {
        this.showHealthHistoryForm = true;
        this.editingHealthHistoryId = null;
        this.healthHistoryFormError = "";
        this.newHealthHistory = this.createEmptyHealthHistoryForm();

        if (!this.healthHistoryReferenceDataLoaded) {
            this.loadHealthHistoryReferenceData();
        }
    }

    openEditHealthHistory(item: HealthHistoryEntry): void {
        this.showHealthHistoryForm = true;
        this.editingHealthHistoryId = item.id;
        this.healthHistoryFormError = "";
        this.newHealthHistory = {
            age: item.age ?? "",
            conditionCode: item.conditionCode ?? ""
        };

        if (!this.healthHistoryReferenceDataLoaded) {
            this.loadHealthHistoryReferenceData();
        }
    }

    closeHealthHistoryForm(): void {
        this.showHealthHistoryForm = false;
        this.editingHealthHistoryId = null;
    }

    get availableHistoryConditionOptions(): HistoryConditionOption[] {
        const existingCodes = new Set(
            this.healthHistory
                .filter(item => item.id !== this.editingHealthHistoryId)
                .map(item => this.conditionCodeKey(item.conditionCode))
                .filter(Boolean)
        );
        return this.historyConditionOptions.filter(option =>
            !existingCodes.has(this.conditionCodeKey(option.code))
        );
    }

    private loadHealthHistoryReferenceData(): void {
        this.healthHistoryReferenceDataLoading = true;

        forkJoin({
            conditions: this.http.get<HistoryConditionOption[]>("/api/reference/history-conditions"),
            ages: this.http.get<string[]>("/api/reference/ages")
        }).subscribe({
            next: ({ conditions, ages }) => {
                this.historyConditionOptions = conditions ?? [];
                this.ageOptions = ages ?? [];
                this.healthHistoryReferenceDataLoading = false;
                this.healthHistoryReferenceDataLoaded = true;
                this.cdr.markForCheck();
            },
            error: () => {
                this.historyConditionOptions = [];
                this.ageOptions = [];
                this.healthHistoryReferenceDataLoading = false;
                this.healthHistoryFormError = "Unable to load form options.";
                this.cdr.markForCheck();
            }
        });
    }

    submitHealthHistoryForm(): void {
        if (!this.patientId) {
            return;
        }

        const requiredFields: { key: keyof NewHealthHistoryRequest; label: string }[] = [
            { key: "conditionCode", label: "Condition" },
            { key: "age", label: "Age" }
        ];
        const missing = requiredFields.filter((field) => !this.newHealthHistory[field.key]);

        if (missing.length > 0) {
            this.healthHistoryFormError = `${missing.map((field) => field.label).join(", ")} ${missing.length > 1 ? "are" : "is"} required.`;
            return;
        }

        this.addingHealthHistory = true;
        this.healthHistoryFormError = "";

        const request$ = this.editingHealthHistoryId
            ? this.http.put<HealthHistoryEntry>(
                `/api/patients/${this.patientId}/history/health-history/${this.editingHealthHistoryId}`,
                this.newHealthHistory
            )
            : this.http.post<HealthHistoryEntry>(
                `/api/patients/${this.patientId}/history/health-history`,
                this.newHealthHistory
            );

        request$.subscribe({
            next: () => {
                this.addingHealthHistory = false;
                this.showHealthHistoryForm = false;
                this.editingHealthHistoryId = null;
                this.loadHistory();
            },
            error: () => {
                this.addingHealthHistory = false;
                this.healthHistoryFormError = this.editingHealthHistoryId ? "Unable to save history item." : "Unable to add history item.";
                this.cdr.markForCheck();
            }
        });
    }

    openDeleteHealthHistory(item: HealthHistoryEntry): void {
        this.deletingHealthHistory = item;
        this.deleteHealthHistoryError = "";
    }

    closeDeleteHealthHistory(): void {
        this.deletingHealthHistory = null;
        this.deleteHealthHistoryError = "";
    }

    confirmDeleteHealthHistory(): void {
        if (!this.patientId || !this.deletingHealthHistory) {
            return;
        }

        this.deletingHealthHistoryInProgress = true;
        this.deleteHealthHistoryError = "";

        this.http.delete<void>(
            `/api/patients/${this.patientId}/history/health-history/${this.deletingHealthHistory.id}`
        ).subscribe({
            next: () => {
                this.deletingHealthHistoryInProgress = false;
                this.deletingHealthHistory = null;
                this.loadHistory();
            },
            error: () => {
                this.deletingHealthHistoryInProgress = false;
                this.deleteHealthHistoryError = "Unable to delete history item.";
                this.cdr.markForCheck();
            }
        });
    }

    private createEmptyHealthConditionForm(): NewHealthConditionRequest {
        return { conditionCode: "" };
    }

    openAddHealthCondition(): void {
        this.showHealthConditionForm = true;
        this.editingHealthConditionId = null;
        this.healthConditionFormError = "";
        this.newHealthCondition = this.createEmptyHealthConditionForm();

        if (!this.healthConditionReferenceDataLoaded) {
            this.loadHealthConditionReferenceData();
        }
    }

    openEditHealthCondition(item: HealthConditionEntry): void {
        this.showHealthConditionForm = true;
        this.editingHealthConditionId = item.id;
        this.healthConditionFormError = "";
        this.newHealthCondition = {
            conditionCode: item.conditionCode ?? ""
        };

        if (!this.healthConditionReferenceDataLoaded) {
            this.loadHealthConditionReferenceData();
        }
    }

    closeHealthConditionForm(): void {
        this.showHealthConditionForm = false;
        this.editingHealthConditionId = null;
    }

    get availableHealthConditionOptions(): ConditionOption[] {
        const existingCodes = new Set(
            this.healthConditions
                .filter(item => item.id !== this.editingHealthConditionId)
                .map(item => this.conditionCodeKey(item.conditionCode))
                .filter(Boolean)
        );
        return this.conditionOptions.filter(option =>
            !existingCodes.has(this.conditionCodeKey(option.code))
        );
    }

    private conditionCodeKey(code: string | null): string {
        return (code ?? "").trim().toLowerCase();
    }

    private loadHealthConditionReferenceData(): void {
        this.healthConditionReferenceDataLoading = true;

        this.http.get<ConditionOption[]>("/api/reference/conditions").subscribe({
            next: (conditions) => {
                this.conditionOptions = conditions ?? [];
                this.healthConditionReferenceDataLoading = false;
                this.healthConditionReferenceDataLoaded = true;
                this.cdr.markForCheck();
            },
            error: () => {
                this.conditionOptions = [];
                this.healthConditionReferenceDataLoading = false;
                this.healthConditionFormError = "Unable to load form options.";
                this.cdr.markForCheck();
            }
        });
    }

    submitHealthConditionForm(): void {
        if (!this.patientId) {
            return;
        }

        if (!this.newHealthCondition.conditionCode) {
            this.healthConditionFormError = "Condition is required.";
            return;
        }

        this.addingHealthCondition = true;
        this.healthConditionFormError = "";

        const request$ = this.editingHealthConditionId
            ? this.http.put<HealthConditionEntry>(
                `/api/patients/${this.patientId}/history/health-conditions/${this.editingHealthConditionId}`,
                this.newHealthCondition
            )
            : this.http.post<HealthConditionEntry>(
                `/api/patients/${this.patientId}/history/health-conditions`,
                this.newHealthCondition
            );

        request$.subscribe({
            next: () => {
                this.addingHealthCondition = false;
                this.showHealthConditionForm = false;
                this.editingHealthConditionId = null;
                this.loadHistory();
            },
            error: () => {
                this.addingHealthCondition = false;
                this.healthConditionFormError = this.editingHealthConditionId ? "Unable to save condition." : "Unable to add condition.";
                this.cdr.markForCheck();
            }
        });
    }

    openDeleteHealthCondition(item: HealthConditionEntry): void {
        this.deletingHealthCondition = item;
        this.deleteHealthConditionError = "";
    }

    closeDeleteHealthCondition(): void {
        this.deletingHealthCondition = null;
        this.deleteHealthConditionError = "";
    }

    confirmDeleteHealthCondition(): void {
        if (!this.patientId || !this.deletingHealthCondition) {
            return;
        }

        this.deletingHealthConditionInProgress = true;
        this.deleteHealthConditionError = "";

        this.http.delete<void>(
            `/api/patients/${this.patientId}/history/health-conditions/${this.deletingHealthCondition.id}`
        ).subscribe({
            next: () => {
                this.deletingHealthConditionInProgress = false;
                this.deletingHealthCondition = null;
                this.loadHistory();
            },
            error: () => {
                this.deletingHealthConditionInProgress = false;
                this.deleteHealthConditionError = "Unable to delete condition.";
                this.cdr.markForCheck();
            }
        });
    }

    printReport(): void {
        this.printSurgeries = [...this.surgeries].sort((a, b) =>
            (a.date ?? "").localeCompare(b.date ?? "")
        );
        this.printHealthConditions = [...this.healthConditions].sort((a, b) =>
            (a.conditionDescription ?? "").localeCompare(b.conditionDescription ?? "")
        );

        this.showPrintPreview = true;
        this.injectPrintStyle();
    }

    closePrintPreview(): void {
        this.showPrintPreview = false;
        this.removePrintStyle();
    }

    triggerPrint(): void {
        window.print();
    }

    private injectPrintStyle(): void {
        if (document.getElementById("history-print-style")) {
            return;
        }

        const style = document.createElement("style");
        style.id = "history-print-style";

        style.textContent = `
        @media print {
            body * {
                visibility: hidden !important;
            }

            #printReportContent,
            #printReportContent * {
                visibility: visible !important;
            }

            #printReportContent {
                position: static !important;
                width: 100% !important;
                height: auto !important;
                overflow: visible !important;
            }
        }`;

        document.head.appendChild(style);
    }


    private removePrintStyle(): void {
        document.getElementById("history-print-style")?.remove();
    }
}