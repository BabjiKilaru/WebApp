import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { History } from './history';

describe('Patient History', () => {
    let component: History;
    let http: HttpTestingController;
    beforeEach(async () => {
        await TestBed.configureTestingModule({ imports: [History], providers: [provideHttpClient(), provideHttpClientTesting()] })
            .overrideComponent(History, { set: { template: '' } }).compileComponents();
        component = TestBed.createComponent(History).componentInstance;
        http = TestBed.inject(HttpTestingController);
    });
    afterEach(() => { component.ngOnDestroy(); http.verify(); });
    it('does not load data without a patient', () => {
        component.loadHistory();
        expect(component.loading).toBe(false);
        http.expectNone(request => request.url.includes('/history'));
    });
    it('loads and separates the patient history sections', () => {
        component.patientId = 42;
        component.loadHistory();
        const req = http.expectOne('/api/patients/42/history');
        req.flush({ surgeries: [{ id: 1 }], botox: [], healthHistory: [], healthConditions: [{ id: 2 }] });
        expect(component.surgeries).toHaveLength(1);
        expect(component.healthConditions).toHaveLength(1);
        expect(component.loading).toBe(false);
    });
    it('handles missing optional history sections', () => {
        component.patientId = 42;
        component.loadHistory();
        http.expectOne('/api/patients/42/history').flush({});
        expect(component.surgeries).toEqual([]);
        expect(component.botox).toEqual([]);
    });
    it('handles an HTTP failure without leaving a loading spinner', () => {
        component.patientId = 42;
        component.loadHistory();
        http.expectOne('/api/patients/42/history').flush(null, { status: 500, statusText: 'Error' });
        expect(component.loading).toBe(false);
        expect(component.errorMessage).not.toBe('');
    });
    it('formats sides and missing patient demographics safely', () => {
        expect(component.sideLabel('L')).toBe('Left');
        expect(component.sideLabel('R')).toBe('Right');
        expect(component.patientName).toBe('Not recorded');
        expect(component.patientAge).toBe('Not recorded');
    });
});