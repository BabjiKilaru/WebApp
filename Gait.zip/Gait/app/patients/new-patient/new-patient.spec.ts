import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewPatient } from './new-patient';

describe('NewPatient', () => {

  let component: NewPatient;
  let fixture: ComponentFixture<NewPatient>;

  beforeEach(async () => {

    await TestBed.configureTestingModule({
      imports: [NewPatient]
    })
      .compileComponents();

    fixture = TestBed.createComponent(NewPatient);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('rejects missing required patient fields without emitting', () => {
    const added: unknown[] = [];
    component.add.subscribe(patient => added.push(patient));
    component.addPatient();
    expect(component.errorMessage).toBe('First Name is required.');
    component.form.firstName = 'Sam';
    component.addPatient();
    expect(component.errorMessage).toBe('Last Name is required.');
    component.form.lastName = 'Jones';
    component.addPatient();
    expect(component.errorMessage).toBe('MRN is required.');
    component.form.mrn = '123';
    component.addPatient();
    expect(component.errorMessage).toBe('Date of Birth is required.');
    expect(added).toEqual([]);
  });

  it('trims identifying fields and emits the requested record', () => {
    component.form = { firstName: ' Sam ', lastName: ' Jones ', mrn: ' 123 ', nickname: '', gender: '', generalDiagnosisCode: null, dateOfBirth: '2012-04-01', comment: ' Patient note ' };
    const added: unknown[] = [];
    component.add.subscribe(patient => added.push(patient));
    component.addPatient();
    expect(added).toHaveLength(1);
    expect(added[0]).toMatchObject({ firstName: 'Sam', lastName: 'Jones', mrn: '123', comment: 'Patient note' });
  });

  it('selects a diagnosis and closes the dropdown', () => {
    component.diagnosisDropdownOpen = true;
    component.selectDiagnosis({ id: 1, code: 'G01', diagnosis: 'Example' });
    expect(component.form.generalDiagnosisCode).toBe(1);
    expect(component.selectedDiagnosisLabel).toContain('Example');
    expect(component.diagnosisDropdownOpen).toBe(false);
  });
});