import { CommonModule } from "@angular/common";
import { Component, EventEmitter, Input, Output } from "@angular/core";
import { FormsModule } from "@angular/forms";

export interface GeneralDiagnosisOption {
    id: number;
    code?: string | null;
    diagnosis?: string | null;
    description?: string | null;
}

export interface NewPatientForm {
    firstName: string;
    lastName: string;
    nickname: string;
    mrn: string;
    gender: string;
    generalDiagnosisCode: number | null;
    dateOfBirth: string;
    comment: string;
}

@Component({
    selector: 'app-new-patient',
    standalone: true,
    imports: [CommonModule, FormsModule],
    templateUrl: './new-patient.html',
    styleUrl: './new-patient.css'
})
export class NewPatient {
    @Input()
    generalDiagnoses: GeneralDiagnosisOption[] = [];

    @Output()
    cancel = new EventEmitter<void>();

    @Output()
    add = new EventEmitter<NewPatientForm>();

    @Input() errorMessage = '';

    diagnosisDropdownOpen = false;
    selectedDiagnosisLabel= '';

    toggleDiagnosisDropdown(): void {
        this.diagnosisDropdownOpen = !this.diagnosisDropdownOpen;
    }

    selectDiagnosis(diagnosis: GeneralDiagnosisOption): void {
        this.form.generalDiagnosisCode =diagnosis.id;
        this.selectedDiagnosisLabel = diagnosis.code ? `${diagnosis.code} - ${diagnosis.diagnosis || diagnosis.description || ''}` : diagnosis.diagnosis || diagnosis.description || '';
        this.diagnosisDropdownOpen = false;
    }

    form: NewPatientForm = this.createEmptyForm();

    private createEmptyForm(): NewPatientForm {
        return {
            firstName: '',
            lastName: '',
            nickname: '',
            mrn: '',
            gender: '',
            generalDiagnosisCode: null,
            dateOfBirth: '',
            comment: ''
        };
    }

    close(): void {
        this.cancel.emit();
    }

    addPatient(): void {
        this.errorMessage = '';

        if (!this.form.firstName.trim()) {
            this.errorMessage = 'First Name is required.';
            return;
        }

        if (!this.form.lastName.trim()) {
            this.errorMessage = 'Last Name is required.';
            return;
        }

        if (!this.form.mrn.trim()) {
            this.errorMessage = 'MRN is required.';
            return;
        }

        if (!this.form.dateOfBirth) {
            this.errorMessage = 'Date of Birth is required.';
            return;
        }

        this.add.emit({
            ...this.form,
            firstName: this.form.firstName.trim(),
            lastName: this.form.lastName.trim(),
            nickname: this.form.nickname.trim(),
            mrn: this.form.mrn.trim(),
            comment: this.form.comment.trim()
        });
    }
}