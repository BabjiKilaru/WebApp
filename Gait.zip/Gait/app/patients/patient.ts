export interface Patient {
  id: number;
  mrn: string | null;
  firstName: string | null;
  lastName: string | null;
  oldLastName?: string | null;
  nickname?: string | null;
  dateOfBirth: string | null;
  gender?: string | null;
  generalDiagnosisCode?: number | null;
  label: boolean | null;
  comment?: string | null;
  historyPerson?: string | null;
  historyRelationship: string | null;
  baselineDate?: string | null;
  premature?: string | null;
  birthStay?: string | null;
  ageWalkWithSupport: string | null;
  ageWalkWithoutSupport: string | null;
  learning: number | null;
  ageWalk?: string | null;
  ageTalk?: string | null;
  icd9Code?: string | null;
  generalDiagnosis?: string | null;
  learningDescription?: string | null;
}
