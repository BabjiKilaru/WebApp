import { CommonModule } from "@angular/common";
import { ChangeDetectorRef, Component, EventEmitter, Injectable, Input, OnChanges, OnDestroy, Output, SimpleChanges, ViewChild } from "@angular/core";
import { FormsModule, NgModel } from "@angular/forms";
import { HttpClient } from "@angular/common/http";
import { Subscription } from "rxjs";

import { Patient } from "../patient";
import { Visit } from "../visits/visits";
import { VisitPhoto } from "./visit-photo/visit-photo";
import { VisitPng } from "./visit-png/visit-png";
import { VideoAssessment } from "./video-assessment/video-assessment";

export type InterpretationKey =
  | "video" | "physical-exam" | "kinematics" | "kinetics" | "foot-model"
  | "emg" | "pedobarograph" | "metabolic" | "step-watch" | "photographs"
  | "assessment" | "recommendations" | "signatures";

export interface InterpretationOption {
  key: InterpretationKey;
  label: string;
  enabled: boolean;
}

@Injectable({ providedIn: "root" })
export class InterpretationService {
  constructor(private readonly http: HttpClient) {}

  options(patientId: number, visitId: number) {
    return this.http.get<InterpretationOption[]>(this.url(patientId, visitId));
  }

  private url(patientId: number, visitId: number): string {
    return `/api/patients/${patientId}/visits/${visitId}/interpretation`;
  }
}

interface VisitHomeDetails {
  id: number;
  patientId: number;
  firstName: string | null;
  lastName: string | null;
  mrn: string | null;
  dateOfBirth: string | null;
  gender: string | null;
  visitDate: string | null;
  attendance: string | null;
  startTime: string | null;
  endTime: string | null;
  visitType: string | null;
  visitSubType: string | null;
  scheduledDate: string | null;
  surgeryDate: string | null;
  diagnosis: string | null;
  reasonForAnalysis: string | null;
  internalComment: string | null;
  interpretationDate: string | null;
  interpretationMd: string | null;
  interpretationPt: string | null;
  referringDoctor: string | null;
  dateSent: string | null;
  visitPt: string | null;
  visitPt2: string | null;
  visitBiomech: string | null;
  visitBiomech2: string | null;
  modemsChildParentAvailable: boolean;
  modemsAdolescentParentAvailable: boolean;
  modemsAdolescentSelfAvailable: boolean;
}

@Component({
  selector: "app-visit-home",
  standalone: true,
  imports: [CommonModule, FormsModule, VisitPng, VisitPhoto, VideoAssessment],
  templateUrl: "./visit-home.html",
  styleUrl: "./visit-home.css"
})
export class VisitHome implements OnChanges, OnDestroy {
  @Input({ required: true }) patient!: Patient;
  @Input({ required: true }) visit!: Visit;

  @Output() visitChanged = new EventEmitter<Visit>();

  @ViewChild(VideoAssessment) private videoAssessment?: VideoAssessment;

  interpretationSections: InterpretationOption[] = [];
  activeInterpretation: InterpretationOption | null = null;
  loadingInterpretation = false;
  interpretationError = "";

  visits: Visit[] = [];
  selectedVisitId: number | null = null;
  details: VisitHomeDetails | null = null;
  activeMenu = "Visit Details";
  interpretationExpanded = false;
  loadingDetails = false;
  loadingVisits = false;
  errorMessage = "";
  visitListError = "";

  private detailsSubscription?: Subscription;
  private visitsSubscription?: Subscription;
  private interpretationSubscription?: Subscription;

  constructor(
    private readonly http: HttpClient,
    private readonly cdr: ChangeDetectorRef,
    private readonly interpretationService: InterpretationService
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes["patient"] && this.patient?.id) {
      this.loadVisits();
    }

    if ((changes["visit"] || changes["patient"]) && this.visit) {
      if (this.visit.patientId !== this.patient.id) {
        this.detailsSubscription?.unsubscribe();
        this.resetInterpretation();
        this.selectedVisitId = null;
        this.details = null;
        this.loadingDetails = false;
        this.errorMessage = "The selected visit does not belong to this patient.";
        return;
      }
      this.selectedVisitId = this.visit.id;
      this.loadDetails(this.visit.id);
    }
  }

  ngOnDestroy(): void {
    this.detailsSubscription?.unsubscribe();
    this.visitsSubscription?.unsubscribe();
    this.interpretationSubscription?.unsubscribe();
  }

  onVisitDateChange(visitId: number | null, control?: NgModel): void {
    if (!visitId || visitId === this.selectedVisitId) {
      return;
    }

    const selectedVisit = this.visits.find((candidate) =>
      candidate.id === visitId && candidate.patientId === this.patient.id);
    if (!selectedVisit) {
      return;
    }

    if (this.videoAssessment && !this.videoAssessment.canLeave()) {
      control?.control.setValue(this.selectedVisitId, { emitViewToModelChange: false });
      return;
    }

    this.selectedVisitId = visitId;
    this.visitChanged.emit(selectedVisit);
    this.loadDetails(visitId);
  }

  setActiveMenu(menu: string): void {
    if (menu !== this.activeMenu && this.videoAssessment && !this.videoAssessment.canLeave()) {
      return;
    }
    this.activeInterpretation = null;
    this.activeMenu = menu;
  }

  toggleInterpretation(): void {
    this.interpretationExpanded = !this.interpretationExpanded;
    if (this.interpretationExpanded && !this.interpretationSections.length && !this.loadingInterpretation) {
      this.loadInterpretation();
    }
  }

  openInterpretation(option: InterpretationOption): void {
    if (!option.enabled || this.loadingInterpretation
        || !this.interpretationSections.includes(option)) {
      return;
    }
    if (option.key !== this.activeInterpretation?.key
        && this.videoAssessment && !this.videoAssessment.canLeave()) {
      return;
    }
    this.activeMenu = option.label;
    this.activeInterpretation = option;
  }

  loadInterpretation(): void {
    this.interpretationSubscription?.unsubscribe();
    this.interpretationSections = [];
    this.interpretationError = "";
    if (!this.selectedVisitId || this.visit.patientId !== this.patient.id) {
      this.loadingInterpretation = false;
      this.interpretationError = "Select a visit belonging to this patient to view interpretation options.";
      return;
    }
    this.loadingInterpretation = true;
    this.interpretationSubscription = this.interpretationService
      .options(this.patient.id, this.selectedVisitId).subscribe({
        next: (options) => {
          this.interpretationSections = options;
          this.loadingInterpretation = false;
          this.cdr.markForCheck();
        },
        error: (error) => {
          console.error("Unable to load interpretation options:", error);
          this.loadingInterpretation = false;
          this.interpretationError = "Unable to load interpretation options for the selected visit.";
          this.cdr.markForCheck();
        }
      });
  }

  get patientAge(): number | null {
    const dateOfBirth = this.details?.dateOfBirth ?? this.patient?.dateOfBirth;
    if (!dateOfBirth) {
      return null;
    }

    const birthDate = new Date(`${dateOfBirth.slice(0, 10)}T00:00:00`);
    const referenceDate = new Date(
      `${(this.details?.visitDate ?? new Date().toISOString()).slice(0, 10)}T00:00:00`
    );

    if (Number.isNaN(birthDate.getTime()) || Number.isNaN(referenceDate.getTime())) {
      return null;
    }

    let age = referenceDate.getFullYear() - birthDate.getFullYear();
    const birthdayHasPassed =
      referenceDate.getMonth() > birthDate.getMonth() ||
      (referenceDate.getMonth() === birthDate.getMonth() &&
        referenceDate.getDate() >= birthDate.getDate());

    if (!birthdayHasPassed) {
      age -= 1;
    }

    return age >= 0 ? age : null;
  }

  private loadVisits(): void {
    this.visitsSubscription?.unsubscribe();
    this.visitListError = "";
    this.loadingVisits = true;

    this.visitsSubscription = this.http
      .get<Visit[]>(`/api/patients/${this.patient.id}/visits`)
      .subscribe({
        next: (visits) => {
          this.visits = visits.filter((visit) => {
            const attendance = visit.attendance?.trim() ?? "";
            return attendance === "" || attendance.toLowerCase() === "yes";
          });
          this.loadingVisits = false;
          this.cdr.markForCheck();
        },
        error: (error) => {
          console.error("Unable to load visit dates:", error);
          this.visits = [];
          this.loadingVisits = false;
          this.visitListError = "Unable to load visit dates.";
          this.cdr.markForCheck();
        }
      });
  }

  private resetInterpretation(): void {
    this.interpretationSubscription?.unsubscribe();
    this.interpretationSections = [];
    this.activeInterpretation = null;
    this.activeMenu = "Visit Details";
    this.interpretationError = "";
    this.loadingInterpretation = false;
  }

  private loadDetails(visitId: number): void {
    this.detailsSubscription?.unsubscribe();
    this.resetInterpretation();
    if (this.interpretationExpanded) {
      this.loadInterpretation();
    }
    this.details = null;
    this.errorMessage = "";
    this.loadingDetails = true;

    this.detailsSubscription = this.http
      .get<VisitHomeDetails>(`/api/visits/${visitId}/overview`)
      .subscribe({
        next: (details) => {
          this.details = details;
          this.loadingDetails = false;
          this.cdr.markForCheck();
        },
        error: (error) => {
          console.error("Unable to load visit overview:", error);
          this.loadingDetails = false;
          this.errorMessage = "Unable to load the selected visit.";
          this.cdr.markForCheck();
        }
      });
  }
}
