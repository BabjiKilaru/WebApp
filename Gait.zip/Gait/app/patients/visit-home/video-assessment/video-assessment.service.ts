import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface VideoAssessmentField {
    id : number;
    paramName: string;
    displayName: string;
    order: number;
    choice: string | null;
    controlType: 'LATERALITY' | 'CHECKBOX' | 'SINGLE_SELECT' | 'TEXT' | 'NUMBER';
    options: { code: string; label: string }[];
    side: 'L' | 'R' | null;
    required: boolean;
}

export interface VideoAssessmentGroup {
    id: number;
    name: string;
    comments: string | null;
    fields: VideoAssessmentField[];
}

export interface VideoAssessmentResponse {
    patientId: number;
    visitId: number;
    visitTypeId: number | null;
    assessmentType: 'STANDARD' | 'RUNNING' | 'UPPER_EXTREMITY';
    questionnaireId: number | null;
    revision: string;
    groups: VideoAssessmentGroup[];
}

export interface VideoAssessmentSaveRequest {
    revision: string;
    groups: {
        id: number;
        comments: string | null;
        fields: { id: number; choice: string | null }[];
    }[];
}

@Injectable({
    providedIn: 'root'
})
export class VideoAssessmentService {
    constructor(private readonly http: HttpClient) {}

    getAssessment(patientId: number, visitId: number): Observable<VideoAssessmentResponse> {
        return this.http.get<VideoAssessmentResponse>(`/api/patients/${patientId}/visits/${visitId}/video-assessment`);
    }

    saveAssessment(
        patientId: number, visitId: number, request: VideoAssessmentSaveRequest
    ): Observable<VideoAssessmentResponse> {
        return this.http.put<VideoAssessmentResponse>(
            `/api/patients/${patientId}/visits/${visitId}/video-assessment`, request
        );
    }
}