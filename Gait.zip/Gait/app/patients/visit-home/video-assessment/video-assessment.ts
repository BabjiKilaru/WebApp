import { NgTemplateOutlet } from '@angular/common';
import { ChangeDetectorRef, Component, HostListener, Input, OnChanges, OnDestroy, SimpleChanges } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Subscription } from 'rxjs';
import { AuthService } from '../../../core/auth.service';
import {
    VideoAssessmentService, VideoAssessmentResponse, VideoAssessmentGroup,
    VideoAssessmentField, VideoAssessmentSaveRequest
} from './video-assessment.service';

@Component({
    selector: 'app-video-assessment',
    standalone: true,
    imports: [NgTemplateOutlet],
    templateUrl: './video-assessment.html',
    styleUrls: ['./video-assessment.css']
})
export class VideoAssessment implements OnChanges, OnDestroy {
    @Input({ required: true }) patientId!: number;
    @Input({ required: true }) visitId!: number;

    assessment: VideoAssessmentResponse | null = null;
    editing = false;
    loading = false;
    saving = false;
    errorMessage = '';
    saveError = '';
    savedMessage = '';
    conflict = false;
    showDiscardConfirmation = false;

    readonly radioOptions = [
        { code: 'N', label: 'None' },
        { code: 'R', label: 'Right' },
        { code: 'L', label: 'Left' },
        { code: 'B', label: 'Bilateral' }
    ];
    private draft: VideoAssessmentGroup[] | null = null;
    private assessmentSubscription?: Subscription;
    private saveSubscription?: Subscription;

    constructor(
        private readonly service: VideoAssessmentService,
        private readonly cdr: ChangeDetectorRef,
        private readonly auth: AuthService
    ) {}

    get canEdit(): boolean {
        const role = this.auth.user()?.access.toLowerCase();
        return role === 'admin' || role === 'user';
    }

    get title(): string {
        switch (this.assessment?.assessmentType) {
            case 'RUNNING': return 'Running Video Assessment';
            case 'UPPER_EXTREMITY': return 'Upper Extremity Video Assessment';
            default: return 'Video Assessment';
        }
    }

    get sections(): VideoAssessmentGroup[] {
        return this.draft ?? this.assessment?.groups ?? [];
    }

    get standardCommentGroups(): VideoAssessmentGroup[] {
        return this.assessment?.assessmentType === 'STANDARD'
            ? this.sections.filter(group => group.id === 0 || group.id === 1)
                .sort((left, right) => right.id - left.id)
            : [];
    }

    get findingSections(): VideoAssessmentGroup[] {
        return this.assessment?.assessmentType === 'STANDARD'
            ? this.sections.filter(group => group.id !== 0 && group.id !== 1)
            : this.sections;
    }

    get hasChanges(): boolean {
        return this.draft !== null && this.assessment !== null
            && JSON.stringify(this.toSaveGroups(this.draft))
                !== JSON.stringify(this.toSaveGroups(this.assessment.groups));
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes['patientId'] || changes['visitId']) {
            this.saveSubscription?.unsubscribe();
            this.saving = false;
            this.resetEditing();
            this.loadAssessment();
        }
    }

    ngOnDestroy(): void {
        this.assessmentSubscription?.unsubscribe();
        this.saveSubscription?.unsubscribe();
    }

    @HostListener('window:beforeunload', ['$event'])
    onBeforeUnload(event: BeforeUnloadEvent): void {
        if (this.hasChanges || this.saving) {
            event.preventDefault();
            event.returnValue = '';
        }
    }

    canLeave(): boolean {
        if (this.saving) {
            window.alert('Please wait for the assessment save to finish before leaving.');
            return false;
        }
        return !this.hasChanges || window.confirm('Discard unsaved assessment changes?');
    }

    loadAssessment(): void {
        if (this.editing || this.saving) {
            return;
        }
        this.assessmentSubscription?.unsubscribe();
        this.assessment = null;
        this.errorMessage = '';
        this.savedMessage = '';

        if (!Number.isInteger(this.patientId) || this.patientId <= 0
            || !Number.isInteger(this.visitId) || this.visitId <= 0) {
            this.loading = false;
            this.errorMessage = 'Select a valid patient and visit.';
            return;
        }

        this.loading = true;
        this.assessmentSubscription = this.service.getAssessment(this.patientId, this.visitId)
            .subscribe({
                next: response => {
                    this.assessment = response;
                    this.loading = false;
                    this.cdr.markForCheck();
                },
                error: (error: HttpErrorResponse) => {
                    console.error('Video assessment load failed:', error);
                    this.errorMessage = 'Unable to load assessment. Please try again.';
                    this.loading = false;
                    this.cdr.markForCheck();
                }
            });
    }

    startEditing(): void {
        if (!this.canEdit || !this.assessment || this.loading || this.editing || this.saving) {
            return;
        }
        this.draft = this.assessment.groups.map(group => ({
            ...group,
            fields: group.fields.map(field => ({
                ...field, options: field.options.map(option => ({ ...option }))
            }))
        }));
        this.editing = true;
        this.saveError = '';
        this.savedMessage = '';
        this.conflict = false;
    }

    cancelEditing(): void {
        if (this.saving) {
            return;
        }
        if (this.hasChanges) {
            this.showDiscardConfirmation = true;
            return;
        }
        this.resetEditing();
    }

    keepEditing(): void {
        this.showDiscardConfirmation = false;
    }

    confirmDiscardChanges(): void {
        this.showDiscardConfirmation = false;
        this.resetEditing();
    }

    setComments(group: VideoAssessmentGroup, value: string): void {
        if (this.editing && !this.saving) {
            group.comments = value;
        }
    }

    setChoice(field: VideoAssessmentField, value: string | null): void {
        if (this.editing && !this.saving) {
            field.choice = value;
        }
    }

    isGroupSelection(group: VideoAssessmentGroup, field: VideoAssessmentField): boolean {
        return this.assessment?.assessmentType === 'STANDARD' && group.id === 12
            && field.controlType === 'SINGLE_SELECT' && field.options.length === 0;
    }

    selectGroupField(group: VideoAssessmentGroup, selected: VideoAssessmentField): void {
        if (!this.editing || this.saving) {
            return;
        }
        for (const field of group.fields) {
            if (field.id === selected.id) {
                field.choice = 'Y';
            } else if (field.choice === 'Y') {
                field.choice = 'N';
            }
        }
    }

    pairedSideField(
        group: VideoAssessmentGroup, field: VideoAssessmentField, side: 'L' | 'R'
    ): VideoAssessmentField | undefined {
        const key = this.sideQuestionKey(field);
        if (!key || !field.side) {
            return undefined;
        }
        const matchingFields = (targetSide: 'L' | 'R') => group.fields.filter(candidate =>
            this.sideQuestionKey(candidate) === key
            && candidate.side === targetSide
            && candidate.displayName === field.displayName
            && candidate.controlType === field.controlType
        );
        const index = matchingFields(field.side).indexOf(field);
        return index < 0 ? undefined : matchingFields(side)[index];
    }

    isPairedRightField(group: VideoAssessmentGroup, field: VideoAssessmentField): boolean {
        return field.side === 'R' && this.pairedSideField(group, field, 'L') !== undefined;
    }

    isSharedCommentsField(group: VideoAssessmentGroup, field: VideoAssessmentField): boolean {
        return group.name === 'Comments'
            && field.controlType === 'TEXT'
            && /comments/i.test(field.displayName);
    }

    saveAssessment(): void {
        if (!this.canEdit || !this.assessment || !this.editing || !this.hasChanges || this.saving || this.conflict) {
            return;
        }
        this.saving = true;
        this.saveError = '';
        this.savedMessage = '';
        const request: VideoAssessmentSaveRequest = {
            revision: this.assessment.revision,
            groups: this.toSaveGroups(this.sections)
        };
        this.saveSubscription = this.service.saveAssessment(this.patientId, this.visitId, request)
            .subscribe({
                next: response => {
                    this.assessment = response;
                    this.saving = false;
                    this.resetEditing();
                    this.savedMessage = 'Assessment saved.';
                    this.cdr.markForCheck();
                },
                error: (error: HttpErrorResponse) => {
                    console.error('Video assessment save failed:', error);
                    this.saving = false;
                    this.conflict = error.status === 409;
                    if (this.conflict) {
                        this.saveError = 'This assessment changed since you loaded it. Your draft has been kept. '
                            + 'Reload the latest assessment before editing again.';
                    } else if (error.status === 403) {
                        this.saveError = 'You do not have permission to save this assessment. Your draft has been kept.';
                    } else if (error.status === 400) {
                        this.saveError = 'Some assessment values were rejected. Review your entries and try again.';
                    } else {
                        this.saveError = 'Unable to save assessment. Your draft has been kept. Please try again.';
                    }
                    this.cdr.markForCheck();
                }
            });
    }

    discardAndReload(): void {
        if (!this.canLeave()) {
            return;
        }
        this.resetEditing();
        this.loadAssessment();
    }

    private resetEditing(): void {
        this.editing = false;
        this.draft = null;
        this.showDiscardConfirmation = false;
        this.saveError = '';
        this.conflict = false;
    }

    private sideQuestionKey(field: VideoAssessmentField): string | null {
        return field.paramName.match(/^(UEVA\d{2})[LR]\./)?.[1] ?? null;
    }

    private toSaveGroups(groups: VideoAssessmentGroup[]): VideoAssessmentSaveRequest['groups'] {
        return groups.map(group => ({
            id: group.id,
            comments: group.comments,
            fields: group.fields.map(field => ({ id: field.id, choice: field.choice }))
        }));
    }
}
