import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { vi } from 'vitest';
import { AuthService } from '../../../core/auth.service';
import { VideoAssessment } from './video-assessment';
import { VideoAssessmentField, VideoAssessmentResponse } from './video-assessment.service';

describe('VideoAssessment', () => {
    let fixture: ComponentFixture<VideoAssessment>;
    let http: HttpTestingController;
    const url = '/api/patients/42/visits/7/video-assessment';

    function field(id: number, overrides: Partial<VideoAssessmentField> = {}): VideoAssessmentField {
        return {
            id, paramName: `condition-${id}`, displayName: `Condition ${id}`, order: id,
            choice: null, controlType: 'LATERALITY', options: [], side: null, required: false,
            ...overrides
        };
    }

    function standard(): VideoAssessmentResponse {
        return {
            patientId: 42, visitId: 7, visitTypeId: 1, assessmentType: 'STANDARD',
            questionnaireId: null, revision: 'original',
            groups: [
                { id: 0, name: 'Current Comments', comments: 'Current finding', fields: [] },
                { id: 1, name: 'General / Past Comments', comments: 'Past finding', fields: [] },
                { id: 2, name: 'Ambulatory Aids', comments: null, fields: [
                    field(20, { controlType: 'CHECKBOX', choice: 'Y', displayName: 'Walker' }),
                    field(21, { controlType: 'CHECKBOX', displayName: 'Crutches' })
                ] },
                { id: 3, name: 'Foot Wear Conditions', comments: null, fields: [field(30, { choice: 'R' })] },
                { id: 12, name: 'Running', comments: null, fields: [
                    field(120, { controlType: 'SINGLE_SELECT', choice: 'Y' }),
                    field(121, { controlType: 'SINGLE_SELECT', choice: 'N' })
                ] },
                { id: 13, name: 'Running Conditions', comments: null, fields: [field(130)] }
            ]
        };
    }

    function load(response = standard()): void {
        fixture.componentRef.setInput('patientId', 42);
        fixture.componentRef.setInput('visitId', 7);
        fixture.detectChanges();
        http.expectOne(url).flush(response);
        fixture.detectChanges();
    }

    function button(label: string): HTMLButtonElement {
        const buttons = Array.from(fixture.nativeElement.querySelectorAll('button')) as HTMLButtonElement[];
        const match = buttons.find(item => item.textContent?.trim() === label);
        expect(match, `Expected button "${label}"`).toBeDefined();
        return match!;
    }

    function edit(): void {
        button('Edit').click();
        fixture.detectChanges();
    }

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [VideoAssessment],
            providers: [provideHttpClient(), provideHttpClientTesting()]
        }).compileComponents();
        fixture = TestBed.createComponent(VideoAssessment);
        http = TestBed.inject(HttpTestingController);
        TestBed.inject(AuthService).user.set({
            userid: 'editor', access: 'User', firstName: 'Demo', lastName: 'Reviewer'
        });
    });

    afterEach(() => {
        http.verify();
        vi.restoreAllMocks();
    });

    it('shows every standard section in order on one page, including both Running groups', () => {
        load();
        const headings = Array.from(fixture.nativeElement.querySelectorAll(
            '.assessment-section h3, .assessment-section .table-section-title'
        )) as HTMLElement[];
        expect(headings.map(heading => heading.textContent?.trim())).toEqual(
            ['Comments', ...standard().groups.slice(2).map(group => group.name)]
        );
        expect(fixture.nativeElement.querySelector('.field-count')).toBeNull();
        const tableHeaders = Array.from(fixture.nativeElement.querySelectorAll('.assessment-table thead th')) as HTMLElement[];
        expect(tableHeaders.some(header => header.textContent?.trim() === 'Finding')).toBe(false);
        const commentsTable = fixture.nativeElement.querySelector('#standard-comments-heading').closest('table') as HTMLTableElement;
        const commentRows = Array.from(commentsTable.querySelectorAll('tbody tr'));
        expect(commentRows.map(row => row.querySelector('label')?.textContent?.trim()))
            .toEqual(['Comments on Past Video', 'Current Evaluation Comments']);
        expect(commentsTable.querySelectorAll('.comment-content').length).toBe(2);
        expect(fixture.nativeElement.textContent).not.toContain('implemented separately');
        expect(fixture.nativeElement.querySelectorAll('.assessment-section').length).toBe(5);
        const inputs = Array.from(fixture.nativeElement.querySelectorAll('input')) as HTMLInputElement[];
        expect(inputs.length).toBeGreaterThan(0);
        expect(inputs.every(input => input.disabled)).toBe(true);
        expect(button('Edit').closest('.assessment-header')).not.toBeNull();
        expect(button('Edit').querySelector('svg[aria-hidden="true"]')).not.toBeNull();
        const checkboxFinding: HTMLElement = fixture.nativeElement.querySelector(
            '#assessment-label-2-20'
        ).nextElementSibling;
        expect(checkboxFinding.textContent?.trim()).toBe('');
        expect(checkboxFinding.querySelector('input[type="checkbox"]:checked')).not.toBeNull();
        expect(fixture.nativeElement.querySelector('.assessment-header').textContent)
            .toContain('View only. Select Edit above to change assessment findings.');
        expect(fixture.nativeElement.textContent)
            .not.toContain('All assessment sections for the selected visit, in one page.');
        expect(fixture.nativeElement.querySelector('.assessment-footer')).toBeNull();
        const commentStyle = getComputedStyle(fixture.nativeElement.querySelector('.comment-content'));
        expect(commentStyle.borderTopStyle).toBe('solid');
        expect(commentStyle.borderTopWidth).toBe('1px');
    });

    it('edits a separate draft and Cancel restores the original values without saving', () => {
        load();
        edit();
        const textarea: HTMLTextAreaElement = fixture.nativeElement.querySelector('#assessment-comments-0');
        textarea.value = 'Changed finding';
        textarea.dispatchEvent(new Event('input'));
        const checkbox: HTMLInputElement = fixture.nativeElement.querySelector('#assessment-field-2-20');
        checkbox.click();
        fixture.detectChanges();
        expect(fixture.nativeElement.querySelector('.assessment-header').textContent)
            .toContain('Editing all sections. Save applies your changes; Cancel restores the loaded assessment.');
        expect(fixture.componentInstance.assessment?.groups[0].comments).toBe('Current finding');
        expect(button('Save').disabled).toBe(false);
        button('Cancel').click();
        fixture.detectChanges();
        expect(fixture.nativeElement.querySelector('[role="alertdialog"]')).not.toBeNull();
        button('Discard changes').click();
        fixture.detectChanges();
        expect(fixture.nativeElement.textContent).toContain('Current finding');
        expect(fixture.nativeElement.textContent).not.toContain('Changed finding');
        expect(fixture.componentInstance.assessment?.groups[2].fields[0].choice).toBe('Y');
        http.expectNone(request => request.method === 'PUT');
    });

    it('keeps the draft when Cancel confirmation is declined', () => {
        load();
        edit();
        fixture.componentInstance.setComments(fixture.componentInstance.sections[0], 'Draft finding');
        button('Cancel').click();
        fixture.detectChanges();

        expect(fixture.nativeElement.querySelector('[role="alertdialog"]')).not.toBeNull();
        button('Keep editing').click();
        fixture.detectChanges();
        expect(fixture.componentInstance.editing).toBe(true);
        expect(fixture.componentInstance.showDiscardConfirmation).toBe(false);
        expect(fixture.componentInstance.sections[0].comments).toBe('Draft finding');
    });

    it('shows full laterality labels and defaults missing values to None without changing loaded answers', () => {
        const response = standard();
        response.groups.push({
            id: 14, name: 'Additional Findings', comments: null,
            fields: [field(140, { choice: '' }), field(141, { choice: 'N' }),
                field(142, { choice: 'L' }), field(143, { choice: 'B' })]
        });
        load(response);

        const labels = Array.from(fixture.nativeElement.querySelectorAll(
            'input[name="assessment-7-13-130"]'
        )) as HTMLInputElement[];
        expect(labels.map(input => input.parentElement?.textContent?.trim())).toEqual(
            ['None', 'Right', 'Left', 'Bilateral']
        );
        for (const [groupId, fieldId, value] of [
            [3, 30, 'R'], [13, 130, 'N'], [14, 140, 'N'],
            [14, 141, 'N'], [14, 142, 'L'], [14, 143, 'B']
        ]) {
            const checked: HTMLInputElement = fixture.nativeElement.querySelector(
                `input[name="assessment-7-${groupId}-${fieldId}"]:checked`
            );
            expect(checked.value).toBe(value);
        }

        edit();
        expect(button('Save').disabled).toBe(true);
        expect(fixture.componentInstance.assessment?.groups[5].fields[0].choice).toBeNull();
        const right: HTMLInputElement = fixture.nativeElement.querySelector(
            'input[name="assessment-7-13-130"][value="R"]'
        );
        right.click();
        fixture.detectChanges();
        const none: HTMLInputElement = fixture.nativeElement.querySelector(
            'input[name="assessment-7-13-130"][value="N"]'
        );
        none.click();
        fixture.componentInstance.saveAssessment();
        const request = http.expectOne(url);
        expect(request.request.body.groups[5].fields[0]).toEqual({ id: 130, choice: 'N' });
        request.flush(response);
    });

    it('leaves missing findings and comments empty without recorded-value placeholders', () => {
        const response = standard();
        response.groups[0].comments = null;
        response.groups[1].comments = '';
        response.groups.push({
            id: 14, name: 'Additional Findings', comments: '', fields: [
                field(140, { controlType: 'TEXT' }),
                field(141, { controlType: 'NUMBER' }),
                field(142, { controlType: 'SINGLE_SELECT', options: [{ code: 'Y', label: 'Yes' }] }),
                field(143, { controlType: 'CHECKBOX', choice: '' }),
                field(144, { controlType: 'NUMBER', choice: '0' })
            ]
        });
        load(response);
        expect(fixture.nativeElement.textContent).not.toMatch(/not recorded|no comments recorded/i);
        const emptyElements = Array.from(fixture.nativeElement.querySelectorAll(
            '.comment-content, .group-comments p, .text-finding'
        )) as HTMLElement[];
        expect(emptyElements.length).toBe(4);
        expect(emptyElements.every(element => element.textContent?.trim() === '')).toBe(true);
        for (const id of [21, 140, 141, 142, 143]) {
            const value: HTMLElement = fixture.nativeElement.querySelector(
                `#assessment-label-${id === 21 ? 2 : 14}-${id}`
            ).nextElementSibling;
            expect(value.textContent?.trim()).toBe(id === 142 ? 'Yes' : '');
            expect(value.querySelector('input:checked')).toBeNull();
        }
        const zero: HTMLElement = fixture.nativeElement.querySelector(
            '#assessment-label-14-144'
        ).nextElementSibling;
        expect(zero.textContent?.trim()).toBe('0');
    });

    it('saves comments and findings once with the loaded revision, preserving unanswered fields', () => {
        load();
        edit();
        expect(button('Save').disabled).toBe(true);
        const textarea: HTMLTextAreaElement = fixture.nativeElement.querySelector('#assessment-comments-0');
        textarea.value = 'Updated finding';
        textarea.dispatchEvent(new Event('input'));
        fixture.detectChanges();
        button('Save').click();
        fixture.componentInstance.saveAssessment();
        fixture.detectChanges();
        const request = http.expectOne(url);
        expect(request.request.method).toBe('PUT');
        expect(request.request.body.revision).toBe('original');
        expect(request.request.body.groups[0].comments).toBe('Updated finding');
        expect(request.request.body.groups[2].fields[1]).toEqual({ id: 21, choice: null });
        expect(request.request.body.groups[2].fields[0]).toEqual({ id: 20, choice: 'Y' });
        expect(button('Saving...').disabled).toBe(true);
        expect(button('Cancel').disabled).toBe(true);
        const saved = standard();
        saved.revision = 'saved';
        saved.groups[0].comments = 'Updated finding';
        request.flush(saved);
        fixture.detectChanges();
        expect(fixture.componentInstance.editing).toBe(false);
        expect(fixture.componentInstance.assessment?.revision).toBe('saved');
        expect(fixture.nativeElement.textContent).toContain('Assessment saved.');
    });

    it('keeps unsaved changes and offers explicit reload when a stale save is rejected', () => {
        load();
        edit();
        fixture.componentInstance.setComments(fixture.componentInstance.sections[0], 'Draft');
        fixture.componentInstance.saveAssessment();
        http.expectOne(url).flush({}, { status: 409, statusText: 'Conflict' });
        fixture.detectChanges();
        expect(fixture.componentInstance.editing).toBe(true);
        expect(fixture.componentInstance.sections[0].comments).toBe('Draft');
        expect(fixture.nativeElement.querySelector('[role="alert"]').textContent).toContain('changed');
        const confirm = vi.spyOn(window, 'confirm').mockReturnValue(false);
        button('Discard changes and reload').click();
        expect(confirm).toHaveBeenCalled();
        http.expectNone(url);
        confirm.mockReturnValue(true);
        button('Discard changes and reload').click();
        http.expectOne(url).flush(standard());
        fixture.detectChanges();
        expect(fixture.componentInstance.editing).toBe(false);
    });

    it('renders Running questionnaire answers, including laterality and comments', () => {
        const response = standard();
        response.assessmentType = 'RUNNING';
        response.visitTypeId = 3;
        response.questionnaireId = 3;
        response.groups = [{
            id: 80, name: 'Hips', comments: null, fields: [
                field(800, { displayName: 'Hip rotation', choice: 'B' }),
                field(801, { displayName: 'Comments', controlType: 'TEXT', choice: 'Running notes' })
            ]
        }];
        load(response);
        expect(fixture.nativeElement.querySelector('h2').textContent).toContain('Running Video Assessment');
        expect(fixture.nativeElement.textContent).toContain('Running notes');
        expect(fixture.nativeElement.querySelector('input[value="B"]').checked).toBe(true);
        edit();
        const left: HTMLInputElement = fixture.nativeElement.querySelector('input[value="L"]');
        left.click();
        fixture.componentInstance.saveAssessment();
        const request = http.expectOne(url);
        expect(request.request.body.groups[0].fields[0].choice).toBe('L');
        request.flush(response);
    });

    it('renders Upper Extremity sides and frequency options without changing absent records', () => {
        const response = standard();
        response.assessmentType = 'UPPER_EXTREMITY';
        response.visitTypeId = 2;
        response.questionnaireId = 6;
        const options = ['None', 'Mostly', 'Occasionally'].map(code => ({ code, label: code }));
        response.groups = [{
            id: 36, name: 'Hand Use', comments: null, fields: [
                field(361, { controlType: 'SINGLE_SELECT', choice: 'Mostly', side: 'L', options }),
                field(362, { controlType: 'SINGLE_SELECT', side: 'R', options }),
                field(-36, { controlType: 'TEXT', displayName: 'Comments', side: 'L' })
            ]
        }];
        load(response);
        expect(fixture.nativeElement.querySelector('h2').textContent).toContain('Upper Extremity');
        expect(fixture.nativeElement.textContent).toContain('Left');
        expect(fixture.nativeElement.textContent).toContain('Right');
        edit();
        const occasional: HTMLInputElement = fixture.nativeElement.querySelector(
            'input[name="assessment-7-36-361"][value="Occasionally"]'
        );
        occasional.click();
        fixture.componentInstance.saveAssessment();
        const request = http.expectOne(url);
        expect(request.request.body.groups[0].fields[0].choice).toBe('Occasionally');
        expect(request.request.body.groups[0].fields[1].choice).toBeNull();
        request.flush(response);
    });

    it('shows matching left and right findings in separate columns on one question row', () => {
        const response = standard();
        response.assessmentType = 'UPPER_EXTREMITY';
        response.visitTypeId = 2;
        response.questionnaireId = 6;
        const options = ['None', 'Mostly', 'Occasionally'].map(code => ({ code, label: code }));
        response.groups = [{
            id: 35, name: 'Comments', comments: null, fields: [
                field(350, {
                    paramName: 'UEVA01L.comments', displayName: 'Comments',
                    controlType: 'TEXT', choice: 'Upper extremity comment', side: 'L'
                })
            ]
        }, {
            id: 36, name: 'Hand Use', comments: null, fields: [
                field(361, {
                    paramName: 'UEVA02L.361', displayName: 'Hand use', order: 1001,
                    controlType: 'SINGLE_SELECT', choice: 'Mostly', side: 'L', options
                }),
                field(362, {
                    paramName: 'UEVA02R.362', displayName: 'Hand use', order: 2001,
                    controlType: 'SINGLE_SELECT', choice: 'Occasionally', side: 'R', options
                }),
                field(-36, {
                    paramName: 'UEVA02L.comments', displayName: 'Hand use Comments',
                    controlType: 'TEXT', side: 'L'
                })
            ]
        }];
        load(response);

        const tables = Array.from(fixture.nativeElement.querySelectorAll('.assessment-table')) as HTMLTableElement[];
        expect(tables.length).toBe(1);
        const commentField = fixture.nativeElement.querySelector('.ue-comment-field') as HTMLElement;
        expect(commentField.querySelector('label')?.textContent?.trim()).toBe('Comments');
        expect(commentField.textContent).toContain('Upper extremity comment');
        const findingTableHeaders = Array.from(tables[0].querySelectorAll('thead th')) as HTMLElement[];
        expect(findingTableHeaders.map(header => header.textContent?.trim())).toEqual(['Hand Use', 'Left', 'Right']);
        expect(tables[0].querySelector('thead')?.textContent)
            .not.toContain('Assessment');
        const sectionTitle = findingTableHeaders[0];
        const titleStyle = getComputedStyle(sectionTitle);
        expect(titleStyle.fontSize).toBe('16px');
        expect(titleStyle.fontWeight).toBe('700');
        expect(titleStyle.color).toBe('rgb(15, 42, 74)');
        const rows = Array.from(fixture.nativeElement.querySelectorAll('.assessment-table tbody tr')) as HTMLTableRowElement[];
        expect(rows.length).toBe(2);
        const handUseTable = tables[0];
        const handUseRows = Array.from(handUseTable.querySelectorAll('tbody tr')) as HTMLTableRowElement[];
        const questionRow = handUseRows.find(row => row.querySelector('.field-name')?.textContent?.trim() === 'Hand use');
        expect(questionRow?.querySelectorAll('td').length).toBe(2);
        expect((fixture.nativeElement.querySelector(
            'input[name="assessment-7-36-361"][value="Mostly"]'
        ) as HTMLInputElement).checked).toBe(true);
        expect((fixture.nativeElement.querySelector(
            'input[name="assessment-7-36-362"][value="Occasionally"]'
        ) as HTMLInputElement).checked).toBe(true);
        const commentsRow = handUseRows.find(row => row.querySelector('.field-name')?.textContent?.includes('Comments'));
        expect(commentsRow?.querySelectorAll('td').length).toBe(2);
        expect(commentsRow?.querySelector('td')?.getAttribute('colspan')).toBeNull();
    });

    it('allows only one selection in the standard Running selection group', () => {
        const response = standard();
        response.groups[4].fields.push(
            field(122, { controlType: 'SINGLE_SELECT' }),
            field(123, { controlType: 'SINGLE_SELECT' })
        );
        load(response);
        const table = fixture.nativeElement.querySelector('#assessment-section-12').closest('table') as HTMLTableElement;
        expect(table.querySelectorAll('tbody tr').length).toBe(1);
        expect(table.querySelectorAll('tbody input[type="radio"]').length).toBe(4);
        expect(table.querySelectorAll('tbody input:disabled').length).toBe(4);
        edit();
        const choice: HTMLInputElement = fixture.nativeElement.querySelector('#assessment-field-12-121');
        choice.click();
        fixture.detectChanges();
        const running = fixture.componentInstance.sections.find(group => group.id === 12)!;
        expect(running.fields.map(item => item.choice)).toEqual(['N', 'Y', null, null]);
    });

    it('retains the draft and reports save failures instead of showing success', () => {
        load();
        edit();
        fixture.componentInstance.setComments(fixture.componentInstance.sections[0], 'Draft');
        fixture.componentInstance.saveAssessment();
        http.expectOne(url).flush({}, { status: 403, statusText: 'Forbidden' });
        fixture.detectChanges();
        expect(fixture.componentInstance.editing).toBe(true);
        expect(fixture.componentInstance.sections[0].comments).toBe('Draft');
        expect(fixture.nativeElement.querySelector('[role="alert"]').textContent).toContain('permission');
        expect(fixture.nativeElement.textContent).not.toContain('Assessment saved.');
    });

    it('hides Refresh, protects an active draft, and loads a clean form when the visit changes', () => {
        load();
        edit();
        fixture.componentInstance.setComments(fixture.componentInstance.sections[0], 'Unsaved');
        expect(fixture.nativeElement.querySelector('.refresh-button')).toBeNull();
        fixture.componentInstance.loadAssessment();
        http.expectNone(url);
        fixture.componentRef.setInput('visitId', 8);
        fixture.detectChanges();
        const response = standard();
        response.visitId = 8;
        http.expectOne('/api/patients/42/visits/8/video-assessment').flush(response);
        fixture.detectChanges();
        expect(fixture.componentInstance.editing).toBe(false);
        expect(fixture.componentInstance.sections[0].comments).toBe('Current finding');
        expect(fixture.componentInstance.assessment?.visitId).toBe(8);
    });

    it('handles a failed load and retries without displaying an empty success state', () => {
        fixture.componentRef.setInput('patientId', 42);
        fixture.componentRef.setInput('visitId', 7);
        fixture.detectChanges();
        http.expectOne(url).flush({}, { status: 500, statusText: 'Server Error' });
        fixture.detectChanges();
        expect(fixture.nativeElement.querySelector('[role="alert"]').textContent).toContain('Unable to load');
        button('Try Again').click();
        http.expectOne(url).flush(standard());
        fixture.detectChanges();
        expect(button('Edit').disabled).toBe(false);
    });

    it('saves numeric and text questionnaire values without converting an unanswered number to zero', () => {
        const response = standard();
        response.assessmentType = 'UPPER_EXTREMITY';
        response.questionnaireId = 6;
        response.groups = [{
            id: 36, name: 'Hand Use', comments: null, fields: [
                field(361, { controlType: 'NUMBER', choice: null }),
                field(362, { controlType: 'TEXT', choice: 'Original' })
            ]
        }];
        load(response);
        edit();
        const numberInput: HTMLInputElement = fixture.nativeElement.querySelector('input[type="number"]');
        numberInput.value = '2.5';
        numberInput.dispatchEvent(new Event('input'));
        const textInput: HTMLTextAreaElement = fixture.nativeElement.querySelector('.field-value textarea');
        textInput.value = 'Line one\nLine two';
        textInput.dispatchEvent(new Event('input'));
        fixture.componentInstance.saveAssessment();
        const request = http.expectOne(url);
        expect(request.request.body.groups[0].fields).toEqual([
            { id: 361, choice: '2.5' }, { id: 362, choice: 'Line one\nLine two' }
        ]);
        request.flush(response);
    });

    it('warns before closing a dirty page and blocks navigation while saving', () => {
        load();
        const cleanEvent = new Event('beforeunload', { cancelable: true });
        fixture.componentInstance.onBeforeUnload(cleanEvent as BeforeUnloadEvent);
        expect(cleanEvent.defaultPrevented).toBe(false);
        edit();
        fixture.componentInstance.setComments(fixture.componentInstance.sections[0], 'Draft');
        const dirtyEvent = new Event('beforeunload', { cancelable: true });
        fixture.componentInstance.onBeforeUnload(dirtyEvent as BeforeUnloadEvent);
        expect(dirtyEvent.defaultPrevented).toBe(true);
        fixture.componentInstance.saveAssessment();
        const alert = vi.spyOn(window, 'alert').mockImplementation(() => {});
        expect(fixture.componentInstance.canLeave()).toBe(false);
        expect(alert).toHaveBeenCalled();
        http.expectOne(url).flush(standard());
        expect(fixture.componentInstance.canLeave()).toBe(true);
    });

    it('does not request an assessment for invalid patient or visit identifiers', () => {
        fixture.componentRef.setInput('patientId', 42);
        fixture.componentRef.setInput('visitId', -1);
        fixture.detectChanges();
        expect(fixture.nativeElement.querySelector('[role="alert"]').textContent).toContain('valid patient and visit');
        http.expectNone(request => request.url.includes('video-assessment'));
    });

    it('keeps Internal accounts read-only even when startEditing is called directly', () => {
        TestBed.inject(AuthService).user.set({
            userid: 'reader', access: 'Internal', firstName: 'Demo', lastName: 'Reader'
        });
        load();
        expect(fixture.nativeElement.textContent).toContain('does not have permission');
        expect(fixture.nativeElement.querySelector('.primary-button')).toBeNull();
        fixture.componentInstance.startEditing();
        expect(fixture.componentInstance.editing).toBe(false);
    });
});
