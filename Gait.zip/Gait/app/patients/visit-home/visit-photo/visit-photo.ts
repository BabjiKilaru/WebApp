import { ChangeDetectorRef, Component, Input, OnChanges, OnDestroy, SimpleChanges } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Subscription } from "rxjs";

interface VisitPhotoFile {
  id: string;
  fileName: string;
  contentUrl: string;
}

@Component({
  selector: "app-visit-photo",
  standalone: true,
  templateUrl: "./visit-photo.html",
  styleUrl: "./visit-photo.css"
})
export class VisitPhoto implements OnChanges, OnDestroy {
  @Input({ required: true }) patientId!: number;
  @Input() visitId: number | null = null;

  images: VisitPhotoFile[] = [];
  loading = false;
  errorMessage = "";

  private imagesSubscription?: Subscription;

  constructor(
    private readonly http: HttpClient,
    private readonly cdr: ChangeDetectorRef
  ) {}

  ngOnChanges(_changes: SimpleChanges): void {
    this.loadImages();
  }

  ngOnDestroy(): void {
    this.imagesSubscription?.unsubscribe();
  }

  private loadImages(): void {
    this.imagesSubscription?.unsubscribe();
    this.images = [];
    this.errorMessage = "";

    if (!this.patientId || !this.visitId) {
      this.loading = false;
      return;
    }

    this.loading = true;
    this.imagesSubscription = this.http
      .get<VisitPhotoFile[]>(
        `/api/patients/${this.patientId}/visits/${this.visitId}/images`,
        { params: { type: "PHOTO" } }
      )
      .subscribe({
        next: (images) => {
          this.images = images;
          this.loading = false;
          this.cdr.markForCheck();
        },
        error: (error) => {
          console.error("Unable to load visit photos:", error);
          this.loading = false;
          this.errorMessage = "Unable to load photos for this visit.";
          this.cdr.markForCheck();
        }
      });
  }
}
