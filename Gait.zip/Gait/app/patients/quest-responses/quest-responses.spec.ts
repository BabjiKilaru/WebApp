import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { QuestionnaireResponses } from './quest-responses';

describe('QuestionnaireResponses', () => {
    let component: QuestionnaireResponses;
    let http: HttpTestingController;
    beforeEach(async () => {
        await TestBed.configureTestingModule({ imports: [QuestionnaireResponses], providers: [provideHttpClient(), provideHttpClientTesting()] })
            .overrideComponent(QuestionnaireResponses, { set: { template: '' } }).compileComponents();
        component = TestBed.createComponent(QuestionnaireResponses).componentInstance;
        http = TestBed.inject(HttpTestingController);
    });
    afterEach(() => { component.ngOnDestroy(); http.verify(); });
    it('starts without an editable visit or patient record', () => {
        expect(component.editorReady).toBe(false);
        expect(component.visitChoices).toEqual([{ value: null, label: 'Select visit' }]);
        expect(component.patientName).toBe('Not recorded');
        expect(component.patientAge).toBe('Not recorded');
    });
    it('loads questionnaire page and dropdown options for the selected patient', () => {
        component.patient = { id: 42, firstName: 'Alex', lastName: 'Smith', dateOfBirth: '2014-01-01', gender: 'F' } as any;
        component.ngOnChanges();
        const page = http.expectOne('/api/patients/42/questionnaire-responses');
        const opts = http.expectOne('/api/patients/42/questionnaire-responses/options');
        page.flush({ baseline: { fields: {}, lists: {}, version: 'a' }, visits: [{ id: 55, date: '2026-10-13', visitType: 'Gait', visitSubType: null, appointmentTime: '09:00', appointmentTimeEnd: null }] });
        opts.flush({ relationships: [], premature: [], birthStays: [], ages: [], learning: [], walkingSupport: [], walkingChanges: [], fms: [], medications: [], devices: [], gaitConcerns: [], pain: [] });
        expect(component.patientName).toBe('Smith, Alex');
        expect(component.patientSex).toBe('Female');
        expect(component.visitChoices.some(choice => choice.value === 55)).toBe(true);
        expect(component.loading).toBe(false);
    });
    it('shows only dates while retaining distinct visit IDs for visits on the same date', () => {
        component.page = {
            baseline: { fields: {}, lists: {}, version: 'a' },
            visits: [
                { id: 55, date: '2026-10-13', visitType: 'Gait', visitSubType: 'Step Watch', appointmentTime: '09:00', appointmentTimeEnd: null },
                { id: 56, date: '2026-10-13', visitType: 'Gait', visitSubType: 'Step Watch', appointmentTime: '10:00', appointmentTimeEnd: null },
                { id: 57, date: '2026-10-13', visitType: 'Gait', visitSubType: 'Step Watch', appointmentTime: '10:00', appointmentTimeEnd: null }
            ]
        };

        expect(component.visitChoices).toEqual([
            { value: null, label: 'Select visit' },
            { value: 55, label: '2026-10-13' },
            { value: 56, label: '2026-10-13' },
            { value: 57, label: '2026-10-13' }
        ]);
    });
    it('keeps the fallback label for a visit without a date', () => {
        component.page = {
            baseline: { fields: {}, lists: {}, version: 'a' },
            visits: [
                { id: 55, date: null, visitType: 'Gait', visitSubType: null, appointmentTime: '09:00', appointmentTimeEnd: null }
            ]
        };

        expect(component.visitChoices).toEqual([
            { value: null, label: 'Select visit' },
            { value: 55, label: 'Date not recorded' }
        ]);
    });
    it('reports a load error when the response API fails', () => {
        component.patient = { id: 42 } as any;
        component.ngOnChanges();
        http.expectOne('/api/patients/42/questionnaire-responses/options').flush([]);
        http.expectOne('/api/patients/42/questionnaire-responses').flush(null, { status: 500, statusText: 'Error' });
        expect(component.pageError).not.toBe('');
    });
    it('closes dropdowns on outside clicks', () => {
        component.openDropdown = 'relationship';
        component.closeDropdowns();
        expect(component.openDropdown).toBeNull();
    });
});