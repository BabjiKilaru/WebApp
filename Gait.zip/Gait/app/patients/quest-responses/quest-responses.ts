import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, EventEmitter, HostListener, Input, OnChanges, OnDestroy, Output, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, forkJoin, map, of, Subscription } from 'rxjs';
import { Patient } from '../patient';

type Value = string | number | null;
type Fields = Record<string, Value>;
type Row = Record<string, Value>;
type Scope = 'baseline' | 'items' | 'medications' | 'details';
type EditorMode = 'baseline' | 'visit';

interface Section {
  fields: Fields;
  lists: Record<string, Row[]>;
  version: string;
}
interface VisitOption {
  id: number;
  date: string | null;
  visitType: string | null;
  visitSubType: string | null;
  appointmentTime: string | null;
  appointmentTimeEnd: string | null;
}
interface ResponsePage {
  baseline: Section;
  visits: VisitOption[];
}
interface VisitResponses {
  visitId: number;
  visitDate: string | null;
  effective: Fields;
  items: Section;
  medications: Section;
  details: Section;
}
interface Choice {
  value: Value;
  label: string | null;
  description?: string | null;
}
interface Options {
  relationships: string[];
  premature: string[];
  birthStays: string[];
  ages: string[];
  learning: Choice[];
  walkingSupport: Choice[];
  walkingChanges: string[];
  fms: Choice[];
  medications: string[];
  devices: string[];
  gaitConcerns: Choice[];
  pain: string[];
}
interface Field {
  key: string;
  label: string;
  kind: 'text' | 'date' | 'select';
  options?: keyof Options | 'frequency';
}

@Component({
  selector: 'app-quest-responses',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './quest-responses.html',
  styleUrl: './quest-responses.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QuestionnaireResponses implements OnChanges, OnDestroy {
  @Input() patient: Patient | null = null;
  @Output() baselineSaved = new EventEmitter<Patient>();
  @ViewChild('editor', { static: true }) editor!: ElementRef<HTMLDialogElement>;
  @ViewChild('preview', { static: true }) preview!: ElementRef<HTMLDialogElement>;
  @ViewChild('printContent') printContent?: ElementRef<HTMLElement>;

  readonly baselineFields: Field[] = [
    { key: 'historyPerson', label: 'Person Reporting', kind: 'text' },
    { key: 'historyRelationship', label: 'Relationship to Patient', kind: 'select', options: 'relationships' },
    { key: 'baselineDate', label: 'Date Reported', kind: 'date' },
    { key: 'premature', label: 'How premature?', kind: 'select', options: 'premature' },
    { key: 'birthStay', label: 'How long in hospital following birth?', kind: 'select', options: 'birthStays' },
    { key: 'ageWalk', label: 'Age first walked', kind: 'select', options: 'ages' },
    { key: 'ageTalk', label: 'Age first talked', kind: 'select', options: 'ages' },
    { key: 'learning', label: 'How does child learn?', kind: 'select', options: 'learning' }
  ];
  readonly itemFields: Field[] = [
    { key: 'reportingPerson', label: 'Person completing questionnaire', kind: 'text' },
    { key: 'relationship', label: 'Relationship to patient', kind: 'select', options: 'relationships' },
    { key: 'walkingSupportCode', label: 'Need for support while walking', kind: 'select', options: 'walkingSupport' },
    { key: 'walkingChange', label: 'Recent change in ability to walk', kind: 'select', options: 'walkingChanges' },
    { key: 'fms5Id', label: 'FMS5', kind: 'select', options: 'fms' },
    { key: 'fms50Id', label: 'FMS50', kind: 'select', options: 'fms' },
    { key: 'fms500Id', label: 'FMS500', kind: 'select', options: 'fms' }
  ];
  readonly therapyFields: Field[] = ['Pt', 'Ot'].flatMap(type =>
    ['hospital', 'clinic', 'school', 'home'].map(place => ({
      key: place + type,
      label: `${type.toUpperCase()} Frequency — ${place[0].toUpperCase()}${place.slice(1)}`,
      kind: 'select' as const,
      options: 'frequency' as const
    }))
  );
  readonly frequencyChoices: Choice[] = [
    { value: '1', label: 'One or more times per week' },
    { value: '2', label: 'Two or three times per month' },
    { value: '3', label: 'About once per month' },
    { value: '4', label: 'None' }
  ];
  readonly sideChoices: Choice[] = [
    { value: null, label: 'Not recorded' },
    { value: 'L', label: 'Left' },
    { value: 'R', label: 'Right' },
    { value: 'Both', label: 'Both' }
  ];
  readonly painSides = ['Left', 'Right', 'Both', 'None'];
  readonly listFields = [
    { key: 'devices', label: 'Devices / Braces' },
    { key: 'gaitConcerns', label: 'Gait Concerns' },
    { key: 'pain', label: 'Pain' }
  ];

  page: ResponsePage | null = null;
  report: VisitResponses | null = null;
  options: Options | null = null;
  drafts: Partial<Record<Scope, Section>> = {};
  selectedVisitId: number | null = null;
  editingVisitDate: string | null = null;
  mode: EditorMode = 'baseline';
  loading = false;
  loadingVisit = false;
  editorLoading = false;
  saving = false;
  retryLocked = false;
  pageError = '';
  visitError = '';
  editorError = '';
  notice = '';
  openDropdown: string | null = null;
  newMedication = '';
  otherDevice = '';

  private patientId: number | null = null;
  private editingVisitId: number | null = null;
  private originals: Partial<Record<Scope, Section>> = {};
  private pendingSave: Scope[] | null = null;
  private wroteChanges = false;
  private pageRequest?: Subscription;
  private visitRequest?: Subscription;
  private editRequest?: Subscription;
  private saveRequest?: Subscription;
  private printFrame?: HTMLIFrameElement;
  private printTimer?: ReturnType<typeof setTimeout>;

  constructor(private http: HttpClient, private cdr: ChangeDetectorRef) {}

  ngOnChanges(): void {
    const id = this.patient?.id || null;
    if (id === this.patientId) return;
    this.reset();
    this.patientId = id;
    if (id) this.loadPage();
  }

  ngOnDestroy(): void {
    this.reset();
  }

  @HostListener('document:click')
  closeDropdowns(): void {
    this.openDropdown = null;
  }

  private reset(): void {
    this.pageRequest?.unsubscribe();
    this.visitRequest?.unsubscribe();
    this.editRequest?.unsubscribe();
    this.saveRequest?.unsubscribe();
    this.editor?.nativeElement.close();
    this.preview?.nativeElement.close();
    this.cleanupPrint();
    this.page = null;
    this.report = null;
    this.options = null;
    this.drafts = {};
    this.originals = {};
    this.selectedVisitId = null;
    this.editingVisitId = null;
    this.editingVisitDate = null;
    this.pendingSave = null;
    this.wroteChanges = false;
    this.loading = false;
    this.loadingVisit = false;
    this.editorLoading = false;
    this.saving = false;
    this.retryLocked = false;
    this.pageError = '';
    this.visitError = '';
    this.editorError = '';
    this.notice = '';
    this.openDropdown = null;
    this.newMedication = '';
    this.otherDevice = '';
  }

  private base(): string {
    return `/api/patients/${this.patientId}/questionnaire-responses`;
  }

  get patientName(): string {
    return [this.patient?.lastName, this.patient?.firstName].filter(Boolean).join(', ') || 'Not recorded';
  }

  get patientAge(): string {
    const value = this.patient?.dateOfBirth?.slice(0, 10);
    if (!value || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return 'Not recorded';
    const [year, month, day] = value.split('-').map(Number);
    const birth = new Date(year, month - 1, day);
    const today = new Date();
    if (birth.getFullYear() !== year || birth.getMonth() !== month - 1 || birth.getDate() !== day || birth > today) return 'Not recorded';
    let age = today.getFullYear() - year;
    if (today.getMonth() < month - 1 || (today.getMonth() === month - 1 && today.getDate() < day)) age--;
    return `${age} ${age === 1 ? 'year' : 'years'}`;
  }

  get patientSex(): string {
    const value = this.patient?.gender;
    if (!value) return 'Not recorded';
    if (value.toUpperCase() === 'M') return 'Male';
    if (value.toUpperCase() === 'F') return 'Female';
    return value;
  }

  get visitChoices(): Choice[] {
    return [
      { value: null, label: 'Select visit' },
      ...(this.page?.visits ?? []).map(visit => ({
        value: visit.id,
        label: visit.date || 'Date not recorded'
      }))
    ];
  }

  get editorReady(): boolean {
    return this.mode === 'baseline'
      ? !!this.drafts.baseline
      : !!this.drafts.items && !!this.drafts.medications && !!this.drafts.details;
  }

  get visitSummaryRows(): { label: string; value: string }[][] {
    const fields = [
      { label: 'Visit Date', value: this.report?.visitDate || '' },
      ...this.itemFields.map(field => ({
        label: field.label,
        value: this.report ? this.visitDisplay(field, this.report.effective) : ''
      }))
    ];
    const midpoint = Math.ceil(fields.length / 2);
    return Array.from({ length: midpoint }, (_, index) =>
      [fields[index], fields[index + midpoint]].filter(
        (field): field is { label: string; value: string } => !!field
      )
    );
  }

  visitDisplay(field: Field, values: Fields): string {
    const value = values[field.key];
    return value === null || value === undefined || value === '' ? '' : this.display(field, values);
  }

  loadPage(): void {
    if (!this.patientId) return;
    this.pageRequest?.unsubscribe();
    this.loading = true;
    this.pageError = '';
    this.pageRequest = forkJoin({
      page: this.http.get<ResponsePage>(this.base()),
      options: this.http.get<Options>(`${this.base()}/options`)
    }).subscribe({
      next: ({ page, options }) => {
        this.page = page;
        this.options = options;
        this.loading = false;
        this.cdr.markForCheck();
      },
      error: error => {
        this.loading = false;
        this.pageError = this.errorMessage(error, 'Unable to load questionnaire responses.');
        this.cdr.markForCheck();
      }
    });
  }

  loadVisit(): void {
    if (!this.selectedVisitId || !this.page?.visits.some(visit => visit.id === this.selectedVisitId)) return;
    this.visitRequest?.unsubscribe();
    this.report = null;
    this.loadingVisit = true;
    this.visitError = '';
    this.visitRequest = this.http.get<VisitResponses>(`${this.base()}/visits/${this.selectedVisitId}`).subscribe({
      next: report => {
        this.report = report;
        this.loadingVisit = false;
        this.cdr.markForCheck();
      },
      error: error => {
        this.loadingVisit = false;
        this.visitError = this.errorMessage(error, 'Unable to load this visit.');
        this.cdr.markForCheck();
      }
    });
  }

  choiceText(choice: Choice): string {
    return choice.description || choice.label || String(choice.value ?? '');
  }

  selectedLabel(choices: Choice[], value: Value | undefined): string {
    const selected = choices.find(choice => choice.value === value);
    return selected ? this.choiceText(selected) : String(value ?? 'Not recorded');
  }

  toggleDropdown(key: string, event: Event): void {
    event.stopPropagation();
    this.openDropdown = this.openDropdown === key ? null : key;
  }

  dropdownKeydown(event: KeyboardEvent): void {
    if (event.key !== 'Escape' || !this.openDropdown) return;
    event.preventDefault();
    event.stopPropagation();
    this.openDropdown = null;
    (event.currentTarget as HTMLElement).querySelector<HTMLButtonElement>('.dropdown-button')?.focus();
  }

  choose(key: string, value: Value, event: Event, scope?: Scope, row?: Row): void {
    event.stopPropagation();
    if (this.saving || this.retryLocked) return;
    this.openDropdown = null;
    if (key === 'visit') {
      this.visitRequest?.unsubscribe();
      this.selectedVisitId = value as number | null;
      this.report = null;
      this.loadingVisit = false;
      this.visitError = '';
      this.notice = '';
      if (this.selectedVisitId !== null) this.loadVisit();
    } else if (row) {
      row['side'] = value;
    } else if (scope && this.drafts[scope]) {
      this.drafts[scope]!.fields[key] = value;
    }
    (event.currentTarget as HTMLElement).closest('.dropdown')?.querySelector<HTMLButtonElement>('.dropdown-button')?.focus();
  }

  private choices(field: Field): Choice[] {
    if (!field.options) return [];
    if (field.options === 'frequency') return this.frequencyChoices;
    return (this.options?.[field.options] ?? []).map(value =>
      typeof value === 'string' ? { value, label: value } : value
    );
  }

  fieldChoices(field: Field, scope: Scope): Choice[] {
    const choices: Choice[] = [{ value: null, label: 'Not recorded' }, ...this.choices(field)];
    const value = this.drafts[scope]?.fields[field.key];
    if (value !== undefined && !choices.some(choice => choice.value === value)) {
      choices.push({ value, label: `Existing value: ${value === '' ? '(blank)' : value}` });
    }
    return choices;
  }

  display(field: Field, values: Fields): string {
    const value = values[field.key];
    if (value === null || value === undefined || value === '') return '';
    if (!field.options) return String(value);
    const choice = this.choices(field).find(item => item.value === value);
    return choice ? this.choiceText(choice) : `Existing value: ${value}`;
  }

  listRows(key: string): Row[] {
    const section = key === 'medications' ? this.report?.medications : this.report?.details;
    return section?.lists[key] ?? [];
  }

  rowLabel(key: string, row: Row): string {
    if (key === 'gaitConcerns') {
      const choice = this.options?.gaitConcerns.find(item => item.value === row['code']);
      return choice ? this.choiceText(choice) : `Existing concern: ${row['code'] ?? 'Not recorded'}`;
    }
    return [key === 'pain' ? row['bodyPart'] : row['name'], this.sideLabel(row['side'])]
      .filter(value => value !== null && value !== undefined && value !== '')
      .join(' — ') || 'Not recorded';
  }

  sideLabel(value: Value): string {
    return value === 'L' ? 'Left' : value === 'R' ? 'Right' : String(value ?? '');
  }

  openEdit(mode: EditorMode): void {
    if (!this.page || !this.options || this.loading || this.loadingVisit || this.saving || (mode === 'visit' && !this.report)) return;
    this.mode = mode;
    this.editingVisitId = mode === 'visit' ? this.report!.visitId : null;
    this.editingVisitDate = mode === 'visit' ? this.report!.visitDate : null;
    this.drafts = {};
    this.originals = {};
    this.pendingSave = null;
    this.wroteChanges = false;
    this.retryLocked = false;
    this.editorLoading = true;
    this.editorError = '';
    this.openDropdown = null;
    this.newMedication = '';
    this.otherDevice = '';
    this.editor.nativeElement.showModal();
    this.editRequest?.unsubscribe();
    const url = mode === 'baseline' ? this.base() : `${this.base()}/visits/${this.editingVisitId}`;
    this.editRequest = forkJoin({
      data: this.http.get<ResponsePage | VisitResponses>(url),
      options: this.http.get<Options>(`${this.base()}/options`)
    }).subscribe({
      next: ({ data, options }) => {
        this.options = options;
        if (mode === 'baseline') {
          this.drafts = { baseline: structuredClone((data as ResponsePage).baseline) };
        } else {
          const visit = data as VisitResponses;
          this.editingVisitDate = visit.visitDate;
          this.drafts = {
            items: structuredClone(visit.items),
            medications: structuredClone(visit.medications),
            details: structuredClone(visit.details)
          };
        }
        this.originals = structuredClone(this.drafts);
        this.editorLoading = false;
        this.cdr.markForCheck();
      },
      error: error => {
        this.editorLoading = false;
        this.editorError = this.errorMessage(error, 'Unable to load the editor. Close it and retry.');
        this.cdr.markForCheck();
      }
    });
  }

  closeEditor(event?: Event): void {
    if (this.saving) {
      event?.preventDefault();
      return;
    }
    const refresh = this.wroteChanges;
    const mode = this.mode;
    this.editRequest?.unsubscribe();
    this.editor.nativeElement.close();
    this.drafts = {};
    this.originals = {};
    this.pendingSave = null;
    this.editorLoading = false;
    this.editorError = '';
    this.retryLocked = false;
    this.wroteChanges = false;
    this.openDropdown = null;
    this.newMedication = '';
    this.otherDevice = '';
    if (refresh) {
      if (mode === 'baseline') this.loadPage();
      else this.loadVisit();
    }
  }

  draftRows(key: string): Row[] {
    const scope = key === 'medications' ? 'medications' : 'details';
    return this.drafts[scope]?.lists[key] ?? [];
  }

  getDraft(scope: Scope): Section | undefined {
    return this.drafts[scope];
  }

  private restoredRows(key: string, field: string, value: Value): Row[] {
    const scope = key === 'medications' ? 'medications' : 'details';
    return structuredClone(this.originals[scope]?.lists[key]?.filter(row => row[field] === value) ?? []);
  }

  get deviceNames(): string[] {
    return [...new Set(this.options?.devices ?? [])];
  }

  get otherDeviceRows(): Row[] {
    const standardNames = new Set(this.deviceNames.map(name => name.toLowerCase()));
    return this.draftRows('devices').filter(row => {
      const name = String(row['name'] ?? '').trim();
      return !!name && !standardNames.has(name.toLowerCase());
    });
  }

  hasDevice(name: string): boolean {
    return this.draftRows('devices').some(row => row['name'] === name);
  }

  deviceRows(name: string): Row[] {
    return this.draftRows('devices').filter(row => row['name'] === name);
  }

  toggleDevice(name: string, checked: boolean): void {
    const draft = this.drafts.details;
    if (!draft || this.saving || this.retryLocked) return;
    if (!checked) {
      draft.lists['devices'] = this.draftRows('devices').filter(row => row['name'] !== name);
    } else if (!this.hasDevice(name)) {
      const previous = this.restoredRows('devices', 'name', name);
      draft.lists['devices'].push(...(previous.length ? previous : [{ id: null, name, side: null }]));
    }
  }

  showDeviceSide(name: string, row: Row): boolean {
    return /cane|crutch/i.test(name) || !!row['side'];
  }

  deviceSideChoices(row: Row): Choice[] {
    const value = row['side'];
    return this.sideChoices.some(choice => choice.value === value)
      ? this.sideChoices
      : [...this.sideChoices, { value, label: `Existing value: ${value}` }];
  }

  addOtherDevice(): void {
    const draft = this.drafts.details;
    if (!draft || this.saving || this.retryLocked) return;
    const name = this.otherDevice.trim();
    if (!name) return;
    if (!this.draftRows('devices').some(row => String(row['name']).toLowerCase() === name.toLowerCase())) {
      draft.lists['devices'].push({ id: null, name, side: null });
    }
    this.otherDevice = '';
  }

  removeOtherDevice(row: Row): void {
    if (this.saving || this.retryLocked) return;
    const draft = this.drafts.details;
    if (!draft) return;
    draft.lists['devices'] = this.draftRows('devices').filter(item => item !== row);
  }

  get gaitChoices(): Choice[] {
    const choices = [...(this.options?.gaitConcerns ?? [])];
    for (const row of this.draftRows('gaitConcerns')) {
      if (!choices.some(choice => choice.value === row['code'])) {
        choices.push({ value: row['code'], label: `Existing concern: ${row['code'] ?? 'Not recorded'}` });
      }
    }
    return choices;
  }

  get gaitColumns(): Choice[][] {
    const choices = this.gaitChoices;
    const middle = Math.ceil(choices.length / 2);
    return [choices.slice(0, middle), choices.slice(middle)];
  }

  hasConcern(value: Value): boolean {
    return this.draftRows('gaitConcerns').some(row => row['code'] === value);
  }

  toggleConcern(value: Value, checked: boolean): void {
    const draft = this.drafts.details;
    if (!draft || this.saving || this.retryLocked) return;
    if (!checked) {
      draft.lists['gaitConcerns'] = this.draftRows('gaitConcerns').filter(row => row['code'] !== value);
    } else if (!this.hasConcern(value)) {
      const previous = this.restoredRows('gaitConcerns', 'code', value);
      draft.lists['gaitConcerns'].push(...(previous.length ? previous : [{ id: null, code: value }]));
    }
  }

  get painLocations(): string[] {
    return [...new Set([
      ...(this.options?.pain ?? []),
      ...this.draftRows('pain').map(row => String(row['bodyPart'] ?? '')).filter(Boolean)
    ])];
  }

  painSidesFor(part: string): string[] {
    return part.toLowerCase() === 'back' ? ['Upper', 'Lower', 'Both', 'None'] : this.painSides;
  }

  reportPainLocations(): string[] {
    return [...new Set([
      ...(this.options?.pain ?? []),
      ...(this.report?.details.lists['pain'] ?? []).map(row => String(row['bodyPart'] ?? '')).filter(Boolean)
    ])];
  }

  reportPainSide(part: string): string {
    const rows = (this.report?.details.lists['pain'] ?? []).filter(row => row['bodyPart'] === part);
    const sides = rows.map(row => this.normalizedPainSide(row['side']));
    if (sides.includes('both') || (sides.includes('left') && sides.includes('right')) || (sides.includes('upper') && sides.includes('lower'))) return 'Both';
    return this.painSidesFor(part).find(side => sides.includes(side.toLowerCase())) ?? 'None';
  }

  reportListValue(key: string): string {
    const values = this.listRows(key).map(row => key === 'medications' ? String(row['name'] ?? '') : this.rowLabel(key, row)).filter(Boolean);
    return values.length ? values.join(', ') : '';
  }

  private normalizedPainSide(value: Value): string {
    const side = String(value ?? '').toLowerCase();
    return side === 'l' ? 'left' : side === 'r' ? 'right' : side;
  }

  painSide(part: string): string {
    const rows = this.draftRows('pain').filter(row => row['bodyPart'] === part);
    const sides = rows.map(row => this.normalizedPainSide(row['side']));
    if (sides.includes('both') || (sides.includes('left') && sides.includes('right')) || (sides.includes('upper') && sides.includes('lower'))) return 'Both';
    return this.painSidesFor(part).find(side => sides.includes(side.toLowerCase())) ?? 'None';
  }

  setPainSide(part: string, side: string): void {
    const draft = this.drafts.details;
    if (!draft || this.saving || this.retryLocked) return;
    const current = this.draftRows('pain').filter(row => row['bodyPart'] === part);
    const others = this.draftRows('pain').filter(row => row['bodyPart'] !== part);
    if (side === 'None') {
      draft.lists['pain'] = others;
      return;
    }
    const previous = this.restoredRows('pain', 'bodyPart', part);
    const row = current[0] ?? previous[0] ?? { id: null, bodyPart: part, side };
    draft.lists['pain'] = [...others, { ...row, side }];
  }

  get medicationChoices(): string[] {
    const search = this.newMedication.trim().toLowerCase();
    const selected = new Set(this.draftRows('medications').map(row => String(row['name']).toLowerCase()));
    return (this.options?.medications ?? []).filter(name => !selected.has(name.toLowerCase()) && name.toLowerCase().includes(search));
  }

  chooseMedication(name: string): void {
    if (this.saving || this.retryLocked) return;
    this.newMedication = name;
    this.openDropdown = null;
  }

  addMedication(name = this.newMedication): void {
    const draft = this.drafts.medications;
    if (!draft || this.saving || this.retryLocked) return;
    name = name.trim();
    if (!name) return;
    if (!this.draftRows('medications').some(row => String(row['name']).toLowerCase() === name.toLowerCase())) {
      const previous = this.restoredRows('medications', 'name', name);
      draft.lists['medications'].push(...(previous.length ? previous : [{ id: null, name }]));
    }
    this.newMedication = '';
    this.openDropdown = null;
  }

  removeMedication(index: number): void {
    if (!this.saving && !this.retryLocked) this.drafts.medications?.lists['medications'].splice(index, 1);
  }

  save(): void {
    if (!this.editorReady || this.saving || this.editorLoading) return;
    if (this.mode === 'visit' && !this.editingVisitId) return;
    this.editorError = '';
    if (!this.retryLocked && this.mode === 'visit') {
      this.addOtherDevice();
    }
    if (!this.pendingSave) {
      const scopes: Scope[] = this.mode === 'baseline' ? ['baseline'] : ['items', 'medications', 'details'];
      this.pendingSave = scopes.filter(scope => JSON.stringify(this.drafts[scope]) !== JSON.stringify(this.originals[scope]));
    }
    if (!this.pendingSave.length) {
      this.closeEditor();
      return;
    }
    this.saving = true;
    this.openDropdown = null;
    const requests = this.pendingSave.map(scope => {
      const url = scope === 'baseline'
        ? `${this.base()}/baseline`
        : `${this.base()}/visits/${this.editingVisitId}/${scope}`;
      return this.http.put<void>(url, structuredClone(this.drafts[scope]!)).pipe(
        map(() => ({ scope, error: '' })),
        catchError(error => of({ scope, error: this.errorMessage(error, 'Unable to save these answers.') }))
      );
    });
    this.saveRequest = forkJoin(requests).subscribe(results => {
      this.saving = false;
      const saved = results.filter(result => !result.error);
      const failed = results.filter(result => !!result.error);
      if (saved.length) this.wroteChanges = true;
      this.pendingSave = failed.map(result => result.scope);
      if (!failed.length) {
        if (this.mode === 'baseline' && this.patient && this.drafts.baseline) {
          const updated = { ...this.patient, ...this.drafts.baseline.fields } as Patient;
          updated.learningDescription = this.options?.learning.find(choice => choice.value === updated.learning)?.label ?? null;
          this.baselineSaved.emit(updated);
        }
        this.notice = this.mode === 'baseline' ? 'Baseline answers saved.' : 'Per visit answers saved.';
        this.closeEditor();
      } else {
        this.retryLocked = this.wroteChanges;
        const errors = [...new Set(failed.map(result => result.error))].join(' ');
        this.editorError = this.retryLocked
          ? `Some changes were saved. ${errors} Retry saves only the remaining changes. Close reloads the saved data.`
          : errors;
        if (!this.retryLocked) this.pendingSave = null;
      }
      this.cdr.markForCheck();
    });
  }

  private errorMessage(error: HttpErrorResponse, fallback: string): string {
    if (error.status === 0) return 'Cannot reach the server. Check the connection and retry.';
    if (error.status === 409) return 'These answers changed. Close and reopen the editor to load the latest data.';
    return typeof error.error?.message === 'string' ? error.error.message : fallback;
  }

  openPrintPreview(): void {
    if (!this.page || this.loading || this.loadingVisit || this.pageError || this.visitError) return;
    this.preview.nativeElement.showModal();
  }

  closePrintPreview(): void {
    this.preview.nativeElement.close();
  }

  print(): void {
    const content = this.printContent?.nativeElement;
    if (!content) return;
    this.cleanupPrint();
    const frame = document.createElement('iframe');
    frame.title = 'Questionnaire responses print document';
    frame.setAttribute('aria-hidden', 'true');
    frame.style.cssText = 'position:fixed;width:1px;height:1px;bottom:0;right:0;border:0';
    document.body.appendChild(frame);
    this.printFrame = frame;
    const doc = frame.contentDocument;
    const win = frame.contentWindow;
    if (!doc || !win) {
      this.cleanupPrint();
      return;
    }
    doc.title = 'Questionnaire Responses';
    const style = doc.createElement('style');
    style.textContent = `
      @page{
        size: Letter portrait;
        margin: 12mm;
      }
      *{
        box-sizing: border-box;
      }
      body {
        margin: 0;
        font: 14px Arial, sans-serif;
        color: #30363b;
        print-color-adjust: exact;
        -webkit-print-color-adjust: exact;
      }
      .report-masthead {
        text-align: center;
        padding-bottom: 18px;
        border-bottom: 2px solid #0f2a4a;
        break-inside: avoid;
      }
      .report-masthead h2 {
        margin: 0 0 4px;
        color: #0f2a4a;
        font-size: 20px;
      }
      .report-masthead h3 {
        margin: 0;
        font-size: 15px;
        font-weight: 600;
      }
      .report-info-card {
        display: grid;
        flex-direction: column;
        gap: 6px 18px;
        padding: 14px 16px;
        margin-bottom: 22px;
        background: #f5f7fa;
        border-radius: 6px;
        break-inside: avoid;
        grid-template-columns: 1fr 1fr 1fr 1fr;
      }
      .report-info-card span {
        padding: 4px 0;
        overflow-wrap: anywhere;
      }
      .report-section {
        margin-bottom: 24px;
      }
      .report-pain-therapy-layout {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        align-items: stretch;
        gap: 18px;
        margin-bottom: 4px;
      }
      .report-pain-column {
        display: flex;
        flex-direction: column;
        min-width: 0;
      }
      .report-pain-column table {
        flex: 1;
      }
      .report-therapy-column {
        min-width: 0;
      }
      h4 {
        margin: 0 0 10px;
        color: #0f2a4a;
        font-size: 15px;
        font-weight: 700;
        break-after: avoid;
      }
      table {
        width: 100%;
        table-layout: fixed;
        border-collapse: collapse;
        margin: 0 0 20px;
        border: 1px solid #64748b;
      }
      th, td {
        padding: 7px 4px;
        border: 1px solid #64748b;
        color: #30363b;
        background: #fff;
        font-size: 14px;
        text-align: left;
        vertical-align: top;
        white-space: pre-wrap;
        overflow-wrap: anywhere;
      }
      th {
        background: #f5f7fa;
      }
      th:first-child{
        width: 55%;
        color: #3d454b;
        font-weight: 400;
      }
      thead {
        display: table-header-group;
      }
      thead th {
        font-weight: 600;
        background: #f5f7fa;
      }
      tr {
        break-inside: avoid;
      }
      @media (max-width: 600px) {
        .report-pain-therapy-layout {
          grid-template-columns: 1fr;
        }
      }
    `;
    doc.head.appendChild(style);
    doc.body.appendChild(content.cloneNode(true));
    win.addEventListener('afterprint', () => this.cleanupPrint(), { once: true });
    this.printTimer = setTimeout(() => this.cleanupPrint(), 120000);
    win.focus();
    win.print();
  }

  private cleanupPrint(): void {
    if (this.printTimer) clearTimeout(this.printTimer);
    this.printTimer = undefined;
    this.printFrame?.remove();
    this.printFrame = undefined;
  }
}