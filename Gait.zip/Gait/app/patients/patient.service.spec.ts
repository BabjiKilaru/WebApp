import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { PatientService } from './patient.service';

describe('PatientService HTTP contract', () => {
    let service: PatientService;
    let http: HttpTestingController;
    beforeEach(() => {
        TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
        service = TestBed.inject(PatientService);
        http = TestBed.inject(HttpTestingController);
    });
    afterEach(() => http.verify());

    it('gets a patient by ID and a patient by encoded MRN', () => {
        service.getPatientById(42).subscribe();
        service.getByMrn('A B/123').subscribe();
        expect(http.expectOne('/api/patients/42').request.method).toBe('GET');
        expect(http.expectOne('/api/patients/mrn/A%20B%2F123').request.method).toBe('GET');
    });
    it('uses query parameters for search rather than interpolating unsanitized URLs', () => {
        service.searchPatients('Smith & Jones').subscribe();
        const req = http.expectOne(request => request.url === '/api/patients/search');
        expect(req.request.params.get('query')).toBe('Smith & Jones');
        req.flush([]);
        service.searchByLastName("O'Neil").subscribe();
        const lastNameReq = http.expectOne(request => request.url === '/api/patients');
        expect(lastNameReq.request.params.get('lastName')).toBe("O'Neil");
        lastNameReq.flush([]);
    });
    it('sends create and update payloads using POST and PUT', () => {
        const patient = { firstName: 'Avery', mrn: '100' };
        service.createPatient(patient).subscribe();
        service.updatePatient(42, patient).subscribe();
        const create = http.expectOne('/api/patients');
        expect(create.request.method).toBe('POST');
        expect(create.request.body).toEqual(patient);
        create.flush({});
        const update = http.expectOne('/api/patients/42');
        expect(update.request.method).toBe('PUT');
        expect(update.request.body).toEqual(patient);
        update.flush({});
    });
    it('retrieves diagnosis reference data', () => {
        service.getGeneralDiagnoses().subscribe();
        const request = http.expectOne('/api/patients/general-diagnoses');
        expect(request.request.method).toBe('GET');
        request.flush([]);
    });
});