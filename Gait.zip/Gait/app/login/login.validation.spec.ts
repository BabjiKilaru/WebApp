import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ActivatedRoute, Router, provideRouter } from '@angular/router';
import { vi } from 'vitest';
import { Login } from './login';

describe('Login credentials and server responses', () => {
    let component: Login;
    let http: HttpTestingController;
    let router: Router;
    beforeEach(async () => {
        await TestBed.configureTestingModule({ imports: [Login], providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()] })
            .overrideComponent(Login, { set: { template: '' } }).compileComponents();
        component = TestBed.createComponent(Login).componentInstance;
        http = TestBed.inject(HttpTestingController);
        router = TestBed.inject(Router);
        http.expectOne('/api/health').flush('ok');
    });
    afterEach(() => http.verify());
    it('blocks blank usernames and passwords', () => {
        component.onSubmit();
        expect(component.error()).toContain('username');
        component.username.set('clinician');
        component.onSubmit();
        expect(component.error()).toContain('password');
        http.expectNone('/api/auth/login');
    });
    it('prevents duplicate login submissions', () => {
        component.username.set('clinician');
        component.password.set('P@ssw0rd');
        component.onSubmit();
        component.onSubmit();
        const requests = http.match('/api/auth/login');
        expect(requests).toHaveLength(1);
        requests[0].flush({}, { status: 401, statusText: 'Unauthorized' });
        expect(component.error()).toBe('Invalid username or password.');
    });
    it('navigates after successful login', () => {
        const navigate = vi.spyOn(router, 'navigateByUrl').mockResolvedValue(true);
        component.username.set(' clinician ');
        component.password.set('P@ssw0rd');
        component.onSubmit();
        const request = http.expectOne('/api/auth/login');
        expect(request.request.body.userid).toBe('clinician');
        request.flush({ userid: 'clinician', access: 'user', firstName: 'Test', lastName: 'User' });
        expect(navigate).toHaveBeenCalledWith('/patients');
    });
    it('forces users with a temporary password to profile instead of their return URL', () => {
        const navigate = vi.spyOn(router, 'navigateByUrl').mockResolvedValue(true);
        vi.spyOn(TestBed.inject(ActivatedRoute).snapshot.queryParamMap, 'get').mockReturnValue('/patients');
        component.username.set('clinician');
        component.password.set('Temporary1!');
        component.onSubmit();
        http.expectOne('/api/auth/login').flush({
            userid: 'clinician', access: 'user', firstName: 'Test', lastName: 'User', mustChangePassword: true,
        });
        expect(navigate).toHaveBeenCalledWith('/profile');
    });
    it('preserves significant leading and trailing whitespace in passwords (known failing regression)', () => {
        component.username.set('clinician');
        component.password.set(' space-sensitive ');
        component.onSubmit();
        const request = http.expectOne('/api/auth/login');
        expect(request.request.body.password).toBe(' space-sensitive ');
        request.flush({}, { status: 401, statusText: 'Unauthorized' });
    });
});