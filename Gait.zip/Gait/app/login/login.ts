import { CommonModule } from "@angular/common";
import { Component, signal } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { HttpClient } from "@angular/common/http";
import { ActivatedRoute, Router } from "@angular/router";
import { AuthService } from "../core/auth.service";

@Component({
  selector: "app-login",
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: "./login.html",
  styleUrl: "./login.css"
})

export class Login {
  username = signal("");
  password = signal("");
  error = signal("");

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private auth: AuthService,
    private http: HttpClient,
  ) {
    this.http.get("/api/health").subscribe({ error: () => {} });

    if (this.route.snapshot.queryParamMap.get("expired")) {
      this.error.set("Your session has expired. Please sign in again.");
    }
  }

  private submitting = false;

  onSubmit(): void {
    this.error.set("");

    const username = this.username().trim();
    const password = this.password();
    if (this.submitting) return;
    if (!username) {
      this.error.set("Please enter your username.");
      return;
    }

    if (!password.trim()) {
      this.error.set("Please enter your password.");
      return;
    }

    this.submitting = true;
    this.auth.login(username, password).subscribe({
      next: (user) => {
        this.submitting = false;
        const returnUrl = this.route.snapshot.queryParamMap.get("returnUrl");
        this.router.navigateByUrl(user.mustChangePassword
          ? "/profile"
          : returnUrl && returnUrl.startsWith("/") ? returnUrl : "/patients");
      },

      error: (err) => {
        this.submitting = false;
        this.error.set(err.status === 401
          ? "Invalid username or password."
          : "Unable to sign in right now. Please try again.");
      },
    });
  }
}