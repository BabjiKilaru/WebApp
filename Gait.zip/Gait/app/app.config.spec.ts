import { TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { appConfig } from './app.config';

describe('Application provider configuration', () => {
    it('registers HttpClient and the router for application-wide use', () => {
        TestBed.configureTestingModule({ providers: [...appConfig.providers] });
        expect(TestBed.inject(HttpClient)).toBeTruthy();
        expect(TestBed.inject(Router)).toBeTruthy();
    });
});
