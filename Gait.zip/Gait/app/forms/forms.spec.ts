import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Forms } from './forms';

const PATIENT = {
    visitId: 10, patientId: 1, mrn: '123', firstName: 'Sam', lastName: 'Doe',
    visitType: 'Gait', visitSubType: 'Follow-up', visitDate: '2026-10-13',
    appointmentTime: '09:00', recommendedForms: ['patientform', 'invalid', 'patientform', 'analysisform'],
};

describe('Forms', () => {
    let component: Forms;
    let http: HttpTestingController;
    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [Forms], providers: [provideHttpClient(), provideHttpClientTesting()],
        }).overrideComponent(Forms, { set: { template: '' } }).compileComponents();
        component = TestBed.createComponent(Forms).componentInstance;
        http = TestBed.inject(HttpTestingController);
    });
    afterEach(() => http.verify());

    it('builds six weeks of calendar dates', () => {
        component.buildCalendar();
        expect(component.calendarDays).toHaveLength(42);
        expect(component.calendarYears).toHaveLength(101);
    });
    it('does not change months while generating a PDF', () => {
        const month = component.calendarMonth.getMonth();
        component.generatingPdf = true;
        component.changeMonth(1);
        expect(component.calendarMonth.getMonth()).toBe(month);
    });
    it('loads scheduled patients and filters unsupported/duplicate form codes', () => {
        component.selectedDate = '2026-10-13';
        component.loadPatients();
        const req = http.expectOne(request => request.url === '/api/forms/patients');
        expect(req.request.params.get('date')).toBe('2026-10-13');
        req.flush([PATIENT]);
        expect(component.patients[0].selectedForms).toEqual(['patientform', 'analysisform']);
        expect(component.patients[0].selected).toBe(false);
        expect(component.loadedDate).toBe('2026-10-13');
        expect(component.loadingPatients).toBe(false);
    });
    it('shows an error if patient listing fails', () => {
        component.loadPatients();
        http.expectOne(request => request.url === '/api/forms/patients').flush(null, { status: 500, statusText: 'Internal error' });
        expect(component.errorMessage).toContain('Unable to load');
        expect(component.patients).toEqual([]);
        expect(component.loadingPatients).toBe(false);
    });
    it('requires at least one selected patient before generating forms', () => {
        component.viewPrintableForms();
        expect(component.errorMessage).toBe('select at least one patient.');
        http.expectNone('/api/forms/preview');
    });
    it('requires forms for every selected patient', () => {
        component.patients = [{ ...PATIENT, recommendedForms: [], selectedForms: [], selected: true }];
        component.viewPrintableForms();
        expect(component.errorMessage).toBe('Select at least one form for each selected patient.');
        http.expectNone('/api/forms/preview');
    });
    it('respects the manual/automatic form-selection mode', () => {
        component.patients = [{ ...PATIENT, recommendedForms: ['analysisform'], selectedForms: [], selected: true }];
        component.onAutomaticSelectionChange();
        expect(component.patients[0].selectedForms).toEqual(['analysisform']);
        const checkbox = { target: { checked: true } } as unknown as Event;
        component.onFormSelectionChange(component.patients[0], 'ptueform', checkbox);
        expect(component.patients[0].selectedForms).not.toContain('ptueform');
        component.chooseAutomatically = false;
        component.onFormSelectionChange(component.patients[0], 'ptueform', checkbox);
        expect(component.patients[0].selectedForms).toContain('ptueform');
    });
    it('POSTs the selected visit IDs and handles PDF-generation failure', () => {
        component.patients = [{ ...PATIENT, recommendedForms: ['patientform'], selectedForms: ['patientform'], selected: true }];
        component.viewPrintableForms();
        const req = http.expectOne('/api/forms/preview');
        expect(req.request.method).toBe('POST');
        expect(req.request.body).toEqual({ visits: [{ visitId: 10, forms: ['patientform'] }] });
        req.flush(null, { status: 500, statusText: 'Internal error' });
        expect(component.generatingPdf).toBe(false);
        expect(component.errorMessage).toContain('Unable to generate');
    });
});