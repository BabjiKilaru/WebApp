import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize, timeout } from 'rxjs';

import { Header } from '../header/header';

interface PrintableFormOption {
  key: string;
  label: string;
}

interface FormsPatientResponse {
  visitId: number;
  patientId: number;
  mrn: string;
  firstName: string;
  lastName: string;
  visitType: string;
  visitSubType: string;
  visitDate: string;
  appointmentTime: string;
  recommendedForms: string[];
}

interface PrintableFormsPatient extends FormsPatientResponse {
  selectedForms: string[];
  selected: boolean;
}

interface PrintableFormsRequest {
  visitId: number;
  forms: string[];
}

interface CalendarDay {
  date: string;
  day: number;
  currentMonth: boolean;
}

@Component({
  selector: 'app-forms',
  standalone: true,
  imports: [CommonModule, FormsModule, Header],
  templateUrl: './forms.html',
  styleUrl: './forms.css'
})
export class Forms implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly cdr = inject(ChangeDetectorRef);

  readonly weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  readonly formOptions: PrintableFormOption[] = [
    {
      key: 'patientform',
      label: 'Patient Visit Form'
    },
    {
      key: 'analysisform',
      label: 'Analysis Info Sheet'
    },
    {
      key: 'ptevalform',
      label: 'PT Eval'
    },
    {
      key: 'engineerform',
      label: 'Engineer'
    },
    {
      key: 'footstudysurvey',
      label: 'PT Foot Eval'
    },
    {
      key: 'shueeform',
      label: 'SHUEE Grading Form'
    },
    {
      key: 'ueengineerform',
      label: 'UE Engineer Form'
    },
    {
      key: 'runningengineerform',
      label: 'Running Engineer Form'
    },
    {
      key: 'ptueform',
      label: 'UE Eval Form'
    }
  ];

  selectedDate = this.getToday();
  loadedDate = '';
  chooseAutomatically = true;
  patients: PrintableFormsPatient[] = [];
  calendarDays: CalendarDay[] = [];
  calendarYears: number[] = [];
  loadingPatients = false;
  generatingPdf = false;
  errorMessage = '';

  calendarMonth = new Date(
    Number(this.selectedDate.slice(0, 4)),
    Number(this.selectedDate.slice(5, 7)) - 1,
    1
  );

  ngOnInit(): void {
    this.buildCalendar();
  }

  get calendarMonthTitle(): string {
    return this.calendarMonth.toLocaleDateString('en-US', {
      month: 'long'
    });
  }

  buildCalendar(): void {
    const year = this.calendarMonth.getFullYear();
    const month = this.calendarMonth.getMonth();
    const firstWeekday = new Date(year, month, 1).getDay();
    this.calendarYears = Array.from({ length: 101 }, (_, index) => year + index - 50);

    this.calendarDays = Array.from({ length: 42 }, (_, index) => {
      const date = new Date(year, month, index - firstWeekday + 1);

      return {
        date: this.toDateString(date),
        day: date.getDate(),
        currentMonth: date.getMonth() === month
      };
    });
  }

  changeMonth(direction: number): void {
    if (this.loadingPatients || this.generatingPdf) {
      return;
    }

    this.calendarMonth = new Date(
      this.calendarMonth.getFullYear(),
      this.calendarMonth.getMonth() + direction,
      1
    );

    this.buildCalendar();
  }

  changeYear(year: number): void {
    if (this.loadingPatients || this.generatingPdf || !Number.isInteger(year)) {
      return;
    }

    this.calendarMonth = new Date(year, this.calendarMonth.getMonth(), 1);
    this.buildCalendar();
  }

  selectCalendarDay(day: CalendarDay): void {
    if (this.loadingPatients || this.generatingPdf) {
      return;
    }

    this.selectedDate = day.date;

    if (!day.currentMonth) {
      this.calendarMonth = new Date(
        Number(day.date.slice(0, 4)),
        Number(day.date.slice(5, 7)) - 1,
        1
      );

      this.buildCalendar();
    }
  }

  formatDisplayDate(value: string): string {
    if (!value) {
      return '';
    }

    return new Date(
      Number(value.slice(0, 4)),
      Number(value.slice(5, 7)) - 1,
      Number(value.slice(8, 10))
    ).toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    });
  }

  loadPatients(): void {
    if (
      !this.selectedDate ||
      this.loadingPatients ||
      this.generatingPdf
    ) {
      return;
    }

    const requestDate = this.selectedDate;

    this.loadingPatients = true;
    this.errorMessage = '';
    this.loadedDate = '';
    this.patients = [];

    this.http
      .get<FormsPatientResponse[]>('/api/forms/patients', {
        params: {
          date: requestDate
        }
      })
      .pipe(
        timeout(15000),
        finalize(() => {
          this.loadingPatients = false;
          this.cdr.markForCheck();
        })
      )
      .subscribe({
        next: patients => {
          this.loadedDate = requestDate;

          this.patients = patients.map(patient => {
            const recommendedForms = this.normalizeForms(
              patient.recommendedForms ?? []
            );

            return {
              ...patient,
              recommendedForms,
              selectedForms: [...recommendedForms],
              selected: false
            };
          });
        },
        error: () => {
          this.loadedDate = '';
          this.patients = [];
          this.errorMessage =
            'Unable to load the scheduled patients for the selected date.';
        }
      });
  }

  onAutomaticSelectionChange(): void {
    if (!this.chooseAutomatically) {
      return;
    }

    this.patients = this.patients.map(patient => ({
      ...patient,
      selectedForms: [...patient.recommendedForms]
    }));
  }

  onPatientSelectionChange(
    patient: PrintableFormsPatient,
    event: Event
  ): void {
    const checkbox = event.target as HTMLInputElement;
    patient.selected = checkbox.checked;
  }

  areAllPatientsSelected(): boolean {
    return this.patients.length > 0 && this.patients.every(patient => patient.selected);
  }

  onSelectAllPatientsChange(event: Event): void {
    const checkbox = event.target as HTMLInputElement;
    this.patients.forEach(patient => {
      patient.selected = checkbox.checked;
    });
  }

  isFormSelected(
    patient: PrintableFormsPatient,
    key: string
  ): boolean {
    return patient.selectedForms.includes(key);
  }

  onFormSelectionChange(
    patient: PrintableFormsPatient,
    key: string,
    event: Event
  ): void {
    if (this.chooseAutomatically || this.generatingPdf) {
      return;
    }

    const checkbox = event.target as HTMLInputElement;

    if (checkbox.checked) {
      patient.selectedForms = this.normalizeForms([
        ...patient.selectedForms,
        key
      ]);
    } else {
      patient.selectedForms = patient.selectedForms.filter(
        form => form !== key
      );
    }
  }

  hasSelectedPatients(): boolean {
    return this.patients.some(patient => patient.selected);
  }

  trackPatient(
    index: number,
    patient: PrintableFormsPatient
  ): number {
    return patient.visitId;
  }

  viewPrintableForms(): void {
    const selectedPatients = this.patients.filter(patient => patient.selected).map(patient => ({visitId: patient.visitId, forms: patient.selectedForms}));

    if(selectedPatients.length === 0) {
      this.errorMessage = 'select at least one patient.';
      return;
    }

    const missingForms = selectedPatients.some(visit => !visit.forms || visit.forms.length === 0);

    if(missingForms){
      this.errorMessage = 'Select at least one form for each selected patient.';
      return;
    }

    this.generatingPdf = true;
    this.errorMessage = '';

    this.cdr.detectChanges();

    const request = {visits: selectedPatients};

    this.http.post('/api/forms/preview', request, { responseType: 'blob'})
        .pipe(finalize(() => {this.generatingPdf = false}))
        .subscribe({next: blob => {
          this.generatingPdf = false;
          this.cdr.detectChanges();
          const pdfBlob = new Blob([blob], {type: 'application/pdf'});
          const pdfUrl = URL.createObjectURL(pdfBlob);
          window.open(pdfUrl, '_blank');
          setTimeout(() => {URL.revokeObjectURL(pdfUrl);}, 60000);
        },
        error: error => {
          console.error('Unable to generate printable forms:', error);
          this.generatingPdf = false;
          this.errorMessage = 'Unable to generate printable forms.';
          this.cdr.detectChanges();
        }, 
        complete: () => {
          this.generatingPdf = false;
          this.cdr.detectChanges();
        }
      });
  }

  private normalizeForms(forms: string[]): string[] {
    const supportedForms = new Set(
      this.formOptions.map(form => form.key)
    );

    return [
      ...new Set(
        forms
          .filter(form => typeof form === 'string')
          .map(form => form.trim())
          .filter(form => supportedForms.has(form))
      )
    ];
  }

  private getToday(): string {
    return this.toDateString(new Date());
  }

  private toDateString(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
  }
}
