import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { AuthService } from './auth.service';

const USER = { userid: 'doctor', access: 'admin', firstName: 'Jane', lastName: 'Doe' };

describe('AuthService backend session flow', () => {
    let service: AuthService;
    let http: HttpTestingController;
    beforeEach(() => {
        TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
        service = TestBed.inject(AuthService);
        http = TestBed.inject(HttpTestingController);
    });
    afterEach(() => http.verify());
    it('stores the authenticated user only after a successful login response', () => {
        service.login('doctor', 'secret').subscribe();
        expect(service.user()).toBeNull();
        const request = http.expectOne('/api/auth/login');
        expect(request.request.method).toBe('POST');
        expect(request.request.body).toEqual({ userid: 'doctor', password: 'secret' });
        request.flush(USER);
        expect(service.user()).toEqual(USER);
        expect(service.isAdmin()).toBe(true);
    });
    it('recognizes an expired session, clears user and returns false', () => {
        service.user.set(USER);
        let authenticated = true;
        service.check().subscribe(result => authenticated = result);
        http.expectOne('/api/auth/me').flush({}, { status: 401, statusText: 'Unauthorized' });
        expect(authenticated).toBe(false);
        expect(service.user()).toBeNull();
    });
    it('revalidates a session and updates the current user', () => {
        let authenticated = false;
        service.check().subscribe(result => authenticated = result);
        http.expectOne('/api/auth/me').flush(USER);
        expect(authenticated).toBe(true);
        expect(service.user()).toEqual(USER);
    });
    it('clears local state even if logout fails at the server', () => {
        service.user.set(USER);
        service.logout().subscribe();
        const request = http.expectOne('/api/auth/logout');
        expect(request.request.method).toBe('POST');
        request.flush(null, { status: 503, statusText: 'Service unavailable' });
        expect(service.user()).toBeNull();
    });
});