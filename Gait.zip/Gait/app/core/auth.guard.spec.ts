import { TestBed } from '@angular/core/testing';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot, provideRouter } from '@angular/router';
import { of, firstValueFrom, Observable } from 'rxjs';
import { vi } from 'vitest';
import { AuthService } from './auth.service';
import { adminGuard, authGuard } from './auth.guard';

describe('Route access guards', () => {
    const auth = { check: vi.fn(), isAdmin: vi.fn(), user: vi.fn() };
    let router: Router;
    beforeEach(() => {
        vi.clearAllMocks();
        auth.user.mockReturnValue(null);
        TestBed.configureTestingModule({
            providers: [provideRouter([]), { provide: AuthService, useValue: auth }],
        });
        router = TestBed.inject(Router);
    });
    async function check(guard: typeof authGuard | typeof adminGuard, url: string): Promise<string | boolean> {
        const state = { url } as RouterStateSnapshot;
        const route = {} as ActivatedRouteSnapshot;
        const result = TestBed.runInInjectionContext(() => guard(route, state));
        const resolved = await firstValueFrom(result as Observable<boolean | ReturnType<Router['createUrlTree']>>);
        return typeof resolved === 'boolean' ? resolved : router.serializeUrl(resolved);
    }
    it('allows an authenticated user', async () => {
        auth.check.mockReturnValue(of(true));
        expect(await check(authGuard, '/patients')).toBe(true);
    });
    it('redirects signed-out users to login, preserving their destination', async () => {
        auth.check.mockReturnValue(of(false));
        expect(await check(authGuard, '/patients?tab=history')).toBe('/login?returnUrl=%2Fpatients%3Ftab%3Dhistory');
    });
    it('allows administrators into /admin', async () => {
        auth.check.mockReturnValue(of(true));
        auth.isAdmin.mockReturnValue(true);
        expect(await check(adminGuard, '/admin')).toBe(true);
    });
    it('redirects non-admin authenticated users to patients', async () => {
        auth.check.mockReturnValue(of(true));
        auth.isAdmin.mockReturnValue(false);
        expect(await check(adminGuard, '/admin')).toBe('/patients');
    });
    it('redirects signed-out visitors to login for admin routes', async () => {
        auth.check.mockReturnValue(of(false));
        expect(await check(adminGuard, '/admin')).toBe('/login?returnUrl=%2Fadmin');
    });
    it('blocks all non-profile destinations until the temporary password is changed', async () => {
        auth.check.mockReturnValue(of(true));
        auth.user.mockReturnValue({ mustChangePassword: true });
        auth.isAdmin.mockReturnValue(true);
        for (const url of ['/patients', '/forms', '/schedule', '/questionnaire/session', '/profile-other']) {
            expect(await check(authGuard, url)).toBe('/profile');
        }
        expect(await check(adminGuard, '/admin')).toBe('/profile');
        expect(await check(authGuard, '/profile')).toBe(true);
        expect(await check(authGuard, '/profile?tab=password')).toBe(true);
    });
});