import { HttpErrorResponse, HttpInterceptorFn } from "@angular/common/http";
import { inject } from "@angular/core";
import { Router } from "@angular/router";
import { catchError, throwError } from "rxjs";
import { AuthService } from "./auth.service";

// Auth endpoints report 401 as a normal outcome (bad credentials, signed-out check) and handle it themselves.
const AUTH_ENDPOINT = /^\/api\/auth\//;

export const sessionExpiryInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  return next(req).pipe(
    catchError((error: unknown) => {
      if (error instanceof HttpErrorResponse && error.status === 403
          && error.error?.code === "PASSWORD_CHANGE_REQUIRED") {
        const user = auth.user();
        if (user && !user.mustChangePassword) {
          auth.user.set({ ...user, mustChangePassword: true });
          router.navigate(["/profile"]);
        }
      }
      // Only the first 401 of an active session redirects; clearing the user makes concurrent failures no-ops.
      if (error instanceof HttpErrorResponse && error.status === 401 && !AUTH_ENDPOINT.test(req.url) && auth.user()) {
        auth.user.set(null);
        const returnUrl = router.url;
        router.navigate(["/login"], {
          queryParams: { expired: 1, ...(returnUrl.startsWith("/login") ? {} : { returnUrl }) },
        });
      }
      return throwError(() => error);
    }),
  );
};
