import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting
} from '@angular/common/http/testing';

import { HealthService } from './health';

describe('HealthService', () => {
  let service: HealthService;
  let httpTesting: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(),
        provideHttpClientTesting()
      ]
    });

    service = TestBed.inject(HealthService);
    httpTesting = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpTesting.verify();
  });

  it('should retrieve the backend health message as text', () => {
    let result: string | undefined;

    service.getHealth().subscribe(message => {
      result = message;
    });

    const request = httpTesting.expectOne('/api/health');

    expect(request.request.method).toBe('GET');
    expect(request.request.responseType).toBe('text');

    request.flush('Gait Lab backend is running');

    expect(result).toBe('Gait Lab backend is running');
  });
});