import { HttpClient, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { vi } from 'vitest';
import { AuthService } from './auth.service';
import { sessionExpiryInterceptor } from './session-expiry.interceptor';

describe('sessionExpiryInterceptor', () => {
    let http: HttpClient;
    let httpTesting: HttpTestingController;
    let auth: AuthService;
    let navigate: ReturnType<typeof vi.spyOn>;
    const user = { userid: 'jdoe', access: 'user', firstName: 'Jane', lastName: 'Doe' };

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                provideRouter([]),
                provideHttpClient(withInterceptors([sessionExpiryInterceptor])),
                provideHttpClientTesting(),
            ],
        });
        http = TestBed.inject(HttpClient);
        httpTesting = TestBed.inject(HttpTestingController);
        auth = TestBed.inject(AuthService);
        const router = TestBed.inject(Router);
        vi.spyOn(router, 'url', 'get').mockReturnValue('/patients?tab=history');
        navigate = vi.spyOn(router, 'navigate').mockResolvedValue(true);
        auth.user.set(user);
    });

    afterEach(() => httpTesting.verify());

    function fail(url: string, status: number): unknown {
        let received: unknown;
        http.get(url).subscribe({ error: (e) => (received = e) });
        httpTesting.expectOne(url).flush({}, { status, statusText: 'Error' });
        return received;
    }

    it('clears the session and redirects to login with the current URL on 401', () => {
        const error = fail('/api/patients', 401) as { status: number };
        expect(error.status).toBe(401);
        expect(auth.user()).toBeNull();
        expect(navigate).toHaveBeenCalledExactlyOnceWith(['/login'], {
            queryParams: { expired: 1, returnUrl: '/patients?tab=history' },
        });
    });

    it('redirects only once when several requests fail together', () => {
        fail('/api/patients', 401);
        fail('/api/visits', 401);
        expect(navigate).toHaveBeenCalledTimes(1);
    });

    it('ignores non-401 errors', () => {
        fail('/api/patients', 500);
        fail('/api/patients', 403);
        expect(auth.user()).toEqual(user);
        expect(navigate).not.toHaveBeenCalled();
    });
    it('redirects an existing session when the server requires a password change', () => {
        for (const url of ['/api/patients', '/api/visits']) {
            http.get(url).subscribe({ error: () => {} });
            httpTesting.expectOne(url).flush(
                { code: 'PASSWORD_CHANGE_REQUIRED' }, { status: 403, statusText: 'Forbidden' },
            );
        }
        expect(auth.user()?.mustChangePassword).toBe(true);
        expect(navigate).toHaveBeenCalledExactlyOnceWith(['/profile']);
    });

    it('leaves 401s from auth endpoints to their callers', () => {
        let error: unknown;
        http.post('/api/auth/login', {}).subscribe({ error: (e) => (error = e) });
        httpTesting.expectOne('/api/auth/login').flush({}, { status: 401, statusText: 'Unauthorized' });
        fail('/api/auth/me', 401);
        expect(error).toBeTruthy();
        expect(auth.user()).toEqual(user);
        expect(navigate).not.toHaveBeenCalled();
    });

    it('does nothing when no user is signed in', () => {
        auth.user.set(null);
        fail('/api/patients', 401);
        expect(navigate).not.toHaveBeenCalled();
    });
});
