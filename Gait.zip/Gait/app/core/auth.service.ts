import { Injectable, computed, signal } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable, catchError, map, of, tap } from "rxjs";

// The session is an HttpOnly cookie, so the browser keeps it; this service only tracks who is signed in.
export interface CurrentUser {
  userid: string;
  access: string;
  firstName: string | null;
  lastName: string | null;
  mustChangePassword?: boolean;
}

@Injectable({ providedIn: "root" })
export class AuthService {
  readonly user = signal<CurrentUser | null>(null);
  readonly isAdmin = computed(() => (this.user()?.access ?? "").toLowerCase() === "admin");
  readonly initials = computed(() => {
    const user = this.user();
    const firstNameInitial = user?.firstName?.trim().charAt(0);
    const lastNameInitial = user?.lastName?.trim().charAt(0);

    if (firstNameInitial && lastNameInitial) {
      return `${firstNameInitial}${lastNameInitial}`.toUpperCase();
    }

    return (firstNameInitial || lastNameInitial || user?.userid?.trim().charAt(0) || "").toUpperCase();
  });

  constructor(private http: HttpClient) {}

  login(userid: string, password: string): Observable<CurrentUser> {
    return this.http
      .post<CurrentUser>("/api/auth/login", { userid, password })
      .pipe(tap((user) => this.user.set(user)));
  }

  logout(): Observable<unknown> {
    return this.http.post("/api/auth/logout", {}).pipe(
      tap(() => this.user.set(null)),
      catchError(() => {
        this.user.set(null);
        return of(null);
      }),);

  }
  check(): Observable<boolean> {
    return this.http.get<CurrentUser>("/api/auth/me").pipe(
      tap((user) => this.user.set(user)),
      map(() => true),
      catchError(() => {
        this.user.set(null);
        return of(false);
      }),
    );}
}