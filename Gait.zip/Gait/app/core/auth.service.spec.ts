import { provideHttpClient } from "@angular/common/http";
import { provideHttpClientTesting } from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";

import { AuthService } from "./auth.service";

describe("AuthService initials", () => {
  let auth: AuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    auth = TestBed.inject(AuthService);
  });

  it("uses the uppercase first and last initials", () => {
    auth.user.set({
      userid: "jane.doe",
      access: "user",
      firstName: "jane",
      lastName: "doe",
    });

    expect(auth.initials()).toBe("JD");
  });

  it("uses a single initial when either name is missing", () => {
    auth.user.set({
      userid: "jane.doe",
      access: "user",
      firstName: "jane",
      lastName: null,
    });

    expect(auth.initials()).toBe("J");
  });

  it("falls back to one userid initial when both names are missing", () => {
    auth.user.set({
      userid: "jane.doe",
      access: "user",
      firstName: null,
      lastName: null,
    });

    expect(auth.initials()).toBe("J");
  });
});
