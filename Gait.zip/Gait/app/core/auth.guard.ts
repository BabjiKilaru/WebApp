import { inject } from "@angular/core";
import { CanActivateFn, Router } from "@angular/router";
import { map } from "rxjs";
import { AuthService } from "./auth.service";

export const authGuard: CanActivateFn = (_route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  return auth.check().pipe(
    map((ok) => {
      if (!ok) return router.createUrlTree(["/login"], { queryParams: { returnUrl: state.url } });
      if (auth.user()?.mustChangePassword && !/^\/profile(?:[?#]|$)/.test(state.url)) {
        return router.createUrlTree(["/profile"]);
      }
      return true;
    }),
  );
};

export const adminGuard: CanActivateFn = (_route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  return auth.check().pipe(
    map((ok) => {
      if (!ok) return router.createUrlTree(["/login"], { queryParams: { returnUrl: state.url } });
      if (auth.user()?.mustChangePassword) return router.createUrlTree(["/profile"]);
      return auth.isAdmin() ? true : router.createUrlTree(["/patients"]);
    }),
  );
};