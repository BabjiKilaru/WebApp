import { routes } from './app.routes';
import { adminGuard, authGuard } from './core/auth.guard';

describe('Application routes', () => {
    it('protects every clinical feature route with authGuard', () => {
        for (const path of ['patients', 'questionnaire', 'questionnaire/session', 'forms', 'schedule', 'profile']) {
            const route = routes.find(item => item.path === path);
            expect(route?.canActivate, `route ${path}`).toContain(authGuard);
        }
    });
    it('protects admin with adminGuard rather than merely hiding its menu', () => {
        expect(routes.find(route => route.path === 'admin')?.canActivate).toContain(adminGuard);
    });
    it('has safe root and unknown-path fallbacks to login', () => {
        expect(routes.find(route => route.path === '')?.redirectTo).toBe('login');
        expect(routes.find(route => route.path === '**')?.redirectTo).toBe('login');
    });
});