import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { vi } from 'vitest';

import { AuthService } from '../core/auth.service';
import { Profile } from './profile';

describe('Profile page', () => {
    let component: Profile;
    let fixture: ComponentFixture<Profile>;
    let http: HttpTestingController;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [Profile],
            providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
        }).compileComponents();
        TestBed.inject(AuthService).user.set({
            userid: 'test', access: 'user', firstName: 'Test', lastName: 'User',
        });
        http = TestBed.inject(HttpTestingController);
        fixture = TestBed.createComponent(Profile);
        component = fixture.componentInstance;
        fixture.detectChanges();
        http.expectOne('/api/profile').flush({ userid: 'test' });
        component.openPasswordDialog();
        fixture.detectChanges();
        await fixture.whenStable();
    });

    afterEach(() => http.verify());

    function requirePasswordChange(): void {
        const auth = TestBed.inject(AuthService);
        auth.user.set({ ...auth.user()!, mustChangePassword: true });
        component.closePasswordDialog();
        component.ngOnInit();
        http.expectOne('/api/profile').flush({ userid: 'test' });
        fixture.detectChanges();
    }

    it('automatically opens a non-dismissible dialog for default-password users', () => {
        component.closePasswordDialog();
        requirePasswordChange();
        expect(component.passwordDialogOpen()).toBe(true);
        component.closePasswordDialog();
        expect(component.passwordDialogOpen()).toBe(true);
        expect(fixture.nativeElement.querySelector('.dialog .close-btn')).toBeNull();
        expect(fixture.nativeElement.querySelector('.dialog-actions .secondary-btn')).toBeNull();
        expect(fixture.nativeElement.querySelector('.dialog').textContent).toContain(
            'You must change your temporary password before continuing.',
        );
    });

    it('unlocks access and opens patients only after a successful required password change', () => {
        requirePasswordChange();
        const navigate = vi.spyOn(TestBed.inject(Router), 'navigateByUrl').mockResolvedValue(true);
        component.passwordForm = {
            currentPassword: 'Temporary1!', newPassword: 'Replacement1!', confirmPassword: 'Replacement1!',
        };
        component.changePassword();
        expect(component.mustChangePassword()).toBe(true);
        expect(navigate).not.toHaveBeenCalled();
        http.expectOne('/api/profile/password').flush(null);
        expect(component.mustChangePassword()).toBe(false);
        expect(component.passwordDialogOpen()).toBe(false);
        expect(navigate).toHaveBeenCalledWith('/patients');
    });

    it('keeps the required dialog and restriction when the password update fails', () => {
        requirePasswordChange();
        component.passwordForm = {
            currentPassword: 'Wrongpass1!', newPassword: 'Replacement1!', confirmPassword: 'Replacement1!',
        };
        component.changePassword();
        http.expectOne('/api/profile/password').flush(
            { message: 'Current password is incorrect.' }, { status: 400, statusText: 'Bad Request' },
        );
        component.closePasswordDialog();
        expect(component.passwordDialogOpen()).toBe(true);
        expect(component.mustChangePassword()).toBe(true);
        expect(component.passwordError()).toBe('Current password is incorrect.');
    });

    it('enables Save only when profile fields have changed', async () => {
        component.startEdit();
        fixture.detectChanges();

        const saveButton: HTMLButtonElement = fixture.nativeElement.querySelector(
            '.profile-header-actions .primary-btn',
        );
        expect(saveButton.disabled).toBe(true);

        const firstName: HTMLInputElement = fixture.nativeElement.querySelector('#profile-fname');
        firstName.value = 'Updated';
        firstName.dispatchEvent(new Event('input'));
        await fixture.whenStable();
        fixture.detectChanges();

        expect(saveButton.disabled).toBe(false);
    });

    it('shows five unmet requirements directly below confirmation initially', () => {
        const list: HTMLUListElement = fixture.nativeElement.querySelector('#passwordRequirements');
        expect(list.children.length).toBe(5);
        expect(list.querySelectorAll('.passed').length).toBe(0);
        expect(list.previousElementSibling?.querySelector('#confirmPassword')).not.toBeNull();
        expect(list.textContent).toContain('Not met:');
        expect(list.textContent).toContain('\u2717');
    });

    it('updates each check as the user types and rechecks confirmation on either field change', async () => {
        const newPassword: HTMLInputElement = fixture.nativeElement.querySelector('#newPassword');
        const confirmation: HTMLInputElement = fixture.nativeElement.querySelector('#confirmPassword');
        const type = async (input: HTMLInputElement, value: string) => {
            input.value = value;
            input.dispatchEvent(new Event('input'));
            await fixture.whenStable();
            fixture.detectChanges();
        };

        await type(newPassword, 'Abcdef1!');
        expect(fixture.nativeElement.querySelectorAll('.password-requirements .passed').length).toBe(4);
        await type(confirmation, 'Abcdef1!');
        expect(fixture.nativeElement.querySelectorAll('.password-requirements .passed').length).toBe(5);
        expect(fixture.nativeElement.querySelector('#passwordRequirements').textContent).toContain('\u2713');
        await type(newPassword, 'Abcdef2!');
        expect(component.passwordRequirements[4].passed).toBe(false);
        await type(confirmation, '');
        await type(newPassword, '');
        expect(component.passwordRequirements.every(requirement => !requirement.passed)).toBe(true);
    });

    it.each([
        ['Abcd1!', 0],
        ['Abcdefg!', 1],
        ['abcdef1!', 2],
        ['Abcdef12', 3],
        ['Abcdef1?', 3],
    ])('rejects %s with its failed requirement and does not submit', (password, index) => {
        component.passwordForm = { currentPassword: 'Oldpass1!', newPassword: password, confirmPassword: password };
        component.changePassword();
        expect(component.passwordRequirements[index].passed).toBe(false);
        expect(component.passwordError()).toBe(component.passwordRequirements[index].label);
        http.expectNone('/api/profile/password');
    });

    it('rejects missing fields and mismatched confirmation', () => {
        component.changePassword();
        expect(component.passwordError()).toBe('All password fields are required.');
        component.passwordForm = {
            currentPassword: 'Oldpass1!', newPassword: 'Abcdef1!', confirmPassword: 'Abcdef2!',
        };
        component.changePassword();
        expect(component.passwordError()).toBe(component.passwordRequirements[4].label);
        http.expectNone('/api/profile/password');
    });

    it.each('!@#$%^&*'.split(''))('accepts %s as a special character and submits once', special => {
        component.passwordForm = {
            currentPassword: 'Oldpass1!', newPassword: `Abcdef1${special}`, confirmPassword: `Abcdef1${special}`,
        };
        component.changePassword();
        component.changePassword();
        const request = http.expectOne('/api/profile/password');
        expect(request.request.method).toBe('PUT');
        expect(request.request.body).toEqual(component.passwordForm);
        request.flush(null);
        expect(component.passwordDialogOpen()).toBe(false);
        expect(component.successMessage()).toBe('Your password was changed successfully.');
    });

    it('preserves the maximum length and different-password restrictions', () => {
        const tooLong = 'Abcdef1!' + 'a'.repeat(121);
        component.passwordForm = {
            currentPassword: 'Oldpass1!', newPassword: tooLong, confirmPassword: tooLong,
        };
        component.changePassword();
        expect(component.passwordError()).toBe('New password must be 128 characters or fewer.');
        component.passwordForm = {
            currentPassword: 'Abcdef1!', newPassword: 'Abcdef1!', confirmPassword: 'Abcdef1!',
        };
        component.changePassword();
        expect(component.passwordError()).toBe('New password must be different from the current password.');
        http.expectNone('/api/profile/password');
    });

    it('resets the checklist when the dialog is reopened', () => {
        component.passwordForm.newPassword = 'Abcdef1!';
        component.passwordForm.confirmPassword = 'Abcdef1!';
        component.closePasswordDialog();
        component.openPasswordDialog();
        expect(component.passwordRequirements.every(requirement => !requirement.passed)).toBe(true);
    });
});
