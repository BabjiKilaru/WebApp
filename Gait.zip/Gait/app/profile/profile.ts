import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { finalize } from 'rxjs';

import { AuthService } from '../core/auth.service';
import { Header } from '../header/header';

export interface UserProfile {
    userid: string;
    fname: string | null;
    lname: string | null;
    facility: string | null;
    city: string | null;
    state: string | null;
    phone1: string | null;
    phone2: string | null;
    fax: string | null;
    email: string | null;
    address1: string | null;
    zip: string | null;
}

type EditableField = Exclude<keyof UserProfile, 'userid'>;
type ProfileForm = Record<EditableField, string>;

interface FieldConfig {
    key: EditableField;
    label: string;
    type: 'text' | 'tel' | 'email';
    autocomplete: string;
    maxLength: number;
    span: 3 | 4 | 6 | 9 | 12;
    required?: boolean;
}

interface PasswordForm {
    currentPassword: string;
    newPassword: string;
    confirmPassword: string;
}

const EDITABLE_FIELDS: EditableField[] = [
    'fname', 'lname', 'facility', 'city', 'state', 'phone1', 'phone2', 'fax', 'email', 'address1', 'zip',
];

@Component({
    selector: 'app-profile',
    standalone: true,
    imports: [FormsModule, Header],
    templateUrl: './profile.html',
    styleUrl: './profile.css',
})
export class Profile implements OnInit {
    private readonly http = inject(HttpClient);
    private readonly auth = inject(AuthService);
    private readonly router = inject(Router);
    readonly mustChangePassword = computed(() => this.auth.user()?.mustChangePassword === true);

    readonly fields: FieldConfig[] = [
        { key: 'fname', label: 'First Name', type: 'text', autocomplete: 'given-name', maxLength: 50, span: 4, required: true },
        { key: 'lname', label: 'Last Name', type: 'text', autocomplete: 'family-name', maxLength: 50, span: 4, required: true },
        { key: 'facility', label: 'Facility', type: 'text', autocomplete: 'organization', maxLength: 100, span: 12 },
        { key: 'email', label: 'Email', type: 'email', autocomplete: 'email', maxLength: 254, span: 6 },
        { key: 'phone1', label: 'Phone Number', type: 'tel', autocomplete: 'tel', maxLength: 25, span: 6 },
        { key: 'phone2', label: 'Phone Number 2', type: 'tel', autocomplete: 'off', maxLength: 25, span: 6 },
        { key: 'fax', label: 'Fax', type: 'tel', autocomplete: 'off', maxLength: 25, span: 6 },
        { key: 'address1', label: 'Address', type: 'text', autocomplete: 'street-address', maxLength: 200, span: 9 },
        { key: 'zip', label: 'Zip Code', type: 'text', autocomplete: 'postal-code', maxLength: 10, span: 3 },
        { key: 'city', label: 'City', type: 'text', autocomplete: 'address-level2', maxLength: 50, span: 6 },
        { key: 'state', label: 'State', type: 'text', autocomplete: 'address-level1', maxLength: 50, span: 6 },
    ];

    readonly userid = signal('');
    readonly loading = signal(false);
    readonly loadError = signal('');
    readonly editing = signal(false);
    readonly saving = signal(false);
    readonly successMessage = signal('');
    readonly errorMessage = signal('');

    readonly passwordDialogOpen = signal(false);
    readonly changingPassword = signal(false);
    readonly passwordError = signal('');

    form: ProfileForm = Profile.emptyForm();
    passwordForm: PasswordForm = Profile.emptyPasswordForm();
    private original: ProfileForm = Profile.emptyForm();

    get hasChanges(): boolean {
        return EDITABLE_FIELDS.some(key => this.form[key] !== this.original[key]);
    }

    ngOnInit(): void {
        if (this.mustChangePassword()) {
            this.openPasswordDialog();
        }
        this.loadProfile();
    }

    loadProfile(): void {
        this.loading.set(true);
        this.loadError.set('');

        this.http
            .get<UserProfile>('/api/profile')
            .pipe(finalize(() => this.loading.set(false)))
            .subscribe({
                next: profile => this.applyProfile(profile),
                error: (error: HttpErrorResponse) => {
                    this.loadError.set(Profile.messageFrom(error, 'Unable to load your profile.'));
                },
            });
    }

    startEdit(): void {
        this.clearMessages();
        this.editing.set(true);
    }

    cancelEdit(): void {
        this.form = { ...this.original };
        this.editing.set(false);
        this.clearMessages();
    }

    save(): void {
        if (!this.editing() || this.saving()) {
            return;
        }
        this.clearMessages();

        const validationError = this.validate();
        if (validationError) {
            this.errorMessage.set(validationError);
            return;
        }

        this.saving.set(true);
        this.http
            .put<UserProfile>('/api/profile', this.toRequest())
            .pipe(finalize(() => this.saving.set(false)))
            .subscribe({
                next: profile => {
                    this.applyProfile(profile);
                    this.editing.set(false);
                    this.successMessage.set('Your profile was updated successfully.');
                    const user = this.auth.user();
                    if (user) {
                        this.auth.user.set({ ...user, firstName: profile.fname, lastName: profile.lname });
                    }
                },
                error: (error: HttpErrorResponse) => {
                    this.errorMessage.set(Profile.messageFrom(error, 'Unable to save your profile. Please try again.'));
                },
            });
    }

    openPasswordDialog(): void {
        this.clearMessages();
        this.passwordForm = Profile.emptyPasswordForm();
        this.passwordError.set('');
        this.passwordDialogOpen.set(true);
    }

    closePasswordDialog(): void {
        if (this.changingPassword() || this.mustChangePassword()) {
            return;
        }
        this.passwordForm = Profile.emptyPasswordForm();
        this.passwordError.set('');
        this.passwordDialogOpen.set(false);
    }

    get passwordRequirements() {
        const { newPassword, confirmPassword } = this.passwordForm;
        return [
            { label: 'New password must be at least 8 characters.', passed: newPassword.length >= 8 },
            { label: 'New password must contain at least 1 number.', passed: /[0-9]/.test(newPassword) },
            { label: 'New password must contain at least 1 uppercase letter.', passed: /[A-Z]/.test(newPassword) },
            { label: 'New password must contain at least 1 special character: !@#$%^&*.', passed: /[!@#$%^&*]/.test(newPassword) },
            { label: 'New password and confirmation must match.', passed: newPassword.length > 0 && newPassword === confirmPassword },
        ];
    }

    changePassword(): void {
        if (this.changingPassword()) {
            return;
        }
        const { currentPassword, newPassword, confirmPassword } = this.passwordForm;
        this.passwordError.set('');

        if (!currentPassword || !newPassword || !confirmPassword) {
            this.passwordError.set('All password fields are required.');
            return;
        }
        const failedRequirement = this.passwordRequirements.find(requirement => !requirement.passed);
        if (failedRequirement) {
            this.passwordError.set(failedRequirement.label);
            return;
        }
        if (newPassword.length > 128) {
            this.passwordError.set('New password must be 128 characters or fewer.');
            return;
        }
        if (newPassword === currentPassword) {
            this.passwordError.set('New password must be different from the current password.');
            return;
        }
        this.changingPassword.set(true);
        this.http
            .put<void>('/api/profile/password', this.passwordForm)
            .pipe(finalize(() => this.changingPassword.set(false)))
            .subscribe({
                next: () => {
                    const required = this.mustChangePassword();
                    const user = this.auth.user();
                    if (user) {
                        this.auth.user.set({ ...user, mustChangePassword: false });
                    }
                    this.passwordForm = Profile.emptyPasswordForm();
                    this.passwordDialogOpen.set(false);
                    this.successMessage.set('Your password was changed successfully.');
                    if (required) {
                        this.router.navigateByUrl('/patients');
                    }
                },
                error: (error: HttpErrorResponse) => {
                    this.passwordError.set(Profile.messageFrom(error, 'Unable to change your password. Please try again.'));
                },
            });
    }

    private applyProfile(profile: UserProfile): void {
        this.userid.set(profile.userid ?? '');
        const next = Profile.emptyForm();
        for (const key of EDITABLE_FIELDS) {
            next[key] = profile[key] ?? '';
        }
        this.original = next;
        this.form = { ...next };
    }

    private validate(): string {
        for (const field of this.fields) {
            const value = this.form[field.key].trim();
            if (field.required && !value) {
                return `${field.label} is required.`;
            }
            if (value.length > field.maxLength) {
                return `${field.label} must be ${field.maxLength} characters or fewer.`;
            }
        }
        const email = this.form.email.trim();
        if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            return 'Email address is not valid.';
        }
        return '';
    }

    private toRequest(): Record<EditableField, string | null> {
        const request = {} as Record<EditableField, string | null>;
        for (const key of EDITABLE_FIELDS) {
            const value = this.form[key].trim();
            request[key] = value ? value : null;
        }
        return request;
    }

    private clearMessages(): void {
        this.successMessage.set('');
        this.errorMessage.set('');
    }

    private static messageFrom(error: HttpErrorResponse, fallback: string): string {
        if (error.status === 401) {
            return 'Your session has expired. Please log in again.';
        }
        const message = error.error?.message;
        return typeof message === 'string' && message.trim() ? message : fallback;
    }

    private static emptyForm(): ProfileForm {
        return {
            fname: '', lname: '', facility: '', city: '', state: '', phone1: '',
            phone2: '', fax: '', email: '', address1: '', zip: '',
        };
    }

    private static emptyPasswordForm(): PasswordForm {
        return { currentPassword: '', newPassword: '', confirmPassword: '' };
    }
}
