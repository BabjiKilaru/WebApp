import { Component, HostListener, OnInit } from "@angular/core";
import { Router, RouterLink, RouterLinkActive } from "@angular/router";
import { AuthService } from "../core/auth.service";

@Component ({
    selector: 'app-header',
    standalone: true,
    imports: [RouterLink, RouterLinkActive],
    templateUrl: './header.html',
    styleUrl: './header.css'
})

export class Header implements OnInit {
    menuOpen = false;
    userMenuOpen = false;
    constructor(public auth: AuthService, private router: Router) {}

    ngOnInit(): void {
        if (!this.auth.user()) {
            this.auth.check().subscribe();
        }
    }

    @HostListener("document:click")
    onDocumentClick(): void {
        this.userMenuOpen = false;
    }

    toggleUserMenu(event: Event): void {
        event.stopPropagation();
        this.userMenuOpen = !this.userMenuOpen;
    }

    logout(): void {
        this.menuOpen = false;
        this.userMenuOpen = false;
        this.auth.logout().subscribe(() => this.router.navigate(["/login"]));
    }

    toggleMenu(): void {
        this.menuOpen = !this.menuOpen;
    }

    closeMenu(): void {
        this.menuOpen = false;
    }
}