import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { vi } from 'vitest';
import { AuthService } from '../core/auth.service';
import { Header } from './header';

describe('Header', () => {
    const auth = { user: vi.fn(), check: vi.fn(), logout: vi.fn() };
    let component: Header;
    let router: Router;
    beforeEach(async () => {
        vi.clearAllMocks();
        auth.user.mockReturnValue({ userid: 'clinician' });
        auth.check.mockReturnValue(of(true));
        auth.logout.mockReturnValue(of(null));
        await TestBed.configureTestingModule({
            imports: [Header],
            providers: [provideRouter([]), { provide: AuthService, useValue: auth }],
        }).overrideComponent(Header, { set: { template: '' } }).compileComponents();
        component = TestBed.createComponent(Header).componentInstance;
        router = TestBed.inject(Router);
    });
    it('refreshes user session only when not already loaded', () => {
        component.ngOnInit();
        expect(auth.check).not.toHaveBeenCalled();
        auth.user.mockReturnValue(null);
        component.ngOnInit();
        expect(auth.check).toHaveBeenCalledOnce();
    });
    it('toggles the navigation and user menu, and closes on outside clicks', () => {
        component.toggleMenu();
        expect(component.menuOpen).toBe(true);
        component.closeMenu();
        expect(component.menuOpen).toBe(false);
        const event = { stopPropagation: vi.fn() } as unknown as Event;
        component.toggleUserMenu(event);
        expect(event.stopPropagation).toHaveBeenCalledOnce();
        expect(component.userMenuOpen).toBe(true);
        component.onDocumentClick();
        expect(component.userMenuOpen).toBe(false);
    });
    it('logs out and returns to login', () => {
        const navigate = vi.spyOn(router, 'navigate').mockResolvedValue(true);
        component.menuOpen = true;
        component.userMenuOpen = true;
        component.logout();
        expect(auth.logout).toHaveBeenCalledOnce();
        expect(navigate).toHaveBeenCalledWith(['/login']);
        expect(component.menuOpen).toBe(false);
        expect(component.userMenuOpen).toBe(false);
    });
});