import { Routes } from "@angular/router";

 

import { Login } from "./login/login";

import { PatientSearch } from "./patients/patient-search/patient-search";

import { Questionnaire } from "./questionnaire/questionnaire";

import { QuestionnaireSession } from "./questionnaire/questionnaire-session/questionnaire-session";

import { Admin } from "./admin/admin";

import { Forms } from "./forms/forms";

import { Schedule } from "./schedule/schedule";

import { Profile } from "./profile/profile";

import { authGuard, adminGuard } from "./core/auth.guard";

 

export const routes: Routes = [

  {

    path: "login",

    component: Login,

  },

 

  {

    path: "patients",

    component: PatientSearch,

    canActivate: [authGuard],

  },

 

  {

    path: "questionnaire",

    component: Questionnaire,

    canActivate: [authGuard],

  },

 

  {

    path: "questionnaire/session",

    component: QuestionnaireSession,

    canActivate: [authGuard],

  },

 

  {

    path: "forms",

    component: Forms,

    canActivate: [authGuard],

  },

  {

    path: "schedule",

    component: Schedule,

    canActivate: [authGuard],

  },

  {

    path: "profile",

    component: Profile,

    canActivate: [authGuard],

  },

 

  {

    path: "admin",

    component: Admin,

    canActivate: [adminGuard],

  },

 

  {

    path: "",

    redirectTo: "login",

    pathMatch: "full",

  },

 

  {

    path: "**",

    redirectTo: "login",

  },

];