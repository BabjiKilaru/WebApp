import { CommonModule } from "@angular/common";
import { Component, Input } from "@angular/core";

@Component({
  selector: "app-questionnaire-patient-info",
  standalone: true,
  imports: [CommonModule],
  templateUrl: "./questionnaire-patient-info.html",
  styleUrl: "./questionnaire-patient-info.css",
})
export class QuestionnairePatientInfo {
  @Input()
  name = "";

  @Input()
  dob = "";

  @Input()
  sex = "";

  @Input()
  mrn = "";

  get displaySex(): string {
    const value = (this.sex ?? "").trim().toUpperCase();

    if (value === "M" || value === "MALE") {
      return "Male";
    }

    if (value === "F" || value === "FEMALE") {
      return "Female";
    }

    return this.sex || "-";
  }
}
