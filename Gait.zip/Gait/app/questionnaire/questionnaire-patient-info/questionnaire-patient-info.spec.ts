import { QuestionnairePatientInfo } from './questionnaire-patient-info';

describe('QuestionnairePatientInfo', () => {
  it.each([['M','Male'], ['Male','Male'], ['F','Female'], ['female','Female'], ['', '-'], ['Other', 'Other']])(
    'displays gender %s as %s', (value, expected) => {
      const component = new QuestionnairePatientInfo();
      component.sex = value;
      expect(component.displaySex).toBe(expected);
    },
  );
});
