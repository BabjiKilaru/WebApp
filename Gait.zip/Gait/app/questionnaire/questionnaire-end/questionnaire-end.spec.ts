import { vi } from 'vitest';
import { QuestionnaireEnd } from './questionnaire-end';

describe('QuestionnaireEnd', () => {
  it('emits a close-window event', () => {
    const component = new QuestionnaireEnd();
    const close = vi.fn();
    component.closeWindow.subscribe(close);
    component.close();
    expect(close).toHaveBeenCalledOnce();
  });
});
