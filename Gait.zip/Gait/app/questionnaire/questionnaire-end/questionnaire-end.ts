import { Component, EventEmitter, Output } from "@angular/core";

@Component({
  selector: "app-questionnaire-end",
  standalone: true,
  templateUrl: "./questionnaire-end.html",
  styleUrl: "./questionnaire-end.css",
})
export class QuestionnaireEnd {
  @Output()
  closeWindow = new EventEmitter<void>();

  close(): void {
    this.closeWindow.emit();
  }
}
