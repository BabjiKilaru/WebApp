// Spanish text of the legacy questionnaire pages (clinconn/lab/quest/*.jsp), transcribed verbatim from
// the `if ("sp".equals(session.getAttribute("language")))` branches — including the legacy typos and
// unfinished strings ("continur", "Codiciones", the trailing "TODO"), because the goal is exact parity.
// See docs/legacy-questions/spanish-text.txt for the file/line of every entry.
//
// Keys are the English strings as rendered. A key may end in `#context` when the same English text has
// a different Spanish rendering on another page; the suffix is dropped for English.
// `[name]` stands for the patient's first name (currFName).
//
// Legacy has NO Spanish for: Hip (WOMAC/UCLA/Harris), Sports and UE History (their Struts pages always
// run with language.id = 1), nq-thanks ("End of Part One"), show-questionnaires (the overview list), and
// most PODCI variants (only the CH pages switch language, handled in podci-bank.ts).

export type QuestionnaireLanguage = "en" | "sp";

const SP: Record<string, string> = {
  // --- alerts ---------------------------------------------------------------------------------
  "Please fill in all answers before moving to the next question.":
    "Por favor, contesta todas las respuestas antes de continur a la próxima pregunta.",

  // --- begin-self / q-start / q-thanks / nq-start ---------------------------------------------
  "This section should be filled out by the patient.":
    "Esta sección debe ser llenada por el paciente.",
  "Welcome to the duPont Hospital for Children Gait Lab":
    "Bienvenido al laboratorio de andar (Gait Lab) de duPont Hospital para los hijos.",
  "In order to best understand our patients, we need your help with some history about [name].":
    "Para entender mejor a nuestros pacientes , necesitamos su ayuda con un poco de historia sobre [name].",
  "In order to best understand our patients, we need your help with some history about [name].#nq":
    "Para entender mejor a nuestros pacientes, necesitamos su ayuda con un poco de historia sobre [name].",
  "If you have any questions while completing the questionnaire, please don't hesitate to ask a member of our staff for help.":
    "Si usted tiene preguntas al completar el cuestionario, por favor no dude en preguntar a un miembro de nuestro personal en busca de ayuda.",
  "These questions will be asked on each visit so we can stay up-to-date with you.":
    "Estas preguntas se harán en cada visita para que podamos estar al día con usted.",
  "Since this is your first time, there are two sections of history questions. This is the only time you will have to answer the questions in the first section.":
    "Dado que esta es la primera vez, hay dos secciones de preguntas de la historia. Esta es la única vez que tendrá que responder a las preguntas de la primera sección.",
  "Thank You": "Gracias",
  "Thank You for Filling Out the Questionnaire. This information helps us get the big picture and provide the best possible care.":
    "Gracias por tomar el cuestionario.",
  "Please tell a member of our staff that you have finished.":
    "Por favor contar a un miembro del personal.",

  // --- nq-who / q-who -------------------------------------------------------------------------
  "Please tell us about you": "Por favor, díganos sobre usted",
  "Your Name:": "Tu nombre:",
  "What is your relationship to [name]?": "¿Cuál es su relación con [name]?",
  "Choose from the list": "Escoge de la lista",

  // --- nq-birth / nq-walking / nq-learning ----------------------------------------------------
  "[name]'s Birth": "[name]'s Nacimiento",
  "How premature was [name]?": "¿Cómo prematura fue [name]?",
  "How much extended hospitalization did [name] require after birth?":
    "¿Cuánto hospitalización prolongada se requiería [name] después del nacimiento?",
  "[name]'s Walking History": "la historia de andar de [name]",
  "What age did [name] first walk?": "¿Cuándo empezó a andar [name]?",
  "What age did [name] start talking?": "¿En qué edad [name] empezó de hablar?",
  Learning: "Aprendizaje",
  "How do you think [name] is able to learn compared to other children of the same age?":
    "¿Cómo cree que [name] puede aprender en comparación con otros niños de la misma edad?",

  // --- q-history / q-add_history --------------------------------------------------------------
  "Health History": "la historia de la salud",
  "Here is what we show for [name]'s Health History:":
    "Aquí es lo que mostramos para la historia de salud sobre [name]:",
  Problem: "Problema",
  Age: "edad",
  "Has [name] had any of the following problems?":
    "¿Tiene [name] unos de los siguientes problemas?",
  "Has [name] had any of the following problems that are not included in the chart above?":
    "¿Tiene [name] unos de los siguientes problemas que no están incluídos en la lista arriba?",
  "Add to the Health History": "añadir a la historia de la salud",
  'Please select the problem and age that [name] was when it happened. If you are not sure, select "Not Sure" in the Age list.':
    "Por favor, indicar el problema y la edad que [name] tuvo cuado occurió. Si no estás seguro, indicar 'No estoy seguro.' en la lista de edad.",
  "Select One Problem": "Seleccionar un problema",
  "Add This To Record": "añadir este a la ficha",

  // --- q-conditions ---------------------------------------------------------------------------
  "Health Conditions": "Codiciones de salud",
  Delete: "Borrar",
  'Here is the information in [name]\'s record to date. If the list is ok, move on to the next question. If you need to delete one of them from the list, click "Delete" in that row.':
    'Aquí es lo que mostramos para la historia de salud sobre [name] ahora. Si esta lista está bíen, continua hasta la próxima pregunta. Si necesita Ud. borrar un elemento de la lista, empuja el "Borrar" en esa fila.',
  Condition: "Condiciones",
  "Does [name] have any conditions that are listed below?":
    "¿Tiene [name] unas condiciones de la lista abajo?",
  "Does [name] have any other conditions that are listed below?":
    "¿Tiene [name] otras condiciones de la lista abajo?",
  "If so, please select them then move to the next question.":
    "Si el niño tiene las condiciones, eligui TODO",
  "Confirm Condition Deletion": "confirmar la eliminación de la condición",
  "Are you sure you want to remove the following entry from your list?":
    "¿Ud. está seguro de que quiere remover los siguientes de la lista?",
  "Yes - Delete this from my List": "Sí, remover esto de la lista",
  "Do Not Delete this Item": "No borrar este artículo",

  // --- shared list-page instructions (devices / gait concerns / seizures / pain) --------------
  'Here is the information you\'ve given so far today. If the list is ok, move on to the next question. If you need to delete one of them from the list, click "Delete" in that row.':
    'Aquí está la información que ha dado hasta el momento actual. Si la lista está bien, pasar a la siguiente pregunta. Si necesita eliminar uno de ellos en la lista, haga clic en "Borrar" en la fila.',
  'Here is the information you\'ve given so far today. If the list is ok, move on to the next question. If you need to delete one of them from the list, click "x" in that row.':
    'Aquí está la información que ha dado hasta el momento. Si la lista está bien, pase a la siguiente pregunta. Si necesita eliminar un elemento, haga clic en la "x" de esa fila.',
  'Here is the information you\'ve given so far today. If the list is ok, move on to the next question. If you need to delete one of them from the list, click "Delete" in that row.#concerns':
    'Aquí está la información que ha dado hasta el momento actual . Si la lista está bien, pasar a la siguiente pregunta. Si necesita eliminar uno de ellos en la lista , haga clic en "Borrar" en la fila.',
  'Here is the information you\'ve given so far today. If the list is ok, move on to the next question. If you need to change or delete one of them, click "Update" in that row.':
    'Aquí está la información que ha dado hasta el momento actual. Si la lista está bien, pasar a la siguiente pregunta. Si necesita eliminar uno de ellos en la lista, haga clic en "Actualizar" en la fila.',

  // --- botox ----------------------------------------------------------------------------------
  "Botox Shot Information": "Información sobre las inyecciones de Botox",
  "A botox shot is a shot placed into tight muscles to loosen them.":
    "Una inyección de Botox está puesto en los músculos apretados para evitar que se peguen.",
  "Below is the information we have on file regarding past Botox injections.":
    "Abajo es la infomación que tenemos sobre las TODO",
  "No Shots on Record": "No historía de inyecciones",
  Where: "¿Dónde?",
  Date: "Fecha",
  Side: "Lado",
  "Hospital/Clinic": "Hospital/clínica",
  "Hospital/Clinic#form": "Hospital/Clinica",
  Physician: "Médico",
  "Please select an option:": "Por favor, elige una opción:",
  "Add a New Shot": "añadir una nueva inyección",
  "Botox Shot Information - Add a New Shot":
    "Información sobre las inyecciones de Botox- Añadir una nueva inyección",
  "Body Location": "el lugar en el cuerpo",
  Left: "izquierda",
  Right: "derecha",
  Both: "ambos",
  "Cancel Add Shot": "borar esta nueva inyección",

  // --- devices --------------------------------------------------------------------------------
  "Devices and Braces": "Dispositivos de asistencia",
  Device: "Dispositivo",
  "Does [name] currently use any devices? If so, please select them then move to the next question.":
    "[name] está utilizando ahora algunos dispositivos? Si es así, por favor seleccione y luego pasar a la siguiente pregunta",
  "Does [name] currently use any other devices? If so, please select them then move to the next question.":
    "[name] está utilizando ahora algunos otros dispositivos? Si es así, por favor seleccione y luego pasar a la siguiente pregunta",
  "Both#side": "Ambos",
  "R only": "Derecho",
  "L only": "Izquierda",
  "Click here to enter a device that is not in the list":
    "Haga clic aquí para indicar un dispositivo qué no está en la lista",
  "Device Entry": "Dispositivo",
  "Enter name of Device:": "Nombre del dispositivo:",
  "Add this Device": "añadir este dispositivo",
  "Click here to return to the previous page without adding a new device":
    "Haga clic aquí que volver a pagina previa sin añadir un dispositivo nuevo",
  "Confirm Device Deletion": "confirmar la eliminación del dispositivo",
  "Yes - Delete this from my List#dot": "Sí, remover esto de la lista.",

  // --- seizure medications --------------------------------------------------------------------
  "Seizure Medications": "Los tratamientos para las convulsiones",
  "Seizure Medications#entry": "Medicamento para las convulsiones",
  "Medication Name": "Medicamentos",
  "Does [name] currently use any seizure medications? If so, please select them then move to the next question.":
    "[name] está utilizando ahora algunos medicamentos para las convulsiones? Si es así, por favor seleccione y luego pasar a la siguiente pregunta",
  "Does [name] currently use any other seizure medications? If so, please select them then move to the next question.":
    "[name] está utilizando ahora algunos otros medicamentos para las convulsiones? Si es así, por favor seleccione y luego pasar a la siguiente pregunta",
  "Click here to enter a medication that is not in the list":
    "Haga clic aquí para indicar un medicamento qué no está en la lista",
  "Enter name of Medication:": "Medicamento:",
  "Add this Medication": "añadir este medicamento",
  "Click here to return to the previous page without adding a new medication":
    "Haga clic aquí que volver a pagina previa sin añadir un medicamento nuevo",
  "Confirm Medication Deletion": "confirmar la eliminación del medicamento",

  // --- pain -----------------------------------------------------------------------------------
  "Pain Information": "Dolor",
  "Location of Pain": "Lugar de Dolor",
  "Does [name] have pain in any places listed? If so, please select where the pain is located then move to the next question.":
    "Tiene [name] dolor en algunas lugares? Si es así, por favor seleccione y luego pasar a la siguiente pregunta",
  "Does [name] have pain in any other places listed? If so, please select where the pain is located then move to the next question.":
    "Tiene [name] dolor en algunas otras lugares? Si es así, por favor seleccione y luego pasar a la siguiente pregunta",
  Upper: "Superior",
  Lower: "Baja",
  "Left#pain": "Izquierdo",
  "Right#pain": "Derecho",
  "Both#pain": "Ambos",
  None: "Ninguna",
  Update: "Actualizar",

  // --- physical therapy -----------------------------------------------------------------------
  "Physical Therapy Services": "Terapia física",
  "If [name] receives any therapy, please select the frequency of PT and/or OT below:":
    "Si [name] somete alguna terapia, por favor indicar la frecuencia abajo:",
  "PHYSICAL THERAPY": "TERAPIA FÍSICA",
  "OCCUPATIONAL THERAPY": "TERAPIA OCUPACIONAL",
  Hospital: "Hospital",
  Clinic: "Clínica",
  School: "Escuela",
  Home: "Hogar",

  // --- followup -------------------------------------------------------------------------------
  "Followup Date": "Fecha de seguimiento",
  "If you know the date of the followup appointment with your doctor, please enter it below:":
    "Si sabe la fecha de la cita de seguimiento con su médico , por favor indica abajo:",
  "(for example, 2/5/2004 or Sept 2003)":
    "por ejemplo 5 febrero 2004 o septiembre de 2003",

  // --- gait pages -----------------------------------------------------------------------------
  "Walking Support": "Apoyo a caminar",
  "Which currently describes [name]'s need for support while walking?":
    "¿Cuál situación describe la necesidad de [name] para el apoyo a caminar ahora?",
  "How does [name] move around for short distances in the house?":
    "¿Cómo [name] se mueve para distancias cortas en la casa?",
  "How does [name] move around in and between classes at school?":
    "¿Cómo [name] se mueve entre las clases en la escuela?",
  "How does [name] move around for long distances such as the shopping center?":
    "¿Cómo [name] se mueve para distancias largas en lugares como un centro comercial?",
  "6. Independent on all surfaces": "6. Independiente en todas las superficies",
  "5. Independent on level surfaces (Requires a rail for stairs)":
    "5. Independiente en superficies niveladas (requiere barandal para las escaleras)",
  "4. Uses cane(s) or stick(s) (one or two)":
    "4. Usa uno o dos bastones",
  "3. Uses crutches": "3. Usa muletas",
  "2. Uses a walker or frame": "2. Usa un andador o marco",
  "1. Uses wheelchair": "1. Usa silla de ruedas",
  "C. Crawling": "C. Gatea",
  "N. does not apply": "N. No aplica",
  "Changes in Walking": "Los cambios en andar",
  "In the last 6-12 months (or since last visit), how has [name]'s ability to walk changed?":
    "¿Dentro las últimas 6-12 meses (o la última visita) cómo la capacidad de andar de [name] ha cambiado?",
  "No Change": "no cambio",
  "Walks Much Better": "Anda mucho más mejor",
  "Walks a Little Better": "Anda mejor",
  "Walks a Little Worse": "Anda peor",
  "Walks Much Worse": "Anda mucho más peor",
  "Current Gait Concerns": "Preocupaciones sobre Gait que tiene ahora",
  "Gait Concern": "Preocupaciones sobre Gait que tiene ahora",
  "Do you currently have any concerns listed below? If so, please select them then move to the next question.":
    "¿Tiene preocupaciónes que están en la lista abajo? Si es así , por favor seleccione y luego pasar a la siguiente pregunta.",
  "Do you currently have any other concerns listed below? If so, please select them then move to the next question.":
    "¿Tiene otras preocupaciónes que están en la lista abajo? Si es así , por favor seleccione y luego pasar a la siguiente pregunta.",
  'Here is the information you\'ve given so far today. If the list is ok, move on to the next question. If you need to delete one of them from the list, click "x" next to concern.':
    'Aquí está la información que ha dado hasta el momento. Si la lista está bien, pase a la siguiente pregunta. Para eliminar una preocupación, haga clic en la "x" junto a ella.',
  "Confirm Gait Concern Deletion": "Confirm Gait Concern Deletion", // English-only in legacy

  // --- q-concerns (Spanish has no heading, one combined prompt) -------------------------------
  "Any Concerns?": "",
  "Please type in any other concerns you have today:":
    "¿Tiene otras preocupaciónes ahora?",
};

// Confirmation pages (q-*_update.jsp) carry English-only lines for some strings; this is the legacy rule.
const ENGLISH_ONLY = new Set(["Confirm Gait Concern Deletion"]);

export function translate(
  key: string,
  language: QuestionnaireLanguage,
): string {
  const english = key.replace(/#\w+$/, "");
  if (language !== "sp" || ENGLISH_ONLY.has(key)) {
    return english;
  }
  const spanish = SP[key];
  return spanish === undefined ? english : spanish;
}

export function fillName(
  text: string,
  firstName: string,
  fallback: string,
): string {
  return text.replace(/\[name\]/g, firstName || fallback);
}
