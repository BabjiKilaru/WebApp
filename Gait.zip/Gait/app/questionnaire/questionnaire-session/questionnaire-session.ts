import { CommonModule } from "@angular/common";
import { HttpClient } from "@angular/common/http";
import { ChangeDetectorRef, Component, ElementRef, OnDestroy, OnInit, QueryList, ViewChildren } from "@angular/core";
import { ActivatedRoute } from "@angular/router";

import { FirstVisitQuestionnaire } from "../first-visit-questionnaire/first-visit-questionnaire";

import { BaselineWho, HistoryQuestionnaire } from "../history-questionnaire/history-questionnaire";
import { HipQuestionnaire } from "../hip-questionnaire/hip-questionnaire";
import { PodciQuestionnaire, PodciVariant } from "../podci-questionnaire/podci-questionnaire";
import { QuestionnaireClose } from "../questionnaire-close/questionnaire-close";
import { QuestionnaireEnd } from "../questionnaire-end/questionnaire-end";
import { QuestionnairePatientInfo } from "../questionnaire-patient-info/questionnaire-patient-info";
import { QuestionnaireProgress } from "../questionnaire-progress/questionnaire-progress";
import { QuestionnaireWelcome } from "../questionnaire-welcome/questionnaire-welcome";
import { SportsQuestionnaire } from "../sports-questionnaire/sports-questionnaire";
import { UeHistoryQuestionnaire } from "../ue-history-questionnaire/ue-history-questionnaire";

interface AssembledQuestionnaire {
  code: string;
  visitId: number;
}

interface QuestionnaireStep {
  key: string;
  title: string;
  codes: string[];
  visitId: number | null;
}

interface PatientInfo {
  id: number;
  fname?: string | null;
  lname?: string | null;
  mrn?: string | null;
  dob?: string | null;
  dateOfBirth?: string | null;
  gender?: string | null;
  sex?: string | null;
}

interface QuestionnaireProgressValue {
  answered: number;
  total: number;
}

interface QuestionnaireProgressItem extends QuestionnaireProgressValue {
  key: string;
  name: string;
  completed: boolean;
}

interface SavableQuestionnaire {
  save(): void;
  validate?(): string | null;
  getInvalidFields?(): string[];
  getProgress?(): QuestionnaireProgressValue;
}

type SaveAction = "next" | "close" | "submit" | null;

const HISTORY_CODES = new Set<string>([
  "NEW_HISTORY",
  "HISTORY",
  "HISTORY_GAIT",
  "HISTORY_CONCERNS",
]);

@Component({
  selector: "app-questionnaire-session",
  standalone: true,
  imports: [
    CommonModule,
    QuestionnaireWelcome,
    QuestionnaireClose,
    QuestionnaireEnd,
    QuestionnairePatientInfo,
    QuestionnaireProgress,
    FirstVisitQuestionnaire,
    HistoryQuestionnaire,
    HipQuestionnaire,
    SportsQuestionnaire,
    PodciQuestionnaire,
    UeHistoryQuestionnaire,
  ],
  templateUrl: "./questionnaire-session.html",
  styleUrl: "./questionnaire-session.css",
})
export class QuestionnaireSession implements OnInit, OnDestroy {
  patientId: number | null = null;
  visitId: number | null = null;
  patientDisplayName = "";
  firstName = "";
  patientDob = "";
  patientSex = "";

  patientMrn = "";

  languageCode: "en" | "sp" = "en";

  private language = "en";

  private selections: string[] = [];

  private assembledList: AssembledQuestionnaire[] = [];

  assembling = false;

  assembleError = "";

  saving = false;

  saveError = "";

  validationInvalid = false;

  steps: QuestionnaireStep[] = [];

  currentIndex = 0;

  progressItems: QuestionnaireProgressItem[] = [];

  showWelcome = true;

  showClosePopup = false;

  showThankYou = false;

  baseline: BaselineWho | null = null;

  private pendingSaveCount = 0;

  private saveFailed = false;

  private saveAction: SaveAction = null;

  private saveErrorTimer: ReturnType<typeof setTimeout> | null = null;

  @ViewChildren("sectionCmp")
  private sectionCmps!: QueryList<SavableQuestionnaire>;

  @ViewChildren("sectionCmp", { read: ElementRef })
  private sectionElements!: QueryList<ElementRef<HTMLElement>>;

  constructor(
    private http: HttpClient,

    private route: ActivatedRoute,

    private cdr: ChangeDetectorRef,
  ) {}

  ngOnInit(): void {
    const params = this.route.snapshot.queryParamMap;

    this.patientId = params.get("patientId")
      ? Number(params.get("patientId"))
      : null;

    this.visitId = params.get("visitId") ? Number(params.get("visitId")) : null;

    this.patientDisplayName = params.get("patientName") ?? "";

    this.firstName = params.get("firstName") ?? "";

    this.language = params.get("language") ?? "en";

    this.languageCode = this.language === "sp" ? "sp" : "en";

    this.selections = (params.get("selections") ?? "")
      .split(",")
      .map((value) => value.trim())
      .filter(Boolean);

    this.loadPatient();

    this.assemble();
  }

  ngOnDestroy(): void {
    this.clearSaveErrorTimer();
  }

  private loadPatient(): void {
    if (!this.patientId) {
      return;
    }

    this.http.get<PatientInfo>(`/api/patients/${this.patientId}`).subscribe({
      next: (patient) => {
        const fullName = `${patient.fname ?? ""} ${patient.lname ?? ""}`.trim();

        if (fullName) {
          this.patientDisplayName = fullName;
        }

        if (patient.fname) {
          this.firstName = patient.fname;
        }

        this.patientDob = patient.dateOfBirth ?? patient.dob ?? "";

        this.patientSex = patient.gender ?? patient.sex ?? "";

        this.patientMrn = patient.mrn ?? "";

        this.cdr.markForCheck();
      },

      error: (error) => {
        console.error(
          "Unable to load questionnaire patient information:",
          error,
        );
      },
    });
  }

  private assemble(): void {
    if (!this.patientId || !this.visitId || this.selections.length === 0) {
      this.assembleError =
        "Missing patient, visit, or questionnaire selection.";

      return;
    }

    this.assembling = true;

    this.assembleError = "";

    this.http
      .post<AssembledQuestionnaire[]>(
        `/api/patients/${this.patientId}/questionnaire-picker/assemble`,
        {
          visitId: this.visitId,

          selections: this.selections,

          language: this.language,
        },
      )
      .subscribe({
        next: (assembled) => {
          this.assembledList = assembled ?? [];

          this.steps = this.buildSteps(this.assembledList);

          this.progressItems = this.steps.map((step) => ({
            key: step.key,

            name: step.title,

            answered: 0,

            total: 0,

            completed: false,
          }));

          this.currentIndex = 0;

          this.assembling = false;

          this.cdr.detectChanges();
        },

        error: (error) => {
          console.error("Unable to assemble questionnaires:", error);

          this.assembling = false;

          this.assembleError =
            "Unable to prepare the questionnaires. Please try again.";

          this.cdr.detectChanges();
        },
      });
  }

  private buildSteps(assembled: AssembledQuestionnaire[]): QuestionnaireStep[] {
    const steps: QuestionnaireStep[] = [];

    let historyAdded = false;

    for (const item of assembled) {
      if (HISTORY_CODES.has(item.code)) {
        if (!historyAdded) {
          const historyItems = assembled.filter((questionnaire) =>
            HISTORY_CODES.has(questionnaire.code),
          );

          steps.push({
            key: "HISTORY",

            title: "History",

            codes: historyItems.map((questionnaire) => questionnaire.code),

            visitId: historyItems[0]?.visitId ?? this.visitId,
          });

          historyAdded = true;
        }

        continue;
      }

      if (item.code === "HIP") {
        steps.push({
          key: "HIP",

          title: "Hip",

          codes: ["HIP"],

          visitId: item.visitId,
        });

        continue;
      }

      if (item.code === "SPORTS") {
        steps.push({
          key: "SPORTS",

          title: "Sport",

          codes: ["SPORTS"],

          visitId: item.visitId,
        });

        continue;
      }

      if (item.code === "PODCI_CH") {
        steps.push({
          key: "PODCI_CH",

          title: "PODCI (Child Parent-reported)",

          codes: ["PODCI_CH"],

          visitId: item.visitId,
        });

        continue;
      }

      if (item.code === "PODCI_AP") {
        steps.push({
          key: "PODCI_AP",

          title: "PODCI (Adolescent Parent-reported)",

          codes: ["PODCI_AP"],

          visitId: item.visitId,
        });

        continue;
      }

      if (item.code === "PODCI_AS") {
        steps.push({
          key: "PODCI_AS",

          title: "PODCI Adolescent (Self Reported)",

          codes: ["PODCI_AS"],

          visitId: item.visitId,
        });

        continue;
      }

      if (item.code === "UE_HISTORY") {
        steps.push({
          key: "UE_HISTORY",

          title: "UE History",

          codes: ["UE_HISTORY"],

          visitId: item.visitId,
        });
      }
    }

    return steps;
  }

  retry(): void {
    this.assemble();
  }

  get questionnaireNames(): string[] {
    return this.steps.map((step) => step.title);
  }

  get currentStep(): QuestionnaireStep | null {
    return this.steps[this.currentIndex] ?? null;
  }

  get isLastQuestionnaire(): boolean {
    if (this.steps.length === 0) {
      return false;
    }

    return this.currentIndex === this.steps.length - 1;
  }

  get remainingCount(): number {
    return Math.max(this.steps.length - this.currentIndex - 1, 0);
  }

  get showFirstVisit(): boolean {
    return this.hasCurrentCode("NEW_HISTORY");
  }

  get showWho(): boolean {
    return this.hasCurrentCode("HISTORY");
  }

  get showGeneral(): boolean {
    return this.hasCurrentCode("HISTORY") || this.hasCurrentCode("NEW_HISTORY");
  }

  get showGait(): boolean {
    return this.hasCurrentCode("HISTORY_GAIT");
  }

  get showConcerns(): boolean {
    return this.hasCurrentCode("HISTORY_CONCERNS");
  }

  get historyVisitId(): number | null {
    const history = this.assembledList.find((item) =>
      HISTORY_CODES.has(item.code),
    );

    return history?.visitId ?? this.visitId;
  }

  hasCurrentCode(code: string): boolean {
    return this.currentStep?.codes.includes(code) ?? false;
  }

  podciVariant(code: string): PodciVariant {
    if (code === "PODCI_AP") {
      return "AP";
    }

    if (code === "PODCI_AS") {
      return "AS";
    }

    return "CH";
  }

  startQuestionnaires(): void {
    this.showWelcome = false;

    this.clearSaveError();

    this.cdr.detectChanges();

    this.recordTrackingOnEntry();

    this.scheduleProgressRefresh();

    this.scrollQuestionArea();
  }

  onBaselineChange(baseline: BaselineWho): void {
    this.baseline = baseline;

    this.scheduleProgressRefresh();
  }

  onHistoryQuestionnaireOpened(): void {
    if (this.currentStep?.key === "HISTORY") {
      this.recordTrackingForCurrentStep();
    }
  }

  onTrackedQuestionnaireOpened(key: "SPORTS" | "UE_HISTORY"): void {
    if (this.currentStep?.key === key) {
      this.recordTrackingForCurrentStep();
    }
  }

  scheduleProgressRefresh(): void {
    setTimeout(() => {
      this.refreshValidationHighlight();
      this.refreshCurrentProgress();
    }, 0);
  }

  private refreshValidationHighlight(): void {
    if (!this.validationInvalid || !this.sectionCmps || !this.sectionElements) {
      return;
    }

    const components = this.sectionCmps.toArray();
    const hosts = this.sectionElements.toArray();
    let hasValidationErrors = false;

    components.forEach((component, index) => {
      const host = hosts[index]?.nativeElement;

      if (!host) {
        return;
      }

      host
        .querySelectorAll(
          ".validation-question-text-invalid",
        )
        .forEach((element) =>
          element.classList.remove("validation-question-text-invalid"),
        );

      const invalidFields = component.getInvalidFields?.() ?? [];
      hasValidationErrors = hasValidationErrors || invalidFields.length > 0;

      for (const field of invalidFields) {
        const matchingControls = Array.from(
          host.querySelectorAll<HTMLElement>(
            "input, select, textarea, [data-validation-key]",
          ),
        )
          .filter(
            (element) =>
              element.id === field ||
              element.getAttribute("name") === field ||
              element.getAttribute("data-validation-key") === field,
          );

        if (host.querySelector(".podci-form")) {
          const textTargets = new Set<HTMLElement>();

          for (const control of matchingControls) {
            const rowLabel =
              control.closest("tr")?.querySelector<HTMLElement>(".row-label");
            if (rowLabel) {
              textTargets.add(rowLabel);
              continue;
            }

            const page = control.closest(".podci-page");
            const precedingStems = page
              ? Array.from(page.querySelectorAll<HTMLElement>(".stem")).filter(
                  (stem) =>
                    Boolean(
                      stem.compareDocumentPosition(control) &
                        Node.DOCUMENT_POSITION_FOLLOWING,
                    ),
                )
              : [];
            const stem = precedingStems.at(-1);
            if (stem) {
              textTargets.add(stem);
            }
          }

          textTargets.forEach((target) =>
            target.classList.add("validation-question-text-invalid"),
          );
          continue;
        }

        for (const control of matchingControls) {
          const directTextTarget = Array.from(
            host.querySelectorAll<HTMLElement>("[data-validation-key]"),
          ).find(
            (element) =>
              element.getAttribute("data-validation-key") === field,
          );
          const textTarget =
            directTextTarget ??
            control.closest(".field-row")?.querySelector<HTMLElement>(
              ".field-label",
            ) ??
            control.closest(".question-block")?.querySelector<HTMLElement>(
              ".question-label, .page-heading",
            ) ??
            control.closest(".scale-row")?.querySelector<HTMLElement>(
              ".scale-text",
            ) ??
            control.closest(".harris-item")?.querySelector<HTMLElement>(
              ".harris-label",
            ) ??
            (field === "ucla"
              ? control
                  .closest(".activity-level-section")
                  ?.querySelector<HTMLElement>("h4")
              : null) ??
            control.closest("tr")?.querySelector<HTMLElement>(".row-label");

          textTarget?.classList.add("validation-question-text-invalid");
        }
      }
    });

    if (!hasValidationErrors) {
      this.validationInvalid = false;
      this.cdr.markForCheck();
    }
  }

  refreshCurrentProgress(): void {
    if (!this.currentStep || !this.sectionCmps) {
      return;
    }

    let answered = 0;

    let total = 0;

    const components = this.sectionCmps.toArray();

    for (const component of components) {
      const progress = component.getProgress?.();

      if (!progress) {
        continue;
      }

      answered += progress.answered;

      total += progress.total;
    }

    const item = this.progressItems.find(
      (progress) => progress.key === this.currentStep?.key,
    );

    if (!item) {
      return;
    }

    item.answered = answered;

    item.total = total;

    this.progressItems = [...this.progressItems];

    this.cdr.markForCheck();
  }

  nextQuestionnaire(): void {
    if (this.saving || !this.currentStep) {
      return;
    }

    this.saveCurrent("next");
  }

  requestSaveAndClose(): void {
    if (this.saving || !this.currentStep) {
      return;
    }

    this.showClosePopup = true;
  }

  continueQuestionnaire(): void {
    this.showClosePopup = false;
  }

  confirmSaveAndClose(): void {
    this.showClosePopup = false;

    this.saveCurrent("close");
  }

  submitQuestionnaires(): void {
    if (this.saving || !this.currentStep || !this.isLastQuestionnaire) {
      return;
    }

    this.saveCurrent("submit");
  }

  private saveCurrent(action: SaveAction): void {
    const components = this.sectionCmps.toArray();

    if (components.length === 0) {
      this.afterSuccessfulSave(action);

      return;
    }

    if (action !== "close") {
      for (const component of components) {
        const validation = component.validate?.() ?? null;

        if (validation) {
          this.validationInvalid = true;
          this.showSaveError(validation);

          this.cdr.detectChanges();
          this.refreshValidationHighlight();

          return;
        }
      }
    }

    this.saving = true;

    this.clearSaveError();

    this.saveAction = action;

    this.pendingSaveCount = components.length;

    this.saveFailed = false;

    for (const component of components) {
      component.save();
    }
  }

  onSectionSaved(): void {
    if (!this.saving) {
      return;
    }

    this.pendingSaveCount--;

    this.finishCurrentSave();
  }

  onSectionSaveFailed(message?: string): void {
    if (!this.saving) {
      return;
    }

    this.saveFailed = true;

    this.showSaveError(
      message || "Unable to save this questionnaire. Please try again.",
    );

    this.pendingSaveCount--;

    this.finishCurrentSave();
  }

  private finishCurrentSave(): void {
    if (this.pendingSaveCount > 0) {
      return;
    }

    this.saving = false;

    if (this.saveFailed) {
      this.saveAction = null;

      this.cdr.detectChanges();

      return;
    }

    const action = this.saveAction;

    this.saveAction = null;

    this.afterSuccessfulSave(action);
  }

  private afterSuccessfulSave(action: SaveAction): void {
    this.refreshCurrentProgress();

    if (action !== "close" && this.currentStep) {
      const item = this.progressItems.find(
        (progress) => progress.key === this.currentStep?.key,
      );

      if (item) {
        item.completed = true;

        this.progressItems = [...this.progressItems];
      }
    }

    if (action === "next") {
      if (this.currentIndex < this.steps.length - 1) {
        this.currentIndex++;

        this.validationInvalid = false;
        this.clearSaveError();

        this.cdr.detectChanges();

        this.recordTrackingOnEntry();

        this.scheduleProgressRefresh();

        this.scrollQuestionArea();
      }

      return;
    }

    if (action === "close") {
      this.validationInvalid = false;
      window.close();
      return;
    }

    if (action === "submit") {
      this.showThankYou = true;

      this.validationInvalid = false;
      this.clearSaveError();

      this.cdr.detectChanges();
    }
  }

  private recordTrackingOnEntry(): void {
    if (!["HISTORY", "SPORTS", "UE_HISTORY"].includes(this.currentStep?.key ?? "")) {
      this.recordTrackingForCurrentStep();
    }
  }

  private recordTrackingForCurrentStep(): void {
    const currentStep = this.currentStep;

    if (!currentStep) {
      return;
    }

    const currentCodes = new Set(currentStep.codes);
    this.recordTracking(
      this.assembledList.filter((item) => currentCodes.has(item.code)),
    );
  }

  private recordTracking(assignments: AssembledQuestionnaire[]): void {
    if (!this.patientId || assignments.length === 0) {
      return;
    }

    this.http
      .post(
        `/api/patients/${this.patientId}/questionnaire-tracking`,
        assignments,
      )
      .subscribe({
        error: (error) => {
          console.error("Unable to record questionnaire tracking:", error);
          this.showSaveError(
            "Unable to record questionnaire tracking. Please try again.",
          );
          this.cdr.markForCheck();
        },
      });
  }

  closeWindow(): void {
    window.close();
  }

  private scrollQuestionArea(): void {
    setTimeout(() => {
      document.querySelector(".question-scroll")?.scrollTo({
        top: 0,

        behavior: "smooth",
      });
    }, 0);
  }

  private showSaveError(message: string): void {
    this.clearSaveErrorTimer();
    this.saveError = message;
    this.saveErrorTimer = setTimeout(() => {
      this.saveError = "";
      this.saveErrorTimer = null;
      this.cdr.markForCheck();
    }, 5000);
  }

  private clearSaveError(): void {
    this.clearSaveErrorTimer();
    this.saveError = "";
  }

  private clearSaveErrorTimer(): void {
    if (this.saveErrorTimer !== null) {
      clearTimeout(this.saveErrorTimer);
      this.saveErrorTimer = null;
    }
  }
}
