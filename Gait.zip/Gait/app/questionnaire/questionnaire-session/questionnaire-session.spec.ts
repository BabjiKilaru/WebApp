import { provideHttpClient } from "@angular/common/http";
import {
  HttpTestingController,
  provideHttpClientTesting,
} from "@angular/common/http/testing";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import {
  ActivatedRoute,
  convertToParamMap,
  provideRouter,
} from "@angular/router";

import { QuestionnaireSession } from "./questionnaire-session";

describe("QuestionnaireSession", () => {
  let component: QuestionnaireSession;
  let fixture: ComponentFixture<QuestionnaireSession>;
  let httpTesting: HttpTestingController;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [QuestionnaireSession],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: {
              queryParamMap: convertToParamMap({
                patientId: "1",
                visitId: "10",
                selections: "podci-parent",
                language: "en",
              }),
            },
          },
        },
      ],
    }).compileComponents();

    httpTesting = TestBed.inject(HttpTestingController);
    fixture = TestBed.createComponent(QuestionnaireSession);
    component = fixture.componentInstance;
    fixture.detectChanges();

    httpTesting.expectOne("/api/patients/1").flush({});
    httpTesting
      .expectOne("/api/patients/1/questionnaire-picker/assemble")
      .flush([{ code: "PODCI_CH", visitId: 10 }]);
  });

  afterEach(() => httpTesting.verify());

  it("shows the child parent-reported label on the welcome page", () => {
    expect(component.questionnaireNames).toEqual([
      "PODCI (Child Parent-reported)",
    ]);
  });

  it("tracks the assembled questionnaire as the current and last step", () => {
    expect(component.currentStep?.key).toBe("PODCI_CH");
    expect(component.currentIndex).toBe(0);
    expect(component.isLastQuestionnaire).toBe(true);
    expect(component.remainingCount).toBe(0);
  });

  it("opens and cancels the Save & Close confirmation", () => {
    component.requestSaveAndClose();
    expect(component.showClosePopup).toBe(true);
    component.continueQuestionnaire();
    expect(component.showClosePopup).toBe(false);
  });

  it("uses the child PODCI variant and does not enable history-only sections", () => {
    expect(component.podciVariant("PODCI_CH")).toBe("CH");
    expect(component.showFirstVisit).toBe(false);
    expect(component.showGait).toBe(false);
  });
});
