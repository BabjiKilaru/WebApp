import { CommonModule } from "@angular/common";
import { ChangeDetectorRef, Component, EventEmitter, Input, OnChanges, Output } from "@angular/core";
import { HttpClient } from "@angular/common/http";

import { QuestionnaireProgressValue } from "../questionnaire-progress/questionnaire-progress";

interface SingleChoice {
  key: "handlesObjects" | "dresses" | "bathes" | "toilets";
  question: string;
  options: string[];
}

const DEPENDENCE = [
  "Yes, independently",
  "Yes but needs some assistance",
  "No, is dependent",
];

@Component({
  selector: "app-ue-history-questionnaire",
  standalone: true,
  imports: [CommonModule],
  templateUrl: "./ue-history-questionnaire.html",
  styleUrl: "./ue-history-questionnaire.css",
})
export class UeHistoryQuestionnaire implements OnChanges {
  @Input()
  patientId: number | null = null;

  @Input()
  visitId: number | null = null;

  @Input()
  language: "en" | "sp" = "en";

  @Input()
  hideActions = false;

  @Output()
  saveComplete = new EventEmitter<void>();

  @Output()
  saveFailed = new EventEmitter<string>();

  @Output()
  progressChange = new EventEmitter<void>();

  @Output()
  questionnaireOpened = new EventEmitter<void>();

  readonly handsQuestion: SingleChoice = {
    key: "handlesObjects",

    question: "My child handles objects with both hands",

    options: [
      "Yes",
      "Yes but with difficulty",
      "No RIGHT hand only",
      "No LEFT hand only",
    ],
  };

  readonly selfCareQuestions: SingleChoice[] = [
    {
      key: "dresses",
      question: "My child is able to dress him/herself",
      options: DEPENDENCE,
    },

    {
      key: "bathes",
      question: "My child is able to bathe him/herself",
      options: DEPENDENCE,
    },

    {
      key: "toilets",
      question: "My child is able to use the toilet him/herself",
      options: DEPENDENCE,
    },
  ];

  readonly concernsQuestion = "Concerns with arm /hand";

  readonly concernOptions = [
    "Elbow flexed",
    "Wrist flexed",
    "Thumb in palm",
    "Hand fisted",
    "Weak grasp",
    "Palm down",
    "Neglects arm",
    "Hard to get in a sleeve",
  ];

  answers: Record<string, string | null> = {};

  private sessionId: number | null = null;

  concerns = new Set<string>();

  saving = false;

  saveError = "";

  saved = false;

  constructor(
    private http: HttpClient,

    private cdr: ChangeDetectorRef,
  ) {}

  ngOnChanges(): void {
    this.answers = {};

    this.sessionId = null;

    this.concerns = new Set<string>();

    this.saved = false;

    this.saveError = "";

    this.preload();
  }

  private preload(): void {
    if (!this.patientId || !this.visitId) {
      return;
    }

    const visitId = this.visitId;

    this.http
      .get<Record<string, string | string[] | null> & { sessionId?: number }>(
        `/api/patients/${this.patientId}/ue-history-questionnaire/${visitId}?language=${this.language}`,
      )
      .subscribe({
        next: (saved) => {
          if (visitId !== this.visitId) {
            return;
          }

          this.sessionId = saved?.sessionId ?? null;

          for (const key of [
            "handlesObjects",
            "dresses",
            "bathes",
            "toilets",
          ]) {
            const value = saved?.[key];

            if (typeof value === "string" && value) {
              this.answers[key] = value;
            }
          }

          const chosen = saved?.["armHandConcerns"];

          if (Array.isArray(chosen)) {
            this.concerns = new Set(chosen);
          }

          this.cdr.markForCheck();

          this.progressChange.emit();
          this.questionnaireOpened.emit();
        },

        error: () => {},
      });
  }

  choose(
    key: string,

    value: string,
  ): void {
    this.answers[key] = value;

    this.saved = false;

    this.progressChange.emit();
  }

  toggleConcern(option: string): void {
    if (this.concerns.has(option)) {
      this.concerns.delete(option);
    } else {
      this.concerns.add(option);
    }

    this.saved = false;

    this.progressChange.emit();
  }

  getProgress(): QuestionnaireProgressValue {
    const requiredQuestions = [this.handsQuestion, ...this.selfCareQuestions];

    const answered = requiredQuestions.filter(
      (question) => !!this.answers[question.key],
    ).length;

    return {
      answered,
      total: requiredQuestions.length,
    };
  }

  validate(): string | null {
    return this.getInvalidFields().length > 0
      ? "You must answer above before submitting."
      : null;
  }

  getInvalidFields(): string[] {
    const questions = [this.handsQuestion, ...this.selfCareQuestions];
    return questions
      .filter((question) => !this.answers[question.key])
      .map((question) => question.key);
  }

  save(): void {
    if (!this.patientId || !this.visitId || !this.sessionId) {
      this.saveFailed.emit("Unable to start this questionnaire session. Reload and try again.");

      return;
    }

    this.saving = true;

    this.saveError = "";

    this.http
      .post(`/api/patients/${this.patientId}/ue-history-questionnaire`, {
        visitId: this.visitId,

        sessionId: this.sessionId,

        language: this.language,

        handlesObjects: this.answers["handlesObjects"] ?? null,

        dresses: this.answers["dresses"] ?? null,

        bathes: this.answers["bathes"] ?? null,

        toilets: this.answers["toilets"] ?? null,

        armHandConcerns: [...this.concerns],
      })
      .subscribe({
        next: () => {
          this.saving = false;

          this.saved = true;

          this.cdr.markForCheck();

          this.progressChange.emit();

          this.saveComplete.emit();
        },

        error: (error) => {
          console.error("Unable to save UE History:", error);

          this.saving = false;

          this.saveError = "Unable to save. Please try again.";

          this.cdr.markForCheck();

          this.saveFailed.emit(this.saveError);
        },
      });
  }
}
