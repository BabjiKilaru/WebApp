import { vi } from 'vitest';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { UeHistoryQuestionnaire } from './ue-history-questionnaire';

describe('UeHistoryQuestionnaire', () => {
    let component: UeHistoryQuestionnaire;
    let http: HttpTestingController;
    beforeEach(async () => {
        await TestBed.configureTestingModule({ imports: [UeHistoryQuestionnaire], providers: [provideHttpClient(), provideHttpClientTesting()] })
            .overrideComponent(UeHistoryQuestionnaire, { set: { template: '' } }).compileComponents();
        component = TestBed.createComponent(UeHistoryQuestionnaire).componentInstance;
        http = TestBed.inject(HttpTestingController);
    });
    afterEach(() => http.verify());
    it('requires hand-use and three self-care answers', () => {
        expect(component.getProgress()).toEqual({ answered: 0, total: 4 });
        expect(component.getInvalidFields()).toEqual(['handlesObjects', 'dresses', 'bathes', 'toilets']);
    });
    it('tracks completed responses', () => {
        component.choose('handlesObjects', 'Yes');
        component.choose('dresses', 'No');
        component.choose('bathes', 'Yes');
        component.choose('toilets', 'Yes');
        expect(component.getProgress()).toEqual({ answered: 4, total: 4 });
        expect(component.validate()).toBeNull();
    });
    it('toggles upper-extremity concern choices without duplicating them', () => {
        component.toggleConcern('Weak grasp');
        component.toggleConcern('Weak grasp');
        expect(component.concerns.size).toBe(0);
    });
    it('does not save until a session was obtained from the server', () => {
        component.patientId = 42;
        component.visitId = 10;
        const failed = vi.fn();
        component.saveFailed.subscribe(failed);
        component.save();
        expect(failed).toHaveBeenCalledOnce();
        http.expectNone('/api/patients/42/ue-history-questionnaire');
    });
});