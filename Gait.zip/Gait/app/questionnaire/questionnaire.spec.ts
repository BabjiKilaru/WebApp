import { provideHttpClient } from "@angular/common/http";
import { HttpTestingController, provideHttpClientTesting } from "@angular/common/http/testing";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { provideRouter } from "@angular/router";

import { Questionnaire, QuestionnaireScheduledVisit } from "./questionnaire";

describe("Questionnaire", () => {
  let component: Questionnaire;
  let fixture: ComponentFixture<Questionnaire>;
  let httpTesting: HttpTestingController;

  const visit: QuestionnaireScheduledVisit = {
    visitId: 10,
    patientId: 1,
    firstName: "Avery",
    lastName: "Patient",
    mrn: "1234",
    visitType: null,
    visitSubType: null,
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Questionnaire],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
      ],
    }).compileComponents();

    httpTesting = TestBed.inject(HttpTestingController);
    fixture = TestBed.createComponent(Questionnaire);
    component = fixture.componentInstance;
    fixture.detectChanges();
    httpTesting
      .expectOne((request) => request.url === "/api/patients/scheduled")
      .flush([]);
    httpTesting.expectOne("/api/auth/me").flush(
      {},
      { status: 401, statusText: "Unauthorized" },
    );
  });

  afterEach(() => httpTesting.verify());

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should default to English and today's date", () => {
    expect(component.selectedLanguage).toBe("English");
    expect(component.selectedDate).toMatch(/^\d{4}-\d{2}-\d{2}$/);
  });

  it("should change the calendar year without changing the month or selected date", () => {
    const selectedDate = component.selectedDate;
    const month = component.calendarMonth.getMonth();

    component.changeYear(2016);

    expect(component.calendarMonth.getFullYear()).toBe(2016);
    expect(component.calendarMonth.getMonth()).toBe(month);
    expect(component.selectedDate).toBe(selectedDate);
    expect(component.calendarYears).toContain(2016);
    expect(component.calendarDays.some((day) => day.date.startsWith("2016-"))).toBe(
      true,
    );
  });

  it("should expose the available questionnaire categories", () => {
    const questionnaireIds = component.categories.flatMap((category) =>
      category.options.map((option) => option.id),
    );

    expect(questionnaireIds).toEqual([
      "history",
      "podci-parent",
      "podci-self",
      "sports",
      "hip",
    ]);
  });

  it("should select a visit and clear questionnaire selections", () => {
    component.selectVisit(visit);
    component.toggleQuestionnaire("history");
    component.selectVisit({ ...visit, visitId: 11 });

    expect(component.selectedPatientId).toBe(1);
    expect(component.selectedVisitId).toBe(11);
    expect(component.selectedQuestionnaireIds).toEqual([]);
  });

  it("should toggle questionnaire selections only after selecting a visit", () => {
    component.toggleQuestionnaire("history");
    expect(component.selectedQuestionnaireIds).toEqual([]);

    component.selectVisit(visit);
    component.toggleQuestionnaire("history");
    expect(component.selectedQuestionnaireIds).toEqual(["history"]);

    component.toggleQuestionnaire("history");
    expect(component.selectedQuestionnaireIds).toEqual([]);
  });

  it("should require a questionnaire before starting", () => {
    component.selectVisit(visit);
    component.startQuestionnaire();

    expect(component.errorMessage).toBe(
      "Please select at least one questionnaire.",
    );
  });
});
