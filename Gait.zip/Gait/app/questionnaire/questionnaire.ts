import { CommonModule } from "@angular/common";
import { ChangeDetectorRef, Component, OnInit } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { HttpClient } from "@angular/common/http";

import { Header } from "../header/header";

// One row per scheduled VISIT for the selected date (not deduped by
// patient) — mirrors pickpt.jsp's picker exactly, including coincident
// same-day visits showing as separate, explicitly-chosen rows.
export interface QuestionnaireScheduledVisit {
  visitId: number;
  patientId: number;
  firstName: string;
  lastName: string;
  mrn: string;
  visitType: string | null;
  visitSubType: string | null;
}

export interface QuestionnaireOption {
  id: string;
  name: string;
}

export interface QuestionnaireCategory {
  id: string;
  label: string;
  options: QuestionnaireOption[];
}

interface CalendarDay {
  date: string;
  day: number;
  currentMonth: boolean;
}

@Component({
  selector: "app-questionnaire",
  standalone: true,
  imports: [CommonModule, FormsModule, Header],
  templateUrl: "./questionnaire.html",
  styleUrl: "./questionnaire.css",
})
export class Questionnaire implements OnInit {
  readonly weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  selectedDate = this.getTodayDate();
  calendarMonth = new Date(
    Number(this.selectedDate.slice(0, 4)),
    Number(this.selectedDate.slice(5, 7)) - 1,
    1,
  );
  calendarDays: CalendarDay[] = [];
  calendarYears: number[] = [];
  selectedLanguage = "English";
  selectedPatientId: number | null = null;
  // Resolved once, by primary key, when the user picks a specific
  // scheduled visit — not re-derived from a date at save time. See
  // history-visit-questionnaire.ts for the legacy-behavior citation.
  selectedVisitId: number | null = null;
  selectedQuestionnaireIds: string[] = [];
  errorMessage = "";

  scheduledVisits: QuestionnaireScheduledVisit[] = [];
  loadingVisits = false;
  visitsError = "";

  constructor(
    private http: HttpClient,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnInit(): void {
    this.buildCalendar();
    this.loadScheduledVisits();
  }

  get calendarMonthTitle(): string {
    return this.calendarMonth.toLocaleDateString("en-US", {
      month: "long",
    });
  }

  private buildCalendar(): void {
    const year = this.calendarMonth.getFullYear();
    const month = this.calendarMonth.getMonth();
    const firstWeekday = new Date(year, month, 1).getDay();
    this.calendarYears = Array.from({ length: 101 }, (_, index) => year + index - 50);

    this.calendarDays = Array.from({ length: 42 }, (_, index) => {
      const date = new Date(year, month, index - firstWeekday + 1);
      return {
        date: this.toDateString(date),
        day: date.getDate(),
        currentMonth: date.getMonth() === month,
      };
    });
  }

  changeMonth(direction: number): void {
    if (this.loadingVisits) {
      return;
    }

    this.calendarMonth = new Date(
      this.calendarMonth.getFullYear(),
      this.calendarMonth.getMonth() + direction,
      1,
    );
    this.buildCalendar();
  }

  changeYear(year: number): void {
    if (this.loadingVisits || !Number.isInteger(year)) {
      return;
    }

    this.calendarMonth = new Date(year, this.calendarMonth.getMonth(), 1);
    this.buildCalendar();
  }

  selectCalendarDay(day: CalendarDay): void {
    if (this.loadingVisits) {
      return;
    }

    this.selectedDate = day.date;
    if (!day.currentMonth) {
      this.calendarMonth = new Date(
        Number(day.date.slice(0, 4)),
        Number(day.date.slice(5, 7)) - 1,
        1,
      );
      this.buildCalendar();
    }

    this.onDateChange();
  }

  formatDisplayDate(value: string): string {
    if (!value) {
      return "";
    }

    return new Date(
      Number(value.slice(0, 4)),
      Number(value.slice(5, 7)) - 1,
      Number(value.slice(8, 10)),
    ).toLocaleDateString("en-US", {
      month: "long",
      day: "numeric",
      year: "numeric",
    });
  }

  private loadScheduledVisits(): void {
    this.loadingVisits = true;
    this.visitsError = "";

    this.http
      .get<QuestionnaireScheduledVisit[]>(`/api/patients/scheduled`, {
        params: { date: this.selectedDate },
      })
      .subscribe({
        next: (visits) => {
          this.scheduledVisits = visits;
          this.loadingVisits = false;
          this.cdr.markForCheck();
        },
        error: (error) => {
          console.error("Unable to load scheduled visits:", error);
          this.scheduledVisits = [];
          this.loadingVisits = false;
          this.visitsError = "Unable to load patients for this date.";
          this.cdr.markForCheck();
        },
      });
  }

  // Mirrors the legacy picker (clinconn/lab/pickpt.jsp) exactly: 3 hardcoded
  // groups, 5 checkable items. There is no category concept in the legacy
  // DB — grouping was always hardcoded in the JSP markup, not data-driven.
  categories: QuestionnaireCategory[] = [
    {
      id: "history",
      label: "History questionnaire",
      options: [{ id: "history", name: "History" }],
    },
    {
      id: "podci",
      label: "PODCI questionnaire",
      options: [
        { id: "podci-parent", name: "Child/Adolescent (Parent Reported)" },
        { id: "podci-self", name: "Adolescent (Self Reported)" },
      ],
    },
    {
      id: "other",
      label: "Other",
      options: [
        { id: "sports", name: "Sports" },
        { id: "hip", name: "Hip" },
      ],
    },
  ];

  languages: string[] = ["English", "Spanish"];

  onDateChange(): void {
    this.errorMessage = "";
    this.selectedPatientId = null;
    this.selectedVisitId = null;
    this.selectedQuestionnaireIds = [];
    this.loadScheduledVisits();
  }

  // The one legacy-accurate resolution point: picking a row here resolves
  // both patientId and visitId together, by primary key, exactly once —
  // matching find_quest.jsp's currVisitID resolution off pickpt.jsp's list.
  selectVisit(visit: QuestionnaireScheduledVisit): void {
    this.selectedPatientId = visit.patientId;
    this.selectedVisitId = visit.visitId;
    this.selectedQuestionnaireIds = [];
    this.errorMessage = "";
  }

  isQuestionnaireSelected(questionnaireId: string): boolean {
    return this.selectedQuestionnaireIds.includes(questionnaireId);
  }

  toggleQuestionnaire(questionnaireId: string): void {
    if (!this.selectedPatientId) {
      return;
    }

    this.selectedQuestionnaireIds = this.isQuestionnaireSelected(
      questionnaireId,
    )
      ? this.selectedQuestionnaireIds.filter((id) => id !== questionnaireId)
      : [...this.selectedQuestionnaireIds, questionnaireId];

    this.errorMessage = "";
  }

  // Legacy (pickpt.jsp openQuest()) opens a blank, fullscreen, named popup
  // window synchronously, THEN targets the picker form's own submit into
  // it — find_quest.jsp (visit resolution + assembly) runs inside that
  // popup, not the original window. We mirror that split: this just opens
  // /questionnaire/fill in a popup with the picked visit + selections as
  // query params; QuestionnaireFill does the assemble call itself, same
  // as find_quest.jsp would. No logout — confirmed there isn't one in
  // legacy (see questionnaire-fill.ts).
  startQuestionnaire(): void {
    this.errorMessage = "";
    if (!this.selectedPatientId || !this.selectedVisitId) {
      return;
    }
    if (this.selectedQuestionnaireIds.length === 0) {
      this.errorMessage = "Please select at least one questionnaire.";
      return;
    }
    if (!this.selectedLanguage) {
      this.errorMessage = "Please select a language.";
      return;
    }

    const visit = this.getSelectedVisit();
    const params = new URLSearchParams({
      patientId: String(this.selectedPatientId),
      visitId: String(this.selectedVisitId),
      selections: this.selectedQuestionnaireIds.join(","),
      language: this.selectedLanguage === "Spanish" ? "sp" : "en",
      patientName: visit ? `${visit.firstName} ${visit.lastName}`.trim() : "",
      firstName: visit ? visit.firstName.trim() : "",
    });

    const popup = this.openFullscreenPopup(
      `/questionnaire/session?${params.toString()}`,
    );
    if (!popup) {
      this.errorMessage =
        "Please allow pop-ups for this site to open the questionnaire.";
    }
  }

  // Matches pickpt.jsp's openQuest() sizing (screen.availHeight - 30,
  // screen.availWidth - 10, positioned at 0,0) — must be called
  // synchronously from a click handler or browsers will block it as an
  // unsolicited popup.
  private openFullscreenPopup(url: string): Window | null {
    const availHeight = (window.screen?.availHeight ?? window.innerHeight) - 30;
    const availWidth = (window.screen?.availWidth ?? window.innerWidth) - 10;
    const features = `left=0,top=0,width=${availWidth},height=${availHeight},scrollbars=yes,resizable=yes`;
    return window.open(url, "questwin", features);
  }

  getSelectedVisit(): QuestionnaireScheduledVisit | undefined {
    return this.scheduledVisits.find(
      (visit) => visit.visitId === this.selectedVisitId,
    );
  }

  private getTodayDate(): string {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const day = String(today.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  }

  private toDateString(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  }
}
