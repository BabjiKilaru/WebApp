import { vi } from 'vitest';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { FirstVisitQuestionnaire } from './first-visit-questionnaire';

describe('FirstVisitQuestionnaire', () => {
    let component: FirstVisitQuestionnaire;
    let http: HttpTestingController;
    beforeEach(async () => {
        await TestBed.configureTestingModule({ imports: [FirstVisitQuestionnaire], providers: [provideHttpClient(), provideHttpClientTesting()] })
            .overrideComponent(FirstVisitQuestionnaire, { set: { template: '' } }).compileComponents();
        component = TestBed.createComponent(FirstVisitQuestionnaire).componentInstance;
        http = TestBed.inject(HttpTestingController);
    });
    afterEach(() => http.verify());
    it('tracks seven required baseline answers', () => {
        component.section = { fields: { historyPerson: 'Parent', historyRelationship: '--', premature: null, birthStay: null, ageWalk: null, ageTalk: null, learning: null }, lists: {}, version: '1' };
        expect(component.getProgress()).toEqual({ answered: 1, total: 7 });
        expect(component.getInvalidFields()).toContain('historyRelationship');
        expect(component.validate()).not.toBeNull();
    });
    it('accepts complete answers including numeric learning codes', () => {
        component.section = { fields: { historyPerson: 'Parent', historyRelationship: 'Mother', premature: 'No', birthStay: 'None', ageWalk: '12m', ageTalk: '24m', learning: 0 }, lists: {}, version: '1' };
        expect(component.getProgress()).toEqual({ answered: 7, total: 7 });
        expect(component.validate()).toBeNull();
    });
    it('does not write a baseline without a patient ID', () => {
        const saved = vi.fn();
        component.saveComplete.subscribe(saved);
        component.save();
        expect(saved).toHaveBeenCalledOnce();
        http.expectNone(request => request.method === 'POST' || request.method === 'PUT');
    });
});