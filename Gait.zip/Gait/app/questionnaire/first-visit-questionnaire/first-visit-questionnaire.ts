import { CommonModule } from "@angular/common";
import { ChangeDetectorRef, Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { HttpClient } from "@angular/common/http";
import { forkJoin } from "rxjs";

import { BaselineWho, REQUIRED_MESSAGE } from "../history-questionnaire/history-questionnaire";
import { fillName, QuestionnaireLanguage, translate } from "../legacy-i18n";
import { QuestionnaireProgressValue } from "../questionnaire-progress/questionnaire-progress";

interface Choice {
  value: string | number | null;
  label: string | null;
}

interface BaselineSection {
  fields: Record<string, string | number | null>;
  lists: Record<string, unknown[]>;
  version: string;
}

interface BaselinePage {
  baseline: BaselineSection;
}

type LabelledOption =
  | string
  | {
      value: string;
      label: string | null;
    };

interface RawBaselineOptions {
  relationships: LabelledOption[];
  premature: LabelledOption[];
  birthStays: LabelledOption[];
  ages: LabelledOption[];
  learning: Choice[];
}

interface BaselineOptions {
  relationships: string[];

  premature: string[];

  birthStays: string[];

  ages: string[];

  learning: Choice[];
}

@Component({
  selector: "app-first-visit-questionnaire",

  standalone: true,

  imports: [CommonModule, FormsModule],

  templateUrl: "./first-visit-questionnaire.html",

  styleUrl: "./first-visit-questionnaire.css",
})
export class FirstVisitQuestionnaire implements OnChanges {
  @Input()
  patientId: number | null = null;

  @Input()
  firstName = "";

  @Input()
  hideActions = false;

  @Input()
  language: QuestionnaireLanguage = "en";

  @Output()
  saveComplete = new EventEmitter<void>();

  @Output()
  saveFailed = new EventEmitter<string>();

  @Output()
  baselineChange = new EventEmitter<BaselineWho>();

  @Output()
  progressChange = new EventEmitter<void>();

  loading = false;

  loadError = "";

  saving = false;

  saveError = "";

  saved = false;

  section: BaselineSection | null = null;

  options: BaselineOptions | null = null;

  private labels: Record<string, string> = {};

  constructor(
    private http: HttpClient,

    private cdr: ChangeDetectorRef,
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (!(changes["patientId"] || changes["language"])) {
      return;
    }

    this.saved = false;

    this.saveError = "";

    this.section = null;

    this.options = null;

    this.load();
  }

  text(key: string): string {
    return fillName(
      translate(key, this.language),
      this.firstName,
      this.language === "sp" ? "su niño(a)" : "your child",
    );
  }

  lab(
    kind: string,

    value: string | number | null | undefined,
  ): string {
    const key = String(value ?? "");

    return this.labels[`${kind}:${key}`] ?? key;
  }

  private base(): string {
    return `/api/patients/` + `${this.patientId}/` + `questionnaire-responses`;
  }

  private load(): void {
    if (!this.patientId) {
      return;
    }

    this.loading = true;

    this.loadError = "";

    forkJoin({
      page: this.http.get<BaselinePage>(this.base()),

      options: this.http.get<RawBaselineOptions>(`${this.base()}/options`, {
        params: {
          language: this.language,
        },
      }),
    }).subscribe({
      next: ({ page, options }) => {
        this.section = page.baseline;

        this.labels = {};

        const values = (
          kind: string,

          list: LabelledOption[],
        ) =>
          list.map((item) => {
            if (typeof item === "string") {
              return item;
            }

            if (item.label) {
              this.labels[`${kind}:${item.value}`] = item.label;
            }

            return item.value;
          });

        this.options = {
          relationships: values("relationships", options.relationships ?? []),

          premature: values("premature", options.premature ?? []),

          birthStays: values("birthStays", options.birthStays ?? []),

          ages: values("ages", options.ages ?? []),

          learning: options.learning ?? [],
        };

        this.loading = false;

        this.emitWho();

        this.cdr.markForCheck();

        this.progressChange.emit();
      },

      error: (error) => {
        console.error("Unable to load First Visit History:", error);

        this.loading = false;

        this.loadError = "Unable to load this questionnaire.";

        this.cdr.markForCheck();
      },
    });
  }

  field(key: string): string | number | null {
    return this.section?.fields[key] ?? null;
  }

  setField(
    key: string,

    value: string | number | null,
  ): void {
    if (!this.section) {
      return;
    }

    this.section.fields[key] = value;

    if (key === "historyRelationship") {
      this.emitWho();
    }

    this.progressChange.emit();
  }

  setPerson(name: string): void {
    if (!this.section) {
      return;
    }

    this.section.fields["historyPerson"] = name;

    this.section.fields["baselineDate"] = this.today();

    this.emitWho();

    this.progressChange.emit();
  }

  private emitWho(): void {
    const fields = this.section?.fields;

    this.baselineChange.emit({
      person: (fields?.["historyPerson"] as string | null | undefined) ?? null,

      relationship:
        (fields?.["historyRelationship"] as string | null | undefined) ?? null,
    });
  }

  private today(): string {
    const now = new Date();

    const month = String(now.getMonth() + 1).padStart(2, "0");

    const day = String(now.getDate()).padStart(2, "0");

    return `${now.getFullYear()}` + `-${month}` + `-${day}`;
  }

  getProgress(): QuestionnaireProgressValue {
    const fields = this.section?.fields ?? {};

    const keys = [
      "historyPerson",
      "historyRelationship",
      "premature",
      "birthStay",
      "ageWalk",
      "ageTalk",
      "learning",
    ];

    const blank = (value: unknown) =>
      value === null || value === undefined || value === "" || value === "--";

    return {
      answered: keys.filter((key) => !blank(fields[key])).length,

      total: keys.length,
    };
  }

  validate(): string | null {
    return this.getInvalidFields().length > 0
      ? translate(REQUIRED_MESSAGE, this.language)
      : null;
  }

  getInvalidFields(): string[] {
    const fields = this.section?.fields;

    if (!fields) {
      return [];
    }

    const keys = [
      "historyPerson",
      "historyRelationship",
      "premature",
      "birthStay",
      "ageWalk",
      "ageTalk",
      "learning",
    ];

    const blank = (value: unknown) =>
      value === null || value === undefined || value === "" || value === "--";

    return keys.filter((key) => blank(fields[key]));
  }

  save(): void {
    if (!this.patientId || !this.section) {
      this.saveComplete.emit();

      return;
    }

    for (const key of [
      "historyPerson",
      "historyRelationship",
      "premature",
      "birthStay",
      "ageWalk",
      "ageTalk",
    ]) {
      if (
        this.section.fields[key] === null ||
        this.section.fields[key] === undefined
      ) {
        this.section.fields[key] = "";
      }
    }

    if (
      this.section.fields["learning"] === "" ||
      this.section.fields["learning"] === undefined
    ) {
      this.section.fields["learning"] = null;
    }

    this.saving = true;

    this.saveError = "";

    this.http.put<void>(`${this.base()}/baseline`, this.section).subscribe({
      next: () => {
        this.saving = false;

        this.saved = true;

        this.cdr.markForCheck();

        this.saveComplete.emit();
      },

      error: (error) => {
        console.error("Unable to save First Visit History:", error);

        this.saving = false;

        this.saveError = "Unable to save. Please try again.";

        this.cdr.markForCheck();

        this.saveFailed.emit(this.saveError);
      },
    });
  }
}
