import { CommonModule } from "@angular/common";
import { ChangeDetectorRef, Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { HttpClient } from "@angular/common/http";
import { forkJoin, from, of } from "rxjs";
import { fillName, QuestionnaireLanguage, translate } from "../legacy-i18n";
import { QuestionnaireProgressValue } from "../questionnaire-progress/questionnaire-progress";
import { catchError, concatMap, map, switchMap, tap, toArray } from "rxjs/operators";

import { PatientHistoryData, HealthHistoryEntry, HistoryConditionOption, HealthConditionEntry, ConditionOption, BotoxHistory, SideOption } from "../../patients/history/history";

type Row = Record<string, string | number | null>;

interface Choice {
  value: string | number | null;
  label: string | null;
  description?: string | null;
}

interface Section {
  fields: Record<string, string | number | null>;
  lists: Record<string, Row[]>;
  version: string;
}

interface VisitResponses {
  visitId: number;
  visitDate: string | null;
  items: Section;
  medications: Section;
  details: Section;
}

type LabelledOption =
  | string
  | {
      value: string;
      label: string | null;
    };

interface NormalizedOptions {
  relationships: string[];
  walkingSupport: Choice[];
  walkingChanges: Choice[];
  fms: Choice[];
  devices: string[];
  gaitConcerns: Choice[];
  pain: string[];
}

interface HistoryOptions {
  relationships: LabelledOption[];
  walkingSupport: Choice[];
  walkingChanges: Choice[];
  fms: Choice[];
  devices: LabelledOption[];
  gaitConcerns: Choice[];
  pain: LabelledOption[];
}

export const REQUIRED_MESSAGE = "Please fill in all answers before moving to the next question.";

export interface BaselineWho {
  person: string | null;
  relationship: string | null;
}

@Component({
  selector: "app-history-questionnaire",
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: "./history-questionnaire.html",
  styleUrl: "./history-questionnaire.css",
})
export class HistoryQuestionnaire implements OnChanges {
  @Input()
  patientId: number | null = null;

  @Input()
  visitId: number | null = null;

  @Input()
  firstName = "";

  @Input()
  hideActions = false;

  @Input()
  language: QuestionnaireLanguage = "en";

  @Input()
  showWho = true;

  @Input()
  showGeneral = true;

  @Input()
  showGait = true;

  @Input()
  showConcerns = true;

  @Input()
  copyWho: BaselineWho | null = null;

  @Output()
  saveComplete = new EventEmitter<void>();

  @Output()
  saveFailed = new EventEmitter<string>();

  @Output()
  progressChange = new EventEmitter<void>();

  @Output()
  questionnaireOpened = new EventEmitter<void>();

  frequencyChoices: {
    value: string;
    label: string;
  }[] = [
    {
      value: "4",
      label: "None",
    },

    {
      value: "3",
      label: "About once per month",
    },

    {
      value: "2",
      label: "Two or three times per month",
    },

    {
      value: "1",
      label: "One or more times per week",
    },
  ];

  readonly therapyGroups = [
    {
      title: "PHYSICAL THERAPY",
      fields: [
        {
          key: "hospitalPt",
          label: "Hospital",
        },

        {
          key: "clinicPt",
          label: "Clinic",
        },

        {
          key: "schoolPt",
          label: "School",
        },

        {
          key: "homePt",
          label: "Home",
        },
      ],
    },

    {
      title: "OCCUPATIONAL THERAPY",
      fields: [
        {
          key: "hospitalOt",
          label: "Hospital",
        },

        {
          key: "clinicOt",
          label: "Clinic",
        },

        {
          key: "schoolOt",
          label: "School",
        },

        {
          key: "homeOt",
          label: "Home",
        },
      ],
    },
  ];

  readonly deviceSideOptions = [
    {
      value: "Both",
      label: "Both",
    },

    {
      value: "R",
      label: "R only",
    },

    {
      value: "L",
      label: "L only",
    },
  ];

  readonly fmsQuestions = [
    {
      key: "fms5Id",
      text: "How does [name] move around for short distances in the house?",
    },

    {
      key: "fms50Id",
      text: "How does [name] move around in and between classes at school?",
    },

    {
      key: "fms500Id",
      text: "How does [name] move around for long distances such as the shopping center?",
    },
  ];

  readonly fmsOptionLabels = [
    "6. Independent on all surfaces",
    "5. Independent on level surfaces (Requires a rail for stairs)",
    "4. Uses cane(s) or stick(s) (one or two)",
    "3. Uses crutches",
    "2. Uses a walker or frame",
    "1. Uses wheelchair",
    "C. Crawling",
    "N. does not apply",
  ];

  loading = false;
  loadError = "";
  saving = false;
  saveError = "";
  saved = false;
  items: Section | null = null;
  details: Section | null = null;
  medications: Section | null = null;
  options: NormalizedOptions | null = null;
  healthHistory: HealthHistoryEntry[] = [];
  healthConditions: HealthConditionEntry[] = [];
  botox: BotoxHistory[] = [];
  historyConditionOptions: HistoryConditionOption[] = [];
  ageOptions: string[] = [];
  conditionOptions: ConditionOption[] = [];
  bodyLocationOptions: string[] = [];
  botoxSideOptions: SideOption[] = [];
  seizureMedOptions: string[] = [];
  newHistoryConditionCode = "";
  newHistoryAge = "";
  historyError = "";
  historySaving = false;
  conditionError = "";
  confirmingConditionId: number | null = null;
  showCustomSeizureMed = false;
  customSeizureMed = "";
  pendingSeizureMeds: string[] = [];
  pendingDevices: Row[] = [];
  pendingGaitConcerns: (string | number | null)[] = [];
  showBotoxForm = false;

  newBotox = {
    bodyLocation: "",
    date: "",
    side: "",
    facility: "",
    physician: "",
  };

  botoxSaving = false;
  botoxError = "";
  showCustomDevice = false;
  customDevice = "";
  pendingDeviceSide: Record<string, string> = {};

  constructor(
    private http: HttpClient,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (!(
      changes["patientId"] ||
      changes["visitId"] ||
      changes["language"] ||
      changes["showWho"] ||
      changes["showGeneral"] ||
      changes["showGait"] ||
      changes["showConcerns"]
    )) {
      return;
    }

    this.saved = false;
    this.saveError = "";
    this.items = null;
    this.details = null;
    this.medications = null;
    this.options = null;
    this.healthHistory = [];
    this.healthConditions = [];
    this.botox = [];
    this.newHistoryConditionCode = "";
    this.newHistoryAge = "";
    this.historyError = "";
    this.conditionError = "";
    this.pendingConditions = new Set<string>();
    this.confirmingConditionId = null;
    this.pendingRemoval = null;
    this.showCustomSeizureMed = false;
    this.customSeizureMed = "";
    this.pendingSeizureMeds = [];
    this.showBotoxForm = false;
    this.newBotox = {
      bodyLocation: "",
      date: "",
      side: "",
      facility: "",
      physician: "",
    };

    this.botoxError = "";
    this.showCustomDevice = false;
    this.customDevice = "";
    this.pendingDeviceSide = {};
    this.pendingDevices = [];
    this.pendingGaitConcerns = [];
    this.load();
  }

  get langParams(): {
    language: string;
  } {
    return {
      language: this.language,
    };
  }

  private labels: Record<
    "relationship" | "age" | "device" | "pain" | "bodyLoc",
    Record<string, string>
  > = {
    relationship: {},
    age: {},
    device: {},
    pain: {},
    bodyLoc: {},
  };

  private normalize(
    kind: "relationship" | "age" | "device" | "pain" | "bodyLoc",
    list: LabelledOption[] | undefined,
  ): string[] {
    return (list ?? []).map((item) => {
      if (typeof item === "string") {
        return item;
      }

      if (item.label) {
        this.labels[kind][item.value] = item.label;
      }

      return item.value;
    });
  }

  lab(
    kind: "relationship" | "age" | "device" | "pain" | "bodyLoc",
    value: string | number | null | undefined,
  ): string {
    const key = String(value ?? "");
    return this.labels[kind][key] ?? key;
  }

  conditionName(
    code: string | null | undefined,
    fallback: string | null | undefined,
  ): string {
    const found = this.conditionOptions.find((option) => option.code === code);
    return found?.name ?? fallback ?? "";
  }

  historyConditionName(
    code: string | null | undefined,
    fallback: string | null | undefined,
  ): string {
    const found = this.historyConditionOptions.find(
      (option) => option.code === code,
    );

    return found?.name ?? fallback ?? "";
  }

  walkingChangeLabel(choice: Choice): string {
    const english: Record<string, string> = {
      "No Change": "No Change",
      "Much Better": "Walks Much Better",
      "Little Better": "Walks a Little Better",
      "Little Worse": "Walks a Little Worse",
      "Much Worse": "Walks Much Worse",
    };

    return choice.label && this.language === "en"
      ? choice.label
      : this.text(
          english[String(choice.value)] ??
            String(choice.label ?? choice.value ?? ""),
        );
  }

  fmsOptionLabel(choice: Choice, index: number): string {
    return this.text(
      this.fmsOptionLabels[index] ?? String(choice.label ?? choice.value ?? ""),
    );
  }

  text(key: string): string {
    return fillName(
      translate(key, this.language),
      this.firstName,
      this.language === "sp" ? "su niño(a)" : "your child",
    );
  }

  pendingRemoval: {
    kind: "device" | "seizure" | "concern";
    key: string | number | null;
    label: string;
  } | null = null;

  askRemove(
    kind: "device" | "seizure" | "concern",
    key: string | number | null,
    label: string,
  ): void {
    this.pendingRemoval = {
      kind,
      key,
      label,
    };
  }

  cancelRemove(): void {
    this.pendingRemoval = null;
  }

  removalText(part: "title" | "question" | "confirm" | "cancel"): string {
    const kind = this.pendingRemoval?.kind;
    const englishOnly = kind === "concern" && part !== "cancel";
    const lang: QuestionnaireLanguage = englishOnly ? "en" : this.language;

    const key =
      part === "title"
        ? kind === "device"
          ? "Confirm Device Deletion"
          : kind === "seizure"
            ? "Confirm Medication Deletion"
            : "Confirm Gait Concern Deletion"
        : part === "question"
          ? "Are you sure you want to remove the following entry from your list?"
          : part === "confirm"
            ? kind === "concern"
              ? "Yes - Delete this from my List"
              : "Yes - Delete this from my List#dot"
            : "Do Not Delete this Item";

    return translate(key, lang);
  }

  confirmRemove(): void {
    const removal = this.pendingRemoval;
    this.pendingRemoval = null;

    if (!removal) {
      return;
    }

    if (removal.kind === "device") {
      this.removeDevice(String(removal.key));
    } else if (removal.kind === "seizure") {
      this.removeSeizureMed(String(removal.key));
    } else {
      this.removeGaitConcern(removal.key);
    }

    this.progressChange.emit();
  }

  private base(): string {
    return `/api/patients/` + `${this.patientId}/` + `questionnaire-responses`;
  }

  private patientBase(): string {
    return `/api/patients/` + `${this.patientId}`;
  }

  private load(): void {
    if (!this.patientId || !this.visitId) {
      return;
    }

    this.loading = true;
    this.loadError = "";

    forkJoin({
      visit: this.http.get<VisitResponses>(
        `${this.base()}/visits/${this.visitId}`,
      ),

      options: this.http.get<HistoryOptions>(`${this.base()}/options`, {
        params: this.langParams,
      }),

      patientHistory: this.http.get<PatientHistoryData>(
        `${this.patientBase()}/history`,
      ),

      historyConditions: this.http.get<HistoryConditionOption[]>(
        "/api/reference/history-conditions",
        {
          params: this.langParams,
        },
      ),

      ages: this.http.get<LabelledOption[]>("/api/reference/ages", {
        params: this.langParams,
      }),

      conditions: this.http.get<ConditionOption[]>(
        "/api/reference/conditions",
        {
          params: this.langParams,
        },
      ),

      bodyLocations: this.http.get<LabelledOption[]>(
        "/api/reference/body-locations",
        {
          params: this.langParams,
        },
      ),

      botoxSides: this.http.get<SideOption[]>("/api/reference/botox-sides", {
        params: this.langParams,
      }),

      seizureMedOptions: this.http.get<string[]>("/api/reference/seizure-meds"),

      frequencies: this.http.get<
        {
          value: string;

          label: string | null;
        }[]
      >("/api/reference/frequencies", {
        params: this.langParams,
      }),
    }).subscribe({
      next: (result) => {
        this.items = result.visit.items;
        this.details = result.visit.details;
        this.medications = result.visit.medications;

        this.labels = {
          relationship: {},
          age: {},
          device: {},
          pain: {},
          bodyLoc: {},
        };

        this.options = {
          ...result.options,

          relationships: this.normalize(
            "relationship",
            result.options.relationships,
          ),

          devices: this.normalize("device", result.options.devices),
          pain: this.normalize("pain", result.options.pain),
        };

        this.healthHistory = result.patientHistory.healthHistory ?? [];
        this.healthConditions = result.patientHistory.healthConditions ?? [];
        this.botox = result.patientHistory.botox ?? [];
        this.historyConditionOptions = result.historyConditions ?? [];
        this.ageOptions = this.normalize("age", result.ages);
        this.conditionOptions = result.conditions ?? [];

        this.bodyLocationOptions = this.normalize(
          "bodyLoc",
          result.bodyLocations,
        );

        this.botoxSideOptions = result.botoxSides ?? [];
        this.seizureMedOptions = result.seizureMedOptions ?? [];

        if (result.frequencies?.length) {
          this.frequencyChoices = result.frequencies.map((item) => ({
            value: String(item.value),

            label: item.label ?? String(item.value),
          }));
        }

        this.applyLegacyDefaults();
        this.loading = false;
        this.cdr.markForCheck();
        this.progressChange.emit();
        this.questionnaireOpened.emit();
      },

      error: (error) => {
        console.error("Unable to load History:", error);
        this.loading = false;
        this.loadError = "Unable to load this questionnaire.";
        this.cdr.markForCheck();
      },
    });
  }

  private applyLegacyDefaults(): void {
    if (!this.details) {
      return;
    }

    for (const group of this.therapyGroups) {
      for (const field of group.fields) {
        const current = this.details.fields[field.key];

        if (current === null || current === undefined || current === "") {
          this.details.fields[field.key] = "4";
        }
      }
    }
  }

  setItem(
    key: string,

    value: string | number | null,
  ): void {
    if (this.items) {
      this.items.fields[key] = value;
      this.progressChange.emit();
    }
  }

  private reloadPatientHistory(): void {
    if (!this.patientId) {
      return;
    }

    this.http
      .get<PatientHistoryData>(`${this.patientBase()}/history`)
      .subscribe({
        next: (history) => {
          this.healthHistory = history.healthHistory ?? [];
          this.healthConditions = history.healthConditions ?? [];
          this.botox = history.botox ?? [];
          this.cdr.markForCheck();
          this.progressChange.emit();
        },

        error: (error) => {
          console.error("Unable to reload patient history:", error);

          this.cdr.markForCheck();
        },
      });
  }

  addHealthHistory(): void {
    if (
      !this.patientId ||
      !this.newHistoryConditionCode ||
      !this.newHistoryAge
    ) {
      this.historyError = !this.newHistoryAge
        ? translate(REQUIRED_MESSAGE, this.language)
        : "Please select a condition before moving to the next question.";

      return;
    }

    this.historySaving = true;

    this.historyError = "";

    this.http
      .post<HealthHistoryEntry>(
        `${this.patientBase()}/history/health-history`,
        {
          age: this.newHistoryAge,
          conditionCode: this.newHistoryConditionCode,
        },
      )
      .subscribe({
        next: () => {
          this.newHistoryConditionCode = "";
          this.newHistoryAge = "";
          this.historySaving = false;
          this.reloadPatientHistory();
        },

        error: (error) => {
          console.error("Unable to add health history item:", error);
          this.historySaving = false;
          this.historyError = "Unable to add. Please try again.";
          this.cdr.markForCheck();
        },
      });
  }

  availableConditionOptions(): ConditionOption[] {
    const existing = new Set(
      this.healthConditions.map((item) =>
        (item.conditionCode ?? "").trim().toLowerCase(),
      ),
    );

    return this.conditionOptions.filter(
      (option) => !existing.has(option.code.trim().toLowerCase()),
    );
  }

  pendingConditions = new Set<string>();

  isConditionPending(code: string): boolean {
    return this.pendingConditions.has(code);
  }

  togglePendingCondition(code: string): void {
    if (this.pendingConditions.has(code)) {
      this.pendingConditions.delete(code);
    } else {
      this.pendingConditions.add(code);
    }

    this.progressChange.emit();
  }

  askDeleteCondition(id: number): void {
    this.confirmingConditionId = id;
  }

  cancelDeleteCondition(): void {
    this.confirmingConditionId = null;
  }

  get confirmingCondition(): HealthConditionEntry | undefined {
    return this.healthConditions.find(
      (entry) => entry.id === this.confirmingConditionId,
    );
  }

  confirmDeleteCondition(): void {
    const id = this.confirmingConditionId;

    if (!this.patientId || id === null) {
      return;
    }

    this.http
      .delete<void>(`${this.patientBase()}/history/health-conditions/${id}`)
      .subscribe({
        next: () => {
          this.confirmingConditionId = null;
          this.reloadPatientHistory();
        },

        error: (error) => {
          console.error("Unable to remove health condition:", error);
          this.conditionError = "Unable to remove. Please try again.";
          this.cdr.markForCheck();
        },
      });
  }

  get hasSeizuresCondition(): boolean {
    const recorded = this.healthConditions.some((entry) => {
      const text = `${entry.conditionCode ?? ""} ${
        entry.conditionDescription ?? ""
      }`.toLowerCase();

      return entry.conditionCode === "SEIZ" || text.includes("seizure");
    });

    return recorded || this.pendingConditions.has("SEIZ");
  }

  get seizureMedRows(): Row[] {
    return this.medications?.lists["medications"] ?? [];
  }

  rowName(row: Row): string {
    return String(row["name"] ?? "");
  }

  availableSeizureMeds(): string[] {
    return this.seizureMedOptions;
  }

  isSeizureMedSelected(name: string): boolean {
    const normalizedName = name.trim().toLowerCase();

    return (
      this.seizureMedRows.some(
        (row) => this.rowName(row).trim().toLowerCase() === normalizedName,
      ) ||
      this.pendingSeizureMeds.some(
        (pendingName) => pendingName.trim().toLowerCase() === normalizedName,
      )
    );
  }

  toggleSeizureMed(name: string, event: Event): void {
    const selected =
      event.target instanceof HTMLInputElement && event.target.checked;

    if (selected) {
      this.addSeizureMed(name);
    } else {
      this.removeSeizureMed(name);
    }
  }

  addSeizureMed(name: string): void {
    const trimmed = name.trim();

    if (!trimmed || !this.medications) {
      return;
    }

    if (this.isSeizureMedSelected(trimmed)) {
      return;
    }
    this.pendingSeizureMeds = [...this.pendingSeizureMeds, trimmed];
    this.progressChange.emit();
  }

  addCustomSeizureMed(): void {
    this.addSeizureMed(this.customSeizureMed);
    this.customSeizureMed = "";
  }

  removeSeizureMed(name: string): void {
    if (!this.medications) {
      return;
    }

    this.pendingSeizureMeds = this.pendingSeizureMeds.filter(
      (pendingName) => pendingName.toLowerCase() !== name.toLowerCase(),
    );

    const rows = this.medications.lists["medications"] ?? [];

    this.medications.lists["medications"] = rows.filter(
      (row) => row["name"] !== name,
    );

    this.progressChange.emit();
  }

  addBotox(): void {
    if (!this.patientId) {
      return;
    }

    this.botoxSaving = true;
    this.botoxError = "";
    this.http
      .post<BotoxHistory>(`${this.patientBase()}/history/botox`, this.newBotox)
      .subscribe({
        next: () => {
          this.newBotox = {
            bodyLocation: "",
            date: "",
            side: "",
            facility: "",
            physician: "",
          };

          this.botoxSaving = false;
          this.showBotoxForm = false;
          this.reloadPatientHistory();
        },

        error: (error) => {
          console.error("Unable to add botox shot:", error);
          this.botoxSaving = false;
          this.botoxError = "Unable to add. Please try again.";
          this.cdr.markForCheck();
        },
      });
  }

  get deviceRows(): Row[] {
    return this.details?.lists["devices"] ?? [];
  }

  deviceHasSide(name: string): boolean {
    return name === "Crutch" || name === "Cane";
  }

  availableDevices(): string[] {
    return this.options?.devices ?? [];
  }

  isDeviceSelected(name: string): boolean {
    const normalizedName = name.trim().toLowerCase();

    return [...this.deviceRows, ...this.pendingDevices].some(
      (row) => String(row["name"] ?? "").trim().toLowerCase() === normalizedName,
    );
  }

  toggleDevice(name: string, event: Event): void {
    const selected =
      event.target instanceof HTMLInputElement && event.target.checked;
    const existing = this.deviceRows.some(
      (row) => String(row["name"] ?? "").toLowerCase() === name.toLowerCase(),
    );

    if (selected) {
      if (!existing && !this.isDeviceSelected(name)) {
        this.stageDevice(name);
      }
    } else if (existing) {
      this.removeDevice(name);
    } else {
      this.pendingDevices = this.pendingDevices.filter(
        (row) => String(row["name"] ?? "").toLowerCase() !== name.toLowerCase(),
      );
    }

    this.progressChange.emit();
  }

  private stageDevice(name: string): void {
    const trimmed = name.trim();

    if (!trimmed || this.isDeviceSelected(trimmed)) {
      return;
    }

    this.pendingDevices = [
      ...this.pendingDevices,
      {
        id: null,
        name: trimmed,
        side: this.deviceHasSide(trimmed) ? this.pendingSide(trimmed) : null,
      },
    ];
  }

  pendingSide(name: string): string {
    return this.pendingDeviceSide[name] ?? "Both";
  }

  setPendingSide(
    name: string,

    side: string,
  ): void {
    this.pendingDeviceSide[name] = side;
    this.pendingDevices = this.pendingDevices.map((row) =>
      row["name"] === name ? { ...row, side } : row,
    );
  }

  addDevice(name: string): void {
    this.stageDevice(name);
    this.progressChange.emit();
  }

  addCustomDevice(): void {
    const name = this.customDevice.trim();

    if (name) {
      this.stageDevice(name);
    }

    if (name) {
      this.customDevice = "";
    }

    this.progressChange.emit();
  }

  removeDevice(name: string): void {
    if (!this.details) {
      return;
    }

    this.pendingDevices = this.pendingDevices.filter(
      (row) => String(row["name"] ?? "") !== name,
    );

    const rows = this.details.lists["devices"] ?? [];

    this.details.lists["devices"] = rows.filter((row) => row["name"] !== name);

    this.progressChange.emit();
  }

  private normalizeSide(
    value: string | number | null | undefined,
  ): string | null {
    const side = String(value ?? "");

    if (!side) {
      return null;
    }

    const lower = side.toLowerCase();

    return lower === "left" ? "L" : lower === "right" ? "R" : side;
  }

  painSideChoices(bodyPart: string): {
    value: string;

    label: string;
  }[] {
    return bodyPart === "Back"
      ? [
          {
            value: "Upper",
            label: this.text("Upper"),
          },

          {
            value: "Lower",
            label: this.text("Lower"),
          },

          {
            value: "None",
            label: this.text("None"),
          },
        ]
      : [
          {
            value: "L",
            label: this.text("Left#pain"),
          },

          {
            value: "R",
            label: this.text("Right#pain"),
          },

          {
            value: "Both",
            label: this.text("Both#pain"),
          },

          {
            value: "None",
            label: this.text("None"),
          },
        ];
  }

  painSide(bodyPart: string): string {
    const row = this.details?.lists["pain"]?.find(
      (row) => row["bodyPart"] === bodyPart,
    );

    return row ? (this.normalizeSide(row["side"]) ?? "None") : "None";
  }

  setPainSide(
    bodyPart: string,

    side: string,
  ): void {
    if (!this.details) {
      return;
    }

    const rows = this.details.lists["pain"] ?? [];

    const others = rows.filter((row) => row["bodyPart"] !== bodyPart);

    if (side === "None") {
      this.details.lists["pain"] = others;

      this.progressChange.emit();

      return;
    }

    const existing = rows.find((row) => row["bodyPart"] === bodyPart);

    this.details.lists["pain"] = [
      ...others,

      {
        id: existing ? existing["id"] : null,

        bodyPart,
        side,
      },
    ];

    this.progressChange.emit();
  }

  get gaitConcernRows(): Row[] {
    return this.details?.lists["gaitConcerns"] ?? [];
  }

  gaitConcernLabel(code: string | number | null): string {
    const choice = (this.options?.gaitConcerns ?? []).find(
      (item) => item.value === code,
    );

    return choice?.label ?? String(code ?? "");
  }

  availableGaitConcerns(): Choice[] {
    const added = new Set(this.gaitConcernRows.map((row) => row["code"]));

    return (this.options?.gaitConcerns ?? []).filter(
      (choice) => !added.has(choice.value),
    );
  }

  isGaitConcernSelected(code: string | number | null): boolean {
    return this.pendingGaitConcerns.includes(code);
  }

  toggleGaitConcern(code: string | number | null, event: Event): void {
    const selected =
      event.target instanceof HTMLInputElement && event.target.checked;

    if (selected) {
      this.addGaitConcern(code);
    } else {
      this.pendingGaitConcerns = this.pendingGaitConcerns.filter(
        (pendingCode) => pendingCode !== code,
      );

      this.progressChange.emit();
    }
  }

  addGaitConcern(code: string | number | null): void {
    if (
      !this.details ||
      this.gaitConcernRows.some((row) => row["code"] === code) ||
      this.pendingGaitConcerns.includes(code)
    ) {
      return;
    }

    this.pendingGaitConcerns = [...this.pendingGaitConcerns, code];

    this.progressChange.emit();
  }

  removeGaitConcern(code: string | number | null): void {
    if (!this.details) {
      return;
    }

    const rows = this.details.lists["gaitConcerns"] ?? [];

    this.details.lists["gaitConcerns"] = rows.filter(
      (row) => row["code"] !== code,
    );

    this.progressChange.emit();
  }

  getProgress(): QuestionnaireProgressValue {
    const fields = this.items?.fields ?? {};

    const blank = (value: unknown) =>
      value === null || value === undefined || value === "" || value === "--";

    const keys: string[] = [];

    if (this.showWho) {
      keys.push("reportingPerson", "relationship");
    }

    if (this.showGait) {
      keys.push(
        "walkingSupportCode",
        "fms5Id",
        "fms50Id",
        "fms500Id",
        "walkingChange",
      );
    }

    return {
      answered: keys.filter((key) => !blank(fields[key])).length,

      total: keys.length,
    };
  }

  validate(): string | null {
    return this.getInvalidFields().length > 0
      ? translate(REQUIRED_MESSAGE, this.language)
      : null;
  }

  getInvalidFields(): string[] {
    const fields = this.items?.fields;

    if (!fields) {
      return [];
    }

    const blank = (value: unknown) =>
      value === null || value === undefined || value === "" || value === "--";

    const invalid: string[] = [];

    if (
      this.showWho &&
      blank(fields["reportingPerson"])
    ) {
      invalid.push("reportingPerson");
    }

    if (this.showWho && blank(fields["relationship"])) {
      invalid.push("relationship");
    }

    if (this.showGait) {
      const keys = [
        "walkingSupportCode",
        "fms5Id",
        "fms50Id",
        "fms500Id",
        "walkingChange",
      ];

      invalid.push(...keys.filter((key) => blank(fields[key])));
    }

    return invalid;
  }

  save(): void {
    if (
      !this.patientId ||
      !this.visitId ||
      !this.items ||
      !this.details ||
      !this.medications
    ) {
      this.saveComplete.emit();

      return;
    }

    if (!this.showWho && this.copyWho) {
      if (this.copyWho.person) {
        this.items.fields["reportingPerson"] = this.copyWho.person;
      }

      if (this.copyWho.relationship) {
        this.items.fields["relationship"] = this.copyWho.relationship;
      }
    }

    for (const key of [
      "reportingPerson",
      "relationship",
      "walkingSupportCode",
      "walkingChange",
    ]) {
      if (
        this.items.fields[key] === null ||
        this.items.fields[key] === undefined
      ) {
        this.items.fields[key] = "";
      }
    }

    for (const key of ["followup", "generalConcerns"]) {
      if (
        this.details.fields[key] === null ||
        this.details.fields[key] === undefined
      ) {
        this.details.fields[key] = "";
      }
    }

    this.saving = true;

    this.saveError = "";

    const pending = [...this.pendingConditions];
    const detailsToSave: Section = {
      ...this.details,
      fields: { ...this.details.fields },
      lists: {
        ...this.details.lists,
        devices: [
          ...(this.details.lists["devices"] ?? []),
          ...this.pendingDevices,
        ],
        gaitConcerns: [
          ...(this.details.lists["gaitConcerns"] ?? []),
          ...this.pendingGaitConcerns
            .filter(
              (code) =>
                !(this.details!.lists["gaitConcerns"] ?? []).some(
                  (row) => row["code"] === code,
                ),
            )
            .map((code) => ({ id: null, code })),
        ],
      },
    };
    const medicationsToSave: Section = {
      ...this.medications,
      fields: { ...this.medications.fields },
      lists: {
        ...this.medications.lists,
        medications: [
          ...(this.medications.lists["medications"] ?? []),
          ...this.pendingSeizureMeds
            .filter((name) => !this.isSeizureMedInRows(name))
            .map((name) => ({ id: null, name })),
        ],
      },
    };

    const addConditions = from(pending).pipe(
      concatMap((code) =>
        this.http
          .post<HealthConditionEntry>(
            `${this.patientBase()}/history/health-conditions`,
            {
              conditionCode: code,
            },
          )
          .pipe(tap(() => this.pendingConditions.delete(code))),
      ),

      toArray(),
    );

    const put = (
      part: string,

      body: Section,
    ) =>
      this.http
        .put<void>(`${this.base()}/visits/${this.visitId}/${part}`, body)
        .pipe(
          map(() => null as string | null),

          catchError((error) => {
            console.error(`Unable to save History (${part}):`, error);

            return of(part as string | null);
          }),
        );

    addConditions
      .pipe(
        switchMap(() =>
          forkJoin([
            put("items", this.items!),

            put("details", detailsToSave),

            put("medications", medicationsToSave),
          ]),
        ),
      )
      .subscribe({
        next: (results) => {
          if (pending.length > 0) {
            this.reloadPatientHistory();
          }

          if (results[1] === null) {
            this.details!.lists["devices"] =
              detailsToSave.lists["devices"] ?? [];

            this.pendingDevices = [];

            this.details!.lists["gaitConcerns"] =
              detailsToSave.lists["gaitConcerns"] ?? [];

            this.pendingGaitConcerns = [];
          }

          if (results[2] === null) {
            this.medications!.lists["medications"] =
              medicationsToSave.lists["medications"] ?? [];

            this.pendingSeizureMeds = [];
          }

          const failed = results.filter(
            (part): part is string => part !== null,
          );

          this.saving = false;

          if (failed.length > 0) {
            this.saveError = `Unable to save (${failed.join(", ")}). Please try again.`;

            this.cdr.markForCheck();

            this.saveFailed.emit(this.saveError);

            return;
          }

          this.saved = true;

          this.cdr.markForCheck();

          this.progressChange.emit();

          this.saveComplete.emit();
        },

        error: (error) => {
          console.error("Unable to add health conditions:", error);

          if (pending.length !== this.pendingConditions.size) {
            this.reloadPatientHistory();
          }

          this.saving = false;

          this.saveError =
            "Unable to save the ticked conditions. Please try again.";

          this.cdr.markForCheck();

          this.saveFailed.emit(this.saveError);
        },
      });
  }

  private isSeizureMedInRows(name: string): boolean {
    const normalizedName = name.trim().toLowerCase();

    return this.seizureMedRows.some(
      (row) => this.rowName(row).trim().toLowerCase() === normalizedName,
    );
  }
}
