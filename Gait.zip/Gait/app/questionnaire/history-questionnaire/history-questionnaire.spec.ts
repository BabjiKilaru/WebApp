import { vi } from 'vitest';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { HistoryQuestionnaire } from './history-questionnaire';

describe('HistoryQuestionnaire', () => {
    let component: HistoryQuestionnaire;
    let http: HttpTestingController;
    beforeEach(async () => {
        await TestBed.configureTestingModule({ imports: [HistoryQuestionnaire], providers: [provideHttpClient(), provideHttpClientTesting()] })
            .overrideComponent(HistoryQuestionnaire, { set: { template: '' } }).compileComponents();
        component = TestBed.createComponent(HistoryQuestionnaire).componentInstance;
        http = TestBed.inject(HttpTestingController);
    });
    afterEach(() => http.verify());
    it('requires the reporter and gait details when those sections are enabled', () => {
        component.items = { fields: {}, lists: {}, version: '1' };
        expect(component.getProgress().total).toBe(7);
        expect(component.getInvalidFields()).toContain('reportingPerson');
        expect(component.getInvalidFields()).toContain('walkingSupportCode');
        expect(component.validate()).not.toBeNull();
    });
    it('excludes hidden sections from validation and progress', () => {
        component.items = { fields: {}, lists: {}, version: '1' };
        component.showWho = false;
        component.showGait = false;
        expect(component.getProgress()).toEqual({ answered: 0, total: 0 });
        expect(component.getInvalidFields()).toEqual([]);
        expect(component.validate()).toBeNull();
    });
    it('does not send a save request without a valid loaded visit', () => {
        const saved = vi.fn();
        component.saveComplete.subscribe(saved);
        component.save();
        expect(saved).toHaveBeenCalledOnce();
        http.expectNone(request => request.method === 'POST' || request.method === 'PUT');
    });
});
