// GENERATED from the legacy PODCI JSPs (clinconn/lab/q2/q2_{ch,ap,as}_001..027.jsp) by a script that
// parses each page's DOM: page text, option/scale labels, radio values, checkbox names. Do not hand-edit
// wording here — regenerate from source instead. English = the JSP's English branch; Spanish exists only
// for the CH (parent-reported child) pages, which switch language per session; AP/AS are English-only in
// legacy (their Spanish falls back to English). "[name]" is the patient's first name (currFName).
export type PodciLang = "en" | "sp";
export interface PodciOption {
  value: number;
  label: string;
}
export type PodciBlock =
  | { t: "text"; text: string }
  | { t: "radios"; name: string; options: PodciOption[] }
  | { t: "scale"; columns: string[]; rows: { name: string; text: string }[] }
  | {
      t: "grid";
      columns: string[];
      rows: {
        label: string;
        cells: { name: string; options: PodciOption[] }[];
      }[];
    }
  | { t: "checks"; items: { name: string; label: string; rowLabel: string }[] }
  | { t: "textarea"; name: string };
export interface PodciPage {
  n: number;
  blocks: { en: PodciBlock[]; sp?: PodciBlock[] };
  required?: string[];
}
export type PodciBankVariant = "CH" | "AP" | "AS";

export const PODCI_BANK: Record<PodciBankVariant, PodciPage[]> = {
  CH: [
    {
      n: 0,
      blocks: {
        en: [
          {
            t: "text",
            text: "The following is a survey designed by a group of doctors [1] to measure the quality of life of the children they treat.",
          },
          {
            t: "text",
            text: "Your answers will help us to understand how your child's condition affects his or her daily functions and overall happiness.",
          },
          {
            t: "text",
            text: "It will also let us see if the treatment your child receives improves his or her quality of life.",
          },
          {
            t: "text",
            text: "We appreciate your input and thank you for allowing us to provide this service.",
          },
          {
            t: "text",
            text: "[1] The Pediatric Outcomes Data Collection Instrument (PODCI), Version 2.0, revised Aug 2005.",
          },
        ],
        sp: [
          {
            t: "text",
            text: "Le pedimos que complete esta encuesta sobre [name], a fin de entender mejor su salud en general, así como problemas relacionados con condiciones de los huesos y de los músculos. El completar esta encuesta es voluntario. Sus respuestas se mantendrán en la más estricta confidencialidad. Se tomará de 15 a 20 minutos para completarse.",
          },
          {
            t: "text",
            text: "Por favor, conteste cada una de las preguntas. Es posible que algunas preguntas se parezcan a otras, pero cada una es diferente.",
          },
          {
            t: "text",
            text: "Conteste las preguntas, poniendo un círculo en el número apropiado, o escribiendo la respuesta, según se requiera.",
          },
          {
            t: "text",
            text: "No hay respuestas correctas, ni incorrectas. Si no está seguro sobre cómo contestar una pregunta, por favor, dé la mejor respuesta que pueda dar, y escriba un comentario en el margen. Leeremos todos sus comentarios, así que siéntase en libertad de hacer tantos comentarios como quiera.",
          },
          {
            t: "text",
            text: "[1] The Pediatric Outcomes Data Collection Instrument (PODCI), Version 2.0, revised Aug 2005.",
          },
        ],
      },
    },
    {
      n: 1,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          { t: "text", text: "In general, would you say [name]'s health is:" },
          {
            t: "radios",
            name: "q2_005",
            options: [
              { value: 1, label: "Excellent" },
              { value: 2, label: "Very Good" },
              { value: 3, label: "Good" },
              { value: 4, label: "Fair" },
              { value: 5, label: "Poor" },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          { t: "text", text: "En general, diría que la salud de [name] es:" },
          {
            t: "radios",
            name: "q2_005",
            options: [
              { value: 1, label: "Excelente" },
              { value: 2, label: "Muy buena" },
              { value: 3, label: "Buena" },
              { value: 4, label: "Regular" },
              { value: 5, label: "Mala" },
            ],
          },
        ],
      },
    },
    {
      n: 2,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Compared to one year ago, how would you rate [name]'s health in general:",
          },
          {
            t: "radios",
            name: "q2_006",
            options: [
              { value: 1, label: "Much better now than one year ago" },
              { value: 2, label: "Somewhat better now than one year ago" },
              { value: 3, label: "About the same as one year ago" },
              { value: 4, label: "Somewhat worse now than one year ago" },
              { value: 5, label: "Much worse now than one year ago" },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "Comparado con un año atrás, ¿cómo calificaría la salud de [name] en general ahora?",
          },
          {
            t: "radios",
            name: "q2_006",
            options: [
              { value: 1, label: "Mucho mejor que hace un año" },
              { value: 2, label: "Algo mejor que hace un año" },
              { value: 3, label: "Casi igual" },
              { value: 4, label: "Algo peor que hace un año" },
              { value: 5, label: "Mucho peor que hace un año" },
            ],
          },
        ],
      },
    },
    {
      n: 3,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Have you ever been told by a doctor, nurse, teacher, or other health professional that [name] has had any of the following conditions?",
          },
          {
            t: "text",
            text: "If yes, indicate if your child is being treated for this condition and if your child is limited by those conditions.",
          },
          {
            t: "grid",
            columns: [
              "Has your child ever had it?",
              "Does your child receive treatment for it now?",
              "Are your child's activities limited by it now?",
            ],
            rows: [
              {
                label: "Juvenile Arthritis (one or two joints)",
                cells: [
                  {
                    name: "q2_007a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_007b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_007c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Juvenile Arthritis (many joints)",
                cells: [
                  {
                    name: "q2_008a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_008b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_008c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Anorexia or bulemia (eating disorders)",
                cells: [
                  {
                    name: "q2_009a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_009b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_009c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Asthma",
                cells: [
                  {
                    name: "q2_010a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_010b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_010c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Attention or behavioral problems",
                cells: [
                  {
                    name: "q2_011a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_011b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_011c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Chronic allergies or sinus trouble",
                cells: [
                  {
                    name: "q2_012a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_012b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_012c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Developmental delay",
                cells: [
                  {
                    name: "q2_013a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_013b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_013c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Cognitive Impairment",
                cells: [
                  {
                    name: "q2_014a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_014b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_014c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Diabetes",
                cells: [
                  {
                    name: "q2_015a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_015b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_015c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Epilepsy (seizure disorder)",
                cells: [
                  {
                    name: "q2_016a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_016b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_016c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Hearing impairment or deafness",
                cells: [
                  {
                    name: "q2_017a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_017b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_017c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Heart problem",
                cells: [
                  {
                    name: "q2_018a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_018b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_018c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Learning problem",
                cells: [
                  {
                    name: "q2_019a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_019b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_019c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Sleep disturbance",
                cells: [
                  {
                    name: "q2_020a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_020b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_020c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Speech problems",
                cells: [
                  {
                    name: "q2_021a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_021b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_021c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Vision problems",
                cells: [
                  {
                    name: "q2_022a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_022b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_022c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "¿Alguna vez le ha dicho un(a) doctor(a), enfermero(a), maestro(a) u otro profesional médico que [name] ha tenido alguna de las siguientes condiciones?",
          },
          {
            t: "text",
            text: "Si la respuesta es sí, indique si a su niño(a) se le está tratando para esta condición, y si su niño(a) está limitado(a) a causa de estas condiciones.",
          },
          {
            t: "grid",
            columns: [
              "¿La ha tenido [name] alguna vez?",
              "¿Recibe [name] tratamiento para ésta ahora?",
              "¿Están limitadas las actividades de [name] por ésta ahora?",
            ],
            rows: [
              {
                label: "Artritis juvenil (una o dos articulaciones)",
                cells: [
                  {
                    name: "q2_007a",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_007b",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_007c",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Artritis juvenil (varias articulaciones)",
                cells: [
                  {
                    name: "q2_008a",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_008b",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_008c",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Anorexia o bulimia (Problemas de alimentación)",
                cells: [
                  {
                    name: "q2_009a",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_009b",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_009c",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Asma",
                cells: [
                  {
                    name: "q2_010a",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_010b",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_010c",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Problemas de atención o comportamiento",
                cells: [
                  {
                    name: "q2_011a",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_011b",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_011c",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Alergias crónicas o problemas de sinusitis",
                cells: [
                  {
                    name: "q2_012a",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_012b",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_012c",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Retraso del desarrollo",
                cells: [
                  {
                    name: "q2_013a",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_013b",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_013c",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Retraso mental",
                cells: [
                  {
                    name: "q2_014a",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_014b",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_014c",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Diabetes",
                cells: [
                  {
                    name: "q2_015a",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_015b",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_015c",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Epilepsia (ataques)",
                cells: [
                  {
                    name: "q2_016a",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_016b",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_016c",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Problemas del oído o sordera",
                cells: [
                  {
                    name: "q2_017a",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_017b",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_017c",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Problemas del corazón",
                cells: [
                  {
                    name: "q2_018a",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_018b",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_018c",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Problemas de aprendizaje",
                cells: [
                  {
                    name: "q2_019a",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_019b",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_019c",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Trastornos del sueño",
                cells: [
                  {
                    name: "q2_020a",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_020b",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_020c",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Problemas del habla",
                cells: [
                  {
                    name: "q2_021a",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_021b",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_021c",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Problemas de la vista",
                cells: [
                  {
                    name: "q2_022a",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_022b",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_022c",
                    options: [
                      { value: 1, label: "Sí" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
            ],
          },
        ],
      },
      required: [
        "q2_007a",
        "q2_008a",
        "q2_009a",
        "q2_010a",
        "q2_011a",
        "q2_012a",
        "q2_013a",
        "q2_014a",
        "q2_015a",
        "q2_016a",
        "q2_017a",
        "q2_018a",
        "q2_019a",
        "q2_020a",
        "q2_021a",
        "q2_022a",
        "q2_007b",
        "q2_008b",
        "q2_009b",
        "q2_010b",
        "q2_011b",
        "q2_012b",
        "q2_013b",
        "q2_014b",
        "q2_015b",
        "q2_016b",
        "q2_017b",
        "q2_018b",
        "q2_019b",
        "q2_020b",
        "q2_021b",
        "q2_022b",
        "q2_007c",
        "q2_008c",
        "q2_009c",
        "q2_010c",
        "q2_011c",
        "q2_012c",
        "q2_013c",
        "q2_014c",
        "q2_015c",
        "q2_016c",
        "q2_017c",
        "q2_018c",
        "q2_019c",
        "q2_020c",
        "q2_021c",
        "q2_022c",
      ],
    },
    {
      n: 4,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "For [name]'s front right side, please indicate those areas that bother him/her or limit his/her function.",
          },
          {
            t: "checks",
            items: [
              { name: "q2_023a", label: "Neck", rowLabel: "" },
              { name: "q2_023b", label: "Shoulder area", rowLabel: "" },
              { name: "q2_023c", label: "Elbow/Forearm", rowLabel: "" },
              { name: "q2_023d", label: "Wrist/Hand", rowLabel: "" },
              { name: "q2_023e", label: "Hip", rowLabel: "" },
              { name: "q2_023f", label: "Thigh", rowLabel: "" },
              { name: "q2_023g", label: "Knee area", rowLabel: "" },
              { name: "q2_023h", label: "Calf area", rowLabel: "" },
              { name: "q2_023i", label: "Ankle/Foot area", rowLabel: "" },
            ],
          },
          {
            t: "text",
            text: "For [name]'s front left side, please indicate those areas that bother him/her or limit his/her function.",
          },
          {
            t: "checks",
            items: [
              { name: "q2_024a", label: "Neck", rowLabel: "" },
              { name: "q2_024b", label: "Shoulder area", rowLabel: "" },
              { name: "q2_024c", label: "Elbow/Forearm", rowLabel: "" },
              { name: "q2_024d", label: "Wrist/Hand", rowLabel: "" },
              { name: "q2_024e", label: "Hip", rowLabel: "" },
              { name: "q2_024f", label: "Thigh", rowLabel: "" },
              { name: "q2_024g", label: "Knee area", rowLabel: "" },
              { name: "q2_024h", label: "Calf area", rowLabel: "" },
              { name: "q2_024i", label: "Ankle/Foot area", rowLabel: "" },
            ],
          },
          {
            t: "text",
            text: "For [name]'s back, please indicate those areas that bother him/her or limit his/her function.",
          },
          {
            t: "checks",
            items: [
              { name: "q2_025a", label: "Neck", rowLabel: "" },
              { name: "q2_025b", label: "Upper Back", rowLabel: "" },
              { name: "q2_025c", label: "Lower Back", rowLabel: "" },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "Para el lado derecho del cuerpo, por favor indique aquellas áreas que le producen molestias a [name] o limitan su funcionamiento.",
          },
          {
            t: "checks",
            items: [
              { name: "q2_023a", label: "Cuello", rowLabel: "" },
              { name: "q2_023b", label: "Área del Hombro", rowLabel: "" },
              { name: "q2_023c", label: "Codo/Antebrazo", rowLabel: "" },
              { name: "q2_023d", label: "Muñeca/Mano", rowLabel: "" },
              { name: "q2_023e", label: "Cadera", rowLabel: "" },
              { name: "q2_023f", label: "Muslo", rowLabel: "" },
              { name: "q2_023g", label: "Área de la Rodilla", rowLabel: "" },
              { name: "q2_023h", label: "Área de la Pantorilla", rowLabel: "" },
              { name: "q2_023i", label: "Área del Tobillo/Pie", rowLabel: "" },
            ],
          },
          {
            t: "text",
            text: "Para el lado izquierdo del cuerpo, por favor indique aquellas áreas que le producen molestias a [name] o limitan su funcionamiento.",
          },
          {
            t: "checks",
            items: [
              { name: "q2_024a", label: "Cuello", rowLabel: "" },
              { name: "q2_024b", label: "Área del Hombro", rowLabel: "" },
              { name: "q2_024c", label: "Codo/Antebrazo", rowLabel: "" },
              { name: "q2_024d", label: "Muñeca/Mano", rowLabel: "" },
              { name: "q2_024e", label: "Cadera", rowLabel: "" },
              { name: "q2_024f", label: "Muslo", rowLabel: "" },
              { name: "q2_024g", label: "Área de la Rodilla", rowLabel: "" },
              { name: "q2_024h", label: "Área de la Pantorilla", rowLabel: "" },
              { name: "q2_024i", label: "Área del Tobillo/Pie", rowLabel: "" },
            ],
          },
          {
            t: "text",
            text: "En la parte de la espalda, por favor indique aquellas áreas que le producen molestias a [name] o limitan su funcionamiento",
          },
          {
            t: "checks",
            items: [
              { name: "q2_025a", label: "Cuello", rowLabel: "" },
              { name: "q2_025b", label: "Espalda alta", rowLabel: "" },
              { name: "q2_025c", label: "Espalda baja", rowLabel: "" },
            ],
          },
        ],
      },
    },
    {
      n: 5,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Some kinds of problems can make it hard to do many activities, such as eating, bathing, school work, and playing with friends.",
          },
          { t: "text", text: "We would like to find out how [name] is doing." },
          {
            t: "text",
            text: "During the last week was it easy or hard for your child to:",
          },
          {
            t: "scale",
            columns: [
              "Easy",
              "A little hard",
              "Very hard",
              "Can't do at all",
              "Too young for this activity",
            ],
            rows: [
              { name: "q2_026", text: "Lift heavy books?" },
              { name: "q2_027", text: "Pour a half gallon of milk?" },
              {
                name: "q2_028",
                text: "Open a jar that has been opened before?",
              },
              { name: "q2_029", text: "Use a fork and spoon?" },
              { name: "q2_030", text: "Comb his/her hair?" },
              { name: "q2_031", text: "Button buttons?" },
              { name: "q2_032x", text: "Put on his/her coat?" },
              { name: "q2_033", text: "Write with a pencil?" },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "Algunas tipos de problemas pueden dificultar realizar muchas actividades, como comer, bañarse, tareas escolares y jugar con los amigos.",
          },
          { t: "text", text: "Nos gustaría saber cómo está [name]." },
          {
            t: "text",
            text: "Durante la semana pasada ¿fue fácil o difícil para [name]:",
          },
          {
            t: "scale",
            columns: [
              "Fácil",
              "Un poco difícil",
              "Muy difícil",
              "No puede hacerlo",
              "Muy joven para esta actividad",
            ],
            rows: [
              { name: "q2_026", text: "levantar libros pesados?" },
              { name: "q2_027", text: "servir un medio galón de leche?" },
              {
                name: "q2_028",
                text: "abrir un frasco que se ha abierto anteriormente?",
              },
              { name: "q2_029", text: "usar un tenedor y una cuchara?" },
              { name: "q2_030", text: "peinarse el pelo?" },
              { name: "q2_031", text: "abrocharse los botones?" },
              { name: "q2_032x", text: "ponerse los calcetines?" },
              { name: "q2_033", text: "escribir con un lápiz?" },
            ],
          },
        ],
      },
    },
    {
      n: 6,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "On average, over the last 12 months, how often did [name] miss school (preschool, day care, camp, etc.) because of his/her health?",
          },
          {
            t: "radios",
            name: "q2_034",
            options: [
              { value: 1, label: "Rarely" },
              { value: 2, label: "Once a month" },
              { value: 3, label: "Two or three times a month" },
              { value: 4, label: "Once a week" },
              { value: 5, label: "More than once a week" },
              { value: 6, label: "Does not attend school, etc." },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "En un promedio, durante los últimos 12 meses, ¿con qué frecuencia faltó [name] a la escuela (kinder, guardería, campamento, etc.) debido a su salud?",
          },
          {
            t: "radios",
            name: "q2_034",
            options: [
              { value: 1, label: "Rara vez" },
              { value: 2, label: "Una vez al mes" },
              { value: 3, label: "Dos o tres veces al mes" },
              { value: 4, label: "Una vez a la semana" },
              { value: 5, label: "Más de una vez a la semana" },
              { value: 6, label: "No va a la escuela, etc." },
            ],
          },
        ],
      },
      required: ["q2_034"],
    },
    {
      n: 7,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "During the last week, how happy has [name] been with:",
          },
          {
            t: "scale",
            columns: [
              "Very happy",
              "Somewhat happy",
              "Not sure",
              "Somewhat unhappy",
              "Very unhappy",
              "Child is too young",
            ],
            rows: [
              { name: "q2_035", text: "How he/she looks?" },
              { name: "q2_036", text: "His/her body?" },
              { name: "q2_037", text: "What clothes or shoes he/she can wear" },
              {
                name: "q2_038",
                text: "His/her ability to do the same things his/her friends do?",
              },
              { name: "q2_039", text: "His/her health in general?" },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "Durante la semana pasada, ¿qué tan feliz ha estado [name] con:",
          },
          {
            t: "scale",
            columns: [
              "Muy feliz",
              "Algo feliz",
              "No estoy seguro(a)",
              "Algo infeliz",
              "Muy infeliz",
              "El niño(a) es muy joven",
            ],
            rows: [
              { name: "q2_035", text: "cómo se ve?" },
              { name: "q2_036", text: "su cuerpo?" },
              { name: "q2_037", text: "la ropa o zapatos que puede usar?" },
              {
                name: "q2_038",
                text: "su habilidad para hacer las mismas cosas que hacen sus amigos?",
              },
              { name: "q2_039", text: "su salud en general?" },
            ],
          },
        ],
      },
      required: ["q2_035", "q2_036", "q2_037", "q2_038", "q2_039"],
    },
    {
      n: 8,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          { t: "text", text: "During the last week, how much of the time:" },
          {
            t: "scale",
            columns: [
              "Most of the time",
              "Some of the time",
              "A little of the time",
              "None of the time",
            ],
            rows: [
              { name: "q2_040", text: "Did [name] feel sick and tired?" },
              { name: "q2_041", text: "Was [name] full of pep and energy?" },
              {
                name: "q2_042",
                text: "Did pain or discomfort interfere with [name]'s activities?",
              },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          { t: "text", text: "Durante la semana pasada, ¿cuánto tiempo:" },
          {
            t: "scale",
            columns: [
              "La mayoría del tiempo",
              "Parte del tiempo",
              "Poco tiempo",
              "En ningún momento",
            ],
            rows: [
              { name: "q2_040", text: "se sintió [name] mal y cansado(a)?" },
              {
                name: "q2_041",
                text: "se sintió [name] lleno(a) de vigor y energía?",
              },
              {
                name: "q2_042",
                text: "interfirió el dolor o malestar con las actividades de [name]?",
              },
            ],
          },
        ],
      },
      required: ["q2_040", "q2_041", "q2_042"],
    },
    {
      n: 9,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "During the last week, has it been easy or hard for [name] to:",
          },
          {
            t: "scale",
            columns: [
              "Easy",
              "A little hard",
              "Very hard",
              "Can't do at all",
              "Too young for this activity",
            ],
            rows: [
              { name: "q2_043", text: "Run short distances?" },
              { name: "q2_044", text: "Bicycle or tricycle?" },
              { name: "q2_045", text: "Climb three flights of stairs?" },
              { name: "q2_046", text: "Climb one flight of stairs?" },
              { name: "q2_047", text: "Walk more than a mile?" },
              { name: "q2_048", text: "Walk three blocks?" },
              { name: "q2_049", text: "Walk one block?" },
              { name: "q2_050", text: "Get on and off a bus?" },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "Durante la semana pasada, ¿ha sido fácil o difícil para [name]:",
          },
          {
            t: "scale",
            columns: [
              "Fácil",
              "Un poco difícil",
              "Muy difícil",
              "No puede hacerlo para nada",
              "Muy joven para esta actividad",
            ],
            rows: [
              { name: "q2_043", text: "correr distancias cortas?" },
              { name: "q2_044", text: "andar en bicicleta o triciclo?" },
              { name: "q2_045", text: "subir tres tramos de escaleras?" },
              { name: "q2_046", text: "subir un tramo de escaleras?" },
              { name: "q2_047", text: "caminar más de una milla?" },
              { name: "q2_048", text: "caminar tres cuadras?" },
              { name: "q2_049", text: "caminar una cuadra?" },
              { name: "q2_050", text: "subir o bajar del autobús?" },
            ],
          },
        ],
      },
      required: [
        "q2_043",
        "q2_044",
        "q2_045",
        "q2_046",
        "q2_047",
        "q2_048",
        "q2_049",
        "q2_050",
      ],
    },
    {
      n: 10,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "How often does [name] need help from another person for walking and climbing?",
          },
          {
            t: "radios",
            name: "q2_051",
            options: [
              { value: 1, label: "Never" },
              { value: 2, label: "Sometimes" },
              { value: 3, label: "About half the time" },
              { value: 4, label: "Often" },
              { value: 5, label: "All the time" },
            ],
          },
          {
            t: "text",
            text: "How often does [name] use assistive devices (such as braces, crutches, or wheelchair) for walking and climbing?",
          },
          {
            t: "radios",
            name: "q2_052",
            options: [
              { value: 1, label: "Never" },
              { value: 2, label: "Sometimes" },
              { value: 3, label: "About half the time" },
              { value: 4, label: "Often" },
              { value: 5, label: "All the time" },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "¿Con qué frecuencia necesita [name] ayuda de otra persona para caminar o subir?",
          },
          {
            t: "radios",
            name: "q2_051",
            options: [
              { value: 1, label: "Nunca" },
              { value: 2, label: "Algunas veces" },
              { value: 3, label: "Aproximadamente la mitad del tiempo" },
              { value: 4, label: "Frecuentemente" },
              { value: 5, label: "Todo el tiempo" },
            ],
          },
          {
            t: "text",
            text: "¿Con qué frecuencia usa [name] aparatos auxiliares (como férulas, muletas, andador o sillas de ruedas para caminar o subir?",
          },
          {
            t: "radios",
            name: "q2_052",
            options: [
              { value: 1, label: "Nunca" },
              { value: 2, label: "Algunas veces" },
              { value: 3, label: "Aproximadamente la mitad del tiempo" },
              { value: 4, label: "Frecuentemente" },
              { value: 5, label: "Todo el tiempo" },
            ],
          },
        ],
      },
      required: ["q2_051", "q2_052"],
    },
    {
      n: 11,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "During the last week, has it been easy or hard for [name] to:",
          },
          {
            t: "scale",
            columns: [
              "Easy",
              "A little hard",
              "Very hard",
              "Can't do at all",
              "Too young for this activity",
            ],
            rows: [
              {
                name: "q2_053",
                text: "Stand while washing his/her hands and face at a sink?",
              },
              {
                name: "q2_054",
                text: "Sit in a regular chair without holding on?",
              },
              { name: "q2_055", text: "Get on and off a toilet or chair?" },
              { name: "q2_056", text: "Get in and out of bed?" },
              { name: "q2_057", text: "Turn door knobs?" },
              {
                name: "q2_058",
                text: "Bend over from a standing position and pick up something off the floor?",
              },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "Durante la semana pasada, ¿ha sido fácil o difícil para [name]:",
          },
          {
            t: "scale",
            columns: [
              "Fácil",
              "Un poco difícil",
              "Muy difícil",
              "No puede hacerlo para nada",
              "Muy joven para esta actividad",
            ],
            rows: [
              {
                name: "q2_053",
                text: "estar de pie mientras se lava las manos y cara ?",
              },
              {
                name: "q2_054",
                text: "sentarse en una silla normal sin sujetarse de algo?",
              },
              {
                name: "q2_055",
                text: "sentarse y pararse de un inodoro o silla?",
              },
              { name: "q2_056", text: "acostarse o levantarse de la cama?" },
              {
                name: "q2_057",
                text: "Dar vuelta las perillas de las puertas?",
              },
              {
                name: "q2_058",
                text: "agacharse cuando está de pie para recoger algo del piso?",
              },
            ],
          },
        ],
      },
    },
    {
      n: 12,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "How often does [name] need help from another person for sitting and standing?",
          },
          {
            t: "radios",
            name: "q2_059",
            options: [
              { value: 1, label: "Never" },
              { value: 2, label: "Sometimes" },
              { value: 3, label: "About half the time" },
              { value: 4, label: "Often" },
              { value: 5, label: "All the time" },
            ],
          },
          {
            t: "text",
            text: "How often does [name] use assistive devices (such as braces, crutches, or wheelchair) for sitting and standing?",
          },
          {
            t: "radios",
            name: "q2_060",
            options: [
              { value: 1, label: "Never" },
              { value: 2, label: "Sometimes" },
              { value: 3, label: "About half the time" },
              { value: 4, label: "Often" },
              { value: 5, label: "All the time" },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "¿Con qué frecuencia necesita [name] ayuda de otra persona para sentarse y ponerse de pie?",
          },
          {
            t: "radios",
            name: "q2_059",
            options: [
              { value: 1, label: "Nunca" },
              { value: 2, label: "Algunas veces" },
              { value: 3, label: "Aproximadamente la mitad del tiempo" },
              { value: 4, label: "Frecuentemente" },
              { value: 5, label: "Todo el tiempo" },
            ],
          },
          {
            t: "text",
            text: "¿Con qué frecuencia usa [name] la ayuda de aparatos auxiliares (como férulas, muletas, andador o sillas de ruedas) para sentarse o ponerse de pie?",
          },
          {
            t: "radios",
            name: "q2_060",
            options: [
              { value: 1, label: "Nunca" },
              { value: 2, label: "Algunas veces" },
              { value: 3, label: "Aproximadamente la mitad del tiempo" },
              { value: 4, label: "Frecuentemente" },
              { value: 5, label: "Todo el tiempo" },
            ],
          },
        ],
      },
      required: ["q2_059", "q2_060"],
    },
    {
      n: 13,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Can [name] participate in recreational outdoor activities with other children the same age?",
          },
          {
            t: "text",
            text: "(For example: bicycling, tricycling, skating, hiking, jogging)",
          },
          {
            t: "radios",
            name: "q2_061",
            options: [
              { value: 1, label: "Yes, easily" },
              { value: 2, label: "Yes, but a little hard" },
              { value: 3, label: "Yes, but very hard" },
              { value: 4, label: "No" },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "¿Puede [name] participar en actividades recreativas al aire libre con otros niños de su misma edad?",
          },
          {
            t: "text",
            text: "(Por ejemplo: andar en bicicleta, triciclo, patines, escalar o trotar)",
          },
          {
            t: "radios",
            name: "q2_061",
            options: [
              { value: 1, label: "Sí, fácilmente" },
              { value: 2, label: "Sí, pero es un poco difícil" },
              { value: 3, label: "Sí, pero es muy difícil" },
              { value: 4, label: "No" },
            ],
          },
        ],
      },
      required: ["q2_061"],
    },
    {
      n: 14,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Can [name] participate in recreational outdoor activities with other children the same age? (cont.)",
          },
          {
            t: "text",
            text: "(For example: bicycling, tricycling, skating, hiking, jogging)",
          },
          { t: "text", text: "Was [name]'s activity limited by:" },
          {
            t: "checks",
            items: [
              { name: "q2_062", label: "Yes", rowLabel: "Pain?" },
              { name: "q2_063", label: "Yes", rowLabel: "General Health?" },
              {
                name: "q2_064",
                label: "Yes",
                rowLabel: "Doctor or parent instructions?",
              },
              {
                name: "q2_065",
                label: "Yes",
                rowLabel: "Fear the other kids won't like him/her?",
              },
              {
                name: "q2_066",
                label: "Yes",
                rowLabel: "Dislike of recreational outdoor activities?",
              },
              { name: "q2_067", label: "Yes", rowLabel: "Too young?" },
              {
                name: "q2_068",
                label: "Yes",
                rowLabel: "Activity not in season?",
              },
            ],
          },
          { t: "text", text: "Additional Comment for Selection(s) Above:" },
          { t: "textarea", name: "q2_061comment" },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "¿Puede [name] participar en actividades recreativas al aire libre con otros niños de su misma edad?",
          },
          {
            t: "text",
            text: "(Por ejemplo: andar en bicicleta, triciclo, patines, escalar o trotar)",
          },
          { t: "text", text: "¿se limitó la actividad de [name] debido a:" },
          {
            t: "checks",
            items: [
              { name: "q2_062", label: "Sí", rowLabel: "dolor?" },
              { name: "q2_063", label: "Sí", rowLabel: "salud en general?" },
              {
                name: "q2_064",
                label: "Sí",
                rowLabel: "instrucciones del médico o de los padres?",
              },
              {
                name: "q2_065",
                label: "Sí",
                rowLabel: "miedo a no ser aceptado por los otros niños?",
              },
              {
                name: "q2_066",
                label: "Sí",
                rowLabel:
                  "Desagrado a las actividades recreativas al aire libre?",
              },
              { name: "q2_067", label: "Sí", rowLabel: "que es muy joven?" },
              {
                name: "q2_068",
                label: "Sí",
                rowLabel: "que la actividad está fuera de temporada?",
              },
            ],
          },
          {
            t: "text",
            text: "Comentario Adicional para las Selecciones Anteriores:",
          },
          { t: "textarea", name: "q2_061comment" },
        ],
      },
    },
    {
      n: 15,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Can [name] participate in pickup games or sports with other children the same age?",
          },
          {
            t: "text",
            text: "(For example: tag, dodge ball, basketball, soccer, catch, jump rope, touch football, hop scotch)",
          },
          {
            t: "radios",
            name: "q2_069",
            options: [
              { value: 1, label: "Yes, easily" },
              { value: 2, label: "Yes, but a little hard" },
              { value: 3, label: "Yes, but very hard" },
              { value: 4, label: "No" },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "¿Puede [name] participar en juegos o deportes de pelota o de movimiento con otros niños de su misma edad?",
          },
          {
            t: "text",
            text: "[Por ejemplo, la roña (tag), esquivar la pelota (dodge ball), baloncesto, fútbol soccer, atrapar la pelota (catch), saltar la cuerda, fútbol americano, rayuela (hop scotch)]",
          },
          {
            t: "radios",
            name: "q2_069",
            options: [
              { value: 1, label: "Sí, fácilmente" },
              { value: 2, label: "Sí, pero es un poco difícil" },
              { value: 3, label: "Sí, pero es muy difícil" },
              { value: 4, label: "No" },
            ],
          },
        ],
      },
      required: ["q2_069"],
    },
    {
      n: 16,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Can [name] participate in pickup games or sports with other children the same age? (cont.)",
          },
          {
            t: "text",
            text: "(For example: tag, dodge ball, basketball, soccer, catch, jump rope, touch football, hop scotch)",
          },
          { t: "text", text: "Was [name]'s activity limited by:" },
          {
            t: "checks",
            items: [
              { name: "q2_070", label: "Yes", rowLabel: "Pain?" },
              { name: "q2_071", label: "Yes", rowLabel: "General Health?" },
              {
                name: "q2_072",
                label: "Yes",
                rowLabel: "Doctor or parent instructions?",
              },
              {
                name: "q2_073",
                label: "Yes",
                rowLabel: "Fear the other kids won't like him/her?",
              },
              {
                name: "q2_074",
                label: "Yes",
                rowLabel: "Dislike of pickup games or sports?",
              },
              { name: "q2_075", label: "Yes", rowLabel: "Too young?" },
              {
                name: "q2_076",
                label: "Yes",
                rowLabel: "Activity not in season?",
              },
            ],
          },
          { t: "text", text: "Additional Comment for Selection(s) Above:" },
          { t: "textarea", name: "q2_069comment" },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "¿Puede [name] participar en juegos o deportes de pelota o de movimiento con otros niños de su misma edad?",
          },
          {
            t: "text",
            text: "[Por ejemplo, la roña (tag), esquivar la pelota (dodge ball), baloncesto, fútbol soccer, atrapar la pelota (catch), saltar la cuerda, fútbol americano, rayuela (hop scotch)]",
          },
          { t: "text", text: "¿se limitó la actividad de [name] debido a:" },
          {
            t: "checks",
            items: [
              { name: "q2_070", label: "Sí", rowLabel: "dolor?" },
              { name: "q2_071", label: "Sí", rowLabel: "salud en general?" },
              {
                name: "q2_072",
                label: "Sí",
                rowLabel: "instrucciones del médico o de los padres?",
              },
              {
                name: "q2_073",
                label: "Sí",
                rowLabel: "miedo a no ser aceptado por los otros niños?",
              },
              {
                name: "q2_074",
                label: "Sí",
                rowLabel:
                  "su disgusto por los juegos o deportes de pelota o de movimiento?",
              },
              { name: "q2_075", label: "Sí", rowLabel: "que es muy joven?" },
              {
                name: "q2_076",
                label: "Sí",
                rowLabel: "que la actividad está fuera de temporada?",
              },
            ],
          },
          {
            t: "text",
            text: "Comentario Adicional para las Selecciones Anteriores:",
          },
          { t: "textarea", name: "q2_069comment" },
        ],
      },
    },
    {
      n: 17,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Can [name] participate in competitive level sports with other children the same age?",
          },
          {
            t: "text",
            text: "(For example: hockey, basketball, soccer, football, baseball, swimming, running [track or cross country], gymnastics, or dance)",
          },
          {
            t: "radios",
            name: "q2_077",
            options: [
              { value: 1, label: "Yes, easily" },
              { value: 2, label: "Yes, but a little hard" },
              { value: 3, label: "Yes, but very hard" },
              { value: 4, label: "No" },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "¿Puede [name] participar en deportes a nivel competitivo con otros niños de su misma edad?",
          },
          {
            t: "text",
            text: "[Por ejemplo: hockey, baloncesto, fútbol soccer, fútbol americano, béisbol, natación, carreras (carreras en pistas o a campo traviesa) (track o cross country)], gimnasia o danza]",
          },
          {
            t: "radios",
            name: "q2_077",
            options: [
              { value: 1, label: "Sí, fácilmente" },
              { value: 2, label: "Sí, pero es un poco difícil" },
              { value: 3, label: "Sí, pero es muy difícil" },
              { value: 4, label: "No" },
            ],
          },
        ],
      },
      required: ["q2_077"],
    },
    {
      n: 18,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Can [name] participate in competitive level sports with other children the same age? (cont.)",
          },
          {
            t: "text",
            text: "(For example: hockey, basketball, soccer, football, baseball, swimming, running [track or cross country], gymnastics, or dance)",
          },
          { t: "text", text: "Was [name]'s activity limited by:" },
          {
            t: "checks",
            items: [
              { name: "q2_078", label: "Yes", rowLabel: "Pain?" },
              { name: "q2_079", label: "Yes", rowLabel: "General Health?" },
              {
                name: "q2_080",
                label: "Yes",
                rowLabel: "Doctor or parent instructions?",
              },
              {
                name: "q2_081",
                label: "Yes",
                rowLabel: "Fear the other kids won't like him/her?",
              },
              {
                name: "q2_082",
                label: "Yes",
                rowLabel: "Dislike of competitive level sports?",
              },
              { name: "q2_083", label: "Yes", rowLabel: "Too young?" },
              {
                name: "q2_084",
                label: "Yes",
                rowLabel: "Activity not in season?",
              },
            ],
          },
          { t: "text", text: "Additional Comment for Selection(s) Above:" },
          { t: "textarea", name: "q2_077comment" },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "¿Puede [name] participar en deportes a nivel competitivo con otros niños de su misma edad?",
          },
          {
            t: "text",
            text: "[Por ejemplo: hockey, baloncesto, fútbol soccer, fútbol americano, béisbol, natación, carreras (carreras en pistas o a campo traviesa) (track o cross country)], gimnasia o danza]",
          },
          { t: "text", text: "¿se limitó la actividad de [name] debido a:" },
          {
            t: "checks",
            items: [
              { name: "q2_078", label: "Sí", rowLabel: "dolor?" },
              { name: "q2_079", label: "Sí", rowLabel: "salud en general?" },
              {
                name: "q2_080",
                label: "Sí",
                rowLabel: "instrucciones del médico o de los padres?",
              },
              {
                name: "q2_081",
                label: "Sí",
                rowLabel: "miedo a no ser aceptado por los otros niños?",
              },
              {
                name: "q2_082",
                label: "Sí",
                rowLabel: "su disgusto por los deportes a nivel competitivo?",
              },
              { name: "q2_083", label: "Sí", rowLabel: "que es muy joven?" },
              {
                name: "q2_084",
                label: "Sí",
                rowLabel: "que la actividad está fuera de temporada?",
              },
            ],
          },
          {
            t: "text",
            text: "Comentario Adicional para las Selecciones Anteriores:",
          },
          { t: "textarea", name: "q2_077comment" },
        ],
      },
    },
    {
      n: 19,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "How often in the last week did [name] get together and do things with friends?",
          },
          {
            t: "radios",
            name: "q2_085",
            options: [
              { value: 1, label: "Often" },
              { value: 2, label: "Sometimes" },
              { value: 3, label: "Never or rarely" },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "¿Con qué frecuencia durante la semana pasada ¿[name] se reunió o hizo algo con sus amigos?",
          },
          {
            t: "radios",
            name: "q2_085",
            options: [
              { value: 1, label: "Frecuentemente" },
              { value: 2, label: "Algunas veces" },
              { value: 3, label: "Nunca o rara vez" },
            ],
          },
        ],
      },
      required: ["q2_085"],
    },
    {
      n: 20,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "How often in the last week did [name] get together and do things with friends? (cont.)",
          },
          { t: "text", text: "Was [name]'s activity limited by:" },
          {
            t: "checks",
            items: [
              { name: "q2_086", label: "Yes", rowLabel: "Pain?" },
              { name: "q2_087", label: "Yes", rowLabel: "General Health?" },
              {
                name: "q2_088",
                label: "Yes",
                rowLabel: "Doctor or parent instructions?",
              },
              {
                name: "q2_089",
                label: "Yes",
                rowLabel: "Fear the other kids won't like him/her?",
              },
              { name: "q2_090", label: "Yes", rowLabel: "Friends not around?" },
            ],
          },
          { t: "text", text: "Additional Comment for Selection(s) Above:" },
          { t: "textarea", name: "q2_085comment" },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "¿Con qué frecuencia durante la semana pasada ¿[name] se reunió o hizo algo con sus amigos?",
          },
          { t: "text", text: "¿se limitó la actividad de [name] debido a:" },
          {
            t: "checks",
            items: [
              { name: "q2_086", label: "Sí", rowLabel: "dolor?" },
              { name: "q2_087", label: "Sí", rowLabel: "salud en general?" },
              {
                name: "q2_088",
                label: "Sí",
                rowLabel: "instrucciones del médico o de los padres?",
              },
              {
                name: "q2_089",
                label: "Sí",
                rowLabel: "miedo a no ser aceptado por los otros niños?",
              },
              {
                name: "q2_090",
                label: "Sí",
                rowLabel: "que los amigos no se encontraban a su alrededor?",
              },
            ],
          },
          {
            t: "text",
            text: "Comentario Adicional para las Selecciones Anteriores:",
          },
          { t: "textarea", name: "q2_085comment" },
        ],
      },
    },
    {
      n: 21,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "How often in the last week did [name] participate in gym/recess ?",
          },
          {
            t: "radios",
            name: "q2_091",
            options: [
              { value: 1, label: "Often" },
              { value: 2, label: "Sometimes" },
              { value: 3, label: "Never or rarely" },
              { value: 4, label: "No gym or recess" },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "¿Con qué frecuencia durante la semana pasada participó [name] en gimnasia o en actividades deportivas?",
          },
          {
            t: "radios",
            name: "q2_091",
            options: [
              { value: 1, label: "Frecuentemente" },
              { value: 2, label: "Algunas veces" },
              { value: 3, label: "Nunca o rara vez" },
              { value: 4, label: "No fue a gimnasia ni deportes" },
            ],
          },
        ],
      },
      required: ["q2_091"],
    },
    {
      n: 22,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "How often in the last week did [name] participate in gym/recess ? (cont.)",
          },
          { t: "text", text: "Was [name]'s activity limited by:" },
          {
            t: "checks",
            items: [
              { name: "q2_092", label: "Yes", rowLabel: "Pain?" },
              { name: "q2_093", label: "Yes", rowLabel: "General Health?" },
              {
                name: "q2_094",
                label: "Yes",
                rowLabel: "Doctor or parent instructions?",
              },
              {
                name: "q2_095",
                label: "Yes",
                rowLabel: "Fear the other kids won't like him/her?",
              },
              {
                name: "q2_096",
                label: "Yes",
                rowLabel: "Dislike of gym/recess?",
              },
              {
                name: "q2_097",
                label: "Yes",
                rowLabel: "School not in session?",
              },
              {
                name: "q2_098",
                label: "Yes",
                rowLabel: "Does not attend school ?",
              },
            ],
          },
          { t: "text", text: "Additional Comment for Selection(s) Above:" },
          { t: "textarea", name: "q2_091comment" },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "¿Con qué frecuencia durante la semana pasada participó [name] en gimnasia o en actividades deportivas?",
          },
          { t: "text", text: "¿se limitó la actividad de [name] debido a:" },
          {
            t: "checks",
            items: [
              { name: "q2_092", label: "Sí", rowLabel: "dolor?" },
              { name: "q2_093", label: "Sí", rowLabel: "salud en general?" },
              {
                name: "q2_094",
                label: "Sí",
                rowLabel: "instrucciones del médico o de los padres?",
              },
              {
                name: "q2_095",
                label: "Sí",
                rowLabel: "miedo a no ser aceptado por los otros niños?",
              },
              {
                name: "q2_096",
                label: "Sí",
                rowLabel: "su disgusto por la gimnasia/deportes?",
              },
              {
                name: "q2_097",
                label: "Sí",
                rowLabel: "vacaciones escolares?",
              },
              { name: "q2_098", label: "Sí", rowLabel: "no va a la escuela?" },
            ],
          },
          { t: "text", text: "Additional Comment for Selection(s) Above:" },
          { t: "textarea", name: "q2_091comment" },
        ],
      },
    },
    {
      n: 23,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Is it easy or hard for [name] to make friends with children his/her own age?",
          },
          {
            t: "radios",
            name: "q2_099",
            options: [
              { value: 1, label: "Usually easy" },
              { value: 2, label: "Sometimes easy" },
              { value: 3, label: "Sometimes hard" },
              { value: 4, label: "Usually hard" },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "¿Es fácil o difícil para [name] hacer amistad con niños de su misma edad?",
          },
          {
            t: "radios",
            name: "q2_099",
            options: [
              { value: 1, label: "Normalmente fácil" },
              { value: 2, label: "Algunas veces fácil" },
              { value: 3, label: "Algunas veces difícil" },
              { value: 4, label: "Normalmente difícil" },
            ],
          },
        ],
      },
      required: ["q2_099"],
    },
    {
      n: 24,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "How much pain has [name] had during the last week ?",
          },
          {
            t: "radios",
            name: "q2_100",
            options: [
              { value: 1, label: "None" },
              { value: 2, label: "Very mild" },
              { value: 3, label: "Mild" },
              { value: 4, label: "Moderate" },
              { value: 5, label: "Severe" },
              { value: 6, label: "Very severe" },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "¿Cuánto dolor ha tenido [name] durante la semana pasada ?",
          },
          {
            t: "radios",
            name: "q2_100",
            options: [
              { value: 1, label: "Ninguno" },
              { value: 2, label: "Muy leve" },
              { value: 3, label: "Leve" },
              { value: 4, label: "Moderado" },
              { value: 5, label: "Fuerte" },
              { value: 6, label: "Muy fuerte" },
            ],
          },
        ],
      },
      required: ["q2_100"],
    },
    {
      n: 25,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "During the last week, how much did pain interfere with [name]'s normal activities (including at home, outside of the home, and at school)?",
          },
          {
            t: "radios",
            name: "q2_101",
            options: [
              { value: 1, label: "Not at all" },
              { value: 2, label: "A little bit" },
              { value: 3, label: "Moderately" },
              { value: 4, label: "Quite a bit" },
              { value: 5, label: "Extremely" },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "Durante la semana pasada, ¿hasta qué grado interfirió el dolor con las actividades normales de [name] (incluyendo en la casa, fuera de la casa y en la escuela)?",
          },
          {
            t: "radios",
            name: "q2_101",
            options: [
              { value: 1, label: "Para nada" },
              { value: 2, label: "Un poco" },
              { value: 3, label: "Moderadamente" },
              { value: 4, label: "Mucho" },
              { value: 5, label: "Extremadamente" },
            ],
          },
        ],
      },
      required: ["q2_101"],
    },
    {
      n: 26,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "What expectations do you have for [name]'s treatment?",
          },
          {
            t: "text",
            text: "As a result of [name]'s treatment, I expect [name]:",
          },
          {
            t: "scale",
            columns: [
              "Definitely Yes",
              "Probably Yes",
              "Not Sure",
              "Probably Not",
              "Definitely Not",
            ],
            rows: [
              { name: "q2_102", text: "To have pain relief" },
              { name: "q2_103", text: "To look better" },
              { name: "q2_104", text: "To feel better about himself/herself" },
              { name: "q2_105", text: "To sleep more comfortably" },
              { name: "q2_106", text: "To be able to do activities at home" },
              { name: "q2_107", text: "To be able to do more at school" },
              {
                name: "q2_108",
                text: "To be able to do more play or recreational activities (biking, walking, doing things with friends)",
              },
              { name: "q2_109", text: "To be able to do more sports" },
              {
                name: "q2_110",
                text: "To be free from pain or disability as an adult",
              },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "¿Qué expectativas tiene para el tratamiento de [name]?",
          },
          {
            t: "text",
            text: "Como resultado del tratamiento de [name], espero que [name]:",
          },
          {
            t: "scale",
            columns: [
              "Definitivamente sí",
              "Probablemente sí",
              "No estoy seguro(a)",
              "Probablemente no",
              "Definitivamente no",
            ],
            rows: [
              { name: "q2_102", text: "tenga alivio a su dolor." },
              { name: "q2_103", text: "se vea mejor." },
              { name: "q2_104", text: "se sienta mejor consigo mismo(a)." },
              { name: "q2_105", text: "duerma mejor y más cómodamente." },
              { name: "q2_106", text: "pueda hacer más actividades en casa." },
              { name: "q2_107", text: "pueda hacer más en la escuela." },
              {
                name: "q2_108",
                text: "pueda jugar más o realizar más actividades recreativas (andar en bicicleta, caminar, hacer cosas con amigos).",
              },
              { name: "q2_109", text: "pueda practicar más deportes." },
              {
                name: "q2_110",
                text: "esté libre de dolor o incapacidades como adulto.",
              },
            ],
          },
        ],
      },
      required: [
        "q2_102",
        "q2_103",
        "q2_104",
        "q2_105",
        "q2_106",
        "q2_107",
        "q2_108",
        "q2_109",
        "q2_110",
      ],
    },
    {
      n: 27,
      blocks: {
        en: [
          { t: "text", text: "Pediatric Health Assessment (parent reported)" },
          {
            t: "text",
            text: "If [name] had to spend the rest of his/her life with his/her bone and muscle condition as it is right now, how would you feel about it?",
          },
          {
            t: "radios",
            name: "q2_111",
            options: [
              { value: 1, label: "Very satisfied" },
              { value: 2, label: "Somewhat satisfied" },
              { value: 3, label: "Neutral" },
              { value: 4, label: "Somewhat dissatisfied" },
              { value: 5, label: "Very dissatisfied" },
            ],
          },
        ],
        sp: [
          {
            t: "text",
            text: "Evaluación de Salud Pediátrica (informado por los padres)",
          },
          {
            t: "text",
            text: "Si [name] tuviera que pasar el resto de su vida con su condición de los huesos y músculos como la que tiene ahora, ¿cómo se sentiría al respecto?",
          },
          {
            t: "radios",
            name: "q2_111",
            options: [
              { value: 1, label: "Muy satisfecho(a)" },
              { value: 2, label: "Algo satisfecho(a)" },
              { value: 3, label: "Neutral" },
              { value: 4, label: "Algo insa-tisfecho(a)" },
              { value: 5, label: "Muy insa-tisfecho(a)" },
            ],
          },
        ],
      },
      required: ["q2_111"],
    },
  ],
  AP: [
    {
      n: 0,
      blocks: {
        en: [
          {
            t: "text",
            text: "The following is a survey designed by a group of doctors [1] to measure the quality of life of the children they treat.",
          },
          {
            t: "text",
            text: "Your answers will help us to understand how your child's condition affects his or her daily functions and overall happiness.",
          },
          {
            t: "text",
            text: "It will also let us see if the treatment your child receives improves his or her quality of life.",
          },
          {
            t: "text",
            text: "We appreciate your input and thank you for allowing us to provide this service.",
          },
          {
            t: "text",
            text: "[1] The Pediatric Outcomes Data Collection Instrument (PODCI), Version 2.0, revised Aug 2005.",
          },
        ],
      },
    },
    {
      n: 1,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          { t: "text", text: "In general, would you say [name]'s health is:" },
          {
            t: "radios",
            name: "q2_005",
            options: [
              { value: 1, label: "Excellent" },
              { value: 2, label: "Very Good" },
              { value: 3, label: "Good" },
              { value: 4, label: "Fair" },
              { value: 5, label: "Poor" },
            ],
          },
        ],
      },
    },
    {
      n: 2,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Compared to one year ago, how would you rate [name]'s health in general:",
          },
          {
            t: "radios",
            name: "q2_006",
            options: [
              { value: 1, label: "Much better now than one year ago" },
              { value: 2, label: "Somewhat better now than one year ago" },
              { value: 3, label: "About the same as one year ago" },
              { value: 4, label: "Somewhat worse now than one year ago" },
              { value: 5, label: "Much worse now than one year ago" },
            ],
          },
        ],
      },
    },
    {
      n: 3,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Have you ever been told by a doctor, nurse, teacher, or other health professional that [name] has had any of the following conditions?",
          },
          {
            t: "text",
            text: "If yes, indicate if your child is being treated for this condition and if your child is limited by those conditions.",
          },
          {
            t: "grid",
            columns: [
              "Has your child ever had it?",
              "Does your child receive treatment for it now?",
              "Are your child's activities limited by it now?",
            ],
            rows: [
              {
                label: "Juvenile Arthritis (one or two joints)",
                cells: [
                  {
                    name: "q2_007a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_007b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_007c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Juvenile Arthritis (many joints)",
                cells: [
                  {
                    name: "q2_008a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_008b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_008c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Anorexia or bulemia (eating disorders)",
                cells: [
                  {
                    name: "q2_009a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_009b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_009c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Asthma",
                cells: [
                  {
                    name: "q2_010a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_010b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_010c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Attention or behavioral problems",
                cells: [
                  {
                    name: "q2_011a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_011b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_011c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Chronic allergies or sinus trouble",
                cells: [
                  {
                    name: "q2_012a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_012b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_012c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Developmental delay",
                cells: [
                  {
                    name: "q2_013a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_013b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_013c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Cognitive Impairment",
                cells: [
                  {
                    name: "q2_014a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_014b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_014c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Diabetes",
                cells: [
                  {
                    name: "q2_015a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_015b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_015c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Epilepsy (seizure disorder)",
                cells: [
                  {
                    name: "q2_016a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_016b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_016c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Hearing impairment or deafness",
                cells: [
                  {
                    name: "q2_017a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_017b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_017c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Heart problem",
                cells: [
                  {
                    name: "q2_018a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_018b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_018c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Learning problem",
                cells: [
                  {
                    name: "q2_019a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_019b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_019c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Sleep disturbance",
                cells: [
                  {
                    name: "q2_020a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_020b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_020c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Speech problems",
                cells: [
                  {
                    name: "q2_021a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_021b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_021c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Vision problems",
                cells: [
                  {
                    name: "q2_022a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_022b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_022c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
            ],
          },
        ],
      },
      required: [
        "q2_007a",
        "q2_008a",
        "q2_009a",
        "q2_010a",
        "q2_011a",
        "q2_012a",
        "q2_013a",
        "q2_014a",
        "q2_015a",
        "q2_016a",
        "q2_017a",
        "q2_018a",
        "q2_019a",
        "q2_020a",
        "q2_021a",
        "q2_022a",
        "q2_007b",
        "q2_008b",
        "q2_009b",
        "q2_010b",
        "q2_011b",
        "q2_012b",
        "q2_013b",
        "q2_014b",
        "q2_015b",
        "q2_016b",
        "q2_017b",
        "q2_018b",
        "q2_019b",
        "q2_020b",
        "q2_021b",
        "q2_022b",
        "q2_007c",
        "q2_008c",
        "q2_009c",
        "q2_010c",
        "q2_011c",
        "q2_012c",
        "q2_013c",
        "q2_014c",
        "q2_015c",
        "q2_016c",
        "q2_017c",
        "q2_018c",
        "q2_019c",
        "q2_020c",
        "q2_021c",
        "q2_022c",
      ],
    },
    {
      n: 4,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "For [name]'s front right side, please indicate those areas that bother him/her or limit his/her function.",
          },
          {
            t: "checks",
            items: [
              { name: "q2_023a", label: "Neck", rowLabel: "" },
              { name: "q2_023b", label: "Shoulder area", rowLabel: "" },
              { name: "q2_023c", label: "Elbow/Forearm", rowLabel: "" },
              { name: "q2_023d", label: "Wrist/Hand", rowLabel: "" },
              { name: "q2_023e", label: "Hip", rowLabel: "" },
              { name: "q2_023f", label: "Thigh", rowLabel: "" },
              { name: "q2_023g", label: "Knee area", rowLabel: "" },
              { name: "q2_023h", label: "Calf area", rowLabel: "" },
              { name: "q2_023i", label: "Ankle/Foot area", rowLabel: "" },
            ],
          },
          {
            t: "text",
            text: "For [name]'s front left side, please indicate those areas that bother him/her or limit his/her function.",
          },
          {
            t: "checks",
            items: [
              { name: "q2_024a", label: "Neck", rowLabel: "" },
              { name: "q2_024b", label: "Shoulder area", rowLabel: "" },
              { name: "q2_024c", label: "Elbow/Forearm", rowLabel: "" },
              { name: "q2_024d", label: "Wrist/Hand", rowLabel: "" },
              { name: "q2_024e", label: "Hip", rowLabel: "" },
              { name: "q2_024f", label: "Thigh", rowLabel: "" },
              { name: "q2_024g", label: "Knee area", rowLabel: "" },
              { name: "q2_024h", label: "Calf area", rowLabel: "" },
              { name: "q2_024i", label: "Ankle/Foot area", rowLabel: "" },
            ],
          },
          {
            t: "text",
            text: "For [name]'s back, please indicate those areas that bother him/her or limit his/her function.",
          },
          {
            t: "checks",
            items: [
              { name: "q2_025a", label: "Neck", rowLabel: "" },
              { name: "q2_025b", label: "Upper Back", rowLabel: "" },
              { name: "q2_025c", label: "Lower Back", rowLabel: "" },
            ],
          },
        ],
      },
    },
    {
      n: 5,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Some kinds of problems can make it hard to do many activities, such as eating, bathing, school work, and playing with friends.",
          },
          { t: "text", text: "We would like to find out how [name] is doing." },
          {
            t: "text",
            text: "During the last week was it easy or hard for your child to:",
          },
          {
            t: "scale",
            columns: [
              "Easy",
              "A little hard",
              "Very hard",
              "Can't do at all",
              "Too young for this activity",
            ],
            rows: [
              { name: "q2_026", text: "Lift heavy books?" },
              { name: "q2_027", text: "Pour a half gallon of milk?" },
              {
                name: "q2_028",
                text: "Open a jar that has been opened before?",
              },
              { name: "q2_029", text: "Use a fork and spoon?" },
              { name: "q2_030", text: "Comb his/her hair?" },
              { name: "q2_031", text: "Button buttons?" },
              { name: "q2_032x", text: "Put on his/her coat?" },
              { name: "q2_033", text: "Write with a pencil?" },
            ],
          },
        ],
      },
    },
    {
      n: 6,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "On average, over the last 12 months, how often did [name] miss school (camp, etc.) because of his/her health?",
          },
          {
            t: "radios",
            name: "q2_034",
            options: [
              { value: 1, label: "Rarely" },
              { value: 2, label: "Once a month" },
              { value: 3, label: "Two or three times a month" },
              { value: 4, label: "Once a week" },
              { value: 5, label: "More than once a week" },
              { value: 6, label: "Does not attend school, etc." },
            ],
          },
        ],
      },
      required: ["q2_034"],
    },
    {
      n: 7,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "During the last week, how happy has [name] been with:",
          },
          {
            t: "scale",
            columns: [
              "Very happy",
              "Somewhat happy",
              "Not sure",
              "Somewhat unhappy",
              "Very unhappy",
              "Child is too young",
            ],
            rows: [
              { name: "q2_035", text: "How he/she looks?" },
              { name: "q2_036", text: "His/her body?" },
              { name: "q2_037", text: "What clothes or shoes he/she can wear" },
              {
                name: "q2_038",
                text: "His/her ability to do the same things his/her friends do?",
              },
              { name: "q2_039", text: "His/her health in general?" },
            ],
          },
        ],
      },
      required: ["q2_035", "q2_036", "q2_037", "q2_038", "q2_039"],
    },
    {
      n: 8,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          { t: "text", text: "During the last week, how much of the time:" },
          {
            t: "scale",
            columns: [
              "Most of the time",
              "Some of the time",
              "A little of the time",
              "None of the time",
            ],
            rows: [
              { name: "q2_040", text: "Did [name] feel sick and tired?" },
              { name: "q2_041", text: "Was [name] full of pep and energy?" },
              {
                name: "q2_042",
                text: "Did pain or discomfort interfere with [name]'s activities?",
              },
            ],
          },
        ],
      },
      required: ["q2_040", "q2_041", "q2_042"],
    },
    {
      n: 9,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "During the last week, has it been easy or hard for [name] to:",
          },
          {
            t: "scale",
            columns: [
              "Easy",
              "A little hard",
              "Very hard",
              "Can't do at all",
              "Too young for this activity",
            ],
            rows: [
              { name: "q2_043", text: "Run short distances?" },
              { name: "q2_044", text: "Bicycle or tricycle?" },
              { name: "q2_045", text: "Climb three flights of stairs?" },
              { name: "q2_046", text: "Climb one flight of stairs?" },
              { name: "q2_047", text: "Walk more than a mile?" },
              { name: "q2_048", text: "Walk three blocks?" },
              { name: "q2_049", text: "Walk one block?" },
              { name: "q2_050", text: "Get on and off a bus?" },
            ],
          },
        ],
      },
      required: [
        "q2_043",
        "q2_044",
        "q2_045",
        "q2_046",
        "q2_047",
        "q2_048",
        "q2_049",
        "q2_050",
      ],
    },
    {
      n: 10,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "How often does [name] need help from another person for walking and climbing?",
          },
          {
            t: "radios",
            name: "q2_051",
            options: [
              { value: 1, label: "Never" },
              { value: 2, label: "Sometimes" },
              { value: 3, label: "About half the time" },
              { value: 4, label: "Often" },
              { value: 5, label: "All the time" },
            ],
          },
          {
            t: "text",
            text: "How often does [name] use assistive devices (such as braces, crutches, or wheelchair) for walking and climbing?",
          },
          {
            t: "radios",
            name: "q2_052",
            options: [
              { value: 1, label: "Never" },
              { value: 2, label: "Sometimes" },
              { value: 3, label: "About half the time" },
              { value: 4, label: "Often" },
              { value: 5, label: "All the time" },
            ],
          },
        ],
      },
      required: ["q2_051", "q2_052"],
    },
    {
      n: 11,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "During the last week, has it been easy or hard for [name] to:",
          },
          {
            t: "scale",
            columns: [
              "Easy",
              "A little hard",
              "Very hard",
              "Can't do at all",
              "Too young for this activity",
            ],
            rows: [
              {
                name: "q2_053",
                text: "Stand while washing his/her hands and face at a sink?",
              },
              {
                name: "q2_054",
                text: "Sit in a regular chair without holding on?",
              },
              { name: "q2_055", text: "Get on and off a toilet or chair?" },
              { name: "q2_056", text: "Get in and out of bed?" },
              { name: "q2_057", text: "Turn door knobs?" },
              {
                name: "q2_058",
                text: "Bend over from a standing position and pick up something off the floor?",
              },
            ],
          },
        ],
      },
    },
    {
      n: 12,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "How often does [name] need help from another person for sitting and standing?",
          },
          {
            t: "radios",
            name: "q2_059",
            options: [
              { value: 1, label: "Never" },
              { value: 2, label: "Sometimes" },
              { value: 3, label: "About half the time" },
              { value: 4, label: "Often" },
              { value: 5, label: "All the time" },
            ],
          },
          {
            t: "text",
            text: "How often does [name] use assistive devices (such as braces, crutches, or wheelchair) for sitting and standing?",
          },
          {
            t: "radios",
            name: "q2_060",
            options: [
              { value: 1, label: "Never" },
              { value: 2, label: "Sometimes" },
              { value: 3, label: "About half the time" },
              { value: 4, label: "Often" },
              { value: 5, label: "All the time" },
            ],
          },
        ],
      },
      required: ["q2_059", "q2_060"],
    },
    {
      n: 13,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Can [name] participate in recreational outdoor activities with other children the same age?",
          },
          {
            t: "text",
            text: "(For example: bicycling, skating, hiking, jogging)",
          },
          {
            t: "radios",
            name: "q2_061",
            options: [
              { value: 1, label: "Yes, easily" },
              { value: 2, label: "Yes, but a little hard" },
              { value: 3, label: "Yes, but very hard" },
              { value: 4, label: "No" },
            ],
          },
        ],
      },
      required: ["q2_061"],
    },
    {
      n: 14,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Can [name] participate in recreational outdoor activities with other children the same age? (cont.)",
          },
          {
            t: "text",
            text: "(For example: bicycling, skating, hiking, jogging)",
          },
          { t: "text", text: "Was [name]'s activity limited by:" },
          {
            t: "checks",
            items: [
              { name: "q2_062", label: "Yes", rowLabel: "Pain?" },
              { name: "q2_063", label: "Yes", rowLabel: "General Health?" },
              {
                name: "q2_064",
                label: "Yes",
                rowLabel: "Doctor or parent instructions?",
              },
              {
                name: "q2_065",
                label: "Yes",
                rowLabel: "Fear the other kids won't like him/her?",
              },
              {
                name: "q2_066",
                label: "Yes",
                rowLabel: "Dislike of recreational outdoor activities?",
              },
              { name: "q2_067", label: "Yes", rowLabel: "Too young?" },
              {
                name: "q2_068",
                label: "Yes",
                rowLabel: "Activity not in season?",
              },
            ],
          },
          { t: "text", text: "Additional Comment for Selection(s) Above:" },
          { t: "textarea", name: "q2_061comment" },
        ],
      },
    },
    {
      n: 15,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Can [name] participate in pickup games or sports with other children the same age?",
          },
          {
            t: "text",
            text: "(For example: tag, dodge ball, basketball, softball, soccer, catch, jump rope, touch football, hop scotch)",
          },
          {
            t: "radios",
            name: "q2_069",
            options: [
              { value: 1, label: "Yes, easily" },
              { value: 2, label: "Yes, but a little hard" },
              { value: 3, label: "Yes, but very hard" },
              { value: 4, label: "No" },
            ],
          },
        ],
      },
      required: ["q2_069"],
    },
    {
      n: 16,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Can [name] participate in pickup games or sports with other children the same age? (cont.)",
          },
          {
            t: "text",
            text: "(For example: tag, dodge ball, basketball, softball, soccer, catch, jump rope, touch football, hop scotch)",
          },
          { t: "text", text: "Was [name]'s activity limited by:" },
          {
            t: "checks",
            items: [
              { name: "q2_070", label: "Yes", rowLabel: "Pain?" },
              { name: "q2_071", label: "Yes", rowLabel: "General Health?" },
              {
                name: "q2_072",
                label: "Yes",
                rowLabel: "Doctor or parent instructions?",
              },
              {
                name: "q2_073",
                label: "Yes",
                rowLabel: "Fear the other kids won't like him/her?",
              },
              {
                name: "q2_074",
                label: "Yes",
                rowLabel: "Dislike of pickup games or sports?",
              },
              { name: "q2_075", label: "Yes", rowLabel: "Too young?" },
              {
                name: "q2_076",
                label: "Yes",
                rowLabel: "Activity not in season?",
              },
            ],
          },
          { t: "text", text: "Additional Comment for Selection(s) Above:" },
          { t: "textarea", name: "q2_069comment" },
        ],
      },
    },
    {
      n: 17,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Can [name] participate in competitive level sports with other children the same age?",
          },
          {
            t: "text",
            text: "(For example: hockey, basketball, soccer, football, baseball, swimming, running [track or cross country], gymnastics, or dance)",
          },
          {
            t: "radios",
            name: "q2_077",
            options: [
              { value: 1, label: "Yes, easily" },
              { value: 2, label: "Yes, but a little hard" },
              { value: 3, label: "Yes, but very hard" },
              { value: 4, label: "No" },
            ],
          },
        ],
      },
      required: ["q2_077"],
    },
    {
      n: 18,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Can [name] participate in competitive level sports with other children the same age? (cont.)",
          },
          {
            t: "text",
            text: "(For example: hockey, basketball, soccer, football, baseball, swimming, running [track or cross country], gymnastics, or dance)",
          },
          { t: "text", text: "Was [name]'s activity limited by:" },
          {
            t: "checks",
            items: [
              { name: "q2_078", label: "Yes", rowLabel: "Pain?" },
              { name: "q2_079", label: "Yes", rowLabel: "General Health?" },
              {
                name: "q2_080",
                label: "Yes",
                rowLabel: "Doctor or parent instructions?",
              },
              {
                name: "q2_081",
                label: "Yes",
                rowLabel: "Fear the other kids won't like him/her?",
              },
              {
                name: "q2_082",
                label: "Yes",
                rowLabel: "Dislike of competitive level sports?",
              },
              { name: "q2_083", label: "Yes", rowLabel: "Too young?" },
              {
                name: "q2_084",
                label: "Yes",
                rowLabel: "Activity not in season?",
              },
            ],
          },
          { t: "text", text: "Additional Comment for Selection(s) Above:" },
          { t: "textarea", name: "q2_077comment" },
        ],
      },
    },
    {
      n: 19,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "How often in the last week did [name] get together and do things with friends?",
          },
          {
            t: "radios",
            name: "q2_085",
            options: [
              { value: 1, label: "Often" },
              { value: 2, label: "Sometimes" },
              { value: 3, label: "Never or rarely" },
            ],
          },
        ],
      },
      required: ["q2_085"],
    },
    {
      n: 20,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "How often in the last week did [name] get together and do things with friends? (cont.)",
          },
          { t: "text", text: "Was [name]'s activity limited by:" },
          {
            t: "checks",
            items: [
              { name: "q2_086", label: "Yes", rowLabel: "Pain?" },
              { name: "q2_087", label: "Yes", rowLabel: "General Health?" },
              {
                name: "q2_088",
                label: "Yes",
                rowLabel: "Doctor or parent instructions?",
              },
              {
                name: "q2_089",
                label: "Yes",
                rowLabel: "Fear the other kids won't like him/her?",
              },
              { name: "q2_090", label: "Yes", rowLabel: "Friends not around?" },
            ],
          },
          { t: "text", text: "Additional Comment for Selection(s) Above:" },
          { t: "textarea", name: "q2_085comment" },
        ],
      },
    },
    {
      n: 21,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "How often in the last week did [name] participate in gym/recess ?",
          },
          {
            t: "radios",
            name: "q2_091",
            options: [
              { value: 1, label: "Often" },
              { value: 2, label: "Sometimes" },
              { value: 3, label: "Never or rarely" },
              { value: 4, label: "No gym or recess" },
            ],
          },
        ],
      },
      required: ["q2_091"],
    },
    {
      n: 22,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "How often in the last week did [name] participate in gym/recess ? (cont.)",
          },
          { t: "text", text: "Was [name]'s activity limited by:" },
          {
            t: "checks",
            items: [
              { name: "q2_092", label: "Yes", rowLabel: "Pain?" },
              { name: "q2_093", label: "Yes", rowLabel: "General Health?" },
              {
                name: "q2_094",
                label: "Yes",
                rowLabel: "Doctor or parent instructions?",
              },
              {
                name: "q2_095",
                label: "Yes",
                rowLabel: "Fear the other kids won't like him/her?",
              },
              {
                name: "q2_096",
                label: "Yes",
                rowLabel: "Dislike of gym/recess?",
              },
              {
                name: "q2_097",
                label: "Yes",
                rowLabel: "School not in session?",
              },
              {
                name: "q2_098",
                label: "Yes",
                rowLabel: "Does not attend school ?",
              },
            ],
          },
          { t: "text", text: "Additional Comment for Selection(s) Above:" },
          { t: "textarea", name: "q2_091comment" },
        ],
      },
    },
    {
      n: 23,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "Is it easy or hard for [name] to make friends with children his/her own age?",
          },
          {
            t: "radios",
            name: "q2_099",
            options: [
              { value: 1, label: "Usually easy" },
              { value: 2, label: "Sometimes easy" },
              { value: 3, label: "Sometimes hard" },
              { value: 4, label: "Usually hard" },
            ],
          },
        ],
      },
      required: ["q2_099"],
    },
    {
      n: 24,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "How much pain has [name] had during the last week ?",
          },
          {
            t: "radios",
            name: "q2_100",
            options: [
              { value: 1, label: "None" },
              { value: 2, label: "Very mild" },
              { value: 3, label: "Mild" },
              { value: 4, label: "Moderate" },
              { value: 5, label: "Severe" },
              { value: 6, label: "Very severe" },
            ],
          },
        ],
      },
      required: ["q2_100"],
    },
    {
      n: 25,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "During the last week, how much did pain interfere with [name]'s normal activities (including at home, outside of the home, and at school)?",
          },
          {
            t: "radios",
            name: "q2_101",
            options: [
              { value: 1, label: "Not at all" },
              { value: 2, label: "A little bit" },
              { value: 3, label: "Moderately" },
              { value: 4, label: "Quite a bit" },
              { value: 5, label: "Extremely" },
            ],
          },
        ],
      },
      required: ["q2_101"],
    },
    {
      n: 26,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "What expectations do you have for [name]'s treatment?",
          },
          {
            t: "text",
            text: "As a result of [name]'s treatment, I expect [name]:",
          },
          {
            t: "scale",
            columns: [
              "Definitely Yes",
              "Probably Yes",
              "Not Sure",
              "Probably Not",
              "Definitely Not",
            ],
            rows: [
              { name: "q2_102", text: "To have pain relief" },
              { name: "q2_103", text: "To look better" },
              { name: "q2_104", text: "To feel better about himself/herself" },
              { name: "q2_105", text: "To sleep more comfortably" },
              { name: "q2_106", text: "To be able to do activities at home" },
              { name: "q2_107", text: "To be able to do more at school" },
              {
                name: "q2_108",
                text: "To be able to do more play or recreational activities (biking, walking, doing things with friends)",
              },
              { name: "q2_109", text: "To be able to do more sports" },
              {
                name: "q2_110",
                text: "To be free from pain or disability as an adult",
              },
            ],
          },
        ],
      },
      required: [
        "q2_102",
        "q2_103",
        "q2_104",
        "q2_105",
        "q2_106",
        "q2_107",
        "q2_108",
        "q2_109",
        "q2_110",
      ],
    },
    {
      n: 27,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (parent reported)" },
          {
            t: "text",
            text: "If [name] had to spend the rest of his/her life with his/her bone and muscle condition as it is right now, how would you feel about it?",
          },
          {
            t: "radios",
            name: "q2_111",
            options: [
              { value: 1, label: "Very satisfied" },
              { value: 2, label: "Somewhat satisfied" },
              { value: 3, label: "Neutral" },
              { value: 4, label: "Somewhat dissatisfied" },
              { value: 5, label: "Very dissatisfied" },
            ],
          },
        ],
      },
      required: ["q2_111"],
    },
  ],
  AS: [
    {
      n: 0,
      blocks: {
        en: [
          {
            t: "text",
            text: "The following is a survey designed by a group of doctors [1] to measure the quality of life they treat.",
          },
          {
            t: "text",
            text: "Your answers will help us to understand how your condition affects your daily functions and overall happiness.",
          },
          {
            t: "text",
            text: "It will also let us see if the treatment you receive improves your quality of life.",
          },
          {
            t: "text",
            text: "We appreciate your input and thank you for allowing us to provide this service.",
          },
          {
            t: "text",
            text: "[1] The Pediatric Outcomes Data Collection Instrument (PODCI), Version 2.0, revised Aug 2005.",
          },
        ],
      },
    },
    {
      n: 1,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          { t: "text", text: "In general, would you say your health is:" },
          {
            t: "radios",
            name: "q2_005",
            options: [
              { value: 1, label: "Excellent" },
              { value: 2, label: "Very Good" },
              { value: 3, label: "Good" },
              { value: 4, label: "Fair" },
              { value: 5, label: "Poor" },
            ],
          },
        ],
      },
    },
    {
      n: 2,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "Compared to one year ago, how would you rate your health in general:",
          },
          {
            t: "radios",
            name: "q2_006",
            options: [
              { value: 1, label: "Much better now than one year ago" },
              { value: 2, label: "Somewhat better now than one year ago" },
              { value: 3, label: "About the same as one year ago" },
              { value: 4, label: "Somewhat worse now than one year ago" },
              { value: 5, label: "Much worse now than one year ago" },
            ],
          },
        ],
      },
    },
    {
      n: 3,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "Have you ever been told by a doctor, nurse, teacher, or other health professional that you have had any of the following conditions?",
          },
          {
            t: "text",
            text: "If yes, indicate if you are being treated for this condition and if you are limited by those conditions.",
          },
          {
            t: "grid",
            columns: [
              "Have you ever had it?",
              "Do you receive treatment for it now?",
              "Are your activities limited by it now?",
            ],
            rows: [
              {
                label: "Juvenile Arthritis (one or two joints)",
                cells: [
                  {
                    name: "q2_007a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_007b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_007c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Juvenile Arthritis (many joints)",
                cells: [
                  {
                    name: "q2_008a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_008b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_008c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Anorexia or bulemia (eating disorders)",
                cells: [
                  {
                    name: "q2_009a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_009b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_009c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Asthma",
                cells: [
                  {
                    name: "q2_010a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_010b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_010c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Attention or behavioral problems",
                cells: [
                  {
                    name: "q2_011a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_011b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_011c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Chronic allergies or sinus trouble",
                cells: [
                  {
                    name: "q2_012a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_012b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_012c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Developmental delay",
                cells: [
                  {
                    name: "q2_013a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_013b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_013c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Cognitive Impairment",
                cells: [
                  {
                    name: "q2_014a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_014b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_014c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Diabetes",
                cells: [
                  {
                    name: "q2_015a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_015b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_015c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Epilepsy (seizure disorder)",
                cells: [
                  {
                    name: "q2_016a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_016b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_016c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Hearing impairment or deafness",
                cells: [
                  {
                    name: "q2_017a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_017b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_017c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Heart problem",
                cells: [
                  {
                    name: "q2_018a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_018b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_018c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Learning problem",
                cells: [
                  {
                    name: "q2_019a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_019b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_019c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Sleep disturbance",
                cells: [
                  {
                    name: "q2_020a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_020b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_020c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Speech problems",
                cells: [
                  {
                    name: "q2_021a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_021b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_021c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
              {
                label: "Vision problems",
                cells: [
                  {
                    name: "q2_022a",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_022b",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                  {
                    name: "q2_022c",
                    options: [
                      { value: 1, label: "Yes" },
                      { value: 2, label: "No" },
                    ],
                  },
                ],
              },
            ],
          },
        ],
      },
      required: [
        "q2_007a",
        "q2_008a",
        "q2_009a",
        "q2_010a",
        "q2_011a",
        "q2_012a",
        "q2_013a",
        "q2_014a",
        "q2_015a",
        "q2_016a",
        "q2_017a",
        "q2_018a",
        "q2_019a",
        "q2_020a",
        "q2_021a",
        "q2_022a",
        "q2_007b",
        "q2_008b",
        "q2_009b",
        "q2_010b",
        "q2_011b",
        "q2_012b",
        "q2_013b",
        "q2_014b",
        "q2_015b",
        "q2_016b",
        "q2_017b",
        "q2_018b",
        "q2_019b",
        "q2_020b",
        "q2_021b",
        "q2_022b",
        "q2_007c",
        "q2_008c",
        "q2_009c",
        "q2_010c",
        "q2_011c",
        "q2_012c",
        "q2_013c",
        "q2_014c",
        "q2_015c",
        "q2_016c",
        "q2_017c",
        "q2_018c",
        "q2_019c",
        "q2_020c",
        "q2_021c",
        "q2_022c",
      ],
    },
    {
      n: 4,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "For your front right side, please indicate those areas that bother you or limit your function.",
          },
          {
            t: "checks",
            items: [
              { name: "q2_023a", label: "Neck", rowLabel: "" },
              { name: "q2_023b", label: "Shoulder area", rowLabel: "" },
              { name: "q2_023c", label: "Elbow/Forearm", rowLabel: "" },
              { name: "q2_023d", label: "Wrist/Hand", rowLabel: "" },
              { name: "q2_023e", label: "Hip", rowLabel: "" },
              { name: "q2_023f", label: "Thigh", rowLabel: "" },
              { name: "q2_023g", label: "Knee area", rowLabel: "" },
              { name: "q2_023h", label: "Calf area", rowLabel: "" },
              { name: "q2_023i", label: "Ankle/Foot area", rowLabel: "" },
            ],
          },
          {
            t: "text",
            text: "For your front left side, please indicate those areas that bother you or limit your function.",
          },
          {
            t: "checks",
            items: [
              { name: "q2_024a", label: "Neck", rowLabel: "" },
              { name: "q2_024b", label: "Shoulder area", rowLabel: "" },
              { name: "q2_024c", label: "Elbow/Forearm", rowLabel: "" },
              { name: "q2_024d", label: "Wrist/Hand", rowLabel: "" },
              { name: "q2_024e", label: "Hip", rowLabel: "" },
              { name: "q2_024f", label: "Thigh", rowLabel: "" },
              { name: "q2_024g", label: "Knee area", rowLabel: "" },
              { name: "q2_024h", label: "Calf area", rowLabel: "" },
              { name: "q2_024i", label: "Ankle/Foot area", rowLabel: "" },
            ],
          },
          {
            t: "text",
            text: "For your back, please indicate those areas that bother you or limit your function.",
          },
          {
            t: "checks",
            items: [
              { name: "q2_025a", label: "Neck", rowLabel: "" },
              { name: "q2_025b", label: "Upper Back", rowLabel: "" },
              { name: "q2_025c", label: "Lower Back", rowLabel: "" },
            ],
          },
        ],
      },
    },
    {
      n: 5,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "Some kinds of problems can make it hard to do many activities, such as eating, bathing, school work, and playing with friends.",
          },
          { t: "text", text: "We would like to find out how you are doing." },
          {
            t: "text",
            text: "During the last week was it easy or hard for you to:",
          },
          {
            t: "scale",
            columns: ["Easy", "A little hard", "Very hard", "Can't do at all"],
            rows: [
              { name: "q2_026", text: "Lift heavy books?" },
              { name: "q2_027", text: "Pour a half gallon of milk?" },
              {
                name: "q2_028",
                text: "Open a jar that has been opened before?",
              },
              { name: "q2_029", text: "Use a fork and spoon?" },
              { name: "q2_030", text: "Comb your hair?" },
              { name: "q2_031", text: "Button buttons?" },
              { name: "q2_032x", text: "Put on your coat?" },
              { name: "q2_033", text: "Write with a pencil?" },
            ],
          },
        ],
      },
    },
    {
      n: 6,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "On average, over the last 12 months, how often did you miss school (camp, etc.) because of your health?",
          },
          {
            t: "radios",
            name: "q2_034",
            options: [
              { value: 1, label: "Rarely" },
              { value: 2, label: "Once a month" },
              { value: 3, label: "Two or three times a month" },
              { value: 4, label: "Once a week" },
              { value: 5, label: "More than once a week" },
              { value: 6, label: "Do not attend school, etc." },
            ],
          },
        ],
      },
      required: ["q2_034"],
    },
    {
      n: 7,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "During the last week, how happy have you been with:",
          },
          {
            t: "scale",
            columns: [
              "Very happy",
              "Somewhat happy",
              "Not sure",
              "Somewhat unhappy",
              "Very unhappy",
            ],
            rows: [
              { name: "q2_035", text: "How you look?" },
              { name: "q2_036", text: "Your body?" },
              { name: "q2_037", text: "What clothes or shoes you can wear" },
              {
                name: "q2_038",
                text: "Your ability to do the same things your friends do?",
              },
              { name: "q2_039", text: "Your health in general?" },
            ],
          },
        ],
      },
      required: ["q2_035", "q2_036", "q2_037", "q2_038", "q2_039"],
    },
    {
      n: 8,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          { t: "text", text: "During the last week, how much of the time:" },
          {
            t: "scale",
            columns: [
              "Most of the time",
              "Some of the time",
              "A little of the time",
              "None of the time",
            ],
            rows: [
              { name: "q2_040", text: "Did you feel sick and tired?" },
              { name: "q2_041", text: "Were you full of pep and energy?" },
              {
                name: "q2_042",
                text: "Did pain or discomfort interfere with your activities?",
              },
            ],
          },
        ],
      },
      required: ["q2_040", "q2_041", "q2_042"],
    },
    {
      n: 9,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "During the last week, has it been easy or hard for you to:",
          },
          {
            t: "scale",
            columns: ["Easy", "A little hard", "Very hard", "Can't do at all"],
            rows: [
              { name: "q2_043", text: "Run short distances?" },
              { name: "q2_044", text: "Bicycle or tricycle?" },
              { name: "q2_045", text: "Climb three flights of stairs?" },
              { name: "q2_046", text: "Climb one flight of stairs?" },
              { name: "q2_047", text: "Walk more than a mile?" },
              { name: "q2_048", text: "Walk three blocks?" },
              { name: "q2_049", text: "Walk one block?" },
              { name: "q2_050", text: "Get on and off a bus?" },
            ],
          },
        ],
      },
      required: [
        "q2_043",
        "q2_044",
        "q2_045",
        "q2_046",
        "q2_047",
        "q2_048",
        "q2_049",
        "q2_050",
      ],
    },
    {
      n: 10,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "How often do you need help from another person for walking and climbing?",
          },
          {
            t: "radios",
            name: "q2_051",
            options: [
              { value: 1, label: "Never" },
              { value: 2, label: "Sometimes" },
              { value: 3, label: "About half the time" },
              { value: 4, label: "Often" },
              { value: 5, label: "All the time" },
            ],
          },
          {
            t: "text",
            text: "How often do you use assistive devices (such as braces, crutches, or wheelchair) for walking and climbing?",
          },
          {
            t: "radios",
            name: "q2_052",
            options: [
              { value: 1, label: "Never" },
              { value: 2, label: "Sometimes" },
              { value: 3, label: "About half the time" },
              { value: 4, label: "Often" },
              { value: 5, label: "All the time" },
            ],
          },
        ],
      },
      required: ["q2_051", "q2_052"],
    },
    {
      n: 11,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "During the last week, has it been easy or hard for you to:",
          },
          {
            t: "scale",
            columns: ["Easy", "A little hard", "Very hard", "Can't do at all"],
            rows: [
              {
                name: "q2_053",
                text: "Stand while washing your hands and face at a sink?",
              },
              {
                name: "q2_054",
                text: "Sit in a regular chair without holding on?",
              },
              { name: "q2_055", text: "Get on and off a toilet or chair?" },
              { name: "q2_056", text: "Get in and out of bed?" },
              { name: "q2_057", text: "Turn door knobs?" },
              {
                name: "q2_058",
                text: "Bend over from a standing position and pick up something off the floor?",
              },
            ],
          },
        ],
      },
      required: ["q2_053", "q2_054", "q2_055", "q2_056", "q2_057", "q2_058"],
    },
    {
      n: 12,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "How often do you need help from another person for sitting and standing?",
          },
          {
            t: "radios",
            name: "q2_059",
            options: [
              { value: 1, label: "Never" },
              { value: 2, label: "Sometimes" },
              { value: 3, label: "About half the time" },
              { value: 4, label: "Often" },
              { value: 5, label: "All the time" },
            ],
          },
          {
            t: "text",
            text: "How often do you use assistive devices (such as braces, crutches, or wheelchair) for sitting and standing?",
          },
          {
            t: "radios",
            name: "q2_060",
            options: [
              { value: 1, label: "Never" },
              { value: 2, label: "Sometimes" },
              { value: 3, label: "About half the time" },
              { value: 4, label: "Often" },
              { value: 5, label: "All the time" },
            ],
          },
        ],
      },
      required: ["q2_059", "q2_060"],
    },
    {
      n: 13,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "Can you participate in recreational outdoor activities with other kids your own age?",
          },
          {
            t: "text",
            text: "(For example: bicycling, skating, hiking, jogging)",
          },
          {
            t: "radios",
            name: "q2_061",
            options: [
              { value: 1, label: "Yes, easily" },
              { value: 2, label: "Yes, but a little hard" },
              { value: 3, label: "Yes, but very hard" },
              { value: 4, label: "No" },
            ],
          },
        ],
      },
      required: ["q2_061"],
    },
    {
      n: 14,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "Can you participate in recreational outdoor activities with other kids your own age? (cont.)",
          },
          {
            t: "text",
            text: "(For example: bicycling, skating, hiking, jogging)",
          },
          { t: "text", text: "Was your activity limited by:" },
          {
            t: "checks",
            items: [
              { name: "q2_062", label: "Yes", rowLabel: "Pain?" },
              { name: "q2_063", label: "Yes", rowLabel: "General Health?" },
              {
                name: "q2_064",
                label: "Yes",
                rowLabel: "Doctor or parent instructions?",
              },
              {
                name: "q2_065",
                label: "Yes",
                rowLabel: "Fear the other kids won't like you?",
              },
              {
                name: "q2_066",
                label: "Yes",
                rowLabel: "Dislike of recreational outdoor activities?",
              },
              {
                name: "q2_068",
                label: "Yes",
                rowLabel: "Activity not in season?",
              },
            ],
          },
          { t: "text", text: "Additional Comment for Selection(s) Above:" },
          { t: "textarea", name: "q2_061comment" },
        ],
      },
    },
    {
      n: 15,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "Can you participate in pickup games or sports with other kids your own age?",
          },
          {
            t: "text",
            text: "(For example: tag, dodge ball, basketball, softball, soccer, catch, jump rope, touch football, hop scotch)",
          },
          {
            t: "radios",
            name: "q2_069",
            options: [
              { value: 1, label: "Yes, easily" },
              { value: 2, label: "Yes, but a little hard" },
              { value: 3, label: "Yes, but very hard" },
              { value: 4, label: "No" },
            ],
          },
        ],
      },
      required: ["q2_069"],
    },
    {
      n: 16,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "Can you participate in pickup games or sports with other kids your own age? (cont.)",
          },
          {
            t: "text",
            text: "(For example: tag, dodge ball, basketball, softball, soccer, catch, jump rope, touch football, hop scotch)",
          },
          { t: "text", text: "Was your activity limited by:" },
          {
            t: "checks",
            items: [
              { name: "q2_070", label: "Yes", rowLabel: "Pain?" },
              { name: "q2_071", label: "Yes", rowLabel: "General Health?" },
              {
                name: "q2_072",
                label: "Yes",
                rowLabel: "Doctor or parent instructions?",
              },
              {
                name: "q2_073",
                label: "Yes",
                rowLabel: "Fear the other kids won't like you?",
              },
              {
                name: "q2_074",
                label: "Yes",
                rowLabel: "Dislike of pickup games or sports?",
              },
              {
                name: "q2_076",
                label: "Yes",
                rowLabel: "Activity not in season?",
              },
            ],
          },
          { t: "text", text: "Additional Comment for Selection(s) Above:" },
          { t: "textarea", name: "q2_069comment" },
        ],
      },
    },
    {
      n: 17,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "Can you participate in competitive level sports with other kids your own age?",
          },
          {
            t: "text",
            text: "(For example: hockey, basketball, soccer, football, baseball, swimming, running [track or cross country], gymnastics, or dance)",
          },
          {
            t: "radios",
            name: "q2_077",
            options: [
              { value: 1, label: "Yes, easily" },
              { value: 2, label: "Yes, but a little hard" },
              { value: 3, label: "Yes, but very hard" },
              { value: 4, label: "No" },
            ],
          },
        ],
      },
      required: ["q2_077"],
    },
    {
      n: 18,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "Can you participate in competitive level sports with other kids your own age? (cont.)",
          },
          {
            t: "text",
            text: "(For example: hockey, basketball, soccer, football, baseball, swimming, running [track or cross country], gymnastics, or dance)",
          },
          { t: "text", text: "Was your activity limited by:" },
          {
            t: "checks",
            items: [
              { name: "q2_078", label: "Yes", rowLabel: "Pain?" },
              { name: "q2_079", label: "Yes", rowLabel: "General Health?" },
              {
                name: "q2_080",
                label: "Yes",
                rowLabel: "Doctor or parent instructions?",
              },
              {
                name: "q2_081",
                label: "Yes",
                rowLabel: "Fear the other kids won't like you?",
              },
              {
                name: "q2_082",
                label: "Yes",
                rowLabel: "Dislike of competitive level sports?",
              },
              {
                name: "q2_084",
                label: "Yes",
                rowLabel: "Activity not in season?",
              },
            ],
          },
          { t: "text", text: "Additional Comment for Selection(s) Above:" },
          { t: "textarea", name: "q2_077comment" },
        ],
      },
    },
    {
      n: 19,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "How often in the last week did you get together and do things with friends?",
          },
          {
            t: "radios",
            name: "q2_085",
            options: [
              { value: 1, label: "Often" },
              { value: 2, label: "Sometimes" },
              { value: 3, label: "Never or rarely" },
            ],
          },
        ],
      },
      required: ["q2_085"],
    },
    {
      n: 20,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "How often in the last week did you get together and do things with friends? (cont.)",
          },
          { t: "text", text: "Was your activity limited by:" },
          {
            t: "checks",
            items: [
              { name: "q2_086", label: "Yes", rowLabel: "Pain?" },
              { name: "q2_087", label: "Yes", rowLabel: "General Health?" },
              {
                name: "q2_088",
                label: "Yes",
                rowLabel: "Doctor or parent instructions?",
              },
              {
                name: "q2_089",
                label: "Yes",
                rowLabel: "Fear the other kids won't like you?",
              },
              { name: "q2_090", label: "Yes", rowLabel: "Friends not around?" },
            ],
          },
          { t: "text", text: "Additional Comment for Selection(s) Above:" },
          { t: "textarea", name: "q2_085comment" },
        ],
      },
    },
    {
      n: 21,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "How often in the last week did you participate in gym/recess ?",
          },
          {
            t: "radios",
            name: "q2_091",
            options: [
              { value: 1, label: "Often" },
              { value: 2, label: "Sometimes" },
              { value: 3, label: "Never or rarely" },
              { value: 4, label: "No gym or recess" },
            ],
          },
        ],
      },
      required: ["q2_091"],
    },
    {
      n: 22,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "How often in the last week did you participate in gym/recess ? (cont.)",
          },
          { t: "text", text: "Was your activity limited by:" },
          {
            t: "checks",
            items: [
              { name: "q2_092", label: "Yes", rowLabel: "Pain?" },
              { name: "q2_093", label: "Yes", rowLabel: "General Health?" },
              {
                name: "q2_094",
                label: "Yes",
                rowLabel: "Doctor or parent instructions?",
              },
              {
                name: "q2_095",
                label: "Yes",
                rowLabel: "Fear the other kids won't like you?",
              },
              {
                name: "q2_096",
                label: "Yes",
                rowLabel: "Dislike of gym/recess?",
              },
              {
                name: "q2_097",
                label: "Yes",
                rowLabel: "School not in session?",
              },
              {
                name: "q2_098",
                label: "Yes",
                rowLabel: "I don't attend school?",
              },
            ],
          },
          { t: "text", text: "Additional Comment for Selection(s) Above:" },
          { t: "textarea", name: "q2_091comment" },
        ],
      },
    },
    {
      n: 23,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "Is it easy or hard for you to make friends with kids your own age?",
          },
          {
            t: "radios",
            name: "q2_099",
            options: [
              { value: 1, label: "Usually easy" },
              { value: 2, label: "Sometimes easy" },
              { value: 3, label: "Sometimes hard" },
              { value: 4, label: "Usually hard" },
            ],
          },
        ],
      },
      required: ["q2_099"],
    },
    {
      n: 24,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "How much pain have you had during the last week ?",
          },
          {
            t: "radios",
            name: "q2_100",
            options: [
              { value: 1, label: "None" },
              { value: 2, label: "Very mild" },
              { value: 3, label: "Mild" },
              { value: 4, label: "Moderate" },
              { value: 5, label: "Severe" },
              { value: 6, label: "Very severe" },
            ],
          },
        ],
      },
      required: ["q2_100"],
    },
    {
      n: 25,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "During the last week, how much did pain interfere with your normal activities (including at home, outside of the home, and at school)?",
          },
          {
            t: "radios",
            name: "q2_101",
            options: [
              { value: 1, label: "Not at all" },
              { value: 2, label: "A little bit" },
              { value: 3, label: "Moderately" },
              { value: 4, label: "Quite a bit" },
              { value: 5, label: "Extremely" },
            ],
          },
        ],
      },
      required: ["q2_101"],
    },
    {
      n: 26,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "What expectations do you have for your treatment?",
          },
          { t: "text", text: "As a result of my treatment, I expect:" },
          {
            t: "scale",
            columns: [
              "Definitely Yes",
              "Probably Yes",
              "Not Sure",
              "Probably Not",
              "Definitely Not",
            ],
            rows: [
              { name: "q2_102", text: "To have pain relief" },
              { name: "q2_103", text: "To look better" },
              { name: "q2_104", text: "To feel better about myself" },
              { name: "q2_105", text: "To sleep more comfortably" },
              { name: "q2_106", text: "To be able to do activities at home" },
              { name: "q2_107", text: "To be able to do more at school" },
              {
                name: "q2_108",
                text: "To be able to do more play or recreational activities (biking, walking, doing things with friends)",
              },
              { name: "q2_109", text: "To be able to do more sports" },
              {
                name: "q2_110",
                text: "To be free from pain or disability as an adult",
              },
            ],
          },
        ],
      },
      required: [
        "q2_102",
        "q2_103",
        "q2_104",
        "q2_105",
        "q2_106",
        "q2_107",
        "q2_108",
        "q2_109",
        "q2_110",
      ],
    },
    {
      n: 27,
      blocks: {
        en: [
          { t: "text", text: "Adolescent Health Assessment (self reported)" },
          {
            t: "text",
            text: "If you had to spend the rest of your life with your bone and muscle condition as it is right now, how would you feel about it?",
          },
          {
            t: "radios",
            name: "q2_111",
            options: [
              { value: 1, label: "Very satisfied" },
              { value: 2, label: "Somewhat satisfied" },
              { value: 3, label: "Neutral" },
              { value: 4, label: "Somewhat dissatisfied" },
              { value: 5, label: "Very dissatisfied" },
            ],
          },
        ],
      },
      required: ["q2_111"],
    },
  ],
};
