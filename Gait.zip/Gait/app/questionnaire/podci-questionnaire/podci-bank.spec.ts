import { PODCI_BANK } from './podci-bank';

describe('PODCI question bank consistency', () => {
    it('defines CH, AP, and AS variants', () => {
        expect(Object.keys(PODCI_BANK).sort()).toEqual(['AP', 'AS', 'CH']);
    });
    it('has nonempty, sequential page numbers within each variant', () => {
        for (const [variant, pages] of Object.entries(PODCI_BANK)) {
            expect(pages.length, `${variant} pages`).toBeGreaterThan(0);
            const numbers = pages.map(page => page.n);
            expect(numbers, `${variant} page numbers`).toEqual(Array.from({ length: pages.length }, (_, index) => index));
            expect(pages.every(page => page.blocks.en.length > 0), `${variant} English blocks`).toBe(true);
            expect(pages.every(page => !page.blocks.sp || page.blocks.sp.length > 0), `${variant} Spanish blocks`).toBe(true);
        }
    });
});