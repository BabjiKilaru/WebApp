import { vi } from 'vitest';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { PodciQuestionnaire } from './podci-questionnaire';

describe('PODCIQuestionnaire', () => {
    let component: PodciQuestionnaire;
    let http: HttpTestingController;
    beforeEach(async () => {
        await TestBed.configureTestingModule({ imports: [PodciQuestionnaire], providers: [provideHttpClient(), provideHttpClientTesting()] })
            .overrideComponent(PodciQuestionnaire, { set: { template: '' } }).compileComponents();
        component = TestBed.createComponent(PodciQuestionnaire).componentInstance;
        http = TestBed.inject(HttpTestingController);
    });
    afterEach(() => http.verify());
    it('uses the child parent-report variant and calculates unanswered questions', () => {
        expect(component.variant).toBe('CH');
        expect(component.pages.length).toBeGreaterThan(0);
        expect(component.getProgress().total).toBeGreaterThan(0);
        expect(component.getInvalidFields().length).toBeGreaterThan(0);
    });
    it('records radio responses and notifies progress subscribers', () => {
        const progress = vi.fn();
        component.progressChange.subscribe(progress);
        component.setRadio('q2_061', 4);
        expect(component.selected('q2_061', 4)).toBe(true);
        expect(progress).toHaveBeenCalledOnce();
    });
    it('clears dependent grid values when the disabling answer is selected', () => {
        component.answers['q2_023b'] = 1;
        component.answers['q2_023c'] = 2;
        component.setGrid('q2_023a', 2);
        expect(component.gridDisabled('q2_023b')).toBe(true);
        expect(component.answers['q2_023b']).toBeNull();
        expect(component.answers['q2_023c']).toBeNull();
    });
    it('saves only to the selected patient and visit', () => {
        component.patientId = 42;
        component.visitId = 10;
        component.save();
        const request = http.expectOne('/api/patients/42/podci-questionnaire');
        expect(request.request.method).toBe('POST');
        expect(request.request.body.visitId).toBe(10);
        expect(request.request.body.variant).toBe('ch');
        request.flush({});
        expect(component.saved).toBe(true);
    });
});