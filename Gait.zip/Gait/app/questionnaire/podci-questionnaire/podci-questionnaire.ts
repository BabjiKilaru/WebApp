import { CommonModule } from "@angular/common";
import { ChangeDetectorRef, Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { HttpClient } from "@angular/common/http";

import { PODCI_BANK, PodciBankVariant, PodciBlock, PodciPage } from "./podci-bank";

import { QuestionnaireProgressValue } from "../questionnaire-progress/questionnaire-progress";

export type PodciVariant = PodciBankVariant;

interface FollowUp {
  followUpPage: number;
  key: string;
  showFor: number[];
}

const FOLLOW_UPS: Record<number, FollowUp> = {
  13: {
    followUpPage: 14,
    key: "q2_061",
    showFor: [4],
  },

  15: {
    followUpPage: 16,
    key: "q2_069",
    showFor: [4],
  },

  17: {
    followUpPage: 18,
    key: "q2_077",
    showFor: [4],
  },

  19: {
    followUpPage: 20,
    key: "q2_085",
    showFor: [2, 3],
  },

  21: {
    followUpPage: 22,
    key: "q2_091",
    showFor: [2, 3],
  },
};

const FOLLOW_UP_PAGES = new Set(
  Object.values(FOLLOW_UPS).map((followUp) => followUp.followUpPage),
);

const OPTIONAL_BODY_AREA_FIELDS = /^(q2_023|q2_024|q2_025)[a-i]$/;
const ADDITIONAL_REQUIRED_FIELDS = new Set([
  "q2_005",
  "q2_006",
  "q2_026",
  "q2_027",
  "q2_028",
  "q2_029",
  "q2_030",
  "q2_031",
  "q2_032x",
  "q2_033",
  "q2_053",
  "q2_054",
  "q2_055",
  "q2_056",
  "q2_057",
  "q2_058",
  "q2_061",
  "q2_069",
  "q2_077",
]);

type Answer = number | boolean | string | null;

export interface RenderedPodciPage {
  n: number;
  blocks: PodciBlock[];
}

@Component({
  selector: "app-podci-questionnaire",
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: "./podci-questionnaire.html",
  styleUrl: "./podci-questionnaire.css",
})
export class PodciQuestionnaire implements OnChanges {
  @Input()
  patientId: number | null = null;

  @Input()
  visitId: number | null = null;

  @Input()
  firstName = "";

  @Input()
  variant: PodciVariant = "CH";

  @Input()
  language: "en" | "sp" = "en";

  @Input()
  hideActions = false;

  @Output()
  saveComplete = new EventEmitter<void>();

  @Output()
  saveFailed = new EventEmitter<string>();

  @Output()
  progressChange = new EventEmitter<void>();

  answers: Record<string, Answer> = {};

  saving = false;

  saveError = "";

  saved = false;

  constructor(
    private http: HttpClient,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (!(changes["patientId"] || changes["visitId"] || changes["variant"])) {
      return;
    }
    this.answers = {};
    this.saved = false;
    this.saveError = "";
    this.preload();
  }

  private preload(): void {
    if (!this.patientId || !this.visitId) {
      return;
    }

    const visitId = this.visitId;
    const variant = this.variant;

    this.http
      .get<Record<string, Answer>>(
        `/api/patients/${this.patientId}/podci-questionnaire/${visitId}`,
        {
          params: {
            variant: variant.toLowerCase(),
          },
        },
      )
      .subscribe({
        next: (saved) => {
          if (visitId !== this.visitId || variant !== this.variant) {
            return;
          }

          const loaded: Record<string, Answer> = {};

          for (const [key, value] of Object.entries(saved ?? {})) {
            if (value !== null && value !== undefined) {
              loaded[key] = value;
            }
          }

          this.answers = {
            ...loaded,
            ...this.answers,
          };

          this.cdr.markForCheck();

          this.progressChange.emit();
        },

        error: () => {},
      });
  }

  private blocksFor(page: PodciPage): PodciBlock[] {
    return this.language === "sp" && page.blocks.sp
      ? page.blocks.sp
      : page.blocks.en;
  }

  get pages(): RenderedPodciPage[] {
    const out: RenderedPodciPage[] = [];

    for (const page of PODCI_BANK[this.variant]) {
      if (FOLLOW_UP_PAGES.has(page.n) && !this.followUpShown(page.n)) {
        continue;
      }

      const blocks = this.blocksFor(page);

      out.push({
        n: page.n,

        blocks:
          page.n > 1 && blocks[0]?.t === "text" ? blocks.slice(1) : blocks,
      });
    }

    return out;
  }

  private followUpShown(pageNumber: number): boolean {
    const parent = Object.entries(FOLLOW_UPS).find(
      ([, followUp]) => followUp.followUpPage === pageNumber,
    );

    if (!parent) {
      return true;
    }

    const value = this.answers[parent[1].key];

    return typeof value === "number" && parent[1].showFor.includes(value);
  }

  text(template: string): string {
    return template.replace(
      /\[name\]/g,

      this.firstName || (this.language === "sp" ? "su niño(a)" : "your child"),
    );
  }

  selected(
    name: string,

    value: number,
  ): boolean {
    return this.answers[name] === value;
  }

  setRadio(
    name: string,

    value: number,
  ): void {
    this.answers[name] = value;

    this.saved = false;

    this.progressChange.emit();
  }

  setGrid(
    name: string,

    value: number,
  ): void {
    this.answers[name] = value;

    if (name.endsWith("a") && value === 2) {
      const base = name.slice(0, -1);

      this.answers[base + "b"] = null;

      this.answers[base + "c"] = null;
    }

    this.saved = false;

    this.progressChange.emit();
  }

  gridDisabled(name: string): boolean {
    return /[bc]$/.test(name) && this.answers[name.slice(0, -1) + "a"] === 2;
  }

  private requiredFieldsForPage(page: RenderedPodciPage): string[] {
    const bankPage = PODCI_BANK[this.variant].find(
      (candidate) => candidate.n === page.n,
    );
    const pageFields = new Set<string>();

    for (const block of page.blocks) {
      switch (block.t) {
        case "radios":
        case "textarea":
          pageFields.add(block.name);
          break;
        case "scale":
          block.rows.forEach((row) => pageFields.add(row.name));
          break;
        case "grid":
          block.rows.forEach((row) =>
            row.cells.forEach((cell) => pageFields.add(cell.name)),
          );
          break;
        case "checks":
          block.items.forEach((item) => pageFields.add(item.name));
          break;
      }
    }

    return [
      ...new Set([
        ...(bankPage?.required ?? []),
        ...[...ADDITIONAL_REQUIRED_FIELDS].filter((name) =>
          pageFields.has(name),
        ),
      ]),
    ];
  }

  isChecked(name: string): boolean {
    return this.answers[name] === true;
  }

  setChecked(
    name: string,

    checked: boolean,
  ): void {
    this.answers[name] = checked;

    this.saved = false;

    this.progressChange.emit();
  }

  comment(name: string): string {
    return (this.answers[name] as string) ?? "";
  }

  setComment(
    name: string,

    value: string,
  ): void {
    this.answers[name] = value;

    this.saved = false;

    this.progressChange.emit();
  }

  getProgress(): QuestionnaireProgressValue {
    let answered = 0;

    let total = 0;

    for (const page of this.pages) {
      for (const name of this.requiredFieldsForPage(page)) {
        if (this.gridDisabled(name) || OPTIONAL_BODY_AREA_FIELDS.test(name)) {
          continue;
        }

        total++;

        const value = this.answers[name];

        if (value !== null && value !== undefined && value !== "") {
          answered++;
        }
      }
    }

    return {
      answered,
      total,
    };
  }

  private buildAnswers(): Record<string, Answer> {
    const out: Record<string, Answer> = {};

    for (const page of this.pages) {
      for (const block of page.blocks) {
        switch (block.t) {
          case "radios":
            if (this.answers[block.name] != null) {
              out[block.name] = this.answers[block.name];
            }

            break;

          case "scale":
            for (const row of block.rows) {
              if (this.answers[row.name] != null) {
                out[row.name] = this.answers[row.name];
              }
            }

            break;

          case "grid":
            for (const row of block.rows) {
              for (const cell of row.cells) {
                if (this.gridDisabled(cell.name)) {
                  out[cell.name] = null;
                } else if (this.answers[cell.name] != null) {
                  out[cell.name] = this.answers[cell.name];
                }
              }
            }

            break;

          case "checks":
            for (const item of block.items) {
              out[item.name] = this.answers[item.name] === true;
            }

            break;

          case "textarea":
            out[block.name] = (this.answers[block.name] as string) ?? "";

            break;
        }
      }
    }

    return out;
  }

  validate(): string | null {
    return this.getInvalidFields().length > 0
      ? "Please respond to all questions before continuing."
      : null;
  }

  getInvalidFields(): string[] {
    const invalid: string[] = [];

    for (const page of this.pages) {
      for (const name of this.requiredFieldsForPage(page)) {
        if (this.gridDisabled(name) || OPTIONAL_BODY_AREA_FIELDS.test(name)) {
          continue;
        }

        const value = this.answers[name];

        if (value === null || value === undefined) {
          invalid.push(name);
        }
      }
    }

    return invalid;
  }

  save(): void {
    if (!this.patientId || !this.visitId) {
      this.saveComplete.emit();

      return;
    }

    this.saving = true;

    this.saveError = "";

    this.http
      .post(`/api/patients/${this.patientId}/podci-questionnaire`, {
        visitId: this.visitId,

        variant: this.variant.toLowerCase(),

        answers: this.buildAnswers(),
      })
      .subscribe({
        next: () => {
          this.saving = false;

          this.saved = true;

          this.cdr.markForCheck();

          this.progressChange.emit();

          this.saveComplete.emit();
        },

        error: (error) => {
          console.error("Unable to save PODCI questionnaire:", error);

          this.saving = false;

          this.saveError = "Unable to save. Please try again.";

          this.cdr.markForCheck();

          this.saveFailed.emit(this.saveError);
        },
      });
  }
}
