import { CommonModule } from "@angular/common";
import { Component, Input } from "@angular/core";

export interface QuestionnaireProgressValue {
  answered: number;
  total: number;
}

export interface QuestionnaireProgressItem extends QuestionnaireProgressValue {
  key: string;
  name: string;
  completed: boolean;
}

@Component({
  selector: "app-questionnaire-progress",
  standalone: true,
  imports: [CommonModule],
  templateUrl: "./questionnaire-progress.html",
  styleUrl: "./questionnaire-progress.css",
})
export class QuestionnaireProgress {
  @Input()
  questionnaires: QuestionnaireProgressItem[] = [];

  @Input()
  currentKey = "";

  get current(): QuestionnaireProgressItem | null {
    return (
      this.questionnaires.find((item) => item.key === this.currentKey) ?? null
    );
  }

  get percentage(): number {
    const currentNumber = this.currentNumber;

    if (currentNumber === 0 || this.questionnaires.length === 0) {
      return 0;
    }

    return Math.min(
      100,
      Math.round((currentNumber / this.questionnaires.length) * 100),
    );
  }

  get currentNumber(): number {
    const index = this.questionnaires.findIndex(
      (item) => item.key === this.currentKey,
    );

    return index < 0 ? 0 : index + 1;
  }

  get circleBackground(): string {
    if (this.currentNumber === 0 || this.questionnaires.length === 0) {
      return "conic-gradient(#e5e9ed 0 100%)";
    }

    const previousPercentage = Math.round(
      ((this.currentNumber - 1) / this.questionnaires.length) * 100,
    );
    const currentPercentage = this.percentage;
    const currentIsComplete =
      this.current !== null &&
      this.current.total > 0 &&
      this.current.answered >= this.current.total;
    const currentColor = currentIsComplete ? "#009688" : "#d32f2f";

    return (
      `conic-gradient(` +
      `#009688 0 ${previousPercentage}%, ` +
      `${currentColor} ${previousPercentage}% ${currentPercentage}%, ` +
      `#e5e9ed ${currentPercentage}% 100%)`
    );
  }
}
