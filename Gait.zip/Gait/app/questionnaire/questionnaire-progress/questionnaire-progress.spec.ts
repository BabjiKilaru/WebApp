import { QuestionnaireProgress } from "./questionnaire-progress";

describe("QuestionnaireProgress", () => {
  it("marks only the current questionnaire segment red while incomplete", () => {
    const component = new QuestionnaireProgress();
    component.questionnaires = [
      {
        key: "first",
        name: "First",
        answered: 4,
        total: 4,
        completed: true,
      },
      {
        key: "second",
        name: "Second",
        answered: 2,
        total: 3,
        completed: false,
      },
      {
        key: "third",
        name: "Third",
        answered: 0,
        total: 2,
        completed: false,
      },
    ];
    component.currentKey = "second";

    expect(component.circleBackground).toBe(
      "conic-gradient(#009688 0 33%, #d32f2f 33% 67%, #e5e9ed 67% 100%)",
    );
  });

  it("turns only the current questionnaire segment red again when an answer is cleared", () => {
    const component = new QuestionnaireProgress();
    const current = {
      key: "second",
      name: "Second",
      answered: 3,
      total: 3,
      completed: true,
    };
    component.questionnaires = [
      {
        key: "first",
        name: "First",
        answered: 4,
        total: 4,
        completed: true,
      },
      current,
      {
        key: "third",
        name: "Third",
        answered: 0,
        total: 2,
        completed: false,
      },
    ];
    component.currentKey = "second";

    expect(component.circleBackground).toContain("#009688 33% 67%");

    current.answered = 2;

    expect(component.circleBackground).toContain("#d32f2f 33% 67%");
  });


  it('returns zero progress and an empty circle when nothing is selected', () => {
    const component = new QuestionnaireProgress();
    expect(component.current).toBeNull();
    expect(component.currentNumber).toBe(0);
    expect(component.percentage).toBe(0);
    expect(component.circleBackground).toContain('#e5e9ed');
  });

  it('caps the current questionnaire percentage and marks completed segments green', () => {
    const component = new QuestionnaireProgress();
    component.questionnaires = [{ key: 'a', name: 'A', answered: 2, total: 2, completed: true }];
    component.currentKey = 'a';
    expect(component.percentage).toBe(100);
    expect(component.circleBackground).toContain('#009688');
  });
});