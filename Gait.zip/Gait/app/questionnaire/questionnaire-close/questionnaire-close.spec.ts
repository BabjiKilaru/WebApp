import { vi } from 'vitest';
import { QuestionnaireClose } from './questionnaire-close';

describe('QuestionnaireClose', () => {
    it('emits continue and save-and-close when not saving', () => {
        const component = new QuestionnaireClose();
        const continueSpy = vi.fn();
        const closeSpy = vi.fn();
        component.continueQuestionnaire.subscribe(continueSpy);
        component.saveAndClose.subscribe(closeSpy);
        component.continue();
        component.close();
        expect(continueSpy).toHaveBeenCalledOnce();
        expect(closeSpy).toHaveBeenCalledOnce();
    });
    it('blocks actions during an in-flight save', () => {
        const component = new QuestionnaireClose();
        const closeSpy = vi.fn();
        component.saveAndClose.subscribe(closeSpy);
        component.saving = true;
        component.close();
        expect(closeSpy).not.toHaveBeenCalled();
    });
});