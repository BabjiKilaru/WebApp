import { Component, EventEmitter, Input, Output } from "@angular/core";

@Component({
  selector: "app-questionnaire-close",
  standalone: true,
  templateUrl: "./questionnaire-close.html",
  styleUrl: "./questionnaire-close.css",
})
export class QuestionnaireClose {
  @Input()
  remainingCount = 0;

  @Input()
  saving = false;

  @Output()
  continueQuestionnaire = new EventEmitter<void>();

  @Output()
  saveAndClose = new EventEmitter<void>();

  continue(): void {
    if (this.saving) {
      return;
    }

    this.continueQuestionnaire.emit();
  }

  close(): void {
    if (this.saving) {
      return;
    }

    this.saveAndClose.emit();
  }
}
