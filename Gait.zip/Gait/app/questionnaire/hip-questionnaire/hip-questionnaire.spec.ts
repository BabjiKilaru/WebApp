import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { HipQuestionnaire } from './hip-questionnaire';

describe('HipQuestionnaire', () => {
    let component: HipQuestionnaire;
    let http: HttpTestingController;
    beforeEach(async () => {
        await TestBed.configureTestingModule({ imports: [HipQuestionnaire], providers: [provideHttpClient(), provideHttpClientTesting()] })
            .overrideComponent(HipQuestionnaire, { set: { template: '' } }).compileComponents();
        component = TestBed.createComponent(HipQuestionnaire).componentInstance;
        http = TestBed.inject(HttpTestingController);
    });
    afterEach(() => http.verify());
    it('starts with missing WOMAC, UCLA and Harris answers', () => {
        expect(component.getProgress().total).toBeGreaterThan(0);
        expect(component.getProgress().answered).toBe(0);
        expect(component.validate()).not.toBeNull();
    });
    it('recognizes all required answers, including zero scores', () => {
        for (const item of [...component.womacPain, ...component.womacStiffness, ...component.womacFunction]) component.womac[item.key] = 0;
        for (const item of component.harrisItems) component.harris[item.key] = 0;
        component.ucla = 0;
        expect(component.getInvalidFields()).toEqual([]);
        expect(component.getProgress().answered).toBe(component.getProgress().total);
        expect(component.validate()).toBeNull();
    });
    it('POSTs the visit-associated HIP answers and handles save errors', () => {
        component.patientId = 42;
        component.visitId = 10;
        component.save();
        const request = http.expectOne('/api/patients/42/hip-questionnaire');
        expect(request.request.method).toBe('POST');
        expect(request.request.body.visitId).toBe(10);
        request.flush(null, { status: 500, statusText: 'Error' });
        expect(component.saving).toBe(false);
        expect(component.saved).toBe(false);
    });
});
