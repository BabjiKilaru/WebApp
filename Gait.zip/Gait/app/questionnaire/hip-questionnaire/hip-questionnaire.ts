import { CommonModule } from "@angular/common";
import { ChangeDetectorRef, Component, EventEmitter, Input, OnChanges, Output } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { HttpClient } from "@angular/common/http";
import { QuestionnaireProgressValue } from "../questionnaire-progress/questionnaire-progress";

interface Scale5Item {
  key: string;
  text: string;
}

interface HarrisItem {
  key: string;
  label: string;

  options: {
    points: number;
    label: string;
  }[];
}

@Component({
  selector: "app-hip-questionnaire",
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: "./hip-questionnaire.html",
  styleUrl: "./hip-questionnaire.css",
})
export class HipQuestionnaire implements OnChanges {
  @Input()
  patientId: number | null = null;

  @Input()
  visitId: number | null = null;

  @Input()
  hideActions = false;

  @Output()
  saveComplete = new EventEmitter<void>();

  @Output()
  saveFailed = new EventEmitter<string>();

  @Output()
  progressChange = new EventEmitter<void>();

  readonly womacScale = ["None", "Mild", "Moderate", "Severe", "Extreme"];

  readonly womacPain: Scale5Item[] = [
    {
      key: "womac_01",
      text: "Walking on a flat surface",
    },

    {
      key: "womac_02",
      text: "Going up and down stairs",
    },

    {
      key: "womac_03",
      text: "At night while in bed, pain disturbs your sleep",
    },

    {
      key: "womac_04",
      text: "Sitting or lying",
    },

    {
      key: "womac_05",
      text: "Standing upright",
    },
  ];

  readonly womacStiffness: Scale5Item[] = [
    {
      key: "womac_06",
      text: "How severe is your stiffness after first awakening in the morning?",
    },

    {
      key: "womac_07",
      text: "How severe is your stiffness after sitting, lying, or resting in the day?",
    },
  ];

  readonly womacFunction: Scale5Item[] = [
    {
      key: "womac_08",
      text: "Going down stairs",
    },

    {
      key: "womac_09",
      text: "Going up stairs",
    },

    {
      key: "womac_10",
      text: "Rising from sitting",
    },

    {
      key: "womac_11",
      text: "Standing",
    },

    {
      key: "womac_12",
      text: "Bending to the floor",
    },

    {
      key: "womac_13",
      text: "Walking on flat surfaces",
    },

    {
      key: "womac_14",
      text: "Getting in and out of a car, or on or off a bus",
    },

    {
      key: "womac_15",
      text: "Going shopping",
    },

    {
      key: "womac_16",
      text: "Putting on your socks or stockings",
    },

    {
      key: "womac_17",
      text: "Rising from the bed",
    },

    {
      key: "womac_18",
      text: "Taking off your socks or stockings",
    },

    {
      key: "womac_19",
      text: "Lying in bed",
    },

    {
      key: "womac_20",
      text: "Getting in or out of the bath",
    },

    {
      key: "womac_21",
      text: "Sitting",
    },

    {
      key: "womac_22",
      text: "Getting on or off the toilet",
    },

    {
      key: "womac_23",
      text: "Performance heavy domestic duties",
    },

    {
      key: "womac_24",
      text: "Performing light domestic duties",
    },
  ];

  readonly uclaOptions = [
    "Wholly Inactive, dependent on others, and can not leave residence",

    "Mostly Inactive or restricted to minimum activities of daily living",

    "Sometimes participates in mild activities, such as walking, limited housework and limited shopping",

    "Regularly Participates in mild activities",

    "Sometimes participates in moderate activities such as swimming or could do unlimited housework or shopping",

    "Regularly participates in moderate activities",

    "Regularly participates in active events such as bicycling",

    "Regularly participates in active events, such as golf or bowling",

    "Sometimes participates in impact sports such as jogging, tennis, skiing, acrobatics, ballet, heavy labor or backpacking",

    "Regularly participates in impact sports",
  ];

  readonly harrisItems: HarrisItem[] = [
    {
      key: "harris_01",
      label: "Pain",

      options: [
        {
          points: 44,
          label: "None/ignores",
        },

        {
          points: 40,
          label: "Slight, occasional, no compromise in activity",
        },

        {
          points: 30,
          label:
            "Mild, no effect on ordinary activity, pain after activity, uses aspirin",
        },

        {
          points: 20,
          label: "Moderate, tolerable, makes concessions, occasional codeine",
        },

        {
          points: 10,
          label: "Marked, serious limitations",
        },

        {
          points: 0,
          label: "Totally disabled",
        },
      ],
    },

    {
      key: "harris_02",
      label: "Limp",

      options: [
        {
          points: 11,
          label: "None",
        },

        {
          points: 8,
          label: "Slight",
        },

        {
          points: 5,
          label: "Moderate",
        },

        {
          points: 0,
          label: "Severe / Unable to walk",
        },
      ],
    },

    {
      key: "harris_03",
      label: "Support",

      options: [
        {
          points: 11,
          label: "None",
        },

        {
          points: 7,
          label: "Cane, long walks",
        },

        {
          points: 5,
          label: "Cane, full time",
        },

        {
          points: 4,
          label: "Crutch",
        },

        {
          points: 2,
          label: "2 canes",
        },

        {
          points: 1,
          label: "2 crutches",
        },

        {
          points: 0,
          label: "Unable to walk",
        },
      ],
    },

    {
      key: "harris_04",
      label: "Distance Walked",

      options: [
        {
          points: 11,
          label: "Unlimited",
        },

        {
          points: 8,
          label: "6 blocks",
        },

        {
          points: 5,
          label: "2-3 blocks",
        },

        {
          points: 2,
          label: "Indoors only",
        },

        {
          points: 0,
          label: "Bed and chair",
        },
      ],
    },

    {
      key: "harris_05",
      label: "Stairs",

      options: [
        {
          points: 4,
          label: "Normally",
        },

        {
          points: 2,
          label: "Normally with banister",
        },

        {
          points: 1,
          label: "Any method",
        },

        {
          points: 0,
          label: "Not able",
        },
      ],
    },

    {
      key: "harris_06",
      label: "Sock/Shoes",

      options: [
        {
          points: 4,
          label: "With ease",
        },

        {
          points: 2,
          label: "With difficulty",
        },

        {
          points: 0,
          label: "Unable",
        },
      ],
    },

    {
      key: "harris_07",
      label: "Sitting",

      options: [
        {
          points: 5,
          label: "Any chair, 1 hour",
        },

        {
          points: 3,
          label: "High chair, 1/2 hour",
        },

        {
          points: 0,
          label: "Unable to sit, 1/2 hour, any chair",
        },
      ],
    },

    {
      key: "harris_08",
      label: "Public Transportation",

      options: [
        {
          points: 1,
          label: "Able to enter public transportation",
        },

        {
          points: 0,
          label: "Unable to use public transportation",
        },
      ],
    },
  ];

  womac: Record<string, number | null> = {};

  ucla: number | null = null;

  harris: Record<string, number | null> = {};

  saving = false;

  saveError = "";

  saved = false;

  constructor(
    private http: HttpClient,

    private cdr: ChangeDetectorRef,
  ) {
    this.resetAnswers();
  }

  ngOnChanges(): void {
    this.resetAnswers();

    this.saved = false;

    this.saveError = "";

    this.preload();
  }

  private preload(): void {
    if (!this.patientId || !this.visitId) {
      return;
    }

    const visitId = this.visitId;

    this.http
      .get<{
        womac?: Record<string, number | null>;

        harris?: Record<string, number | null>;

        ucla?: number | null;
      }>(`/api/patients/${this.patientId}/hip-questionnaire/${visitId}`)
      .subscribe({
        next: (saved) => {
          if (visitId !== this.visitId) {
            return;
          }

          for (const [key, value] of Object.entries(saved.womac ?? {})) {
            if (key in this.womac && typeof value === "number") {
              this.womac[key] = value;
            }
          }

          for (const [key, value] of Object.entries(saved.harris ?? {})) {
            if (key in this.harris && typeof value === "number") {
              this.harris[key] = value;
            }
          }

          if (typeof saved.ucla === "number") {
            this.ucla = saved.ucla;
          }

          this.cdr.markForCheck();

          this.progressChange.emit();
        },

        error: () => {},
      });
  }

  private resetAnswers(): void {
    this.womac = {};

    for (const item of [
      ...this.womacPain,
      ...this.womacStiffness,
      ...this.womacFunction,
    ]) {
      this.womac[item.key] = null;
    }

    this.ucla = null;

    this.harris = {};

    for (const item of this.harrisItems) {
      this.harris[item.key] = null;
    }
  }

  answerChanged(): void {
    this.saved = false;

    this.progressChange.emit();
  }

  getProgress(): QuestionnaireProgressValue {
    const total = this.requiredQuestionCount();
    const answered = total - this.getInvalidFields().length;

    return {
      answered,
      total,
    };
  }

  validate(): string | null {
    return this.getInvalidFields().length > 0
      ? "Please answer all Hip questionnaire questions before moving to the next questionnaire."
      : null;
  }

  getInvalidFields(): string[] {
    const womacItems = [
      ...this.womacPain,
      ...this.womacStiffness,
      ...this.womacFunction,
    ];

    return [
      ...womacItems
        .filter((item) => this.womac[item.key] === null || this.womac[item.key] === undefined)
        .map((item) => item.key),
      ...(this.ucla === null || this.ucla === undefined ? ["ucla"] : []),
      ...this.harrisItems
        .filter((item) => this.harris[item.key] === null || this.harris[item.key] === undefined)
        .map((item) => item.key),
    ];
  }

  private requiredQuestionCount(): number {
    return (
      this.womacPain.length +
      this.womacStiffness.length +
      this.womacFunction.length +
      1 +
      this.harrisItems.length
    );
  }

  save(): void {
    if (!this.patientId || !this.visitId) {
      this.saveComplete.emit();

      return;
    }

    this.saving = true;

    this.saveError = "";

    this.http
      .post(`/api/patients/${this.patientId}/hip-questionnaire`, {
        visitId: this.visitId,

        womac: this.womac,

        ucla: this.ucla,

        harris: this.harris,
      })
      .subscribe({
        next: () => {
          this.saving = false;

          this.saved = true;

          this.cdr.markForCheck();

          this.progressChange.emit();

          this.saveComplete.emit();
        },

        error: (error) => {
          console.error("Unable to save Hip questionnaire:", error);

          this.saving = false;

          this.saveError = "Unable to save. Please try again.";

          this.cdr.markForCheck();

          this.saveFailed.emit(this.saveError);
        },
      });
  }
}
