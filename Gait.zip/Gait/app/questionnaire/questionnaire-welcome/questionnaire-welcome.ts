import { Component, EventEmitter, Input, Output } from "@angular/core";

import { CommonModule } from "@angular/common";

@Component({
  selector: "app-questionnaire-welcome",
  standalone: true,
  imports: [CommonModule],
  templateUrl: "./questionnaire-welcome.html",
  styleUrl: "./questionnaire-welcome.css",
})
export class QuestionnaireWelcome {
  @Input()
  patientName = "";

  @Input()
  questionnaireNames: string[] = [];

  @Output()
  startQuestionnaire = new EventEmitter<void>();

  start(): void {
    this.startQuestionnaire.emit();
  }
}
