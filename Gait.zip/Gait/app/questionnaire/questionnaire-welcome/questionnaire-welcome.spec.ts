import { vi } from "vitest";
import { QuestionnaireWelcome } from "./questionnaire-welcome";

describe("QuestionnaireWelcome", () => {
    it("emits the start event when requested", () => {
        const component = new QuestionnaireWelcome();
        const start = vi.fn();
        component.startQuestionnaire.subscribe(start);
        component.start();
        expect(start).toHaveBeenCalledOnce();
    });
});
