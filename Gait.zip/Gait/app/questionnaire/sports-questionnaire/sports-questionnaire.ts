import { CommonModule } from "@angular/common";
import { ChangeDetectorRef, Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { HttpClient } from "@angular/common/http";
import { QuestionnaireProgressValue } from "../questionnaire-progress/questionnaire-progress";

export interface SportsAnswers {
  reportingPerson: string;
  physicalTherapy: string;
  competitiveSports: string;
  yearsInSport: string;
  daysPerWeek: string;
  orthotics: string;
  painLocations: string[];
  mileTimeKnown: "unknown" | "known" | "";
  mileTimeType: "Unknown" | "Time";
  mileTime: string;
  goals: string;
}

@Component({
  selector: "app-sports-questionnaire",
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: "./sports-questionnaire.html",
  styleUrl: "./sports-questionnaire.css",
})
export class SportsQuestionnaire implements OnChanges {
  @Input()
  patientId: number | null = null;

  @Input()
  visitId: number | null = null;

  @Input()
  language: "en" | "sp" = "en";

  @Input()
  hideActions = false;

  @Output()
  saveComplete = new EventEmitter<void>();

  @Output()
  saveFailed = new EventEmitter<string>();

  @Output()
  progressChange = new EventEmitter<void>();

  @Output()
  questionnaireOpened = new EventEmitter<void>();

  readonly physicalTherapyOptions = [
    "3 or more times a week",
    "2 times a week",
    "Once a week",
    "Less than once a week",
    "Not currently",
  ];

  readonly yearsInSportOptions = [
    "Less than one year",
    "1-2 years",
    "3-4 years",
    "5 years or more",
  ];

  readonly daysPerWeekOptions = ["none", "1", "2", "3", "4", "5", "6", "7"];

  readonly orthoticsOptions = [
    "None",
    "Over the counter orthotics",
    "Custom fitted orthotics",
  ];

  readonly painLocationOptions = [
    "None",
    "Back",
    "R Hip",
    "L Hip",
    "R Knee",
    "L Knee",
    "R Ankle",
    "L Ankle",
    "R Foot",
    "L Foot",
    "R Thigh",
    "L Thigh",
    "R Lower leg",
    "L Lower leg",
  ];

  answers: SportsAnswers = this.createEmptyAnswers();

  private sessionId: number | null = null;

  saving = false;

  saveError = "";

  saved = false;

  constructor(
    private http: HttpClient,

    private cdr: ChangeDetectorRef,
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (!(changes["patientId"] || changes["visitId"] || changes["language"])) {
      return;
    }

    this.answers = this.createEmptyAnswers();

    this.sessionId = null;

    this.saved = false;

    this.saveError = "";

    this.preload();
  }

  private preload(): void {
    if (!this.patientId || !this.visitId) {
      return;
    }

    const visitId = this.visitId;

    this.http
      .get<Partial<Record<keyof SportsAnswers, string | string[] | null>> & { sessionId?: number }>(
        `/api/patients/${this.patientId}/sports-questionnaire/${visitId}?language=${this.language}`,
      )
      .subscribe({
        next: (saved) => {
          if (visitId !== this.visitId || !saved) {
            return;
          }

          this.sessionId = saved.sessionId ?? null;

          const text = (value: string | string[] | null | undefined) =>
            typeof value === "string" ? value : "";

          const known = saved.mileTimeKnown;

          this.answers = {
            reportingPerson: text(saved.reportingPerson),

            physicalTherapy: text(saved.physicalTherapy),

            competitiveSports: text(saved.competitiveSports),

            yearsInSport: text(saved.yearsInSport),

            daysPerWeek: text(saved.daysPerWeek),

            orthotics: text(saved.orthotics),

            painLocations: Array.isArray(saved.painLocations)
              ? [...saved.painLocations]
              : [],

            mileTimeKnown:
              known === "unknown" || known === "known" ? known : "unknown",

            mileTimeType: known === "known" ? "Time" : "Unknown",

            mileTime: text(saved.mileTime),

            goals: text(saved.goals),
          };

          this.cdr.markForCheck();

          this.progressChange.emit();
          this.questionnaireOpened.emit();
        },

        error: () => {},
      });
  }

  private createEmptyAnswers(): SportsAnswers {
    return {
      reportingPerson: "",

      physicalTherapy: "",

      competitiveSports: "",

      yearsInSport: "",

      daysPerWeek: "",

      orthotics: "",

      painLocations: [],

      mileTimeKnown: "unknown",

      mileTimeType: "Unknown",

      mileTime: "",

      goals: "",
    };
  }

  painLocationLabel(location: string): string {
    if (location.startsWith("R ")) {
      return `Right ` + `${location.substring(2)}`;
    }

    if (location.startsWith("L ")) {
      return `Left ` + `${location.substring(2)}`;
    }

    return location;
  }

  isPainSelected(location: string): boolean {
    return this.answers.painLocations.includes(location);
  }

  isPainDisabled(location: string): boolean {
    return location !== "None" && this.isPainSelected("None");
  }

  togglePainLocation(location: string): void {
    const selected = this.isPainSelected(location);

    if (location === "None") {
      if (selected) {
        this.answers.painLocations = [];
      } else {
        this.answers.painLocations = ["None"];
      }

      this.progressChange.emit();

      return;
    }

    if (this.isPainSelected("None")) {
      return;
    }

    if (selected) {
      this.answers.painLocations = this.answers.painLocations.filter(
        (item) => item !== location,
      );
    } else {
      this.answers.painLocations = [...this.answers.painLocations, location];
    }

    this.progressChange.emit();
  }

  isMileTimeEnabled(): boolean {
    return this.answers.mileTimeType === "Time";
  }

  setMileTimeType(type: "Unknown" | "Time"): void {
    this.answers.mileTimeType = type;

    if (type === "Unknown") {
      this.answers.mileTimeKnown = "unknown";

      this.answers.mileTime = "";
    } else {
      this.answers.mileTimeKnown = "known";
    }

    this.progressChange.emit();
  }

  getProgress(): QuestionnaireProgressValue {
    const textAnswered = (value: string) =>
      value.trim() !== "" && value.trim() !== "Tap to Enter Text";

    const a = this.answers;

    const answered = [
      textAnswered(a.reportingPerson),

      a.physicalTherapy !== "",

      textAnswered(a.competitiveSports),

      a.yearsInSport !== "",

      a.daysPerWeek !== "",

      a.orthotics !== "",

      a.painLocations.length > 0,

      a.mileTimeKnown !== "",

      textAnswered(a.goals),
    ].filter(Boolean).length;

    return {
      answered,
      total: 9,
    };
  }

  validate(): string | null {
    return this.getInvalidFields().length > 0
      ? "You must answer above before submitting."
      : null;
  }

  getInvalidFields(): string[] {
    const text = (value: string) =>
      value.trim() !== "" && value.trim() !== "Tap to Enter Text";

    const a = this.answers;

    return [
      ...(!text(a.reportingPerson) ? ["reportingPerson"] : []),
      ...(a.physicalTherapy === "" ? ["physicalTherapy"] : []),
      ...(!text(a.competitiveSports) ? ["competitiveSports"] : []),
      ...(a.yearsInSport === "" ? ["yearsInSport"] : []),
      ...(a.daysPerWeek === "" ? ["daysPerWeek"] : []),
      ...(a.orthotics === "" ? ["orthotics"] : []),
      ...(a.painLocations.length === 0 ? ["painLocations"] : []),
      ...(a.mileTimeKnown === "" ? ["mileTimeType"] : []),
      ...(!text(a.goals) ? ["goals"] : []),
    ];
  }

  save(): void {
    if (!this.patientId || !this.visitId || !this.sessionId) {
      this.saveFailed.emit("Unable to start this questionnaire session. Reload and try again.");

      return;
    }

    this.saving = true;

    this.saveError = "";

    this.http
      .post(`/api/patients/${this.patientId}/sports-questionnaire`, {
        visitId: this.visitId,

        sessionId: this.sessionId,

        language: this.language,

        ...this.answers,
      })
      .subscribe({
        next: () => {
          this.saving = false;

          this.saved = true;

          this.cdr.markForCheck();

          this.progressChange.emit();

          this.saveComplete.emit();
        },

        error: (error) => {
          console.error("Unable to save Sports questionnaire:", error);

          this.saving = false;

          this.saveError = "Unable to save. Please try again.";

          this.cdr.markForCheck();

          this.saveFailed.emit(this.saveError);
        },
      });
  }
}
