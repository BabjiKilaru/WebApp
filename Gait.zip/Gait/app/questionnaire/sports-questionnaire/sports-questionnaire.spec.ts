import { vi } from 'vitest';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { SportsQuestionnaire } from './sports-questionnaire';

describe('SportsQuestionnaire', () => {
    let component: SportsQuestionnaire;
    let http: HttpTestingController;
    beforeEach(async () => {
        await TestBed.configureTestingModule({ imports: [SportsQuestionnaire], providers: [provideHttpClient(), provideHttpClientTesting()] })
            .overrideComponent(SportsQuestionnaire, { set: { template: '' } }).compileComponents();
        component = TestBed.createComponent(SportsQuestionnaire).componentInstance;
        http = TestBed.inject(HttpTestingController);
    });
    afterEach(() => http.verify());
    it('requires reporting person, sport details, pain and goals', () => {
        expect(component.getInvalidFields()).toContain('reportingPerson');
        expect(component.getInvalidFields()).toContain('painLocations');
        expect(component.validate()).not.toBeNull();
    });
    it('treats None as mutually exclusive with individual pain locations', () => {
        component.togglePainLocation('R Hip');
        expect(component.answers.painLocations).toEqual(['R Hip']);
        component.togglePainLocation('None');
        expect(component.answers.painLocations).toEqual(['None']);
        component.togglePainLocation('L Hip');
        expect(component.answers.painLocations).toEqual(['None']);
        component.togglePainLocation('None');
        expect(component.answers.painLocations).toEqual([]);
    });
    it('clears the mile time when changed to Unknown', () => {
        component.setMileTimeType('Time');
        expect(component.isMileTimeEnabled()).toBe(true);
        component.answers.mileTime = '08:30';
        component.setMileTimeType('Unknown');
        expect(component.answers.mileTime).toBe('');
        expect(component.answers.mileTimeKnown).toBe('unknown');
    });
    it('refuses to save without a server-assigned questionnaire session', () => {
        component.patientId = 42;
        component.visitId = 10;
        const failed = vi.fn();
        component.saveFailed.subscribe(failed);
        component.save();
        expect(failed).toHaveBeenCalledOnce();
        http.expectNone('/api/patients/42/sports-questionnaire');
    });
});