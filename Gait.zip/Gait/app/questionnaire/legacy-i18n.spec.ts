import { fillName, translate } from './legacy-i18n';

describe('Legacy questionnaire translation', () => {
    it('keeps English text and strips context suffixes', () => {
        expect(translate('Name#entry', 'en')).toBe('Name');
    });
    it('uses known Spanish translations', () => {
        expect(translate('Thank You', 'sp')).toBe('Gracias');
    });
    it('falls back to English for missing Spanish keys', () => {
        expect(translate('Untranslated sentence', 'sp')).toBe('Untranslated sentence');
    });
    it('replaces every patient-name placeholder using the supplied fallback', () => {
        expect(fillName('[name] and [name]', 'Alex', 'your child')).toBe('Alex and Alex');
        expect(fillName('Hello [name]', '', 'your child')).toBe('Hello your child');
    });
});