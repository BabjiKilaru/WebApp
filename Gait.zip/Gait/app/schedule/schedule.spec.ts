import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { vi } from 'vitest';
import { PatientService } from '../patients/patient.service';
import { Schedule, ScheduledVisit } from './schedule';

const VISIT: ScheduledVisit = {
    id: 1, patientId: 42, firstName: 'Alex', lastName: 'Smith', mrn: '500',
    visitDate: '2026-10-13', startTime: '9:00 AM', endTime: '10:00 AM', visitType: 'Gait', visitSubType: 'Initial',
};

describe('Schedule', () => {
    let component: Schedule;
    let http: HttpTestingController;
    let router: Router;
    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [Schedule],
            providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting(),
            { provide: PatientService, useValue: { searchPatients: vi.fn(() => of([])) } }],
        }).overrideComponent(Schedule, { set: { template: '' } }).compileComponents();
        component = TestBed.createComponent(Schedule).componentInstance;
        http = TestBed.inject(HttpTestingController);
        router = TestBed.inject(Router);
    });
    afterEach(() => { component.ngOnDestroy(); http.verify(); });

    it('builds a 42-day calendar with exactly one selected date', () => {
        component.buildCalendar();
        expect(component.calendarDays).toHaveLength(42);
        expect(component.calendarDays.filter(day => day.selected)).toHaveLength(1);
    });
    it('renders appointment positions and widths based on time and duration', () => {
        expect(component.appointmentTop(VISIT)).toBe(75);
        expect(component.appointmentHeight(VISIT)).toBe(75);
        expect(component.getPatientDisplayName(VISIT)).toBe('Alex Smith');
        expect(component.getVisitDisplayType(VISIT)).toBe('Gait - Initial');
    });
    it('loads scheduled visits using the selected date', () => {
        component.selectedDate = new Date(2026, 9, 13);
        component.loadVisits();
        const req = http.expectOne(request => request.url === '/api/schedule-visit/scheduled-visits');
        expect(req.request.params.get('date')).toBe('2026-10-13');
        req.flush([]);
        expect(component.scheduledVisits).toEqual([]);
        expect(component.loadingVisits).toBe(false);
    });
    it('displays a useful load error', () => {
        component.loadVisits();
        http.expectOne(request => request.url === '/api/schedule-visit/scheduled-visits').flush(null, { status: 500, statusText: 'Failure' });
        expect(component.scheduleError).toBe('Unable to load scheduled visits.');
    });
    it('opens the corresponding patient without navigating for an invalid ID', () => {
        const navigate = vi.spyOn(router, 'navigate').mockResolvedValue(true);
        component.openPatient({ ...VISIT, patientId: 0 });
        expect(navigate).not.toHaveBeenCalled();
        component.openPatient(VISIT);
        expect(navigate).toHaveBeenCalledWith(['/patients'], { queryParams: { patientId: 42 } });
    });
});