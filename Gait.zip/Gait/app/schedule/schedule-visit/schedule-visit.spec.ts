import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting
} from '@angular/common/http/testing';

import { ScheduleVisit } from './schedule-visit';

describe('ScheduleVisit', () => {
  let component: ScheduleVisit;
  let fixture: ComponentFixture<ScheduleVisit>;
  let httpTesting: HttpTestingController;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ScheduleVisit],
      providers: [
        provideHttpClient(),
        provideHttpClientTesting()
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(ScheduleVisit);
    component = fixture.componentInstance;
    httpTesting = TestBed.inject(HttpTestingController);

    fixture.detectChanges();

    const endpoints = [
      '/api/schedule-visit/visit-types',
      '/api/schedule-visit/visit-sub-types',
      '/api/schedule-visit/tests',
      '/api/schedule-visit/referring-doctors'
    ];

    for (const endpoint of endpoints) {
      const request = httpTesting.expectOne(endpoint);
      expect(request.request.method).toBe('GET');
      request.flush([]);
    }
  });

  afterEach(() => {
    httpTesting.verify();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('offers half-hour appointment choices', () => {
    expect(component.timeOptions.length).toBeGreaterThan(0);
    expect(component.timeOptions).toContain('8:00 AM');
  });

  it('rejects missing date or visit type', () => {
    component.patientId = 42;
    component.form.visitDate = '';
    component.saveForm();
    expect(component.errorMessage).toBe('Visit date is required.');
    component.form.visitDate = '2026-10-13';
    component.saveForm();
    expect(component.errorMessage).toBe('Visit type is required.');
    httpTesting.expectNone(request => request.method === 'POST');
  });

  it('rejects an end time before the start time', () => {
    component.patientId = 42;
    component.form.visitDate = '2026-10-13';
    component.form.visitTypeId = 1;
    component.form.startTime = '10:00 AM';
    component.form.endTime = '9:00 AM';
    component.saveForm();
    expect(component.errorMessage).toBe('End time must be after start time.');
    httpTesting.expectNone(request => request.method === 'POST');
  });

  it('loads default tests associated with the selected subtype', () => {
    component.form.selectedTests = ['stale'];
    component.onVisitSubTypeChange(3);
    const req = httpTesting.expectOne('/api/schedule-visit/visit-sub-types/3/default-tests');
    expect(req.request.method).toBe('GET');
    req.flush(['PT', 'GAIT']);
    expect(component.form.selectedTests).toEqual(['PT', 'GAIT']);
  });

  it('persists selected tests and emits the saved form after success', () => {
    component.patientId = 42;
    component.form.visitDate = '2026-10-13';
    component.form.visitTypeId = 1;
    component.form.selectedTests = ['GAIT'];
    const emitted: string[][] = [];
    component.save.subscribe(form => emitted.push(form.selectedTests));
    component.saveForm();
    const req = httpTesting.expectOne('/api/schedule-visit/patients/42');
    expect(req.request.method).toBe('POST');
    expect(req.request.body.selectedTests).toEqual(['GAIT']);
    req.flush({});
    expect(emitted).toEqual([['GAIT']]);
  });
});