import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

export interface VisitTypeOption {
  id: number;
  name: string;
}

export interface VisitSubTypeOption {
  id: number;
  name: string;
  visitTypeId: number;
}

export interface ReferringDoctorOption {
  id: number;
  firstName: string;
  lastName: string;
  facility?: string | null;
}

export interface TestOption {
  code: string;
  name: string;
  description?: string | null;
}

export interface NewVisitForm {
  schedulingDate: string;
  visitDate: string;
  visitTypeId: number | null;
  visitSubTypeId: number | null;
  startTime: string;
  endTime: string;
  surgeryDate: string;
  referringMdId: number | null;
  selectedTests: string[];
}

@Component({
  selector: 'app-schedule-visit',
  standalone: true,
  imports: [ CommonModule, FormsModule],
  templateUrl: './schedule-visit.html',
  styleUrl: './schedule-visit.css'
})

export class ScheduleVisit implements OnInit, OnChanges {
  @Input() patientId: number | null = null;
  @Input() patientName = '';
  @Input() mrn = '';

  @Input() disabled = false;
  @Input() initialVisitDate = '';

  @Output() cancel = new EventEmitter<void>();
  @Output() save = new EventEmitter<NewVisitForm>();

  visitTypes: VisitTypeOption[] = [];
  visitSubTypes: VisitSubTypeOption[] = [];
  referringDoctors: ReferringDoctorOption[] = [];
  availableTests: TestOption[] = [];

  timeOptions: string[] = [];

  errorMessage = '';
  loadingDefaultTests = false;

  form: NewVisitForm = this.createEmptyForm();

  constructor(
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.generateTimeOptions();

    if (this.initialVisitDate) {
      this.form.visitDate =
        this.initialVisitDate;
    }

    this.loadVisitTypes();
    this.loadVisitSubTypes();
    this.loadTests();
    this.loadReferringDoctors();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['initialVisitDate'] && this.initialVisitDate) {
      this.form.visitDate = this.initialVisitDate;
    }

    if (changes['patientId'] && changes['patientId'].previousValue && !this.patientId) {
      this.resetForm();
    }
  }

  get filteredVisitSubTypes(): VisitSubTypeOption[] {
    if (!this.form.visitTypeId) {
      return [];
    }

    return this.visitSubTypes.filter(subtype => subtype.visitTypeId === this.form.visitTypeId
    );
  }

  onVisitTypeChange(): void {
    this.form.visitSubTypeId = null;
    this.form.selectedTests = [];
    this.errorMessage = '';
  }

  onVisitSubTypeChange(groupId: number | null): void {
    this.form.selectedTests = [];
    this.errorMessage = '';

    if (!groupId) {
      return;
    }

    this.loadingDefaultTests = true;

    this.http
      .get<string[]>(
        `/api/schedule-visit/visit-sub-types/${groupId}/default-tests`
      )
      .subscribe({
        next: testCodes => {
          this.form.selectedTests = (testCodes ?? []).map(code => String(code));
          this.loadingDefaultTests = false;
        },

        error: error => {
          console.error('Unable to load default tests:', error);
          this.form.selectedTests = [];
          this.loadingDefaultTests = false;
        }
      });
  }

  isTestSelected(code: string): boolean {
    return this.form.selectedTests.includes(code);
  }

  toggleTest(code: string, event: Event): void {
    if (this.disabled) {
      return;
    }

    const checkbox = event.target as HTMLInputElement;

    if (checkbox.checked) {
      if (!this.form.selectedTests.includes(code)) {
        this.form.selectedTests = [...this.form.selectedTests, code];
      }
    } else {
      this.form.selectedTests = this.form.selectedTests.filter(testCode => testCode !== code);
    }
  }

  cancelForm(): void {
    this.cancel.emit();
  }

  saveForm(): void {
    if (this.disabled || !this.patientId) {
      return;
    }

    this.errorMessage = '';

    if (!this.form.visitDate) {
      this.errorMessage = 'Visit date is required.';
      return;
    }

    if (!this.form.visitTypeId) {
      this.errorMessage = 'Visit type is required.';
      return;
    }

    if (this.form.startTime && this.form.endTime
    ) {
      const start = this.timeToMinutes(this.form.startTime);
      const end = this.timeToMinutes(this.form.endTime);

      if (end <= start) {
        this.errorMessage = 'End time must be after start time.';
        return;
      }
    }

    const request = {
      schedulingDate: this.form.schedulingDate,
      visitDate: this.form.visitDate,
      visitTypeId: this.form.visitTypeId,
      visitSubTypeId: this.form.visitSubTypeId,
      startTime: this.form.startTime,
      endTime: this.form.endTime,
      surgeryDate: this.form.surgeryDate || null,
      referringMdId: this.form.referringMdId,
      selectedTests: [...this.form.selectedTests]
    };

    this.http
      .post(
        `/api/schedule-visit/patients/${this.patientId}`, request
      )
      .subscribe({
        next: () => {
          const savedForm:
            NewVisitForm = {
              ...this.form, selectedTests: [...this.form.selectedTests]
            };
          this.save.emit(savedForm);
        },

        error: error => {
          console.error('Failed to save visit:', error);
          this.errorMessage = error?.error?.message || 'Unable to save the visit. Please check the form and try again.';
        }
      });
  }

  private loadVisitTypes(): void {
    this.http .get<any[]>(
        '/api/schedule-visit/visit-types'
      )
      .subscribe({
        next: data => {
          this.visitTypes = data.map(item => ({
              id: Number(item.id),
              name: item.name ?? ''
            }));
        },

        error: error => {
          console.error('Error loading visit types:', error);
        }
      });
  }

  private loadVisitSubTypes(): void {
    this.http
      .get<any[]>(
        '/api/schedule-visit/visit-sub-types'
      )
      .subscribe({
        next: data => {
          this.visitSubTypes = data.map(item => ({
              id: Number(item.id),
              name: item.name ?? '',
              visitTypeId: Number(item.visit_type_id ?? item.visitTypeId)
            }));
        },

        error: error => {
          console.error('Error loading visit sub types:', error);
        }
      });
  }

  private loadTests(): void {
    this.http
      .get<any[]>(
        '/api/schedule-visit/tests'
      )
      .subscribe({
        next: data => {
          this.availableTests = data.map(item => ({
              code: String(item.code),
              name: item.name ?? '',
              description: item.description ?? null
            }));
        },

        error: error => {
          console.error('Error loading tests:', error);
        }
      });
  }

  private loadReferringDoctors(): void {
    this.http
      .get<any[]>(
        '/api/schedule-visit/referring-doctors'
      )
      .subscribe({
         next: data => {
          this.referringDoctors = data.map(item => ({
              id: Number(item.id),
              firstName: item.fname ?? item.firstName ?? '',
              lastName: item.lname ?? item.lastName ?? '',
              facility: item.facility ?? null
            }));
        },

        error: error => {
          console.error('Error loading referring doctors:', error);
        }
      });
  }

  private generateTimeOptions(): void {
    this.timeOptions = [];

    for (let hour = 8; hour <= 18; hour++) {
      for (const minute of [0, 30]) {
        if (hour === 18 && minute === 30) {
          break;
        }

        const period = hour >= 12 ? 'PM' : 'AM';
        const displayHour = hour > 12 ? hour - 12 : hour;
        const displayMinute = minute.toString().padStart(2, '0');
        this.timeOptions.push(
          `${displayHour}:${displayMinute} ${period}`
        );
      }
    }
  }

  private timeToMinutes(value: string): number {
    const [time,period] = value.trim().split(/\s+/);
    const [hour, minute] = time.split(':').map(Number);
    return ((hour % 12 + (period === 'PM' ? 12 : 0)) * 60 + minute);
  }

  private resetForm(): void {
    this.form = this.createEmptyForm();

    if (this.initialVisitDate) {
      this.form.visitDate = this.initialVisitDate;
    }

    this.errorMessage = '';
    this.loadingDefaultTests = false;
  }

  private createEmptyForm(): NewVisitForm {
    return {
      schedulingDate: this.getToday(),
      visitDate: '',
      visitTypeId: null,
      visitSubTypeId: null,
      startTime: '',
      endTime: '',
      surgeryDate: '',
      referringMdId: null,
      selectedTests: []
    };
  }

  private getToday(): string {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
}
