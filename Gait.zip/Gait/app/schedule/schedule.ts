import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Subject, of } from 'rxjs';
import { catchError, debounceTime, distinctUntilChanged, switchMap, takeUntil } from 'rxjs/operators';
import { Header } from '../header/header';
import { Patient } from '../patients/patient';
import { PatientService } from '../patients/patient.service';
import { NewVisitForm, ScheduleVisit } from './schedule-visit/schedule-visit';
import { debounce } from '@angular/forms/signals';

export interface ScheduledVisit {
  id: number;
  patientId: number;
  firstName: string;
  lastName: string;
  mrn: string;
  visitDate: string;
  startTime: string | null;
  endTime: string | null;
  visitType: string | null;
  visitSubType: string | null;

  laneIndex?: number;
  laneCount?: number;
}

interface CalendarDay {
  date: Date;
  dayNumber: number;
  currentMonth: boolean;
  selected: boolean;
  today: boolean;
}

@Component({
  selector: 'app-schedule',
  standalone: true,
  imports: [ CommonModule, FormsModule, Header, ScheduleVisit ],
  templateUrl: './schedule.html',
  styleUrl: './schedule.css'
})
export class Schedule
implements OnInit, OnDestroy {
  selectedDate = this.startOfDay(new Date());
  calendarMonth = new Date(this.selectedDate.getFullYear(), this.selectedDate.getMonth(), 1);
  calendarDays: CalendarDay[] = [];
  calendarYears: number[] = [];
  scheduledVisits: ScheduledVisit[] = [];
  loadingVisits = false;
  scheduleError = '';
  showNewVisitModal = false;
  patientSearchQuery = '';
  patientSuggestions: Patient[] = [];
  patientSuggestionsOpen = false;
  patientSearchLoading = false;
  patientSearchError = '';
  selectedPatient: Patient | null = null;

  readonly scheduleStartMinutes = 8 * 60;
  readonly scheduleEndMinutes = 18 * 60;
  readonly pixelsPerMinute = 1.25;

  readonly timeSlots = [
    '8:00 AM',
    '9:00 AM',
    '10:00 AM',
    '11:00 AM',
    '12:00 PM',
    '1:00 PM',
    '2:00 PM',
    '3:00 PM',
    '4:00 PM',
    '5:00 PM',
    '6:00 PM'
  ];

  private patientSearchSubject = new Subject<string>();

  private destroy$ = new Subject<void>();

  constructor(
    private http: HttpClient,
    private patientService: PatientService,
    private cdr: ChangeDetectorRef,
    private router: Router
  ) {
    this.patientSearchSubject.pipe(
      debounceTime(250),
      distinctUntilChanged(),
      switchMap(query => {
        const search = query.trim();
        if (search.length < 2){
          return of([] as Patient[]);
        }

        this.patientSearchLoading = true;
        this.patientSearchError = '';
        return this.patientService.searchPatients(search).pipe(
          catchError(error => {
            console.error('Patient search failed:', error);
            this.patientSearchError = 'Unable to search patients.';
            return of([] as Patient[]);
          })
        );
      }),
      takeUntil(this.destroy$)
    )
    .subscribe(patients => {
      this.patientSearchLoading = false;
      this.patientSuggestions = patients;
      this.patientSuggestionsOpen = this.patientSearchQuery.trim().length >= 2 && !this.selectedPatient;
      this.cdr.markForCheck();
    });
  }

  ngOnInit(): void {
    this.buildCalendar();
    this.loadVisits();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  openPatient(visit: ScheduledVisit): void {
    if(!visit.patientId){
      return;
    }
    this.router.navigate(['/patients'], {queryParams: {patientId: visit.patientId}});
  }

  get appointmentAreaHeight(): number {
    return (this.scheduleEndMinutes - this.scheduleStartMinutes) * this.pixelsPerMinute;
  }

  get selectedDateForInput(): string {
    return this.formatDateForApi(this.selectedDate);
  }

  buildCalendar(): void {
    const year = this.calendarMonth.getFullYear();
    const month = this.calendarMonth.getMonth();
    this.calendarYears = Array.from({ length: 101 }, (_, index) => year + index - 50);
    const firstDay = new Date(year, month, 1);
    const startDate = new Date(year, month, 1 - firstDay.getDay());
    const today = this.startOfDay(new Date());
    const days: CalendarDay[] = [];

    for (let index = 0; index < 42; index++) {
      const date = new Date(startDate);
      date.setDate(startDate.getDate() + index);

      days.push({
        date: this.startOfDay(date),
        dayNumber: date.getDate(),
        currentMonth: date.getMonth() === month,
        selected: this.isSameDate(date, this.selectedDate),
        today: this.isSameDate(date, today)
      });
    }

    this.calendarDays = days;
  }

  selectDate(day: CalendarDay): void {
    this.selectedDate = this.startOfDay(day.date);

    if (day.date.getMonth() !== this.calendarMonth.getMonth() || day.date.getFullYear() !== this.calendarMonth.getFullYear()) {
      this.calendarMonth = new Date(day.date.getFullYear(), day.date.getMonth(), 1);
    }

    this.buildCalendar();
    this.loadVisits();
  }

  previousMonth(): void {
    this.calendarMonth = new Date(this.calendarMonth.getFullYear(), this.calendarMonth.getMonth() - 1, 1);
    this.buildCalendar();
  }

  nextMonth(): void {
    this.calendarMonth = new Date(this.calendarMonth.getFullYear(), this.calendarMonth.getMonth() + 1, 1);
    this.buildCalendar();
  }

  changeYear(year: number): void {
    if (!Number.isInteger(year)) {
      return;
    }

    this.calendarMonth = new Date(year, this.calendarMonth.getMonth(), 1);
    this.buildCalendar();
  }

  previousDay(): void {
    const date = new Date(this.selectedDate);
    date.setDate(date.getDate() - 1);
    this.changeSelectedDate(date);
  }

  nextDay(): void {
    const date = new Date(this.selectedDate);
    date.setDate(date.getDate() + 1);
    this.changeSelectedDate(date);
  }

  goToToday(): void {
    this.changeSelectedDate(new Date());
  }

  openNewVisit(): void {
    this.showNewVisitModal = true;
    this.resetPatientSearch();
  }

  closeNewVisitModal(): void {
    this.showNewVisitModal = false;
    this.resetPatientSearch();
  }

  onModalBackdropClick(): void {
    this.closeNewVisitModal();
  }

  onPatientSearchInput(value: string): void {
    this.patientSearchQuery = value;
    this.patientSearchError = '';
    if (this.selectedPatient) {
      this.selectedPatient = null;
    }

    const query = value.trim();

    if (query.length < 2) {
      this.patientSuggestions = [];
      this.patientSuggestionsOpen = false;
      this.patientSearchLoading = false;
      return;
    }

    this.patientSuggestionsOpen = true;
    this.patientSearchSubject .next(query);
  }

  selectPatient(patient: Patient): void {
    this.selectedPatient = patient;
    const firstName = patient.firstName ?? '';
    const lastName = patient.lastName ?? '';
    const mrn = patient.mrn ?? '';
    this.patientSearchQuery = `${lastName}, ${firstName} - MRN ${mrn}`;
    this.patientSuggestions = [];
    this.patientSuggestionsOpen = false;
    this.patientSearchLoading = false;
    this.patientSearchError = '';
  }

  clearSelectedPatient(): void {
    this.selectedPatient = null;
    this.patientSearchQuery = '';
    this.patientSuggestions = [];
    this.patientSuggestionsOpen = false;
    this.patientSearchLoading = false;
    this.patientSearchError = '';
  }

  onVisitSaved(form: NewVisitForm): void {
    if (form.visitDate) {
      const parts = form.visitDate.split('-').map(Number);
      if (parts.length === 3) {
        this.selectedDate = new Date(parts[0], parts[1] - 1, parts[2]);
        this.calendarMonth = new Date(parts[0], parts[1] - 1, 1);
        this.buildCalendar();
      }
    }

    this.closeNewVisitModal();
    this.loadVisits();
  }

  loadVisits(): void {
    this.loadingVisits = true;
    this.scheduleError = '';
    const date = this.formatDateForApi(this.selectedDate);

    this.http
      .get<any[]>('/api/schedule-visit/scheduled-visits',
        {
          params: { date }
        }
      )
      .subscribe({ next: data => {
        const visits = (data ?? []).map(item => this.mapScheduledVisit(item)).sort((first, second) => this.sortTime(first.startTime) - this.sortTime(second.startTime));
        this.scheduledVisits = this.layoutOverlappingVisits(visits);
        this.loadingVisits = false;
        this.cdr.detectChanges();
      }, error: error => {
          console.error('Unable to load scheduled visits:', error);
          this.scheduledVisits = [];
          this.loadingVisits = false;
          this.scheduleError = 'Unable to load scheduled visits.';
          this.cdr.detectChanges();
        }
      });
  }

  appointmentTop(visit: ScheduledVisit): number {
    const start = this.timeToMinutes(visit.startTime);
    if (start === null) {
      return 0;
    }

    const safeStart = Math.max(this.scheduleStartMinutes, start);
    return (safeStart - this.scheduleStartMinutes) * this.pixelsPerMinute;
  }

  appointmentHeight(visit: ScheduledVisit): number {
    const start = this.timeToMinutes(visit.startTime);
    const end = this.timeToMinutes(visit.endTime);

    if (start === null) {
      return 60;
    }

    const duration = end !== null && end > start ? end - start : 60;
    return Math.max(duration * this.pixelsPerMinute, 55);
  }

  timeSlotTop(time: string): number {
    const minutes = this.timeToMinutes(time);

    if (minutes === null) {
      return 0;
    }

    return (minutes - this.scheduleStartMinutes) * this.pixelsPerMinute;
  }

  getVisitColorClass(index: number): string {
    const colors = [
      'visit-blue',
      'visit-green',
      'visit-purple',
      'visit-orange',
      'visit-red'
    ];

    return colors[index % colors.length];
  }

  getVisitDisplayType(visit: ScheduledVisit): string {
    if (visit.visitType && visit.visitSubType) {
      return (`${visit.visitType} - ` + `${visit.visitSubType}`);
    }

    return (visit.visitSubType || visit.visitType || '');
  }

  getPatientDisplayName(visit: ScheduledVisit): string {
    const first = visit.firstName || '';
    const last = visit.lastName || '';
    return `${first} ${last}`.trim();
  }

  private layoutOverlappingVisits(visits: ScheduledVisit[]): ScheduledVisit[] {
    const result = visits.map(visit => ({...visit, laneIndex: 0, laneCount: 1}));
    let groupStart = 0;
    while(groupStart < result.length) {
      let groupEnd = groupStart + 1;
      let latestEnd = this.getVisitEndMinutes(result[groupStart]);
      while(groupEnd < result.length) {
        const nextStart = this.getVisitStartMinutes(result[groupEnd]);

        if (nextStart >= latestEnd){
          break;
        }

        latestEnd = Math.max(latestEnd, this.getVisitEndMinutes(result[groupEnd]));

        groupEnd++;
      }
      const group = result.slice(groupStart, groupEnd);
      const laneEndTimes: number[] = [];

      for(const visit of group) {
        const start = this.getVisitStartMinutes(visit);
        const end = this.getVisitEndMinutes(visit);
        let laneIndex = laneEndTimes.findIndex(laneEnd => laneEnd <= start);
        if(laneIndex === -1) {
          laneIndex = laneEndTimes.length;
          laneEndTimes.push(end);
        } else {
          laneEndTimes[laneIndex] = end;
        }
        visit.laneIndex = laneIndex;
      }

      const laneCount = Math.max(laneEndTimes.length, 1);

      for(const visit of group) {
        visit.laneCount = laneCount;
      }
      groupStart = groupEnd;
    }
    return result;
  }

  private getVisitStartMinutes(visit: ScheduledVisit): number {
    return (this.timeToMinutes(visit.startTime) ?? this.scheduleEndMinutes);
  }

  private getVisitEndMinutes(visit: ScheduledVisit): number {
    const start = this.getVisitStartMinutes(visit);
    const end = this.timeToMinutes(visit.endTime);
    if(end !== null && end > start) {
      return end;
    }
    return start + 60;
  }

  appointmentLeft(visit: ScheduledVisit): string {
    const lanes = visit.laneCount ?? 1;
    const lane = visit.laneIndex ?? 0;
    return `calc(${lane * (100 / lanes)}% + 4px)`;
  }

  appointmentWidth(visit: ScheduledVisit): string {
    const lanes = visit.laneCount ?? 1;
    return `calc(${100 / lanes}% - 8px)`;
  }

  private changeSelectedDate(date: Date): void {
    this.selectedDate = this.startOfDay(date);
    this.calendarMonth = new Date(this.selectedDate.getFullYear(), this.selectedDate.getMonth(), 1);
    this.buildCalendar();
    this.loadVisits();
  }

  private resetPatientSearch(): void {
    this.patientSearchQuery = '';
    this.patientSuggestions = [];
    this.patientSuggestionsOpen = false;
    this.patientSearchLoading = false;
    this.patientSearchError = '';
    this.selectedPatient = null;
  }

  private mapScheduledVisit( item: any): ScheduledVisit {
    return {
      id: Number(item.id),
      patientId: Number(item.patientId ?? item.patient_id ?? item.pt_id),
      firstName: item.firstName ?? item.first_name ?? item.fname ?? '',
      lastName: item.lastName ?? item.last_name ?? item.lname ?? '',
      mrn: String(item.mrn ?? ''),
      visitDate: item.visitDate ?? item.visit_date ?? item.date ?? '',
      startTime: item.startTime ?? item.start_time ?? item.appt_time ?? null,
      endTime: item.endTime ?? item.end_time ?? item.appt_time_end ?? null,
      visitType: item.visitType ?? item.visit_type ?? null,
      visitSubType: item.visitSubType ?? item.visit_sub_type ?? null
    };
  }

  private sortTime(time: string | null): number {
    const minutes = this.timeToMinutes(time);
    return (minutes ?? 24 * 60);
  }

  private timeToMinutes(value: string | null): number | null {
    if (!value) {
      return null;
    }

    const normalized = value.trim().toUpperCase();
    const twelveHour = normalized.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/);

    if (twelveHour) {
      let hour = Number(twelveHour[1]);
      const minute = Number(twelveHour[2]);
      const period = twelveHour[3];

      if (hour === 12) {
        hour = 0;
      }

      if (period === 'PM') {
        hour += 12;
      }

      return (hour * 60 + minute);
    }

    const twentyFourHour = normalized.match(/^(\d{1,2}):(\d{2})/);

    if (twentyFourHour) {
      return (Number(twentyFourHour[1]) * 60 + Number(twentyFourHour[2]));
    }

    return null;
  }

  private formatDateForApi(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  private startOfDay(value: Date): Date {
    return new Date(value.getFullYear(), value.getMonth(), value.getDate());
  }

  private isSameDate(first: Date, second: Date): boolean {
    return (
      first.getFullYear() === second.getFullYear() &&

      first.getMonth() === second.getMonth() &&

      first.getDate() === second.getDate()
    );
  }
}