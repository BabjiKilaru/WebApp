import { Admin } from './admin';

describe('Admin navigation', () => {
    let component: Admin;
    beforeEach(() => component = new Admin());

    it('opens User Management by default', () => {
        expect(component.activeSection).toBe('users');
        expect(component.lookupExpanded).toBe(false);
    });

    it('toggles lookup tables and collapses them when switching away', () => {
        component.toggleLookups();
        expect(component.activeSection).toBe('lookups');
        expect(component.lookupExpanded).toBe(true);
        component.toggleLookups();
        expect(component.lookupExpanded).toBe(false);
        component.toggleLookups();
        component.selectSection('reports');
        expect(component.activeSection).toBe('reports');
        expect(component.lookupExpanded).toBe(false);
    });
});