import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Header } from '../header/header';
import { UserManagement } from './user-management/user-management';

type AdminSection = 'users' | 'lookups' | 'reports';

@Component({
    selector: 'app-admin',
    standalone: true,
    imports: [CommonModule, Header, UserManagement],
    templateUrl: './admin.html',
    styleUrl: './admin.css'
})
export class Admin {
    activeSection: AdminSection = 'users';
    lookupExpanded = false;

    selectSection(section: AdminSection): void {
        this.activeSection = section;

        if (section !== 'lookups') {
            this.lookupExpanded = false;
        }
    }

    toggleLookups(): void {
        this.activeSection = 'lookups';
        this.lookupExpanded = !this.lookupExpanded;
    }
}