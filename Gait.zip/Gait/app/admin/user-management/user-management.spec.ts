import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { UserManagement } from './user-management';

const USERS = [
    { userid: 'jsmith', fname: 'Jane', lname: 'Smith', facility: 'Main', access: 'Admin', userAdmin: true, clinType: 'MD', purpose: 'C', active: true },
    { userid: 'jdoe', fname: 'John', lname: 'Doe', facility: 'Main', access: 'User', userAdmin: false, clinType: 'PT', purpose: 'R', active: false },
    { userid: 'babji', fname: 'Babji', lname: 'Kilaru', facility: 'null', access: 'User', userAdmin: false, clinType: 'null', purpose: 'null', active: true },
];

const DETAILS = {
    ...USERS[0], category: 'P', specialty: 'Orthopedics', phone1: '555-0101', phone2: '555-0102',
    fax: '555-0103', email: 'jane@example.com', address1: '123 Main St',
    address2: 'Suite 2', city: 'Wilmington', state: 'DE', zip: '19801', credentials: 'PT, DPT',
    expiration: '2027-12-31T17:30:45', mustChangePassword: false
};

describe('UserManagement', () => {
    let component: UserManagement;
    let fixture: ComponentFixture<UserManagement>;
    let http: HttpTestingController;
    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [UserManagement],
            providers: [provideHttpClient(), provideHttpClientTesting()],
        }).compileComponents();
        fixture = TestBed.createComponent(UserManagement);
        component = fixture.componentInstance;
        http = TestBed.inject(HttpTestingController);
    });

    it('searches from the filters row beside Clear Filters and clears the search', async () => {
        fixture.detectChanges();
        http.expectOne('/api/admin/users').flush(USERS);
        fixture.detectChanges();
        await fixture.whenStable();

        const element: HTMLElement = fixture.nativeElement;
        const input = element.querySelector<HTMLInputElement>('.filters .filter-actions input');
        const clearButton = element.querySelector<HTMLButtonElement>('.filter-actions .clear-button');
        expect(input).not.toBeNull();
        expect(clearButton).not.toBeNull();
        expect(element.querySelector('.page-header input')).toBeNull();
        expect(input!.placeholder).toBe('Search by Name or User ID');

        for (const search of ['Jane', 'jdoe']) {
            input!.value = search;
            input!.dispatchEvent(new Event('input'));
            fixture.detectChanges();
            await fixture.whenStable();
            expect(component.filteredUsers.map(user => user.userid))
                .toEqual([search === 'Jane' ? 'jsmith' : 'jdoe']);
        }

        clearButton!.click();
        fixture.detectChanges();
        await fixture.whenStable();
        expect(input!.value).toBe('');
        expect(component.filteredUsers).toHaveLength(3);
    });
    afterEach(() => http.verify());

    it.each([
        ['Jane', 'Smith', 'Smith, Jane'],
        ['Jane', '', 'Jane'],
        ['', 'Smith', 'Smith'],
        ['Jane', null, 'Jane'],
        [null, 'Smith', 'Smith'],
        [' Jane ', ' Smith ', 'Smith, Jane'],
        ['   ', 'Smith', 'Smith'],
        ['Jane', '   ', 'Jane'],
        ['', '', '-'],
        [null, null, '-'],
    ])('renders first name %j and last name %j as %j before User ID', (fname, lname, expected) => {
        fixture.detectChanges();
        http.expectOne('/api/admin/users').flush([{ ...USERS[0], fname, lname }]);
        fixture.detectChanges();

        const element: HTMLElement = fixture.nativeElement;
        const headings = Array.from(element.querySelectorAll('thead th'), cell => cell.textContent?.trim());
        const cells = element.querySelectorAll('tbody tr:first-child td');
        expect(headings).toEqual(['Name', 'User ID', 'Facility', 'Access', 'Admin', 'Clin Type', 'Purpose', 'Active', 'Actions']);
        expect(cells).toHaveLength(9);
        expect(cells[0].textContent?.trim()).toBe(expected);
        expect(cells[1].textContent?.trim()).toBe('jsmith');
    });

    it('spans all nine columns when no users are found', () => {
        fixture.detectChanges();
        http.expectOne('/api/admin/users').flush([]);
        fixture.detectChanges();

        const element: HTMLElement = fixture.nativeElement;
        expect(element.querySelector('tbody .empty-row')?.getAttribute('colspan')).toBe('9');
    });

    it('loads users and computes sorted unique filter values', () => {
        component.loadUsers();
        const req = http.expectOne('/api/admin/users');
        expect(req.request.method).toBe('GET');
        req.flush(USERS);
        expect(component.filteredUsers).toHaveLength(3);
        expect(component.accessOptions).toEqual(['admin', 'user']);
        expect(component.clinTypeOptions).toEqual(['MD', 'PT']);
        expect(component.loading).toBe(false);
    });

    it('excludes users with empty, whitespace-only or missing User IDs from the table, counts and filters', () => {
        fixture.detectChanges();
        http.expectOne('/api/admin/users').flush([
            ...USERS,
            ...['', '   ', null, undefined].map(userid => ({
                ...USERS[0], userid, access: 'internal', clinType: 'OT'
            }))
        ]);
        fixture.detectChanges();

        const element: HTMLElement = fixture.nativeElement;
        expect(component.users.map(user => user.userid)).toEqual(['jsmith', 'jdoe', 'babji']);
        expect(component.filteredUsers).toHaveLength(3);
        expect(element.querySelectorAll('tbody tr')).toHaveLength(3);
        expect(element.querySelector('.results-row')?.textContent).toContain('Showing 3 of 3 users');
        expect(component.accessOptions).toEqual(['admin', 'user']);
        expect(component.clinTypeOptions).toEqual(['MD', 'PT']);

        component.clearFilters();
        expect(component.filteredUsers).toHaveLength(3);
    });

    it('combines search, access, admin, clinician and active filters', () => {
        component.users = USERS;
        component.searchText = 'smith';
        component.accessFilter = 'admin';
        component.adminFilter = 'yes';
        component.clinTypeFilter = 'MD';
        component.activeFilter = 'active';
        component.applyFilter();
        expect(component.filteredUsers.map(user => user.userid)).toEqual(['jsmith']);
        component.activeFilter = 'inactive';
        component.applyFilter();
        expect(component.filteredUsers).toEqual([]);
        component.clearFilters();
        expect(component.filteredUsers).toHaveLength(3);
    });
    
    it('reports a failed user-list request without leaving stale data', () => {
        component.users = USERS;
        component.loadUsers();
        http.expectOne('/api/admin/users').flush({}, { status: 500, statusText: 'Server Error' });
        expect(component.loadError).toBe('Unable to load users.');
        expect(component.filteredUsers).toEqual([]);
        expect(component.loading).toBe(false);
    });

    async function openEditor(mustChangePassword = false): Promise<HTMLElement> {
        fixture.detectChanges();
        http.expectOne('/api/admin/users').flush(USERS);
        fixture.detectChanges();
        const element: HTMLElement = fixture.nativeElement;
        const dialog = element.querySelector<HTMLDialogElement>('dialog')!;
        dialog.showModal = vi.fn(() => dialog.setAttribute('open', ''));
        dialog.close = vi.fn(() => dialog.removeAttribute('open'));
        element.querySelector<HTMLButtonElement>('tbody .edit-row-btn')!.click();
        http.expectOne('/api/admin/users/jsmith').flush({ ...DETAILS, mustChangePassword });
        fixture.detectChanges();
        await fixture.whenStable();
        fixture.detectChanges();
        return element;
    }

    it.each([true, false])('shows the temporary password reminder only while a change is required (%s)', async required => {
        const element = await openEditor(required);
        const notice = element.querySelector('.temporary-password-status');
        if (required) {
            expect(notice?.textContent).toContain('Temporary password set.');
            expect(notice?.textContent).toContain('Ask the user to change their password after signing in.');
        } else {
            expect(notice).toBeNull();
        }
        expect(element.querySelector('.temporary-password-section .login-details')).toBeNull();
        expect(element.querySelector('.generate-password-button')).not.toBeNull();
        component.closeEdit();
    });

    it('confirms a password reset, blocks concurrent actions, and clears the new password on close', async () => {
        const element = await openEditor();
        component.editUser!.fname = 'Unsaved name';
        component.generateTemporaryPassword();
        http.expectNone(request => request.method === 'POST');
        element.querySelector<HTMLButtonElement>('.generate-password-button')!.click();
        fixture.detectChanges();
        expect(element.querySelector('.temporary-password-section')?.textContent).toContain('even if you cancel other edits');
        element.querySelector<HTMLButtonElement>('.cancel-password-reset')!.click();
        fixture.detectChanges();
        expect(component.confirmPasswordReset).toBe(false);
        element.querySelector<HTMLButtonElement>('.generate-password-button')!.click();
        fixture.detectChanges();
        element.querySelector<HTMLButtonElement>('.confirm-password-reset')!.click();
        fixture.detectChanges();
        const request = http.expectOne('/api/admin/users/jsmith/temporary-password');
        expect(request.request.method).toBe('POST');
        expect(request.request.body).toEqual({});
        expect(element.querySelector<HTMLButtonElement>('.save-button')!.disabled).toBe(true);
        expect(element.querySelector<HTMLFieldSetElement>('fieldset')!.disabled).toBe(true);
        component.closeEdit();
        component.saveUser();
        component.generateTemporaryPassword();
        expect(component.editUser).not.toBeNull();
        http.expectNone(request => request.method === 'PUT' || request.method === 'POST');
        request.flush({ temporaryPassword: 'new-password' });
        fixture.detectChanges();
        expect(element.querySelector('.temporary-password-section .login-details dd')?.textContent).toBe('new-password');
        expect(element.querySelector('.temporary-password-status')?.textContent).toContain('Temporary password set');
        expect(component.editUser!.fname).toBe('Unsaved name');
        expect(component.editUser!.mustChangePassword).toBe(true);
        component.closeEdit();
        expect(component.editTemporaryPassword).toBe('');
        component.openEdit(component.users[1]);
        http.expectOne('/api/admin/users/jdoe').flush({ ...DETAILS, userid: 'jdoe', mustChangePassword: false });
        fixture.detectChanges();
        expect(element.textContent).not.toContain('new-password');
        expect(element.querySelector('.temporary-password-status')).toBeNull();
        component.closeEdit();
    });

    it.each([404, 500])('reports a failed password reset (%s), preserves edits, and allows retry', async status => {
        const element = await openEditor(true);
        component.editUser!.fname = 'Unsaved name';
        component.confirmPasswordReset = true;
        component.generateTemporaryPassword();
        http.expectOne('/api/admin/users/jsmith/temporary-password')
            .flush({}, { status, statusText: 'Error' });
        fixture.detectChanges();
        expect(element.querySelector('[role="alert"]')?.textContent)
            .toContain(status === 404 ? 'no longer exists' : 'Unable to confirm the password reset');
        expect(component.editUser!.fname).toBe('Unsaved name');
        expect(component.editTemporaryPassword).toBe('');
        expect(component.busy).toBe(false);
        component.generateTemporaryPassword();
        http.expectOne('/api/admin/users/jsmith/temporary-password').flush({ temporaryPassword: 'retry-password' });
        expect(component.editTemporaryPassword).toBe('retry-password');
        component.closeEdit();
    });

    it('never submits the read-only password status or generated password with user edits', async () => {
        await openEditor(true);
        component.confirmPasswordReset = true;
        component.generateTemporaryPassword();
        http.expectOne('/api/admin/users/jsmith/temporary-password').flush({ temporaryPassword: 'new-password' });
        component.saveUser();
        const request = http.expectOne('/api/admin/users/jsmith');
        expect(request.request.body.mustChangePassword).toBeUndefined();
        expect(request.request.body.temporaryPassword).toBeUndefined();
        expect(request.request.body.password).toBeUndefined();
        request.flush({ ...DETAILS, mustChangePassword: true });
        expect(component.editTemporaryPassword).toBe('');
    });

    it('opens a popup from the row Edit button with every mapped field and a readonly User ID', async () => {
        const element = await openEditor();
        expect(element.querySelectorAll('tbody .edit-row-btn')).toHaveLength(3);
        expect(element.querySelectorAll('dialog .required-marker')).toHaveLength(3);
        expect(element.querySelector('dialog')!.hasAttribute('open')).toBe(true);
        expect(element.querySelector<HTMLInputElement>('#editUserid')!.readOnly).toBe(true);
        expect(element.querySelector<HTMLInputElement>('#editUserid')!.value).toBe('jsmith');
        const names = Array.from(element.querySelectorAll('dialog input, dialog select'))
            .map(field => field.getAttribute('name'));
        expect(names).toEqual([
            'userid', 'fname', 'lname', 'purpose', 'category', 'clinType', 'specialty', 'facility',
            'phone1', 'phone2', 'fax', 'email', 'address1', 'address2', 'city', 'state',
            'zip', 'credentials', 'access', 'userAdmin', 'active', 'expiration', 'noExpiration'
        ]);
        for (const [name, value] of Object.entries(DETAILS)) {
            const input = element.querySelector<HTMLInputElement>(`dialog input[name="${name}"]`);
            if (input && name !== 'expiration' && input.type !== 'checkbox') {
                expect(input.value).toBe(String(value));
            }
        }
        component.closeEdit();
    });

    it('discards edits on Cancel and Escape without updating the table or sending a write', async () => {
        const element = await openEditor();
        component.editUser!.fname = 'Unsaved';
        element.querySelector<HTMLButtonElement>('.dialog-actions .clear-button')!.click();
        expect(component.users[0].fname).toBe('Jane');
        expect(component.editUser).toBeNull();
        expect(element.querySelector('dialog')!.hasAttribute('open')).toBe(false);
        http.expectNone(request => request.method === 'PUT');

        component.openEdit(component.users[0]);
        http.expectOne('/api/admin/users/jsmith').flush(DETAILS);
        element.querySelector('dialog')!.dispatchEvent(new Event('cancel', { cancelable: true }));
        expect(component.editUser).toBeNull();
        expect(element.querySelector('dialog')!.hasAttribute('open')).toBe(false);
    });

    it('persists all details except userid, refreshes filters and prevents duplicate saves or closing while saving', async () => {
        const element = await openEditor();
        const updated = { ...DETAILS, fname: 'Janet', clinType: 'DO', access: 'internal', active: false, userAdmin: false, expiration: null };
        component.editUser = { ...updated, expiration: '' };
        component.setNoExpiration(true);
        component.activeFilter = 'active';
        component.saveUser();
        component.saveUser();
        component.closeEdit();
        expect(element.querySelector('dialog')!.hasAttribute('open')).toBe(true);
        const req = http.expectOne('/api/admin/users/jsmith');
        expect(req.request.method).toBe('PUT');
        const { userid, mustChangePassword, ...expected } = updated;
        expect(req.request.body).toEqual(expected);
        expect(req.request.body.userid).toBeUndefined();
        req.flush(updated);
        expect(component.users[0]).toEqual(updated);
        expect(component.filteredUsers.map(user => user.userid)).toEqual(['babji']);
        expect(component.accessOptions).toEqual(['internal', 'user']);
        expect(component.clinTypeOptions).toEqual(['DO', 'PT']);
        expect(component.saving).toBe(false);
        expect(component.editUser).toBeNull();
        expect(component.saveMessage).toContain('updated successfully');
    });

    it('keeps edits and the popup open after a failed save so it can be retried', async () => {
        const element = await openEditor();
        component.editUser!.address2 = 'New suite';
        component.saveUser();
        http.expectOne('/api/admin/users/jsmith').flush({}, { status: 500, statusText: 'Server Error' });
        fixture.detectChanges();
        expect(component.editError).toContain('not been saved');
        expect(component.editUser!.address2).toBe('New suite');
        expect(component.users[0].fname).toBe('Jane');
        expect(element.querySelector('dialog')!.hasAttribute('open')).toBe(true);
        expect(element.querySelector('[role="alert"]')!.textContent).toContain('not been saved');
        component.saveUser();
        http.expectOne('/api/admin/users/jsmith').flush({ ...DETAILS, address2: 'New suite' });
        expect(component.editUser).toBeNull();
    });

    it('reports detail-load failures and does not allow saving an unloaded user', async () => {
        const element = await openEditor();
        component.closeEdit();
        component.openEdit(component.users[1]);
        http.expectOne('/api/admin/users/jdoe').flush({}, { status: 404, statusText: 'Not Found' });
        fixture.detectChanges();
        expect(component.editError).toContain('Unable to load user details');
        expect(component.editLoading).toBe(false);
        expect(element.querySelector('.save-button')).toBeNull();
        component.saveUser();
        http.expectNone(request => request.method === 'PUT');
        component.closeEdit();
    });

    it('validates email before allowing form submission', async () => {
        const element = await openEditor();
        const email = element.querySelector<HTMLInputElement>('#editEmail')!;
        email.value = 'invalid';
        email.dispatchEvent(new Event('input'));
        fixture.detectChanges();
        await fixture.whenStable();
        fixture.detectChanges();
        expect(element.querySelector<HTMLButtonElement>('.save-button')!.disabled).toBe(true);
        expect(element.querySelector('.field-error')!.textContent).toContain('valid email');
        component.closeEdit();
    });

    it('submits values edited in the form including timestamp and boolean selections', async () => {
        const element = await openEditor();
        const inputChanges = {
            fname: 'Janet', lname: 'Jones',
            specialty: 'Pediatrics', facility: 'West', phone1: '555-0201', phone2: '555-0202',
            fax: '555-0203', email: 'janet@example.com', address1: '456 Oak St',
            address2: 'Floor 3', city: 'Newark', state: 'NJ', zip: '07102',
            credentials: 'PT, DPT', expiration: '2028-06-01T10:15:30'
        };
        for (const [name, value] of Object.entries(inputChanges)) {
            const input = element.querySelector<HTMLInputElement>(`dialog input[name="${name}"]`)!;
            input.value = value;
            input.dispatchEvent(new Event('input'));
        }
        const selectChanges = { purpose: 'R', category: 'T', clinType: 'DO', access: 'user' };
        for (const [name, value] of Object.entries(selectChanges)) {
            const select = element.querySelector<HTMLSelectElement>(`dialog select[name="${name}"]`)!;
            select.value = value;
            select.dispatchEvent(new Event('change'));
        }
        for (const name of ['userAdmin']) {
            const select = element.querySelector<HTMLSelectElement>(`dialog select[name="${name}"]`)!;
            select.selectedIndex = 1;
            select.dispatchEvent(new Event('change'));
        }
        element.querySelector<HTMLInputElement>('#editActive')!.click();
        fixture.detectChanges();
        await fixture.whenStable();
        fixture.detectChanges();
        element.querySelector<HTMLButtonElement>('.save-button')!.click();
        const req = http.expectOne('/api/admin/users/jsmith');
        expect(req.request.body).toEqual({
            ...inputChanges, ...selectChanges, expiration: '2028-06-01T10:15:30.000', userAdmin: false, active: false
        });
        req.flush({ userid: 'jsmith', ...req.request.body });
        expect(component.users[0].fname).toBe('Janet');
        expect(component.editUser).toBeNull();
    });

    it('cancels a pending detail request when the popup is closed', async () => {
        await openEditor();
        component.closeEdit();
        component.openEdit(component.users[0]);
        const request = http.expectOne('/api/admin/users/jsmith');
        component.closeEdit();
        expect(request.cancelled).toBe(true);
        expect(component.editUser).toBeNull();
    });

    it('offers exactly the requested dropdown labels and database values', async () => {
        const element = await openEditor();
        const instructions = element.querySelector('.access-instructions')!.textContent!;
        expect(instructions).toContain("If you grant 'admin' access to a user, they will be able to access all the areas of the internal lab site.");
        expect(instructions).toContain("If you grant 'user' access, they will only be able to use the external clinician's site.");
        expect(instructions).toContain('No one can access this administrative area regardless of the access level you set here.');
        expect(instructions).not.toContain('Read-only access');
        expect(instructions).not.toContain('No site access');
        expect(instructions).not.toContain('temporary password');
        const options = (id: string) => Array.from(element.querySelectorAll<HTMLOptionElement>(`${id} option`))
            .map(option => [option.textContent!.trim(), option.value]);
        expect(options('#editClinType')).toEqual(['BIO', 'BME', 'DO', 'MD', 'OT', 'PT', 'Other'].map(value => [value, value]));
        expect(options('#editAccess')).toEqual([
            ['User', 'user'], ['Admin', 'admin'], ['Internal (global read-only)', 'internal'], ['None', 'NONE']
        ]);
        expect(element.querySelector<HTMLSelectElement>('#editAccess')!.value).toBe('admin');
        expect(options('#editCategory')).toEqual([
            ['Select category', ''], ['Physician', 'P'], ['Therapist', 'T'], ['Other', 'O']
        ]);
        expect(options('#editPurpose')).toEqual([
            ['Select purpose', ''], ['Clinical', 'C'], ['Research', 'R'], ['Testing', 'T']
        ]);
        expect(options('#editUserAdmin').map(option => option[0])).toEqual(['Yes', 'No']);
        expect(element.querySelector('#expirationHint')!.textContent)
            .toBe('The account will no longer be able to login on this date.');
        expect(element.querySelector('#activeHint')!.textContent)
            .toBe('If the clinician is not on the active list, he/she will not show up in the list when adding clinicians to the patient record.');
        expect(element.querySelector<HTMLInputElement>('#editActive')!.checked).toBe(true);
        expect(element.querySelector<HTMLInputElement>('#noExpiration')!.checked).toBe(false);
        component.closeEdit();
    });

    it('initializes No expiration checked for SQL NULL and defaults an unset administrator to No', async () => {
        const element = await openEditor();
        component.closeEdit();
        component.openEdit(component.users[0]);
        http.expectOne('/api/admin/users/jsmith').flush({ ...DETAILS, expiration: null, userAdmin: null });
        fixture.detectChanges();
        await fixture.whenStable();
        fixture.detectChanges();
        expect(component.editUser!.userAdmin).toBe(false);
        expect(element.querySelector<HTMLSelectElement>('#editUserAdmin')!.selectedOptions[0].textContent).toBe('No');
        expect(element.querySelector<HTMLInputElement>('#noExpiration')!.checked).toBe(true);
        expect(element.querySelector<HTMLInputElement>('#editExpiration')!.disabled).toBe(true);
        component.saveUser();
        const req = http.expectOne('/api/admin/users/jsmith');
        expect(req.request.body.expiration).toBeNull();
        expect(req.request.body.userAdmin).toBe(false);
        req.flush({ ...DETAILS, expiration: null, userAdmin: false });
    });

    it('requires first name, last name, and purpose while allowing category to remain empty', async () => {
        const element = await openEditor();
        const fname = element.querySelector<HTMLInputElement>('#editFname')!;
        const lname = element.querySelector<HTMLInputElement>('#editLname')!;
        const purpose = element.querySelector<HTMLSelectElement>('#editPurpose')!;
        const category = element.querySelector<HTMLSelectElement>('#editCategory')!;

        expect(fname.required).toBe(true);
        expect(lname.required).toBe(true);
        expect(purpose.required).toBe(true);
        expect(category.required).toBe(false);

        category.selectedIndex = 0;
        category.dispatchEvent(new Event('change'));
        fixture.detectChanges();
        expect(component.editUser!.category).toBe('');
        expect(element.querySelector<HTMLButtonElement>('.save-button')!.disabled).toBe(false);

        fname.value = '';
        fname.dispatchEvent(new Event('input'));
        purpose.selectedIndex = 0;
        purpose.dispatchEvent(new Event('change'));
        fixture.detectChanges();
        expect(element.querySelector<HTMLButtonElement>('.save-button')!.disabled).toBe(true);

        fname.value = '   ';
        fname.dispatchEvent(new Event('input'));
        fixture.detectChanges();
        expect(element.querySelector<HTMLButtonElement>('.save-button')!.disabled).toBe(true);

        fname.value = 'Jane';
        fname.dispatchEvent(new Event('input'));
        purpose.value = 'C';
        purpose.dispatchEvent(new Event('change'));
        fixture.detectChanges();
        component.saveUser();
        const request = http.expectOne('/api/admin/users/jsmith');
        expect(request.request.body.category).toBeNull();
        request.flush({ ...DETAILS, category: null });
        expect(component.editUser).toBeNull();
    });

    it('clears expiration to SQL NULL and requires a deadline when No expiration is unchecked', async () => {
        const element = await openEditor();
        const noExpiration = element.querySelector<HTMLInputElement>('#noExpiration')!;
        noExpiration.click();
        fixture.detectChanges();
        await fixture.whenStable();
        expect(component.noExpiration).toBe(true);
        expect(component.editUser!.expiration).toBeNull();
        expect(element.querySelector<HTMLInputElement>('#editExpiration')!.disabled).toBe(true);
        component.saveUser();
        const req = http.expectOne('/api/admin/users/jsmith');
        expect(req.request.body.expiration).toBeNull();
        req.flush({}, { status: 500, statusText: 'Server Error' });
        noExpiration.click();
        fixture.detectChanges();
        await fixture.whenStable();
        fixture.detectChanges();
        expect(element.querySelector<HTMLInputElement>('#editExpiration')!.disabled).toBe(false);
        expect(element.querySelector<HTMLButtonElement>('.save-button')!.disabled).toBe(true);
        component.saveUser();
        expect(component.editError).toContain('Enter an expiration date and time');
        http.expectNone(request => request.method === 'PUT');
        component.closeEdit();
    });

    it('shows readable purpose labels but does not include them in search', async () => {
        const element = await openEditor();
        expect(element.querySelector('tbody')!.textContent).toContain('Clinical');
        component.searchText = 'clinical';
        component.applyFilter();
        expect(component.filteredUsers).toEqual([]);
        expect(component.users[0].purpose).toBe('C');
        component.closeEdit();
    });
});