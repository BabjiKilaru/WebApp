import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { UserManagement } from './user-management';

describe('UserManagement creation', () => {
    let component: UserManagement;
    let fixture: ComponentFixture<UserManagement>;
    let http: HttpTestingController;
    let element: HTMLElement;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [UserManagement],
            providers: [provideHttpClient(), provideHttpClientTesting()]
        }).compileComponents();
        fixture = TestBed.createComponent(UserManagement);
        component = fixture.componentInstance;
        http = TestBed.inject(HttpTestingController);
        fixture.detectChanges();
        http.expectOne('/api/admin/users').flush([]);
        fixture.detectChanges();
        element = fixture.nativeElement;
        for (const dialog of element.querySelectorAll('dialog')) {
            dialog.showModal = vi.fn(() => dialog.setAttribute('open', ''));
            dialog.close = vi.fn(() => dialog.removeAttribute('open'));
        }
        element.querySelector<HTMLButtonElement>('.page-header .new-user-btn')!.click();
        fixture.detectChanges();
        await fixture.whenStable();
        fixture.detectChanges();
        vi.useFakeTimers();
    });

    it.each(['a', 'ab', 'abc', 'abcd'])('blocks User ID %s below the five-character minimum', userid => {
        fillUser();
        const input = element.querySelector<HTMLInputElement>('#editUserid')!;
        input.value = userid;
        input.dispatchEvent(new Event('input'));
        fixture.detectChanges();
        expect(component.usernameStatus).toBe('invalid');
        expect(element.querySelector('#usernameStatus')!.textContent).toContain('5-50');
        expect(element.querySelector<HTMLButtonElement>('form .save-button')!.disabled).toBe(true);
        component.saveUser();
        vi.advanceTimersByTime(300);
        http.expectNone(request => request.url.endsWith('/availability') || request.method === 'POST');
    });

    afterEach(() => {
        fixture.destroy();
        vi.useRealTimers();
        http.verify();
    });

    function checkAvailability(available = true): void {
        vi.advanceTimersByTime(300);
        const request = http.expectOne('/api/admin/users/availability?userid=sjane');
        expect(request.request.method).toBe('GET');
        request.flush({ userid: 'sjane', available });
    }

    function fillUser(): void {
        component.editUser!.fname = 'Jane';
        component.editUser!.lname = 'Smith';
        component.editUser!.purpose = 'C';
        component.suggestUsername();
    }

    it('opens the shared form without exposing a default password', () => {
        expect(element.querySelector('#editUserTitle')!.textContent).toBe('New User');
        expect(element.querySelector<HTMLInputElement>('#editUserid')!.readOnly).toBe(false);
        expect(element.querySelector('#confirmDefaultPassword')).toBeNull();
        expect(element.querySelector('fieldset')!.textContent).not.toMatch(/password/i);
        const instructions = element.querySelector('.access-instructions')!.textContent!;
        expect(instructions).toContain("If you grant 'admin' access to a user, they will be able to access all the areas of the internal lab site.");
        expect(instructions).toContain("If you grant 'user' access, they will only be able to use the external clinician's site.");
        expect(instructions).toContain('No one can access this administrative area regardless of the access level you set here.');
        expect(instructions).not.toContain('Read-only access');
        expect(instructions).not.toContain('No site access');
        expect(instructions).toContain('A temporary password is generated automatically when you create the user.');
        expect(instructions).toContain('It will be shown once after saving; share it securely.');
        expect(element.querySelectorAll('fieldset input, fieldset select')).toHaveLength(23);
        expect(element.querySelector<HTMLButtonElement>('form .save-button')!.disabled).toBe(true);
        expect(component.editUser).toMatchObject({ active: true, userAdmin: false, access: 'NONE', expiration: null });
        expect(element.querySelector<HTMLSelectElement>('#editAccess')!.value).toBe('NONE');
        expect(element.querySelector<HTMLInputElement>('#editUserid')!.minLength).toBe(5);
    });

    it('suggests last initial plus first name, debounces checks and preserves a custom ID', () => {
        fillUser();
        expect(component.editUser!.userid).toBe('sjane');
        expect(component.usernameStatus).toBe('checking');
        http.expectNone(request => request.url.endsWith('/availability'));
        checkAvailability();
        expect(component.usernameAvailable).toBe(true);

        component.editUser!.userid = 'custom.name';
        component.checkUsername();
        expect(component.usernameAvailable).toBe(false);
        component.editUser!.fname = 'Janet';
        component.suggestUsername();
        expect(component.suggestedUsername).toBe('sjanet');
        expect(component.editUser!.userid).toBe('custom.name');
        vi.advanceTimersByTime(300);
        http.expectOne('/api/admin/users/availability?userid=custom.name')
            .flush({ userid: 'custom.name', available: true });
    });

    it('updates the suggestion and checks availability from name input events', () => {
        for (const [id, value] of [['editFname', 'Jane'], ['editLname', 'Smith']]) {
            const input = element.querySelector<HTMLInputElement>(`#${id}`)!;
            input.value = value;
            input.dispatchEvent(new Event('input'));
        }
        fixture.detectChanges();
        expect(component.editUser!.userid).toBe('sjane');
        expect(element.querySelector('#usernameHint')!.textContent).toContain('sjane');
        checkAvailability();
    });

    it('blocks saving without a successfully checked current ID', () => {
        fillUser();
        component.saveUser();
        http.expectNone(request => request.method === 'POST');
        checkAvailability();
        component.editUser!.userid = 'unchecked';
        component.saveUser();
        http.expectNone(request => request.method === 'POST');
    });

    it('enables form submission when required fields and availability are valid without password confirmation', async () => {
        for (const [id, value] of [['editFname', 'Jane'], ['editLname', 'Smith']]) {
            const input = element.querySelector<HTMLInputElement>(`#${id}`)!;
            input.value = value;
            input.dispatchEvent(new Event('input'));
        }
        const purpose = element.querySelector<HTMLSelectElement>('#editPurpose')!;
        purpose.value = 'C';
        purpose.dispatchEvent(new Event('change'));
        fixture.detectChanges();
        expect(element.querySelector<HTMLButtonElement>('form .save-button')!.disabled).toBe(true);
        checkAvailability();
        await vi.advanceTimersByTimeAsync(1);
        fixture.detectChanges();
        const save = element.querySelector<HTMLButtonElement>('form .save-button')!;
        expect(save.disabled).toBe(false);
        save.click();
        const request = http.expectOne('/api/admin/users');
        expect(request.request.method).toBe('POST');
        expect(request.request.body).toMatchObject({
            userid: 'sjane',
            details: { fname: 'Jane', lname: 'Smith', purpose: 'C', access: 'NONE', active: true }
        });
        request.flush({ user: { ...component.editUser! }, temporaryPassword: 'one-time-secret' });
        fixture.detectChanges();
        expect(element.querySelector<HTMLDialogElement>('.created-user-dialog')!.open).toBe(true);
    });

    it('blocks taken and invalid IDs and cancels outdated requests', () => {
        fillUser();
        vi.advanceTimersByTime(300);
        const old = http.expectOne('/api/admin/users/availability?userid=sjane');
        component.editUser!.userid = 'other';
        component.checkUsername();
        expect(old.cancelled).toBe(true);
        component.editUser!.userid = 'sjane';
        component.checkUsername();
        checkAvailability(false);
        expect(component.usernameStatus).toBe('taken');
        component.editUser!.userid = 'bad id';
        component.checkUsername();
        expect(component.usernameStatus).toBe('invalid');
        vi.advanceTimersByTime(300);
        http.expectNone(request => request.url.endsWith('/availability'));
    });

    it('reports availability failures and allows retrying', () => {
        fillUser();
        vi.advanceTimersByTime(300);
        http.expectOne('/api/admin/users/availability?userid=sjane')
            .flush({}, { status: 500, statusText: 'Server Error' });
        fixture.detectChanges();
        expect(component.usernameStatus).toBe('error');
        expect(element.querySelector('#usernameStatus')!.textContent).toContain('Unable to check');
        expect(component.usernameAvailable).toBe(false);
        component.checkUsername();
        checkAvailability();
        expect(component.usernameAvailable).toBe(true);
    });

    it('creates once, refreshes the list and shows the temporary password only after success', () => {
        fillUser();
        checkAvailability();
        const details = { ...component.editUser! };
        component.saveUser();
        component.saveUser();
        component.closeEdit();
        expect(component.saving).toBe(true);
        expect(component.createdUserId).toBe('');
        const request = http.expectOne('/api/admin/users');
        expect(request.request.method).toBe('POST');
        const { userid, mustChangePassword, ...expected } = details;
        expect(request.request.body).toEqual({
            userid, details: { ...expected, category: null }
        });
        expect(request.request.body.password).toBeUndefined();
        expect(request.request.body.details.password).toBeUndefined();
        request.flush({ user: details, temporaryPassword: 'one-time-secret' });
        fixture.detectChanges();
        expect(component.users).toEqual([details]);
        expect(component.filteredUsers).toEqual([details]);
        expect(component.accessOptions).toEqual(['NONE']);
        expect(component.editUser).toBeNull();
        const dialog = element.querySelector<HTMLDialogElement>('.created-user-dialog')!;
        expect(dialog.open).toBe(true);
        expect(dialog.textContent).toContain('User created successfully');
        expect(dialog.querySelector('dl')!.textContent).toContain('sjane');
        expect(dialog.querySelector('dl')!.textContent).toContain('one-time-secret');
        expect(component.createdTemporaryPassword).toBe('one-time-secret');
        component.closeCreated();
        fixture.detectChanges();
        expect(dialog.open).toBe(false);
        expect(dialog.textContent).not.toContain('one-time-secret');
        expect(component.createdTemporaryPassword).toBe('');
    });

    it.each([409, 500])('preserves the form after a %s creation failure without showing login details', status => {
        fillUser();
        checkAvailability();
        component.saveUser();
        http.expectOne('/api/admin/users').flush({}, { status, statusText: 'Save Error' });
        expect(component.editUser!.fname).toBe('Jane');
        expect(component.saving).toBe(false);
        expect(component.createdUserId).toBe('');
        expect(component.users).toEqual([]);
        expect(component.editError).toContain(status === 409 ? 'already taken' : 'not been saved');
        if (status === 409) {
            expect(component.usernameAvailable).toBe(false);
            expect(component.usernameStatus).toBe('taken');
        }
    });

    it('cancels availability checks when closing and resets a new form', () => {
        fillUser();
        vi.advanceTimersByTime(300);
        const request = http.expectOne('/api/admin/users/availability?userid=sjane');
        component.closeEdit();
        expect(request.cancelled).toBe(true);
        http.expectNone(request => request.method === 'POST');
        component.openNew();
        expect(component.editUser!.userid).toBe('');
        expect(component.usernameStatus).toBe('idle');
    });
});
