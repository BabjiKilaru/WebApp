import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { ChangeDetectorRef, Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Subscription, map, switchMap, timer } from 'rxjs';

interface AdminUser {
    userid: string;
    fname: string | null;
    lname: string | null;
    facility: string | null;
    access: string | null;
    userAdmin: boolean;
    clinType: string | null;
    purpose: string | null;
    active: boolean;
}

interface AdminUserDetails extends AdminUser {
    category: string | null;
    specialty: string | null;
    phone1: string | null;
    phone2: string | null;
    fax: string | null;
    email: string | null;
    address1: string | null;
    address2: string | null;
    city: string | null;
    state: string | null;
    zip: string | null;
    credentials: string | null;
    expiration: string | null;
    mustChangePassword: boolean;
}

interface CreateAdminUserResponse {
    user: AdminUserDetails;
    temporaryPassword: string;
}

@Component({
    selector: 'app-user-management',
    standalone: true,
    imports: [CommonModule, FormsModule],
    templateUrl: './user-management.html',
    styleUrl: './user-management.css'
})
export class UserManagement implements OnInit, OnDestroy {
    users: AdminUser[] = [];
    filteredUsers: AdminUser[] = [];
    searchText = '';
    accessFilter = '';
    adminFilter = '';
    clinTypeFilter = '';
    activeFilter = '';
    accessOptions: string[] = [];
    clinTypeOptions: string[] = [];
    readonly clinicianTypes = ['BIO', 'BME', 'DO', 'MD', 'OT', 'PT', 'Other'];
    readonly accessLevels = [
        { label: 'User', value: 'user' },
        { label: 'Admin', value: 'admin' },
        { label: 'Internal (global read-only)', value: 'internal' },
        { label: 'None', value: 'NONE' }
    ];
    readonly categoryLabels: Record<string, string> = { P: 'Physician', T: 'Therapist', O: 'Other' };
    readonly purposeLabels: Record<string, string> = { C: 'Clinical', R: 'Research', T: 'Testing' };

    loading = false;
    loadError = '';
    @ViewChild('editDialog') editDialog!: ElementRef<HTMLDialogElement>;
    editUser: AdminUserDetails | null = null;
    editLoading = false;
    saving = false;
    generatingPassword = false;
    confirmPasswordReset = false;
    editTemporaryPassword = '';
    private passwordRequest?: Subscription;
    editError = '';
    saveMessage = '';
    noExpiration = true;
    private editingUserId: string | null = null;
    private editRequest?: Subscription;
    @ViewChild('createdDialog') createdDialog!: ElementRef<HTMLDialogElement>;
    creating = false;
    createdUserId = '';
    createdTemporaryPassword = '';
    usernameStatus: 'idle' | 'checking' | 'available' | 'taken' | 'error' | 'invalid' = 'idle';
    private checkedUsername = '';
    private availabilityRequest?: Subscription;
    private previousSuggestion = '';

    get suggestedUsername(): string {
        const first = this.editUser?.fname?.trim().toLowerCase().replace(/[^a-z0-9]/g, '') ?? '';
        const last = this.editUser?.lname?.trim().toLowerCase().replace(/[^a-z0-9]/g, '') ?? '';
        return first && last ? (last[0] + first).slice(0, 50) : '';
    }

    get usernameAvailable(): boolean {
        return this.usernameStatus === 'available' && this.checkedUsername === this.editUser?.userid;
    }

    get busy(): boolean {
        return this.saving || this.generatingPassword;
    }

    constructor(private http: HttpClient, private cdr: ChangeDetectorRef) {
    }

    ngOnInit(): void {
        this.loadUsers();
    }

    ngOnDestroy(): void {
        this.editRequest?.unsubscribe();
        this.availabilityRequest?.unsubscribe();
        this.createdTemporaryPassword = '';
        this.editTemporaryPassword = '';
        this.passwordRequest?.unsubscribe();
    }

    openNew(): void {
        if (this.busy) {
            return;
        }
        this.editRequest?.unsubscribe();
        this.availabilityRequest?.unsubscribe();
        this.creating = true;
        this.editingUserId = null;
        this.editLoading = false;
        this.editError = '';
        this.saveMessage = '';
        this.editTemporaryPassword = '';
        this.confirmPasswordReset = false;
        this.usernameStatus = 'idle';
        this.checkedUsername = '';
        this.previousSuggestion = '';
        this.noExpiration = true;
        this.editUser = {
            userid: '', fname: '', lname: '', purpose: '', category: '', clinType: null,
            specialty: '', facility: '', phone1: '', phone2: '', fax: '', email: '',
            address1: '', address2: '', city: '', state: '', zip: '', credentials: '',
            access: 'NONE', userAdmin: false, active: true, expiration: null, mustChangePassword: false
        };
        this.editDialog.nativeElement.showModal();
    }

    suggestUsername(): void {
        if (!this.creating || !this.editUser) {
            return;
        }
        const suggestion = this.suggestedUsername;
        if (!this.editUser.userid || this.editUser.userid === this.previousSuggestion) {
            this.editUser.userid = suggestion;
            this.checkUsername();
        }
        this.previousSuggestion = suggestion;
    }

    checkUsername(): void {
        this.availabilityRequest?.unsubscribe();
        this.checkedUsername = '';
        const userid = this.editUser?.userid ?? '';
        if (!userid) {
            this.usernameStatus = 'idle';
            return;
        }
        if (!/^[A-Za-z0-9._-]{5,50}$/.test(userid)) {
            this.usernameStatus = 'invalid';
            return;
        }
        this.usernameStatus = 'checking';
        this.availabilityRequest = timer(300).pipe(
            switchMap(() => this.http.get<{ userid: string; available: boolean }>(
                '/api/admin/users/availability', { params: { userid } }))
        ).subscribe({
            next: result => {
                if (!this.creating || this.editUser?.userid !== userid) {
                    return;
                }
                this.checkedUsername = userid;
                this.usernameStatus = result.available ? 'available' : 'taken';
                this.cdr.markForCheck();
            },
            error: error => {
                console.error('Unable to check User ID availability:', error);
                this.usernameStatus = 'error';
                this.cdr.markForCheck();
            }
        });
    }

    closeCreated(): void {
        this.createdDialog.nativeElement.close();
        this.createdUserId = '';
        this.createdTemporaryPassword = '';
        this.cdr.markForCheck();
    }

    loadUsers(): void {
        this.loading = true;
        this.loadError = '';

        this.http
            .get<AdminUser[]>('/api/admin/users')
            .subscribe({
                next: users => {
                    this.users = (users ?? [])
                        .filter(user => user.userid?.trim())
                        .map(user => ({ ...user, access: this.normalizeAccess(user.access) }));
                    this.accessOptions = this.getUniqueValues(this.users.map(user => user.access));
                    this.clinTypeOptions = this.getUniqueValues(this.users.map(user => user.clinType));
                    this.applyFilter();
                    this.loading = false;
                    this.cdr.markForCheck();
                },

                error: error => {
                    console.error('Unable to load users:', error);
                    this.users = [];
                    this.filteredUsers = [];
                    this.loading = false;
                    this.loadError = 'Unable to load users.';
                    this.cdr.markForCheck();
                }
            });
    }

    applyFilter(): void {
        const searchValue = this.searchText.trim().toLowerCase();

        this.filteredUsers = this.users.filter(user => {
            const searchValues = [
                user.userid,
                user.fname,
                user.lname
            ];

            const matchesSearch = !searchValue || searchValues.some(value => (value ?? '').toLowerCase().includes(searchValue));

            const matchesAccess = !this.accessFilter || this.normalizeAccess(user.access) === this.normalizeAccess(this.accessFilter);

            const matchesAdmin = !this.adminFilter || (this.adminFilter === 'yes' && user.userAdmin) || (this.adminFilter === 'no' && !user.userAdmin);

            const matchesClinType = !this.clinTypeFilter || user.clinType === this.clinTypeFilter;

            const matchesActive = !this.activeFilter || (this.activeFilter === 'active' && user.active) || (this.activeFilter === 'inactive' && !user.active);

            return (
                matchesSearch &&
                matchesAccess &&
                matchesAdmin &&
                matchesClinType &&
                matchesActive
            );
        });
    }

    displayName(user: AdminUser): string {
        return [user.lname?.trim(), user.fname?.trim()].filter(Boolean).join(', ') || '-';
    }

    clearFilters(): void {
        this.searchText = '';
        this.accessFilter = '';
        this.adminFilter = '';
        this.clinTypeFilter = '';
        this.activeFilter = '';

        this.applyFilter();
    }

    openEdit(user: AdminUser): void {
        if (this.busy) {
            return;
        }
        this.creating = false;
        this.availabilityRequest?.unsubscribe();
        this.editingUserId = user.userid;
        this.editUser = null;
        this.editError = '';
        this.saveMessage = '';
        this.editTemporaryPassword = '';
        this.confirmPasswordReset = false;
        this.editLoading = true;
        this.editDialog.nativeElement.showModal();

        this.editRequest?.unsubscribe();
        this.editRequest = this.http.get<AdminUserDetails>(`/api/admin/users/${encodeURIComponent(user.userid)}`).subscribe({
            next: details => {
                if (this.editingUserId !== user.userid) {
                    return;
                }
                this.editUser = {
                    ...details,
                    access: this.normalizeAccess(details.access),
                    purpose: this.purposeLabels[details.purpose ?? ''] ? details.purpose : null,
                    category: this.categoryLabels[details.category ?? ''] ? details.category : null,
                    userAdmin: details.userAdmin ?? false
                };
                this.noExpiration = details.expiration == null;
                this.editLoading = false;
                this.cdr.markForCheck();
            },
            error: error => {
                console.error('Unable to load user details:', error);
                if (this.editingUserId !== user.userid) {
                    return;
                }
                this.editLoading = false;
                this.editError = 'Unable to load user details. Close the popup and try again.';
                this.cdr.markForCheck();
            }
        });
    }

    closeEdit(event?: Event): void {
        event?.preventDefault();
        if (this.busy) {
            return;
        }
        this.editDialog.nativeElement.close();
        this.editRequest?.unsubscribe();
        this.availabilityRequest?.unsubscribe();
        this.editingUserId = null;
        this.editUser = null;
        this.editTemporaryPassword = '';
        this.confirmPasswordReset = false;
        this.creating = false;
        this.editError = '';
    }

    saveUser(): void {
        if (!this.editUser || (!this.creating && !this.editingUserId) || this.busy) {
            return;
        }
        if (this.creating && !this.usernameAvailable) {
            this.editError = 'Choose an available User ID before saving.';
            return;
        }
        if (!this.noExpiration && !this.editUser.expiration) {
            this.editError = 'Enter an expiration date and time or select No expiration.';
            return;
        }
        const creating = this.creating;
        const userid = creating ? this.editUser.userid : this.editingUserId!;
        const { userid: readonlyId, mustChangePassword, ...details } = this.editUser;
        const request = {
            ...details,
            access: this.normalizeAccess(details.access),
            purpose: details.purpose || null,
            category: details.category || null,
            expiration: this.noExpiration ? null : details.expiration
        };
        this.saving = true;
        this.editError = '';

        const saveRequest = creating
            ? this.http.post<CreateAdminUserResponse>('/api/admin/users', {
                userid, details: request
            }).pipe(map(response => ({
                user: response.user,
                temporaryPassword: response.temporaryPassword
            })))
            : this.http.put<AdminUserDetails>(`/api/admin/users/${encodeURIComponent(userid)}`, request)
                .pipe(map(user => ({ user, temporaryPassword: '' })));
        saveRequest.subscribe({
            next: ({ user: updated, temporaryPassword }) => {
                const normalizedUpdated = { ...updated, access: this.normalizeAccess(updated.access) };
                this.users = creating
                    ? [...this.users, normalizedUpdated].sort((a, b) =>
                        (a.lname ?? '').localeCompare(b.lname ?? '') ||
                        (a.fname ?? '').localeCompare(b.fname ?? '') || a.userid.localeCompare(b.userid))
                    : this.users.map(user => user.userid === userid ? normalizedUpdated : user);
                this.accessOptions = this.getUniqueValues(this.users.map(user => user.access));
                this.clinTypeOptions = this.getUniqueValues(this.users.map(user => user.clinType));
                this.applyFilter();
                this.saving = false;
                this.closeEdit();
                this.saveMessage = `User ${userid} ${creating ? 'created' : 'updated'} successfully.`;
                if (creating) {
                    this.createdUserId = updated.userid;
                    this.createdTemporaryPassword = temporaryPassword;
                    this.createdDialog.nativeElement.showModal();
                }
                this.cdr.markForCheck();
            },
            error: error => {
                console.error('Unable to save user:', error);
                this.saving = false;
                if (creating && error.status === 409) {
                    this.availabilityRequest?.unsubscribe();
                    this.checkedUsername = '';
                    this.usernameStatus = 'taken';
                }
                this.editError = creating && error.status === 409
                    ? 'This User ID is already taken. Choose a different User ID and try again.'
                    : error.status === 400
                    ? 'Unable to save. Check the field values and try again.'
                    : error.status === 404
                        ? 'This user no longer exists. Close the popup and reload the page.'
                        : 'Unable to save user details. Your changes have not been saved. Please try again.';
                this.cdr.markForCheck();
            }
        });
    }

    generateTemporaryPassword(): void {
        if (this.creating || !this.editingUserId || !this.editUser || this.busy || !this.confirmPasswordReset) {
            return;
        }
        this.generatingPassword = true;
        this.editError = '';
        this.editTemporaryPassword = '';
        this.passwordRequest = this.http.post<{ temporaryPassword: string }>(
            `/api/admin/users/${encodeURIComponent(this.editingUserId)}/temporary-password`, {}
        ).subscribe({
            next: response => {
                this.editTemporaryPassword = response.temporaryPassword;
                this.editUser!.mustChangePassword = true;
                this.generatingPassword = false;
                this.confirmPasswordReset = false;
                this.cdr.markForCheck();
            },
            error: error => {
                console.error('Unable to generate temporary password:', error);
                this.generatingPassword = false;
                this.editError = error.status === 404
                    ? 'This user no longer exists. Close the popup and reload the page.'
                    : 'Unable to confirm the password reset. Please try again to generate a new temporary password.';
                this.cdr.markForCheck();
            }
        });
    }

    setNoExpiration(checked: boolean): void {
        this.noExpiration = checked;
        if (checked && this.editUser) {
            this.editUser.expiration = null;
        }
    }

    getUniqueValues(values: Array<string | null>): string[] {
        const filteredValues = values
            .filter((value): value is string => {
                return value !== null && value.trim() !== '' && value.trim().toLowerCase() !== 'null';
            })
            .map(value => value.trim());

        return [...new Set(filteredValues)].sort((a, b) =>
            a.localeCompare(b)
        );
    }

    normalizeAccess(access: string | null): string | null {
        switch (access?.trim().toLowerCase()) {
            case 'user':
                return 'user';
            case 'admin':
                return 'admin';
            case 'internal':
            case 'internal(global read-only)':
                return 'internal';
            case 'none':
                return 'NONE';
            default:
                return access;
        }
    }

    accessLabel(access: string | null): string {
        const normalizedAccess = this.normalizeAccess(access);
        return this.accessLevels.find(level => level.value === normalizedAccess)?.label ?? access ?? '-';
    }

    isKnownAccess(access: string | null): boolean {
        const normalizedAccess = this.normalizeAccess(access);
        return this.accessLevels.some(level => level.value === normalizedAccess);
    }

}
