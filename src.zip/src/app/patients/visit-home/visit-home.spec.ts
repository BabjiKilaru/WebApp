import { ComponentFixture, TestBed } from "@angular/core/testing";
import { provideHttpClient } from "@angular/common/http";
import { HttpTestingController, provideHttpClientTesting } from "@angular/common/http/testing";
import { InterpretationOption, VisitHome } from "./visit-home";
import { Patient } from "../patient";
import { Visit } from "../visits/visits";

describe("VisitHome", () => {
  let fixture: ComponentFixture<VisitHome>;
  let httpTesting: HttpTestingController;

  const patient: Patient = {
    id: 1125,
    mrn: "123456789",
    firstName: "Jane",
    lastName: "Doe",
    dateOfBirth: "2010-05-20",
    gender: "Female",
    generalDiagnosisCode: null,
    label: null,
    historyRelationship: null,
    ageWalkWithSupport: null,
    ageWalkWithoutSupport: null,
    learning: null
  };

  const visit: Visit = {
    id: 5,
    patientId: 1125,
    attendance: "Yes",
    date: "2025-12-03",
    visitType: "Gait",
    visitSubType: "Step Watch"
  };

  const interpretationOptions: InterpretationOption[] = [
    { key: "video", label: "Video Assessment", enabled: true },
    { key: "physical-exam", label: "Gait Physical Examination", enabled: true },
    { key: "kinematics", label: "Kinematics", enabled: false },
    { key: "photographs", label: "Photographs", enabled: true },
    { key: "signatures", label: "Signatures", enabled: true }
  ];

  function loadOverview(): void {
    fixture.componentRef.setInput("patient", patient);
    fixture.componentRef.setInput("visit", visit);
    fixture.detectChanges();
    httpTesting.expectOne("/api/patients/1125/visits").flush([visit]);
    httpTesting.expectOne("/api/visits/5/overview").flush({
      ...visit, firstName: "Jane", lastName: "Doe", visitDate: visit.date
    });
    fixture.detectChanges();
  }

  function expandInterpretation(options = interpretationOptions): void {
    fixture.nativeElement.querySelector(".interpretation-toggle").click();
    httpTesting.expectOne("/api/patients/1125/visits/5/interpretation").flush(options);
    fixture.detectChanges();
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [VisitHome],
      providers: [provideHttpClient(), provideHttpClientTesting()]
    }).compileComponents();

    fixture = TestBed.createComponent(VisitHome);
    httpTesting = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpTesting.verify();
  });

  it("loads and displays the selected visit overview", () => {
    fixture.componentRef.setInput("patient", patient);
    fixture.componentRef.setInput("visit", visit);
    fixture.detectChanges();

    const visitsRequest = httpTesting.expectOne("/api/patients/1125/visits");
    const detailsRequest = httpTesting.expectOne("/api/visits/5/overview");

    visitsRequest.flush([
      visit,
      { ...visit, id: 6, attendance: null, date: "2025-11-01" },
      { ...visit, id: 7, attendance: "Cancelled", date: "2025-10-01" },
      { ...visit, id: 8, attendance: "Rescheduled", date: "2025-09-01" }
    ]);
    detailsRequest.flush({
      ...visit,
      firstName: "Jane",
      lastName: "Doe",
      mrn: "123456789",
      dateOfBirth: "2010-05-20",
      gender: "Female",
      visitDate: "2025-12-03",
      startTime: "09:15",
      endTime: "10:00",
      scheduledDate: "2025-11-01",
      surgeryDate: null,
      diagnosis: "Gait abnormality",
      reasonForAnalysis: "Follow-up evaluation",
      internalComment: "Review progress",
      interpretationDate: "2025-12-04",
      interpretationMd: "Alex Clinician",
      interpretationPt: "Pat Clinician",
      referringDoctor: "Taylor Doctor",
      dateSent: "2025-12-05",
      visitPt: "Morgan Therapist",
      visitPt2: null,
      visitBiomech: "Riley Engineer",
      visitBiomech2: null,
      modemsChildParentAvailable: true,
      modemsAdolescentParentAvailable: false,
      modemsAdolescentSelfAvailable: true
    });
    fixture.detectChanges();

    const pageText = fixture.nativeElement.textContent as string;
    expect(pageText).toContain("Jane");
    expect(pageText).toContain("Gait abnormality");
    expect(pageText).toContain("Follow-up evaluation");
    expect(pageText).toContain("Alex Clinician");
    expect(pageText).toContain("Taylor Doctor");
    expect(pageText).toContain("Morgan Therapist");
    expect(pageText).toContain("Riley Engineer");
    expect(pageText).toContain("Child - Parent Reported");
    expect(pageText).not.toContain("Adolescent - Parent Reported");
    expect(pageText).toContain("Adolescent - Self Reported");
    expect(pageText).toContain("CP Child Questionnaire (Clinician Use Only)");
    expect(pageText).toContain("View PNGs for this visit");
    expect(pageText).toContain("View photos for this visit");
    expect(fixture.componentInstance.visits.map((v) => v.id)).toEqual([5, 6]);
  });

  it("keeps Interpretation collapsed initially and opens it when clicked", () => {
    fixture.componentRef.setInput("patient", patient);
    fixture.componentRef.setInput("visit", visit);
    fixture.detectChanges();

    httpTesting.expectOne("/api/patients/1125/visits").flush([visit]);
    httpTesting.expectOne("/api/visits/5/overview").flush({
      ...visit,
      firstName: "Jane",
      lastName: "Doe",
      dateOfBirth: "2010-05-20",
      visitDate: "2025-12-03"
    });
    fixture.detectChanges();

    const buttons = Array.from(
      fixture.nativeElement.querySelectorAll("button")
    ) as HTMLButtonElement[];
    const interpretationButton = buttons.find(
      (button) => button.textContent?.includes("Interpretation")
    );
    expect(interpretationButton).toBeDefined();

    expect(interpretationButton?.getAttribute("aria-expanded")).toBe("false");
    const chevron = interpretationButton?.querySelector(".chevron");
    expect(chevron?.textContent?.trim()).toBe("›");
    expect(chevron?.classList.contains("expanded")).toBe(false);
    expect(fixture.nativeElement.textContent).not.toContain("Video Assessment");

    interpretationButton?.click();
    httpTesting.expectOne("/api/patients/1125/visits/5/interpretation").flush(interpretationOptions);
    fixture.detectChanges();

    expect(interpretationButton?.getAttribute("aria-expanded")).toBe("true");
    expect(chevron?.textContent?.trim()).toBe("›");
    expect(chevron?.classList.contains("expanded")).toBe(true);
    expect(fixture.nativeElement.textContent).toContain("Video Assessment");
  });

  it("preserves server option order and keeps absent-data options visible and disabled", () => {
    loadOverview();
    expandInterpretation();
    const buttons = Array.from(fixture.nativeElement.querySelectorAll(".sub-menu-item")) as HTMLButtonElement[];
    expect(buttons.map(button => button.querySelector("span")?.textContent))
      .toEqual(interpretationOptions.map(option => option.label));
    const kinematics = buttons[2];
    expect(kinematics.disabled).toBe(true);
    expect(kinematics.textContent).toContain("No matching data for this visit");
    kinematics.click();
    fixture.componentInstance.openInterpretation(fixture.componentInstance.interpretationSections[2]);
    expect(fixture.componentInstance.activeMenu).toBe("Visit Details");
    httpTesting.expectNone("/api/patients/1125/visits/5/interpretation/kinematics");
  });

  it("selects an enabled interpretation menu entry without loading option content", () => {
    loadOverview();
    expandInterpretation([{ key: "kinematics", label: "Kinematics", enabled: true }]);
    fixture.nativeElement.querySelector(".sub-menu-item").click();
    fixture.detectChanges();
    expect(fixture.componentInstance.activeMenu).toBe("Kinematics");
    expect(fixture.nativeElement.querySelector(".sub-menu-item.active")?.getAttribute("aria-current")).toBe("page");
    expect(fixture.nativeElement.querySelector(".not-implemented h2")?.textContent).toBe("Kinematics");
    expect(fixture.nativeElement.querySelector("app-interpretation")).toBeNull();
    httpTesting.expectNone(request => request.url.includes("/interpretation/"));
  });

  it("keeps Interpretation Photographs menu-only without changing the existing photo viewer", () => {
    loadOverview();
    expandInterpretation();
    fixture.nativeElement.querySelectorAll(".sub-menu-item")[3].click();
    fixture.detectChanges();
    expect(fixture.componentInstance.activeMenu).toBe("Photographs");
    expect(fixture.nativeElement.querySelector("app-visit-photo")).toBeNull();
    httpTesting.expectNone(request => request.url.includes("/images"));
  });

  it("clears the previous patient's interpretation and refuses mismatched visit context", () => {
    loadOverview();
    expandInterpretation();
    fixture.componentRef.setInput("patient", { ...patient, id: 2000 });
    fixture.detectChanges();
    httpTesting.expectOne("/api/patients/2000/visits").flush([]);
    fixture.detectChanges();
    expect(fixture.componentInstance.activeInterpretation).toBeNull();
    expect(fixture.componentInstance.interpretationSections).toEqual([]);
    expect(fixture.nativeElement.textContent).toContain("The selected visit does not belong to this patient");
    httpTesting.expectNone("/api/patients/2000/visits/5/interpretation");
    httpTesting.expectNone("/api/visits/5/overview");
  });

  it("cancels stale options and clears the active interpretation when visits change", () => {
    loadOverview();
    fixture.componentInstance.toggleInterpretation();
    const oldRequest = httpTesting.expectOne("/api/patients/1125/visits/5/interpretation");
    fixture.componentRef.setInput("visit", { ...visit, id: 6 });
    fixture.detectChanges();
    expect(oldRequest.cancelled).toBe(true);
    expect(fixture.componentInstance.interpretationSections).toEqual([]);
    expect(fixture.componentInstance.activeInterpretation).toBeNull();
    expect(fixture.componentInstance.activeMenu).toBe("Visit Details");
    httpTesting.expectOne("/api/visits/6/overview").flush({ ...visit, id: 6 });
    httpTesting.expectOne("/api/patients/1125/visits/6/interpretation")
      .flush([{ key: "physical-exam", label: "UE Physical Examination", enabled: true }]);
    fixture.detectChanges();
    expect(fixture.nativeElement.textContent).toContain("UE Physical Examination");
    expect(fixture.nativeElement.textContent).not.toContain("Gait Physical Examination");
  });

  it("uses the visit date selector's visit ID for interpretation menu availability", () => {
    loadOverview();
    fixture.componentInstance.visits.push({ ...visit, id: 6 });
    fixture.componentInstance.onVisitDateChange(6);
    httpTesting.expectOne("/api/visits/6/overview").flush({ ...visit, id: 6 });
    fixture.componentInstance.toggleInterpretation();
    httpTesting.expectOne("/api/patients/1125/visits/6/interpretation")
      .flush([{ key: "signatures", label: "Signatures", enabled: true }]);
    fixture.detectChanges();
    fixture.nativeElement.querySelector(".sub-menu-item").click();
    fixture.detectChanges();
    expect(fixture.componentInstance.selectedVisitId).toBe(6);
    expect(fixture.componentInstance.activeInterpretation?.key).toBe("signatures");
    expect(fixture.nativeElement.querySelector(".not-implemented h2")?.textContent).toBe("Signatures");
    httpTesting.expectNone(request => request.url.includes("/interpretation/"));
  });

  it("surfaces availability failures and allows retry without enabling anything", () => {
    loadOverview();
    fixture.componentInstance.toggleInterpretation();
    httpTesting.expectOne("/api/patients/1125/visits/5/interpretation")
      .flush("Failed", { status: 500, statusText: "Server Error" });
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector(".sub-menu [role=alert]").textContent)
      .toContain("Unable to load interpretation options");
    expect(fixture.componentInstance.interpretationSections).toEqual([]);
    fixture.nativeElement.querySelector(".sub-menu button").click();
    httpTesting.expectOne("/api/patients/1125/visits/5/interpretation").flush(interpretationOptions);
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector(".sub-menu [role=alert]")).toBeNull();
    expect(fixture.nativeElement.querySelectorAll(".sub-menu-item").length).toBe(5);
  });

  it("loads and displays PNGs for the selected visit from the Visit Menu", () => {
    fixture.componentRef.setInput("patient", patient);
    fixture.componentRef.setInput("visit", visit);
    fixture.detectChanges();

    httpTesting.expectOne("/api/patients/1125/visits").flush([visit]);
    httpTesting.expectOne("/api/visits/5/overview").flush({
      ...visit,
      firstName: "Jane",
      lastName: "Doe",
      dateOfBirth: "2010-05-20",
      visitDate: "2025-12-03"
    });
    fixture.detectChanges();

    const menuButtons = Array.from(
      fixture.nativeElement.querySelectorAll("button")
    ) as HTMLButtonElement[];
    menuButtons.find((button) => button.textContent?.includes("View PNGs for this visit"))?.click();
    fixture.detectChanges();

    const imagesRequest = httpTesting.expectOne((request) =>
      request.url === "/api/patients/1125/visits/5/images" &&
      request.params.get("type") === "PNG"
    );
    imagesRequest.flush([{
      id: "image-id",
      fileName: "gait.png",
      sizeBytes: 123,
      contentUrl: "/api/patients/1125/visits/5/images/image-id/content"
    }]);
    fixture.detectChanges();

    expect(fixture.nativeElement.textContent).toContain("gait.png");
    expect(fixture.nativeElement.querySelector("img")?.getAttribute("src"))
      .toBe("/api/patients/1125/visits/5/images/image-id/content");
  });

  it("loads and displays photos for the selected visit from the Visit Menu", () => {
    fixture.componentRef.setInput("patient", patient);
    fixture.componentRef.setInput("visit", visit);
    fixture.detectChanges();

    httpTesting.expectOne("/api/patients/1125/visits").flush([visit]);
    httpTesting.expectOne("/api/visits/5/overview").flush({
      ...visit,
      firstName: "Jane",
      lastName: "Doe",
      dateOfBirth: "2010-05-20",
      visitDate: "2025-12-03"
    });
    fixture.detectChanges();

    const menuButtons = Array.from(
      fixture.nativeElement.querySelectorAll("button")
    ) as HTMLButtonElement[];
    menuButtons.find((button) => button.textContent?.includes("View photos for this visit"))?.click();
    fixture.detectChanges();

    const imagesRequest = httpTesting.expectOne((request) =>
      request.url === "/api/patients/1125/visits/5/images" &&
      request.params.get("type") === "PHOTO"
    );
    imagesRequest.flush([{
      id: "photo-id",
      fileName: "patient.jpg",
      sizeBytes: 123,
      contentUrl: "/api/patients/1125/visits/5/images/photo-id/content"
    }]);
    fixture.detectChanges();

    expect(fixture.nativeElement.textContent).toContain("patient.jpg");
    expect(fixture.nativeElement.querySelector("img")?.getAttribute("src"))
      .toBe("/api/patients/1125/visits/5/images/photo-id/content");
  });
});
