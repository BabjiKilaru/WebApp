package org.nemours.gaitlab.repository;

import org.nemours.gaitlab.model.HistoryCondition;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface HistoryConditionRepository extends JpaRepository<HistoryCondition, String> {
    List<HistoryCondition> findAllByOrderByConditionAsc();

    @Query(value = "SELECT code, condition, il8n_sp FROM public.history_cond ORDER BY condition", nativeQuery = true)
    List<Object[]> findAllWithSpanish();
}
