package org.nemours.gaitlab.repository;

import org.nemours.gaitlab.model.BodyLocation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface BodyLocationRepository extends JpaRepository<BodyLocation, String> {
    List<BodyLocation> findAllByOrderByLocationAsc();

    @Query(value = "SELECT location, il8n_sp FROM public.body_loc ORDER BY location", nativeQuery = true)
    List<Object[]> findAllWithSpanish();
}
