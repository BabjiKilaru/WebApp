package org.nemours.gaitlab.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/** Single data-access class for the whole PT Evaluation feature - one repository per tab/table
 * was judged to be more classes than the feature warranted, so Dystonia/HAT/General/General-MD/
 * Motor Control-Tone/Orthoses/Pain/PROM-Strength are all merged in here. Method names are
 * prefixed with their domain only where the original per-tab class names would otherwise collide
 * (Dystonia/HAT both had findItems/findSelectionsForItem/findSelectionById/
 * existsSelectionForItem; Orthoses/Pain/PROM-Strength all had a findByVisitId with a different
 * table behind it); every other method keeps its original, already-unique name. */
@Repository
public class PtEvaluationRepository {
    public static final List<String> ULLR_OPTIONS = List.of("UER", "LER", "UEL", "LEL");

    private final JdbcTemplate jdbcTemplate;

    public PtEvaluationRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // --- Dystonia Scale: pt-eval-dystonia-scale.jsp/modify_pt_dystonia_scale.jsp ---------------
    // Six items (dystonia_item, value 1-6: Eyes/Mouth/Neck/Trunk/UE/LE); Eyes/Mouth/Neck/Trunk are
    // unilateral (dystonia_scale.eyes/mouth/neck/trunk), UE/LE are bilateral (uer/uel, ler/lel) -
    // matches DystoniaItem#isBilateral() and DystoniaScale#getSelection(item, side) in the legacy
    // Java model.

    // Frontend: PT Evaluation - Dystonia Scale tab (item list)
    public List<Map<String, Object>> findDystoniaItems() {
        return jdbcTemplate.queryForList(
                "SELECT id, item, longdesc, value FROM public.dystonia_item WHERE active = TRUE ORDER BY value ASC");
    }

    // Frontend: PT Evaluation - Dystonia Scale tab (selection dropdown)
    public List<Map<String, Object>> findDystoniaSelectionsForItem(int itemId) {
        return jdbcTemplate.queryForList("""
                SELECT id, item AS selection, value, sortorder FROM public.dystonia_selection
                WHERE item_id = ? AND active = TRUE ORDER BY sortorder ASC
                """, itemId);
    }

    // Frontend: PT Evaluation - Dystonia Scale tab
    public Optional<Map<String, Object>> findDystoniaScaleByVisitId(int visitId) {
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(
                "SELECT * FROM public.dystonia_scale WHERE visit_id = ?", visitId);
        return rows.isEmpty() ? Optional.empty() : Optional.of(rows.get(0));
    }

    // Frontend: PT Evaluation - Dystonia Scale tab
    public Optional<Map<String, Object>> findDystoniaSelectionById(int selectionId) {
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(
                "SELECT id, item AS selection, value FROM public.dystonia_selection WHERE id = ?", selectionId);
        return rows.isEmpty() ? Optional.empty() : Optional.of(rows.get(0));
    }

    // Frontend: PT Evaluation - Dystonia Scale tab (save validation)
    public boolean existsDystoniaSelectionForItem(int itemId, int selectionId) {
        return !jdbcTemplate.queryForList(
                "SELECT 1 FROM public.dystonia_selection WHERE id = ? AND item_id = ?", selectionId, itemId)
                .isEmpty();
    }

    // Frontend: PT Evaluation - Dystonia Scale tab (save form)
    public void updateDystoniaScale(int id, Integer eyes, Integer mouth, Integer neck, Integer trunk, Integer uel,
            Integer uer, Integer lel, Integer ler) {
        jdbcTemplate.update("""
                UPDATE public.dystonia_scale
                SET eyes = ?, mouth = ?, neck = ?, trunk = ?, uel = ?, uer = ?, lel = ?, ler = ?
                WHERE id = ?
                """, eyes, mouth, neck, trunk, uel, uer, lel, ler, id);
    }

    // Frontend: PT Evaluation - Dystonia Scale tab (Create New Record)
    public int insertBlankDystoniaScale(int visitId) {
        return jdbcTemplate.queryForObject(
                "INSERT INTO public.dystonia_scale (visit_id) VALUES (?) RETURNING id", Integer.class, visitId);
    }

    // --- General (Gait): modify_pt.jsp's writes (the General & GMFM edit form) ----------------
    // height/weight/foot measurements live on visits; everything else lives on data_pt, so a save
    // touches both tables - ported as two separate statements, same as legacy's own two
    // PreparedStatements.

    // Frontend: PT Evaluation - General & GMFM tab, and General tab (movement-disorder visits)
    public List<Map<String, Object>> findActiveGmfcsListEntries() {
        return jdbcTemplate.queryForList(
                "SELECT id, label FROM public.gmfcs_list WHERE active = TRUE ORDER BY sortorder ASC");
    }

    // Frontend: PT Evaluation - General & GMFM tab, and General tab (movement-disorder visits)
    public List<Map<String, Object>> findActiveFmsListEntries() {
        return jdbcTemplate.queryForList(
                "SELECT id, label FROM public.fms_list WHERE active = TRUE ORDER BY sortorder ASC");
    }

    // Frontend: PT Evaluation - General & GMFM tab (save validation)
    public boolean existsGmfcsListEntry(int id) {
        return !jdbcTemplate.queryForList("SELECT 1 FROM public.gmfcs_list WHERE id = ?", id).isEmpty();
    }

    // Frontend: PT Evaluation - General & GMFM tab (save validation)
    public boolean existsFmsListEntry(int id) {
        return !jdbcTemplate.queryForList("SELECT 1 FROM public.fms_list WHERE id = ?", id).isEmpty();
    }

    // Frontend: PT Evaluation - General & GMFM tab, and General tab (movement-disorder, save form)
    public void updateVisitMeasurements(int visitId, Float height, Float weight, Float rightFootLength,
            Float leftFootLength, Float rightFootWidth, Float leftFootWidth) {
        jdbcTemplate.update("""
                UPDATE public.visits
                SET height = ?, weight = ?, r_foot_length = ?, l_foot_length = ?, r_foot_width = ?, l_foot_width = ?
                WHERE id = ?
                """, height, weight, rightFootLength, leftFootLength, rightFootWidth, leftFootWidth, visitId);
    }

    // Frontend: PT Evaluation - General & GMFM tab (save form)
    public void updateDataPt(int dataPtId, Integer ambScale, Integer gmfcs, Integer fms5, Integer fms50,
            Integer fms500, String comments, Integer pullStand, Integer indepStand3, Integer indepStand20,
            Integer oneLegHandR, Integer oneLegHandL, Integer oneLegR, Integer oneLegL, Integer shortSitStand,
            Integer highKneeStandR, Integer highKneeStandL, Integer lowerFloor, Integer squats,
            Integer standPickPen, Integer gmfmModA, Integer gmfmModB, Integer gmfmModC, Integer gmfmModE) {
        jdbcTemplate.update("""
                UPDATE public.data_pt
                SET amb_scale = ?, gmfcs = ?, fms_5 = ?, fms_50 = ?, fms_500 = ?, comments = ?,
                    pull_stand = ?, indep_stand_3 = ?, indep_stand_20 = ?, one_leg_hand_r = ?, one_leg_hand_l = ?,
                    one_leg_r = ?, one_leg_l = ?, short_sit_stand = ?, high_knee_stand_r = ?, high_knee_stand_l = ?,
                    lower_floor = ?, squats = ?, stand_pick_pen = ?, gmfm_mod_a = ?, gmfm_mod_b = ?,
                    gmfm_mod_c = ?, gmfm_mod_e = ?
                WHERE id = ?
                """, ambScale, gmfcs, fms5, fms50, fms500, comments, pullStand, indepStand3, indepStand20,
                oneLegHandR, oneLegHandL, oneLegR, oneLegL, shortSitStand, highKneeStandR, highKneeStandL,
                lowerFloor, squats, standPickPen, gmfmModA, gmfmModB, gmfmModC, gmfmModE, dataPtId);
    }

    /** Mirrors pt.jsp's own "Create New Record" insert - a bare data_pt row, visit_id only. */
    // Frontend: PT Evaluation - General & GMFM tab (Create New Record)
    public int insertBlankDataPt(int visitId) {
        return jdbcTemplate.queryForObject(
                "INSERT INTO public.data_pt (visit_id) VALUES (?) RETURNING id", Integer.class, visitId);
    }

    // --- General (Movement Disorder): modify_pt.jsp's isMovementDisorder branch ---------------
    // amb_scale/comments/gmfcs/fms_5/fms_50/fms_500/macs/cfcs on data_pt_movement_disorder.
    // height/weight/foot measurements still live on visits and are shared with the Gait form -
    // updateVisitMeasurements above is reused for those rather than duplicated here.

    // Frontend: PT Evaluation - General tab (movement-disorder visits)
    public List<Map<String, Object>> findActiveMacsListEntries() {
        return jdbcTemplate.queryForList(
                "SELECT id, label FROM public.macs_list WHERE active = TRUE ORDER BY sortorder ASC");
    }

    // Frontend: PT Evaluation - General tab (movement-disorder visits)
    public List<Map<String, Object>> findActiveCfcsListEntries() {
        return jdbcTemplate.queryForList(
                "SELECT id, label FROM public.cfcs_list WHERE active = TRUE ORDER BY sortorder ASC");
    }

    // Frontend: PT Evaluation - General tab (movement-disorder, save validation)
    public boolean existsMacsListEntry(int id) {
        return !jdbcTemplate.queryForList("SELECT 1 FROM public.macs_list WHERE id = ?", id).isEmpty();
    }

    // Frontend: PT Evaluation - General tab (movement-disorder, save validation)
    public boolean existsCfcsListEntry(int id) {
        return !jdbcTemplate.queryForList("SELECT 1 FROM public.cfcs_list WHERE id = ?", id).isEmpty();
    }

    // Frontend: PT Evaluation - General tab (movement-disorder, save form)
    public void updateDataPtMovementDisorder(int dataPtMdId, Integer ambScale, Integer gmfcs, Integer fms5,
            Integer fms50, Integer fms500, Integer macs, Integer cfcs, String comments) {
        jdbcTemplate.update("""
                UPDATE public.data_pt_movement_disorder
                SET amb_scale = ?, gmfcs = ?, fms_5 = ?, fms_50 = ?, fms_500 = ?, macs = ?, cfcs = ?, comments = ?
                WHERE id = ?
                """, ambScale, gmfcs, fms5, fms50, fms500, macs, cfcs, comments, dataPtMdId);
    }

    /** Mirrors insertBlankDataPt - a bare data_pt_movement_disorder row, visit_id only
     * (gmfcs/fms_5/fms_50/fms_500 fall back to their NOT NULL DEFAULT 1). */
    // Frontend: PT Evaluation - General tab (movement-disorder, Create New Record)
    public int insertBlankDataPtMovementDisorder(int visitId) {
        return jdbcTemplate.queryForObject(
                "INSERT INTO public.data_pt_movement_disorder (visit_id) VALUES (?) RETURNING id", Integer.class,
                visitId);
    }

    /** pt-eval-orth.jsp's own MD-only "Comments" textarea+Save - touches only this one column,
     * unlike the General tab's own save which rewrites every field at once. Named apart from the
     * Orthoses-domain methods below since it touches data_pt_movement_disorder, not pt_orthoses. */
    // Frontend: PT Evaluation - Orthotics tab (movement-disorder visits, Comments field)
    public void updateMovementDisorderOrthosesComment(int dataPtMdId, String orthoses) {
        jdbcTemplate.update("UPDATE public.data_pt_movement_disorder SET orthoses = ? WHERE id = ?", orthoses,
                dataPtMdId);
    }

    // --- HAT: pt-eval-hat.jsp/modify_pt_hat.jsp ------------------------------------------------
    // The 7-item Hypertonia Assessment Tool, scored once per limb (hat_scores.ullr - UEL/UER/LEL/
    // LER, UNIQUE(visit_id, ullr) - production's actual schema, gaitdata.export.psql:3298-3310/
    // 8029; aligned here via an explicit migration, see the Phase 4 audit scratchpad). The
    // ULLR_OPTIONS order (UER, LER, UEL, LEL) is the column order both pt-eval-hat.jsp and
    // modify_pt_hat.jsp iterate in - matched exactly below.

    // Frontend: PT Evaluation - HAT tab (item list)
    public List<Map<String, Object>> findHatItems() {
        return jdbcTemplate.queryForList(
                "SELECT id, item, value FROM public.hat_item WHERE active = TRUE ORDER BY value ASC");
    }

    // Frontend: PT Evaluation - HAT tab (selection dropdown)
    public List<Map<String, Object>> findHatSelectionsForItem(int itemId) {
        return jdbcTemplate.queryForList(
                "SELECT id, selection, value FROM public.hat_selection WHERE item_id = ? AND active = TRUE ORDER BY value ASC",
                itemId);
    }

    /** 0-4 rows, each with its own "ullr" - however many limbs have been scored for this visit. */
    // Frontend: PT Evaluation - HAT tab
    public List<Map<String, Object>> findHatScoresByVisitId(int visitId) {
        return jdbcTemplate.queryForList("SELECT * FROM public.hat_scores WHERE visit_id = ?", visitId);
    }

    /** Resolves a hatN selection's value+selection text, or null if unset/unknown. */
    // Frontend: PT Evaluation - HAT tab
    public Optional<Map<String, Object>> findHatSelectionById(int selectionId) {
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(
                "SELECT id, selection, value FROM public.hat_selection WHERE id = ?", selectionId);
        return rows.isEmpty() ? Optional.empty() : Optional.of(rows.get(0));
    }

    // Frontend: PT Evaluation - HAT tab (save validation)
    public boolean existsHatSelectionForItem(int itemId, int selectionId) {
        return !jdbcTemplate.queryForList(
                "SELECT 1 FROM public.hat_selection WHERE id = ? AND item_id = ?", selectionId, itemId).isEmpty();
    }

    // Frontend: PT Evaluation - HAT tab (save form)
    public void updateHatScores(int id, Integer hat1, Integer hat2, Integer hat3, Integer hat4, Integer hat5,
            Integer hat6, Integer hat7) {
        jdbcTemplate.update("""
                UPDATE public.hat_scores
                SET hat1 = ?, hat2 = ?, hat3 = ?, hat4 = ?, hat5 = ?, hat6 = ?, hat7 = ?
                WHERE id = ?
                """, hat1, hat2, hat3, hat4, hat5, hat6, hat7, id);
    }

    /** pt-eval-hat.jsp's own "Create New Record" handler creates all 4 ULLR_OPTIONS rows at once
     * (visit.setHatScores(scores) with one HatScore per limb), not just one. */
    // Frontend: PT Evaluation - HAT tab (Create New Record)
    public void insertBlankHatScoresForAllLimbs(int visitId) {
        for (String ullr : ULLR_OPTIONS) {
            jdbcTemplate.update(
                    "INSERT INTO public.hat_scores (visit_id, ullr) VALUES (?, ?)", visitId, ullr);
        }
    }

    // --- Motor Control / Tone: pt-eval-mc.jsp/pt-eval-tone.jsp ---------------------------------
    // Both join data_tone to a lookup table (mc_tests / tone_tests) by test name, ordered by the
    // lookup table's own id.

    // Frontend: PT Evaluation - Motor Control tab, and the Comparison Report
    public List<Map<String, Object>> findMotorControlByVisitId(int visitId) {
        return jdbcTemplate.queryForList("""
                SELECT dt.id, dt.test, dt.score_r, dt.interp_r, dt.score_l, dt.interp_l
                FROM public.data_tone dt
                JOIN public.mc_tests mt ON dt.test = mt.test
                WHERE dt.visit_id = ? AND dt.mc_tone = 'mc'
                ORDER BY mt.id
                """, visitId);
    }

    // Frontend: PT Evaluation - Tone tab (Gait visits), and the Comparison Report
    public List<Map<String, Object>> findToneByVisitId(int visitId) {
        return jdbcTemplate.queryForList("""
                SELECT dt.id, dt.test, dt.score_r, dt.interp_r, dt.score_l, dt.interp_l
                FROM public.data_tone dt
                JOIN public.tone_tests tt ON dt.test = tt.test
                WHERE dt.visit_id = ? AND dt.mc_tone = 'tone'
                ORDER BY tt.id
                """, visitId);
    }

    /** pt-movement-disorder-eval-tone.jsp's own test list: only tone_tests.id <= 16 (its loop
     * explicitly checks `t.getTest().getId() <= 16`) - Proximal/Distal Muscle Tone (100/101) and
     * *Clonus Severity Notes (102) are Gait-Tone-only, not shown on the movement-disorder page. */
    // Frontend: PT Evaluation - Tone tab (movement-disorder visits)
    public List<Map<String, Object>> findToneByVisitIdForMovementDisorder(int visitId) {
        return jdbcTemplate.queryForList("""
                SELECT dt.id, dt.test, dt.score_r, dt.interp_r, dt.score_l, dt.interp_l
                FROM public.data_tone dt
                JOIN public.tone_tests tt ON dt.test = tt.test
                WHERE dt.visit_id = ? AND dt.mc_tone = 'tone' AND tt.id <= 16
                ORDER BY tt.id
                """, visitId);
    }

    // Frontend: PT Evaluation - Motor Control tab (Create New Record)
    public List<String> findMcTestNames() {
        return jdbcTemplate.queryForList("SELECT test FROM public.mc_tests ORDER BY id ASC", String.class);
    }

    // Frontend: PT Evaluation - Tone tab (Create New Record)
    public List<String> findToneTestNames() {
        return jdbcTemplate.queryForList("SELECT test FROM public.tone_tests ORDER BY id ASC", String.class);
    }

    // Frontend: PT Evaluation - Motor Control tab (save-form score dropdown)
    public List<String> findMcListOptions() {
        return jdbcTemplate.queryForList("SELECT score FROM public.mc_list", String.class);
    }

    // Frontend: PT Evaluation - Tone tab (save-form score dropdown)
    public List<String> findToneListOptions() {
        return jdbcTemplate.queryForList("SELECT scale FROM public.tone_list", String.class);
    }

    /** Shared by Motor Control, Tone and PROM/Strength - all three read the exact same
     * "interp" lookup table the same way, so this one method now backs all of them instead of
     * three identical copies. */
    // Frontend: PT Evaluation - Motor Control, Tone, and PROM/Strength tabs (interpretation dropdown)
    public List<String> findInterpOptions() {
        return jdbcTemplate.queryForList("SELECT scale FROM public.interp ORDER BY id ASC", String.class);
    }

    // Frontend: PT Evaluation - Motor Control and Tone tabs (Create New Record)
    public void insertBlankRow(int visitId, String test, String mcTone) {
        jdbcTemplate.update(
                "INSERT INTO public.data_tone (visit_id, test, mc_tone) VALUES (?, ?, ?)", visitId, test, mcTone);
    }

    // Frontend: PT Evaluation - Motor Control and Tone tabs (save form)
    public void updateScoreAndInterp(int id, String scoreR, String interpR, String scoreL, String interpL) {
        jdbcTemplate.update(
                "UPDATE public.data_tone SET score_r = ?, interp_r = ?, score_l = ?, interp_l = ? WHERE id = ?",
                scoreR, interpR, scoreL, interpL, id);
    }

    // Frontend: PT Evaluation - Motor Control and Tone tabs (save form, interpretation-only tests)
    public void updateInterpOnly(int id, String interpR, String interpL) {
        jdbcTemplate.update(
                "UPDATE public.data_tone SET interp_r = ?, interp_l = ? WHERE id = ?", interpR, interpL, id);
    }

    /** pt-movement-disorder-eval-tone.jsp's Upper Extremity rows - one row per visit (unlike
     * data_tone's one-row-per-test), six muscle groups with R/L score + R/L interp each. */
    // Frontend: PT Evaluation - Tone tab (movement-disorder visits, Upper Extremity rows)
    public Optional<Map<String, Object>> findUeToneByVisitId(int visitId) {
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(
                "SELECT * FROM public.pt_ue_tone WHERE visit_id = ?", visitId);
        return rows.isEmpty() ? Optional.empty() : Optional.of(rows.get(0));
    }

    private static final List<String> UE_TONE_COLUMNS = List.of(
            "shoulder_extensors_r", "shoulder_extensors_r_interp", "shoulder_extensors_l", "shoulder_extensors_l_interp",
            "shoulder_flexors_r", "shoulder_flexors_r_interp", "shoulder_flexors_l", "shoulder_flexors_l_interp",
            "elbow_extensors_r", "elbow_extensors_r_interp", "elbow_extensors_l", "elbow_extensors_l_interp",
            "elbow_flexors_r", "elbow_flexors_r_interp", "elbow_flexors_l", "elbow_flexors_l_interp",
            "wrist_extensors_r", "wrist_extensors_r_interp", "wrist_extensors_l", "wrist_extensors_l_interp",
            "wrist_flexors_r", "wrist_flexors_r_interp", "wrist_flexors_l", "wrist_flexors_l_interp");

    /** Dynamic SET clause built only from the fixed UE_TONE_COLUMNS whitelist above - never from
     * request-supplied keys - same SQL-injection-safe pattern as the PROM/Strength update below. */
    // Frontend: PT Evaluation - Tone tab (movement-disorder visits, save Upper Extremity rows)
    public void updateUeTone(int id, Map<String, String> columns) {
        List<String> setClauses = new ArrayList<>();
        List<Object> params = new ArrayList<>();
        for (String column : UE_TONE_COLUMNS) {
            if (columns.containsKey(column)) {
                setClauses.add(column + " = ?");
                params.add(columns.get(column));
            }
        }
        if (setClauses.isEmpty()) {
            return;
        }
        params.add(id);
        jdbcTemplate.update(
                "UPDATE public.pt_ue_tone SET " + String.join(", ", setClauses) + " WHERE id = ?",
                params.toArray());
    }

    // Frontend: PT Evaluation - Tone tab (movement-disorder visits, Create New Record)
    public int insertBlankUeTone(int visitId) {
        return jdbcTemplate.queryForObject(
                "INSERT INTO public.pt_ue_tone (visit_id) VALUES (?) RETURNING id", Integer.class, visitId);
    }

    // --- Orthoses: pt-eval-orth.jsp's orthoses list and insert_orth.jsp/modify_orth.jsp/ -------
    // delete_orth.jsp (the movement-disorder "Comments" block lives above, in the General-MD
    // section - it touches data_pt_movement_disorder, not pt_orthoses). pt_orthoses has no FK
    // children (no trial/device rows reference it), so delete is a plain single-row delete.

    // Frontend: PT Evaluation - Orthotics tab (list)
    public List<Map<String, Object>> findOrthosesByVisitId(int visitId) {
        return jdbcTemplate.queryForList(
                "SELECT id, orthosis, side FROM public.pt_orthoses WHERE visit_id = ? ORDER BY orthosis ASC",
                visitId);
    }

    // Frontend: PT Evaluation - Orthotics tab (edit form)
    public Optional<Map<String, Object>> findByIdAndVisitId(int id, int visitId) {
        return jdbcTemplate.queryForList(
                "SELECT id, orthosis, side FROM public.pt_orthoses WHERE id = ? AND visit_id = ?", id, visitId)
                .stream().findFirst();
    }

    // Frontend: PT Evaluation - Orthotics tab (orthosis-type dropdown)
    public List<String> findOrthosisOptions() {
        return jdbcTemplate.queryForList("SELECT orthosis FROM public.orthoses ORDER BY orthosis", String.class);
    }

    // Frontend: PT Evaluation - Orthotics tab (Add an Orthosis)
    public int insert(int visitId, String orthosis, String side) {
        return jdbcTemplate.queryForObject(
                "INSERT INTO public.pt_orthoses (visit_id, orthosis, side) VALUES (?, ?, ?) RETURNING id",
                Integer.class, visitId, orthosis, side);
    }

    // Frontend: PT Evaluation - Orthotics tab (edit an orthosis)
    public void update(int id, int visitId, String orthosis, String side) {
        jdbcTemplate.update(
                "UPDATE public.pt_orthoses SET orthosis = ?, side = ? WHERE id = ? AND visit_id = ?",
                orthosis, side, id, visitId);
    }

    // Frontend: PT Evaluation - Orthotics tab (delete an orthosis)
    public void deleteByIdAndVisitId(int id, int visitId) {
        jdbcTemplate.update("DELETE FROM public.pt_orthoses WHERE id = ? AND visit_id = ?", id, visitId);
    }

    // --- Pain: pt-eval-pain.jsp's read of the JPA DataPain entity and its two lookup-backed -----
    // lists.

    // Frontend: PT Evaluation - Pain tab
    public Optional<Map<String, Object>> findPainByVisitId(int visitId) {
        return jdbcTemplate.queryForList("""
                SELECT dp.id, dp.current_level, dp.highest_level, dp.lowest_level,
                       dp.location, dp.frequency, dp.duration,
                       dp.pain_assessment_method_id, pam.label AS assessment_method
                FROM public.data_pain dp
                LEFT JOIN public.pain_assessment_methods pam ON pam.id = dp.pain_assessment_method_id
                WHERE dp.visit_id = ?
                """, visitId).stream().findFirst();
    }

    // Frontend: PT Evaluation - Pain tab (pain factors list)
    public List<String> findFactorLabels(int dataPainId) {
        return jdbcTemplate.queryForList("""
                SELECT pf.label
                FROM public.data_pain_to_pain_factors link
                JOIN public.pain_factors pf ON pf.id = link.pain_factor_id
                WHERE link.data_pain_id = ?
                ORDER BY pf.sortorder
                """, String.class, dataPainId);
    }

    // Frontend: PT Evaluation - Pain tab (activities impacted list)
    public List<String> findActivitiesImpactedLabels(int dataPainId) {
        return jdbcTemplate.queryForList("""
                SELECT pa.label
                FROM public.data_pain_to_pain_activities_impacted link
                JOIN public.pain_activities_impacted pa ON pa.id = link.pain_activities_impacted_id
                WHERE link.data_pain_id = ?
                ORDER BY pa.sortorder
                """, String.class, dataPainId);
    }

    // Frontend: PT Evaluation - Pain tab (save form)
    public List<Integer> findFactorIds(int dataPainId) {
        return jdbcTemplate.queryForList(
                "SELECT pain_factor_id FROM public.data_pain_to_pain_factors WHERE data_pain_id = ?",
                Integer.class, dataPainId);
    }

    // Frontend: PT Evaluation - Pain tab (save form)
    public List<Integer> findActivitiesImpactedIds(int dataPainId) {
        return jdbcTemplate.queryForList(
                "SELECT pain_activities_impacted_id FROM public.data_pain_to_pain_activities_impacted"
                        + " WHERE data_pain_id = ?",
                Integer.class, dataPainId);
    }

    // Frontend: PT Evaluation - Pain tab (assessment method dropdown)
    public List<Map<String, Object>> findAssessmentMethodOptions() {
        return jdbcTemplate.queryForList(
                "SELECT id, label FROM public.pain_assessment_methods ORDER BY sortorder");
    }

    // Frontend: PT Evaluation - Pain tab (pain factors checklist)
    public List<Map<String, Object>> findFactorOptions() {
        return jdbcTemplate.queryForList("SELECT id, label FROM public.pain_factors ORDER BY sortorder");
    }

    // Frontend: PT Evaluation - Pain tab (activities impacted checklist)
    public List<Map<String, Object>> findActivitiesImpactedOptions() {
        return jdbcTemplate.queryForList(
                "SELECT id, label FROM public.pain_activities_impacted ORDER BY sortorder");
    }

    // Frontend: PT Evaluation - Pain tab (save validation)
    public boolean existsAssessmentMethod(int id) {
        return !jdbcTemplate.queryForList(
                "SELECT 1 FROM public.pain_assessment_methods WHERE id = ?", id).isEmpty();
    }

    // Frontend: PT Evaluation - Pain tab (save validation)
    public boolean existsFactor(int id) {
        return !jdbcTemplate.queryForList("SELECT 1 FROM public.pain_factors WHERE id = ?", id).isEmpty();
    }

    // Frontend: PT Evaluation - Pain tab (save validation)
    public boolean existsActivityImpacted(int id) {
        return !jdbcTemplate.queryForList("SELECT 1 FROM public.pain_activities_impacted WHERE id = ?", id)
                .isEmpty();
    }

    /** Inserts a blank data_pain row (every column besides visit_id left null) and returns its
     * new id, mirroring pt-eval-pain.jsp's "Create New Record" - a bare row, nothing else. */
    // Frontend: PT Evaluation - Pain tab (Create New Record)
    public int insertBlankRecord(int visitId) {
        return jdbcTemplate.queryForObject(
                "INSERT INTO public.data_pain (visit_id) VALUES (?) RETURNING id", Integer.class, visitId);
    }

    // Frontend: PT Evaluation - Pain tab (save form)
    public void updateRecord(int dataPainId, Integer assessmentMethodId, Integer currentLevel, Integer lowestLevel,
            Integer highestLevel, String location, String frequency, String duration) {
        jdbcTemplate.update("""
                UPDATE public.data_pain
                SET pain_assessment_method_id = ?, current_level = ?, lowest_level = ?, highest_level = ?,
                    location = ?, frequency = ?, duration = ?
                WHERE id = ?
                """, assessmentMethodId, currentLevel, lowestLevel, highestLevel, location, frequency, duration,
                dataPainId);
    }

    // Frontend: PT Evaluation - Pain tab (save form)
    public void replaceFactorLinks(int dataPainId, List<Integer> factorIds) {
        jdbcTemplate.update("DELETE FROM public.data_pain_to_pain_factors WHERE data_pain_id = ?", dataPainId);
        for (Integer factorId : factorIds) {
            jdbcTemplate.update(
                    "INSERT INTO public.data_pain_to_pain_factors (data_pain_id, pain_factor_id) VALUES (?, ?)",
                    dataPainId, factorId);
        }
    }

    // Frontend: PT Evaluation - Pain tab (save form)
    public void replaceActivitiesImpactedLinks(int dataPainId, List<Integer> activityIds) {
        jdbcTemplate.update(
                "DELETE FROM public.data_pain_to_pain_activities_impacted WHERE data_pain_id = ?", dataPainId);
        for (Integer activityId : activityIds) {
            jdbcTemplate.update("""
                    INSERT INTO public.data_pain_to_pain_activities_impacted
                        (data_pain_id, pain_activities_impacted_id) VALUES (?, ?)
                    """, dataPainId, activityId);
        }
    }

    // --- PROM/Strength: pt-eval-prom.jsp (read) and modify_pt_prom.jsp (write) ----------------
    // Gait (non-movement-disorder) visits only: data_prom, not data_movement_disorder_prom.

    // Frontend: PT Evaluation - PROM/Strength tab (Gait visits), and the Comparison Report
    public Optional<Map<String, Object>> findPromByVisitId(int visitId) {
        return jdbcTemplate.queryForList("SELECT * FROM public.data_prom WHERE visit_id = ?", visitId)
                .stream().findFirst();
    }

    /** modify_pt_prom.jsp buckets the normal-range reference row by the patient's age at the
     * visit (less_than_age: 5, 8, 11, 14, 15, else 25) - ported as one query instead of Java
     * if/else, same bucket boundaries. Empty when data_prom_normals has no row for that bucket
     * (true of every bucket in the current seed data - flagged separately, not bent here). */
    // Frontend: PT Evaluation - PROM/Strength tab (normal-range reference row)
    public Optional<Map<String, Object>> findNormalsForVisit(int visitId) {
        return jdbcTemplate.queryForList("""
                SELECT n.*
                FROM public.data_prom_normals n, public.visits v, public.patients p
                WHERE v.id = ? AND p.id = v.pt_id
                  AND n.less_than_age = (
                    CASE
                        WHEN (v.date - p.dob) / 365.0 < 5.0 THEN 5
                        WHEN (v.date - p.dob) / 365.0 < 8.0 THEN 8
                        WHEN (v.date - p.dob) / 365.0 < 11.0 THEN 11
                        WHEN (v.date - p.dob) / 365.0 < 14.0 THEN 14
                        WHEN (v.date - p.dob) / 365.0 < 15.0 THEN 15
                        ELSE 25
                    END)
                """, visitId).stream().findFirst();
    }

    // Frontend: PT Evaluation - PROM/Strength tab (Create New Record)
    public int insertBlank(int visitId) {
        return jdbcTemplate.queryForObject(
                "INSERT INTO public.data_prom (visit_id) VALUES (?) RETURNING id", Integer.class, visitId);
    }

    /** Column names come only from this port's own fixed PROM field list, never from request
     * data, so building the SET clause from the map's keys is safe - a ~130-column fixed-arity
     * method would be far less maintainable than this port's actual legacy field count. */
    // Frontend: PT Evaluation - PROM/Strength tab (save form)
    public void update(int dataPromId, Map<String, Object> columns) {
        updateColumns("public.data_prom", dataPromId, columns);
    }

    // --- Phase 4: pt-sections.jsp's mainPromTable swap for movement-disorder visits -------------

    // Frontend: PT Evaluation - PROM/Strength tab (movement-disorder visits)
    public Optional<Map<String, Object>> findMdByVisitId(int visitId) {
        return jdbcTemplate.queryForList("SELECT * FROM public.data_movement_disorder_prom WHERE visit_id = ?",
                visitId).stream().findFirst();
    }

    // Frontend: PT Evaluation - PROM/Strength tab (movement-disorder visits, Create New Record)
    public int insertBlankMd(int visitId) {
        return jdbcTemplate.queryForObject(
                "INSERT INTO public.data_movement_disorder_prom (visit_id) VALUES (?) RETURNING id", Integer.class,
                visitId);
    }

    // Frontend: PT Evaluation - PROM/Strength tab (movement-disorder visits, save form)
    public void updateMd(int dataPromId, Map<String, Object> columns) {
        updateColumns("public.data_movement_disorder_prom", dataPromId, columns);
    }

    private void updateColumns(String table, int id, Map<String, Object> columns) {
        StringBuilder sql = new StringBuilder("UPDATE " + table + " SET ");
        List<Object> params = new ArrayList<>();
        boolean first = true;
        for (Map.Entry<String, Object> entry : columns.entrySet()) {
            if (!first) {
                sql.append(", ");
            }
            sql.append(entry.getKey()).append(" = ?");
            params.add(entry.getValue());
            first = false;
        }
        sql.append(" WHERE id = ?");
        params.add(id);
        jdbcTemplate.update(sql.toString(), params.toArray());
    }
}
