package org.nemours.gaitlab.repository;

import org.nemours.gaitlab.model.Condition;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ConditionRepository extends JpaRepository<Condition, String> {
    List<Condition> findAllByOrderByConditionAsc();

    @Query(value = "SELECT code, condition, il8n_sp FROM public.conditions ORDER BY condition", nativeQuery = true)
    List<Object[]> findAllWithSpanish();
}
