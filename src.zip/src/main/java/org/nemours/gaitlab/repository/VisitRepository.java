package org.nemours.gaitlab.repository;

import java.util.List;
import java.time.LocalDate;

import org.nemours.gaitlab.model.Visit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface VisitRepository extends JpaRepository<Visit, Integer> {

    @Query(value = """
            SELECT v.id AS "id", v.visit_type_id AS "visitTypeId"
            FROM public.visits v
            WHERE v.id = :visitId AND v.pt_id = :patientId
            """, nativeQuery = true)
    java.util.Optional<InterpretationVisit> findInterpretationVisitByIdAndPatientId(
            @Param("visitId") Integer visitId,
            @Param("patientId") Integer patientId);

    interface InterpretationVisit {
        Integer getVisitTypeId();
    }

    List<Visit> findByPatientId(Integer patientId);

    List<Visit> findByPatientIdOrderByDateDesc(Integer patientId);

    @Query(value = """
            SELECT v.id AS id, v.date::text AS "visitDate"
            FROM public.visits v
            WHERE v.pt_id = :patientId
            ORDER BY v.date DESC, v.id DESC
            """, nativeQuery = true)
    List<VideoVisitDate> findVideoVisitDatesByPatientId(@Param("patientId") Integer patientId);

    @Query(value = """
            SELECT v.id AS id, v.date::text AS "visitDate"
            FROM public.visits v
            WHERE v.pt_id = :patientId AND v.id = :visitId
            """, nativeQuery = true)
    java.util.Optional<VideoVisitDate> findVideoVisitDateByIdAndPatientId(
            @Param("visitId") Integer visitId,
            @Param("patientId") Integer patientId);

    List<Visit> findByPatientIdAndDateOrderByIdAsc(
        Integer patientId,
        LocalDate date
    );

    @Query(
        value = """
                SELECT COALESCE(MAX(id), 0) + 1
                FROM public.visits
                """,
            nativeQuery = true
    )
    Integer getNextVisitId();

    @Query(value = """
            SELECT 
	            v.id, 
	            v.pt_id, 
                v.date,
                v.attendance,
	            CASE WHEN vt.name IS NULL THEN v.visit_type ELSE vt.name END AS visit_type,
	            tg.name AS visitSubType
            FROM public.visits v
            LEFT JOIN public.new_visit_type vt ON v.visit_type_id = vt.id
            LEFT JOIN public.new_test_group tg ON v.test_group_id = tg.id
            WHERE v.pt_id = :patientId
            ORDER BY v.date DESC, v.id DESC;
            """, nativeQuery = true)
    List<Object[]> findVisitDisplayByPatientId( @Param("patientId") Integer patientId);

    @Query(value = """
            SELECT 
                v.id AS visit_id,
                p.id AS patient_id,
                p.fname,
                p.lname,
                p.mrn,
                CASE 
                    WHEN vt.name IS NULL
                    THEN v.visit_type
                    ELSE vt.name
                END AS visit_type,
                tg.name AS visit_sub_type
            FROM public.patients p
            JOIN public.visits v
                ON v.pt_id = p.id
            LEFT JOIN public.new_visit_type vt
                ON v.visit_type_id = vt.id
            LEFT JOIN public.new_test_group tg
                ON v.test_group_id = tg.id
            WHERE v.date = :date
                AND (v.attendance IS NULL
                    OR v.attendance = ''
                    OR v.attendance = 'Yes')
            ORDER BY p.lname, p.fname, v.id
            """,
            nativeQuery = true
        )
    List<Object[]> findScheduledVisitsByDate(@Param("date") LocalDate date);

    interface VideoVisitDate {
        Integer getId();

        String getVisitDate();
    }

    @Query(value = """
            SELECT
                dp.id AS "dataPtId",
                v.date AS "visitDate",
                v.icd9 AS "icd9",
                p.dob AS "dob",
                p.gender AS "gender",
                p.gen_diag AS "genDiag",
                v.height AS "heightCm",
                v.weight AS "weightKg",
                v.r_foot_length AS "rightFootLengthCm",
                v.l_foot_length AS "leftFootLengthCm",
                v.r_foot_width AS "rightFootWidthCm",
                v.l_foot_width AS "leftFootWidthCm",
                dp.amb_scale AS "ambScaleId",
                amb.description AS "ambulationScale",
                dp.gmfcs AS "gmfcsId",
                dp.fms_5 AS "fms5Id",
                fms5.label AS "fms5m",
                fms5.description AS "fms5mDesc",
                dp.fms_50 AS "fms50Id",
                fms50.label AS "fms50m",
                fms50.description AS "fms50mDesc",
                dp.fms_500 AS "fms500Id",
                fms500.label AS "fms500m",
                fms500.description AS "fms500mDesc",
                dp.comments AS "comments",
                dp.pull_stand AS "pullStand",
                dp.indep_stand_3 AS "indepStand3",
                dp.indep_stand_20 AS "indepStand20",
                dp.one_leg_hand_r AS "oneLegHandR",
                dp.one_leg_hand_l AS "oneLegHandL",
                dp.one_leg_r AS "oneLegR",
                dp.one_leg_l AS "oneLegL",
                dp.short_sit_stand AS "shortSitStand",
                dp.high_knee_stand_r AS "highKneeStandR",
                dp.high_knee_stand_l AS "highKneeStandL",
                dp.lower_floor AS "lowerFloor",
                dp.squats AS "squats",
                dp.stand_pick_pen AS "standPickPen",
                dp.gmfm_mod_a AS "gmfmModA",
                dp.gmfm_mod_b AS "gmfmModB",
                dp.gmfm_mod_c AS "gmfmModC",
                dp.gmfm_mod_e AS "gmfmModE"
            FROM public.visits v
            JOIN public.data_pt dp ON dp.visit_id = v.id
            JOIN public.patients p ON p.id = v.pt_id
            LEFT JOIN public.amb_scale amb ON amb.id = dp.amb_scale
            LEFT JOIN public.fms_list fms5 ON fms5.id = dp.fms_5
            LEFT JOIN public.fms_list fms50 ON fms50.id = dp.fms_50
            LEFT JOIN public.fms_list fms500 ON fms500.id = dp.fms_500
            WHERE v.id = :visitId AND v.pt_id = :patientId
            """, nativeQuery = true)
    java.util.Optional<PtGeneralEvaluationRow> findPtGeneralEvaluationByVisitIdAndPatientId(
            @Param("visitId") Integer visitId,
            @Param("patientId") Integer patientId);

    interface PtGeneralEvaluationRow {
        Integer getDataPtId();

        LocalDate getVisitDate();

        Integer getIcd9();

        LocalDate getDob();

        String getGender();

        Integer getGenDiag();

        Float getHeightCm();

        Float getWeightKg();

        Float getRightFootLengthCm();

        Float getLeftFootLengthCm();

        Float getRightFootWidthCm();

        Float getLeftFootWidthCm();

        Integer getAmbScaleId();

        String getAmbulationScale();

        Integer getGmfcsId();

        Integer getFms5Id();

        String getFms5m();

        String getFms5mDesc();

        Integer getFms50Id();

        String getFms50m();

        String getFms50mDesc();

        Integer getFms500Id();

        String getFms500m();

        String getFms500mDesc();

        String getComments();

        Integer getPullStand();

        Integer getIndepStand3();

        Integer getIndepStand20();

        Integer getOneLegHandR();

        Integer getOneLegHandL();

        Integer getOneLegR();

        Integer getOneLegL();

        Integer getShortSitStand();

        Integer getHighKneeStandR();

        Integer getHighKneeStandL();

        Integer getLowerFloor();

        Integer getSquats();

        Integer getStandPickPen();

        Integer getGmfmModA();

        Integer getGmfmModB();

        Integer getGmfmModC();

        Integer getGmfmModE();
    }

    @Query(value = "SELECT id AS \"id\", label AS \"label\", description AS \"description\" FROM public.gmfcs_list",
            nativeQuery = true)
    List<GmfcsListEntry> findAllGmfcsListEntries();

    interface GmfcsListEntry {
        Integer getId();

        String getLabel();

        String getDescription();
    }

    /** Movement-disorder counterpart of findPtGeneralEvaluationByVisitIdAndPatientId - pt.jsp's
     * isMovementDisorder branch (mainTable=data_pt_movement_disorder), joined with macs_list/
     * cfcs_list the same way pt.jsp's own rsPtAge query does. No GMFM-D task columns - that table
     * has none; Other GMFM Modules and the GMFCS calculation are Gait-only. */
    @Query(value = """
            SELECT
                dp.id AS "dataPtMdId",
                v.date AS "visitDate",
                v.icd9 AS "icd9",
                p.dob AS "dob",
                p.gender AS "gender",
                p.gen_diag AS "genDiag",
                v.height AS "heightCm",
                v.weight AS "weightKg",
                v.r_foot_length AS "rightFootLengthCm",
                v.l_foot_length AS "leftFootLengthCm",
                v.r_foot_width AS "rightFootWidthCm",
                v.l_foot_width AS "leftFootWidthCm",
                dp.amb_scale AS "ambScaleId",
                amb.description AS "ambulationScale",
                dp.gmfcs AS "gmfcsId",
                gmfcs.label AS "gmfcsLabel",
                gmfcs.description AS "gmfcsDesc",
                dp.fms_5 AS "fms5Id",
                fms5.label AS "fms5m",
                fms5.description AS "fms5mDesc",
                dp.fms_50 AS "fms50Id",
                fms50.label AS "fms50m",
                fms50.description AS "fms50mDesc",
                dp.fms_500 AS "fms500Id",
                fms500.label AS "fms500m",
                fms500.description AS "fms500mDesc",
                dp.macs AS "macsId",
                macs.label AS "macsLabel",
                macs.description AS "macsDesc",
                dp.cfcs AS "cfcsId",
                cfcs.label AS "cfcsLabel",
                cfcs.description AS "cfcsDesc",
                dp.comments AS "comments",
                dp.orthoses AS "orthoses"
            FROM public.visits v
            JOIN public.data_pt_movement_disorder dp ON dp.visit_id = v.id
            JOIN public.patients p ON p.id = v.pt_id
            LEFT JOIN public.amb_scale amb ON amb.id = dp.amb_scale
            LEFT JOIN public.gmfcs_list gmfcs ON gmfcs.id = dp.gmfcs
            LEFT JOIN public.fms_list fms5 ON fms5.id = dp.fms_5
            LEFT JOIN public.fms_list fms50 ON fms50.id = dp.fms_50
            LEFT JOIN public.fms_list fms500 ON fms500.id = dp.fms_500
            LEFT JOIN public.macs_list macs ON macs.id = dp.macs
            LEFT JOIN public.cfcs_list cfcs ON cfcs.id = dp.cfcs
            WHERE v.id = :visitId AND v.pt_id = :patientId
            """, nativeQuery = true)
    java.util.Optional<PtGeneralMdEvaluationRow> findPtGeneralMdEvaluationByVisitIdAndPatientId(
            @Param("visitId") Integer visitId,
            @Param("patientId") Integer patientId);

    interface PtGeneralMdEvaluationRow {
        Integer getDataPtMdId();

        LocalDate getVisitDate();

        Integer getIcd9();

        LocalDate getDob();

        String getGender();

        Integer getGenDiag();

        Float getHeightCm();

        Float getWeightKg();

        Float getRightFootLengthCm();

        Float getLeftFootLengthCm();

        Float getRightFootWidthCm();

        Float getLeftFootWidthCm();

        Integer getAmbScaleId();

        String getAmbulationScale();

        Integer getGmfcsId();

        String getGmfcsLabel();

        String getGmfcsDesc();

        Integer getFms5Id();

        String getFms5m();

        String getFms5mDesc();

        Integer getFms50Id();

        String getFms50m();

        String getFms50mDesc();

        Integer getFms500Id();

        String getFms500m();

        String getFms500mDesc();

        Integer getMacsId();

        String getMacsLabel();

        String getMacsDesc();

        Integer getCfcsId();

        String getCfcsLabel();

        String getCfcsDesc();

        String getComments();

        /** pt-eval-orth.jsp's own MD-only "Comments" block - data_pt_movement_disorder.orthoses,
         * nothing to do with the orthoses table/rows above it on the same page. */
        String getOrthoses();
    }

    /** Patient/visit identity fields for the Comparison Report header - eval-report_combined_new
     * .jsp's own pt_info/visit_info queries, the parts that aren't already covered by
     * findPtGeneralEvaluationByVisitIdAndPatientId (name/MRN/therapist/interpreting doctor). */
    @Query(value = """
            SELECT
                p.fname AS "firstName", p.lname AS "lastName", p.mrn AS "mrn",
                p.dob AS "dob", p.gender AS "gender", v.date AS "visitDate",
                therapist.fname AS "therapistFirstName", therapist.lname AS "therapistLastName",
                interpreter.fname AS "interpretingDoctorFirstName",
                interpreter.lname AS "interpretingDoctorLastName"
            FROM public.visits v
            JOIN public.patients p ON p.id = v.pt_id
            LEFT JOIN public.users therapist ON therapist.id = v.visit_pt
            LEFT JOIN public.users interpreter ON interpreter.id = v.interp_md
            WHERE v.id = :visitId AND v.pt_id = :patientId
            """, nativeQuery = true)
    java.util.Optional<ComparisonHeaderRow> findComparisonHeaderByVisitIdAndPatientId(
            @Param("visitId") Integer visitId,
            @Param("patientId") Integer patientId);

    interface ComparisonHeaderRow {
        String getFirstName();

        String getLastName();

        String getMrn();

        LocalDate getDob();

        String getGender();

        LocalDate getVisitDate();

        String getTherapistFirstName();

        String getTherapistLastName();

        String getInterpretingDoctorFirstName();

        String getInterpretingDoctorLastName();
    }
}
