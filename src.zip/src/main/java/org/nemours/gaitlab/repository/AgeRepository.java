package org.nemours.gaitlab.repository;

import org.nemours.gaitlab.model.Age;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AgeRepository extends JpaRepository<Age, String> {
    List<Age> findAllByOrderByChronAsc();

    @Query(value = "SELECT age, age FROM public.ages2 ORDER BY chron", nativeQuery = true)
    List<Object[]> findAllWithSpanish();
}
