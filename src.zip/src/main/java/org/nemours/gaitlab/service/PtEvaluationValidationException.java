package org.nemours.gaitlab.service;

import java.util.Map;

/** Carries field-level validation failures for the PT Evaluation write endpoints, rendered as
 * 400 { "message", "fieldErrors": { name: msg } } by the owning controller. */
public class PtEvaluationValidationException extends RuntimeException {
    private final Map<String, String> fieldErrors;

    public PtEvaluationValidationException(String message, Map<String, String> fieldErrors) {
        super(message);
        this.fieldErrors = fieldErrors;
    }

    public Map<String, String> fieldErrors() {
        return fieldErrors;
    }

    public record Response(String message, Map<String, String> fieldErrors) {
    }
}
