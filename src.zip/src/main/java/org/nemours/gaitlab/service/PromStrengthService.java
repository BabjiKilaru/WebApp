package org.nemours.gaitlab.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.nemours.gaitlab.repository.PtEvaluationRepository;
import org.nemours.gaitlab.service.PtEvaluationForm.Field;
import org.nemours.gaitlab.service.PtEvaluationForm.FormRow;
import org.nemours.gaitlab.service.PtEvaluationForm.FormSection;
import org.nemours.gaitlab.service.PtEvaluationTab.ColumnGroup;
import org.nemours.gaitlab.service.PtEvaluationTab.Row;
import org.nemours.gaitlab.service.PtEvaluationTab.Section;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

/** Ports lab/data/pt-eval-prom.jsp (PROM/Strength tab), Gait visits only. */
@Service
public class PromStrengthService {
    static final String EMPTY_MESSAGE = "No general data has been entered yet for this visit.";

    private final PtEvaluationRepository repository;
    private final PtEvaluationRevision revision;

    public PromStrengthService(PtEvaluationRepository repository, PtEvaluationRevision revision) {
        this.repository = repository;
        this.revision = revision;
    }

    public PtEvaluationTab build(int patientId, int visitId, String tab) {
        return build(patientId, visitId, tab, false);
    }

    /** pt-sections.jsp swaps the backing table to data_movement_disorder_prom for
     * movement-disorder visits - a genuinely different, smaller field set (modify_pt_prom.jsp's
     * own isMovementDisorder branch), not just a different table name for the same columns. */
    public PtEvaluationTab build(int patientId, int visitId, String tab, boolean isMovementDisorder) {
        if (isMovementDisorder) {
            return repository.findMdByVisitId(visitId)
                    .map(row -> PtEvaluationTab.of(patientId, visitId, tab, List.of(buildMdSection(row))))
                    .orElseGet(() -> PtEvaluationTab.empty(patientId, visitId, tab, EMPTY_MESSAGE));
        }
        return repository.findPromByVisitId(visitId)
                .map(row -> PtEvaluationTab.of(patientId, visitId, tab, List.of(buildSection(row))))
                .orElseGet(() -> PtEvaluationTab.empty(patientId, visitId, tab, EMPTY_MESSAGE));
    }

    private Section buildMdSection(Map<String, Object> row) {
        List<ColumnGroup> columnGroups = List.of(
                new ColumnGroup("", 1), new ColumnGroup("PROM", 2), new ColumnGroup("Strength", 2));
        List<String> columns = List.of("", "Right", "Left", "Right", "Left");

        List<Row> rows = new ArrayList<>();
        rows.add(angleRow(row, "Hip Abd", "hip_abd"));
        rows.add(angleRow(row, "Knee Ext", "knee_ext"));
        rows.add(popAngleRow(row));
        rows.add(angleRow(row, "Dorsi (flex)", "dorsi_f"));
        rows.add(angleOnlyRow(row, "Dorsi (ext)", "dorsi_e"));
        rows.add(angleRow(row, "Shoulder Abduction", "shoulder_abduction"));
        rows.add(angleRow(row, "Elbow Extension", "elbow_extension"));
        rows.add(angleRow(row, "Wrist Extension", "wrist_extension"));

        return Section.table(null, columnGroups, columns, rows, null);
    }

    private Section buildSection(Map<String, Object> row) {
        List<ColumnGroup> columnGroups = List.of(
                new ColumnGroup("", 1), new ColumnGroup("PROM", 2), new ColumnGroup("Strength", 2));
        List<String> columns = List.of("", "Right", "Left", "Right", "Left");

        List<Row> rows = new ArrayList<>();
        rows.add(angleRow(row, "Hip Flex", "hip_flex"));
        rows.add(angleRow(row, "Hip Ext", "hip_ext"));
        rows.add(angleRow(row, "Hip Abd", "hip_abd"));
        rows.add(angleOnlyRow(row, "Hip Int Rot", "hip_int_rot"));
        rows.add(angleOnlyRow(row, "Hip Ext Rot", "hip_ext_rot"));
        rows.add(angleOnlyRow(row, "Ryder Test", "ryder_test"));
        rows.add(angleRow(row, "Knee Ext", "knee_ext"));
        rows.add(angleOnlyRow(row, "Extensor Lag", "extensor_lag"));
        rows.add(angleRow(row, "Knee Flex", "knee_flex"));
        rows.add(popAngleRow(row));
        rows.add(angleOnlyRow(row, "Bilateral pop angle", "bilateral_pop"));
        rows.add(angleOnlyRow(row, "Ely Test", "ely"));
        rows.add(angleRow(row, "Dorsi (flex)", "dorsi_f"));
        rows.add(angleOnlyRow(row, "Dorsi (ext)", "dorsi_e"));
        rows.add(angleRow(row, "Plantar", "plantar"));
        rows.add(angleRow(row, "Ankle Inv", "ankle_inv"));
        rows.add(angleRow(row, "Ankle Ever", "ankle_ever"));
        rows.add(textOnlyRow(row, "TMA", "tma"));
        rows.add(textOnlyRow(row, "TFA", "tfa"));
        rows.add(textOnlyRow(row, "FF AB/ADD", "ff_abadd"));
        rows.add(angleOnlyRow(row, "Calcaneal Inv", "calc_inv"));
        rows.add(angleOnlyRow(row, "Calcaneal Ever", "calc_ever"));
        rows.add(new Row("Leg Length (cm)", Arrays.asList(
                PtEvaluationFormat.plainNumberCell(f(row, "leg_length_r")),
                PtEvaluationFormat.plainNumberCell(f(row, "leg_length_l")),
                null, null)));
        rows.add(new Row("Knee Varus/Valgus", Arrays.asList(
                PtEvaluationFormat.signedAngleCell(i(row, "q_angle_r"), s(row, "q_angle_r_interp")),
                PtEvaluationFormat.signedAngleCell(i(row, "q_angle_l"), s(row, "q_angle_l_interp")),
                null, null)));

        return Section.table(null, columnGroups, columns, rows, null);
    }

    /** hip_flex-style row: integer PROM angle on both sides, plus a text strength grade pair. */
    private Row angleRow(Map<String, Object> row, String label, String prefix) {
        String right = PtEvaluationFormat.angleCell(i(row, prefix + "_r"), s(row, prefix + "_r_interp"));
        String left = PtEvaluationFormat.angleCell(i(row, prefix + "_l"), s(row, prefix + "_l_interp"));
        String strengthRight = PtEvaluationFormat.gradeCell(s(row, prefix + "_s_r"), s(row, prefix + "_s_r_interp"));
        String strengthLeft = PtEvaluationFormat.gradeCell(s(row, prefix + "_s_l"), s(row, prefix + "_s_l_interp"));
        return new Row(label, Arrays.asList(right, left, strengthRight, strengthLeft));
    }

    /** Integer-angle row with no strength columns at all (grey filler cells in the legacy page). */
    private Row angleOnlyRow(Map<String, Object> row, String label, String prefix) {
        return new Row(label, Arrays.asList(
                PtEvaluationFormat.angleCell(i(row, prefix + "_r"), s(row, prefix + "_r_interp")),
                PtEvaluationFormat.angleCell(i(row, prefix + "_l"), s(row, prefix + "_l_interp")),
                null, null));
    }

    /** Text-typed PROM column with no strength pair (TMA/TFA/FF AB-ADD are stored as text). */
    private Row textOnlyRow(Map<String, Object> row, String label, String prefix) {
        return new Row(label, Arrays.asList(
                PtEvaluationFormat.gradeCell(s(row, prefix + "_r"), s(row, prefix + "_r_interp")),
                PtEvaluationFormat.gradeCell(s(row, prefix + "_l"), s(row, prefix + "_l_interp")),
                null, null));
    }

    private Row popAngleRow(Map<String, Object> row) {
        return new Row("Pop angle", Arrays.asList(
                PtEvaluationFormat.rangeCell(i(row, "pop_r_low"), i(row, "pop_r_high"), s(row, "pop_r_interp")),
                PtEvaluationFormat.rangeCell(i(row, "pop_l_low"), i(row, "pop_l_high"), s(row, "pop_l_interp")),
                null, null));
    }

    private Integer i(Map<String, Object> row, String key) {
        return (Integer) row.get(key);
    }

    private String s(Map<String, Object> row, String key) {
        Object value = row.get(key);
        return value == null ? null : value.toString();
    }

    private Float f(Map<String, Object> row, String key) {
        Object value = row.get(key);
        if (value == null) {
            return null;
        }
        return value instanceof Float flt ? flt : ((Number) value).floatValue();
    }

    // --- Phase 2: modify_pt_prom.jsp (the PROM/Strength edit form) ---------------------------

    /** One row of modify_pt_prom.jsp's generic PromRow()-style layout (angle + interp both
     * sides, an optional text strength pair, an optional normals reference range) - everything
     * except Pop angle (two values per side, its own section below), Leg Length (no interp, a
     * float not an int) and Knee Varus/Valgus - aka q_angle (a signed int, legacy prefixes "+"
     * for >= 0 - still parses fine since Integer.parseInt accepts a leading '+').
     *
     * <p>numeric gates the "999 = WNL, blank = not tested" validation legacy's onSubmit actually
     * wires up (MM_validateForm's NisNum list) - EXCEPT tma/tfa/ff_abadd, which that same list
     * also names despite being text columns in data_prom (data_prom.tma_r etc. are text, not
     * integer) - a stale copy-paste in legacy's own validator, not something to port literally.
     *
     * <p>hasNormals pulls the reference range from data_prom_normals as this field's `help` -
     * that table is entirely empty in the current seed data, so help is null for everyone until
     * it's seeded; flagged separately, not bent here.
     */
    /** Package-visible (not private) so ComparisonReportService can reuse the exact same field
     * list rather than re-deriving it from the legacy JSP a second time. */
    record PromField(String label, String prefix, boolean numeric, boolean hasStrength,
            boolean hasNormals) {
    }

    static final List<PromField> PROM_FIELDS = List.of(
            new PromField("Hip Flex", "hip_flex", true, true, true),
            new PromField("Hip Ext", "hip_ext", true, true, true),
            new PromField("Hip Abd", "hip_abd", true, true, true),
            new PromField("Hip Int Rot", "hip_int_rot", true, false, true),
            new PromField("Hip Ext Rot", "hip_ext_rot", true, false, true),
            new PromField("Ryder Test", "ryder_test", true, false, true),
            new PromField("Knee Ext", "knee_ext", true, true, true),
            new PromField("Extensor Lag", "extensor_lag", true, false, true),
            new PromField("Knee Flex", "knee_flex", true, true, true),
            new PromField("Bilateral pop angle", "bilateral_pop", true, false, true),
            new PromField("Ely Test", "ely", true, false, true),
            new PromField("Dorsi (flex)", "dorsi_f", true, true, true),
            new PromField("Dorsi (ext)", "dorsi_e", true, false, true),
            new PromField("Plantar", "plantar", true, true, true),
            new PromField("Ankle Inv", "ankle_inv", true, true, true),
            new PromField("Ankle Ever", "ankle_ever", true, true, true),
            new PromField("TMA", "tma", false, false, false),
            new PromField("TFA", "tfa", false, false, false),
            new PromField("FF AB/ADD", "ff_abadd", false, false, false),
            new PromField("Calcaneal Inv", "calc_inv", true, false, true),
            new PromField("Calcaneal Ever", "calc_ever", true, false, true));

    private static final String WNL_HELP = "999 = Within Normal Limits. Leave blank if not tested.";

    /** modify_pt_prom.jsp's isMovementDisorder field list exactly: hip_abd/knee_ext/pop/dorsi_f
     * (all with a strength pair)/dorsi_e (no strength pair), plus the three Upper Extremity
     * items. hasNormals=false throughout - data_prom_normals is entirely empty right now and,
     * even if seeded, modify_pt_prom.jsp's own MD branch never references it the way the Gait
     * branch does, so there's nothing to port here, not an oversight. */
    static final List<PromField> MD_PROM_FIELDS = List.of(
            new PromField("Hip Abd", "hip_abd", true, true, false),
            new PromField("Knee Ext", "knee_ext", true, true, false),
            new PromField("Dorsi (flex)", "dorsi_f", true, true, false),
            new PromField("Dorsi (ext)", "dorsi_e", true, false, false),
            new PromField("Shoulder Abduction", "shoulder_abduction", true, true, false),
            new PromField("Elbow Extension", "elbow_extension", true, true, false),
            new PromField("Wrist Extension", "wrist_extension", true, true, false));

    public PtEvaluationForm buildForm(int visitId) {
        return buildForm(visitId, false);
    }

    public PtEvaluationForm buildForm(int visitId, boolean isMovementDisorder) {
        if (isMovementDisorder) {
            return buildMdForm(visitId);
        }
        Map<String, Object> row = repository.findPromByVisitId(visitId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No PROM/Strength record exists yet for this visit."));
        Map<String, Object> normals = repository.findNormalsForVisit(visitId).orElse(Map.of());

        List<FormRow> promRows = new ArrayList<>();
        List<FormRow> strengthRows = new ArrayList<>();
        for (PromField field : PROM_FIELDS) {
            promRows.add(promRow(row, field, normals));
            if (field.hasStrength()) {
                strengthRows.add(strengthRow(row, field));
            }
        }

        FormSection promSection = FormSection.grid("PROM", List.of("Right", "R Interp", "Left", "L Interp"),
                promRows);
        FormSection strengthSection = FormSection.grid("Strength", List.of("Right", "R Interp", "Left", "L Interp"),
                strengthRows);
        FormSection legLengthSection = FormSection.stack("Leg Length (cm)", List.of(
                Field.text("leg_length_r", "Leg Length (cm) Right", numStr(f(row, "leg_length_r"))),
                Field.text("leg_length_l", "Leg Length (cm) Left", numStr(f(row, "leg_length_l")))));
        FormSection qAngleSection = FormSection.grid("Knee Varus/Valgus", List.of("Right", "R Interp", "Left",
                "L Interp"), List.of(qAngleRow(row, normals)));
        FormSection popAngleSection = FormSection.stack("Pop angle", List.of(
                Field.text("pop_r_low", "Pop angle Right low", idStr(i(row, "pop_r_low"))),
                Field.text("pop_r_high", "Pop angle Right high", idStr(i(row, "pop_r_high"))),
                Field.text("pop_r_interp", "Pop angle Right interp", s(row, "pop_r_interp")),
                Field.text("pop_l_low", "Pop angle Left low", idStr(i(row, "pop_l_low"))),
                Field.text("pop_l_high", "Pop angle Left high", idStr(i(row, "pop_l_high"))),
                Field.text("pop_l_interp", "Pop angle Left interp", s(row, "pop_l_interp"))));

        return new PtEvaluationForm("prom-strength", "Modify PROM & Strength", revision.of(row),
                List.of(promSection, strengthSection, popAngleSection, legLengthSection, qAngleSection));
    }

    private PtEvaluationForm buildMdForm(int visitId) {
        Map<String, Object> row = repository.findMdByVisitId(visitId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No PROM/Strength record exists yet for this visit."));

        List<FormRow> promRows = new ArrayList<>();
        List<FormRow> strengthRows = new ArrayList<>();
        for (PromField field : MD_PROM_FIELDS) {
            promRows.add(promRow(row, field, Map.of()));
            if (field.hasStrength()) {
                strengthRows.add(strengthRow(row, field));
            }
        }

        FormSection promSection = FormSection.grid("PROM", List.of("Right", "R Interp", "Left", "L Interp"),
                promRows);
        FormSection strengthSection = FormSection.grid("Strength", List.of("Right", "R Interp", "Left", "L Interp"),
                strengthRows);
        FormSection popAngleSection = FormSection.stack("Pop angle", List.of(
                Field.text("pop_r_low", "Pop angle Right low", idStr(i(row, "pop_r_low"))),
                Field.text("pop_r_high", "Pop angle Right high", idStr(i(row, "pop_r_high"))),
                Field.text("pop_r_interp", "Pop angle Right interp", s(row, "pop_r_interp")),
                Field.text("pop_l_low", "Pop angle Left low", idStr(i(row, "pop_l_low"))),
                Field.text("pop_l_high", "Pop angle Left high", idStr(i(row, "pop_l_high"))),
                Field.text("pop_l_interp", "Pop angle Left interp", s(row, "pop_l_interp"))));

        return new PtEvaluationForm("prom-strength", "Modify PROM & Strength", revision.of(row),
                List.of(promSection, strengthSection, popAngleSection));
    }

    private FormRow promRow(Map<String, Object> row, PromField field, Map<String, Object> normals) {
        String help = field.hasNormals() ? normalsHelp(normals, field.prefix()) : null;
        Field right = field.numeric()
                ? numberFieldWithHelp(field.prefix() + "_r", field.label() + " Right", idStr(i(row, field.prefix() + "_r")), help)
                : Field.text(field.prefix() + "_r", field.label() + " Right", s(row, field.prefix() + "_r"));
        Field rightInterp = Field.text(field.prefix() + "_r_interp", field.label() + " R Interp",
                s(row, field.prefix() + "_r_interp"));
        Field left = field.numeric()
                ? numberFieldWithHelp(field.prefix() + "_l", field.label() + " Left", idStr(i(row, field.prefix() + "_l")), help)
                : Field.text(field.prefix() + "_l", field.label() + " Left", s(row, field.prefix() + "_l"));
        Field leftInterp = Field.text(field.prefix() + "_l_interp", field.label() + " L Interp",
                s(row, field.prefix() + "_l_interp"));
        return new FormRow(field.label(), Arrays.asList(right, rightInterp, left, leftInterp));
    }

    private FormRow strengthRow(Map<String, Object> row, PromField field) {
        String prefix = field.prefix() + "_s";
        Field right = Field.text(prefix + "_r", field.label() + " Strength Right", s(row, prefix + "_r"));
        Field rightInterp = Field.text(prefix + "_r_interp", field.label() + " Strength R Interp",
                s(row, prefix + "_r_interp"));
        Field left = Field.text(prefix + "_l", field.label() + " Strength Left", s(row, prefix + "_l"));
        Field leftInterp = Field.text(prefix + "_l_interp", field.label() + " Strength L Interp",
                s(row, prefix + "_l_interp"));
        return new FormRow(field.label(), Arrays.asList(right, rightInterp, left, leftInterp));
    }

    private FormRow qAngleRow(Map<String, Object> row, Map<String, Object> normals) {
        String help = normalsHelp(normals, "q_angle");
        Field right = numberFieldWithHelp("q_angle_r", "Knee Varus/Valgus Right",
                signedIdStr(i(row, "q_angle_r")), help);
        Field rightInterp = Field.text("q_angle_r_interp", "Knee Varus/Valgus R Interp", s(row, "q_angle_r_interp"));
        Field left = numberFieldWithHelp("q_angle_l", "Knee Varus/Valgus Left",
                signedIdStr(i(row, "q_angle_l")), help);
        Field leftInterp = Field.text("q_angle_l_interp", "Knee Varus/Valgus L Interp", s(row, "q_angle_l_interp"));
        return new FormRow("Knee Varus/Valgus", Arrays.asList(right, rightInterp, left, leftInterp));
    }

    private static Field numberFieldWithHelp(String name, String label, String value, String help) {
        return new Field(name, label, "number", value, null, false, null, null, null, null,
                help == null ? WNL_HELP : help + ". " + WNL_HELP);
    }

    /** "{mean - sd} - {mean + sd}", one decimal place, matching modify_pt_prom.jsp's own
     * NumberFormat (max 1 fraction digit, no grouping). null when this bucket's row is missing
     * the field's mean/sd pair - true for every field right now, since data_prom_normals has no
     * rows at all in the current seed data. */
    private static String normalsHelp(Map<String, Object> normals, String prefix) {
        Object mean = normals.get(prefix);
        Object sd = normals.get(prefix + "_sd");
        if (!(mean instanceof Number meanNumber) || !(sd instanceof Number sdNumber)) {
            return null;
        }
        float min = meanNumber.floatValue() - sdNumber.floatValue();
        float max = meanNumber.floatValue() + sdNumber.floatValue();
        return "Normal range: " + oneDecimal(min) + " - " + oneDecimal(max);
    }

    private static String oneDecimal(float value) {
        return new java.text.DecimalFormat("0.#").format(value);
    }

    private static String idStr(Integer value) {
        return value == null ? null : String.valueOf(value);
    }

    private static String numStr(Float value) {
        return value == null ? null : String.valueOf(value);
    }

    /** Legacy prefixes a "+" for a non-negative q_angle so the sign is always visible - kept for
     * fidelity; Integer.parseInt happily accepts a leading '+' back on save. */
    private static String signedIdStr(Integer value) {
        if (value == null) {
            return null;
        }
        return value >= 0 ? "+" + value : String.valueOf(value);
    }

    @Transactional
    public PtEvaluationTab save(int patientId, int visitId, String submittedRevision, Map<String, Object> values) {
        return save(patientId, visitId, submittedRevision, values, false);
    }

    @Transactional
    public PtEvaluationTab save(int patientId, int visitId, String submittedRevision, Map<String, Object> values,
            boolean isMovementDisorder) {
        if (isMovementDisorder) {
            return saveMd(patientId, visitId, submittedRevision, values);
        }
        Map<String, Object> row = repository.findPromByVisitId(visitId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No PROM/Strength record exists yet for this visit."));
        if (!revision.of(row).equals(submittedRevision)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "This data has changed since you loaded it. Reload and try again.");
        }

        Map<String, String> errors = new LinkedHashMap<>();
        Map<String, Object> columns = new LinkedHashMap<>();

        for (PromField field : PROM_FIELDS) {
            putFieldColumns(columns, errors, values, row, field);
        }

        columns.put("leg_length_r", resolveFloat(values, "leg_length_r", f(row, "leg_length_r"), errors));
        columns.put("leg_length_l", resolveFloat(values, "leg_length_l", f(row, "leg_length_l"), errors));
        putPopAngleColumns(columns, errors, values, row);
        columns.put("q_angle_r", resolveInt(values, "q_angle_r", (Integer) row.get("q_angle_r"), errors));
        columns.put("q_angle_r_interp", resolveText(values, "q_angle_r_interp", s(row, "q_angle_r_interp")));
        columns.put("q_angle_l", resolveInt(values, "q_angle_l", (Integer) row.get("q_angle_l"), errors));
        columns.put("q_angle_l_interp", resolveText(values, "q_angle_l_interp", s(row, "q_angle_l_interp")));

        if (!errors.isEmpty()) {
            throw new PtEvaluationValidationException("Some PROM/Strength fields are invalid.", errors);
        }

        repository.update((Integer) row.get("id"), columns);
        return build(patientId, visitId, "prom-strength");
    }

    private PtEvaluationTab saveMd(int patientId, int visitId, String submittedRevision,
            Map<String, Object> values) {
        Map<String, Object> row = repository.findMdByVisitId(visitId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No PROM/Strength record exists yet for this visit."));
        if (!revision.of(row).equals(submittedRevision)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "This data has changed since you loaded it. Reload and try again.");
        }

        Map<String, String> errors = new LinkedHashMap<>();
        Map<String, Object> columns = new LinkedHashMap<>();
        for (PromField field : MD_PROM_FIELDS) {
            putFieldColumns(columns, errors, values, row, field);
        }
        putPopAngleColumns(columns, errors, values, row);

        if (!errors.isEmpty()) {
            throw new PtEvaluationValidationException("Some PROM/Strength fields are invalid.", errors);
        }

        repository.updateMd((Integer) row.get("id"), columns);
        return build(patientId, visitId, "prom-strength", true);
    }

    private void putFieldColumns(Map<String, Object> columns, Map<String, String> errors, Map<String, Object> values,
            Map<String, Object> row, PromField field) {
        if (field.numeric()) {
            columns.put(field.prefix() + "_r", resolveInt(values, field.prefix() + "_r", (Integer) row.get(field.prefix() + "_r"), errors));
            columns.put(field.prefix() + "_l", resolveInt(values, field.prefix() + "_l", (Integer) row.get(field.prefix() + "_l"), errors));
        } else {
            columns.put(field.prefix() + "_r", resolveText(values, field.prefix() + "_r", s(row, field.prefix() + "_r")));
            columns.put(field.prefix() + "_l", resolveText(values, field.prefix() + "_l", s(row, field.prefix() + "_l")));
        }
        columns.put(field.prefix() + "_r_interp",
                resolveText(values, field.prefix() + "_r_interp", s(row, field.prefix() + "_r_interp")));
        columns.put(field.prefix() + "_l_interp",
                resolveText(values, field.prefix() + "_l_interp", s(row, field.prefix() + "_l_interp")));
        if (field.hasStrength()) {
            String sPrefix = field.prefix() + "_s";
            columns.put(sPrefix + "_r", resolveText(values, sPrefix + "_r", s(row, sPrefix + "_r")));
            columns.put(sPrefix + "_r_interp", resolveText(values, sPrefix + "_r_interp", s(row, sPrefix + "_r_interp")));
            columns.put(sPrefix + "_l", resolveText(values, sPrefix + "_l", s(row, sPrefix + "_l")));
            columns.put(sPrefix + "_l_interp", resolveText(values, sPrefix + "_l_interp", s(row, sPrefix + "_l_interp")));
        }
    }

    private void putPopAngleColumns(Map<String, Object> columns, Map<String, String> errors,
            Map<String, Object> values, Map<String, Object> row) {
        columns.put("pop_r_low", resolveInt(values, "pop_r_low", (Integer) row.get("pop_r_low"), errors));
        columns.put("pop_r_high", resolveInt(values, "pop_r_high", (Integer) row.get("pop_r_high"), errors));
        columns.put("pop_r_interp", resolveText(values, "pop_r_interp", s(row, "pop_r_interp")));
        columns.put("pop_l_low", resolveInt(values, "pop_l_low", (Integer) row.get("pop_l_low"), errors));
        columns.put("pop_l_high", resolveInt(values, "pop_l_high", (Integer) row.get("pop_l_high"), errors));
        columns.put("pop_l_interp", resolveText(values, "pop_l_interp", s(row, "pop_l_interp")));
    }

    private static String resolveText(Map<String, Object> values, String key, String currentValue) {
        if (!values.containsKey(key)) {
            return currentValue;
        }
        Object raw = values.get(key);
        String submitted = raw == null ? null : raw.toString();
        return (submitted == null || submitted.isEmpty()) ? null : submitted;
    }

    private static Integer resolveInt(Map<String, Object> values, String key, Integer currentValue,
            Map<String, String> errors) {
        if (!values.containsKey(key)) {
            return currentValue;
        }
        Object raw = values.get(key);
        String submitted = raw == null ? null : raw.toString();
        if (submitted == null || submitted.isEmpty()) {
            return null;
        }
        try {
            return Integer.parseInt(submitted);
        } catch (NumberFormatException e) {
            errors.put(key, "Must be a whole number (999 = Within Normal Limits).");
            return currentValue;
        }
    }

    private static Float resolveFloat(Map<String, Object> values, String key, Float currentValue,
            Map<String, String> errors) {
        if (!values.containsKey(key)) {
            return currentValue;
        }
        Object raw = values.get(key);
        String submitted = raw == null ? null : raw.toString();
        if (submitted == null || submitted.isEmpty()) {
            return null;
        }
        try {
            return Float.parseFloat(submitted);
        } catch (NumberFormatException e) {
            errors.put(key, "Must be a number.");
            return currentValue;
        }
    }

    public PtEvaluationTab createRecord(int patientId, int visitId) {
        return createRecord(patientId, visitId, false);
    }

    public PtEvaluationTab createRecord(int patientId, int visitId, boolean isMovementDisorder) {
        if (isMovementDisorder) {
            if (repository.findMdByVisitId(visitId).isPresent()) {
                throw new ResponseStatusException(HttpStatus.CONFLICT,
                        "PROM/Strength data already exists for this visit.");
            }
            repository.insertBlankMd(visitId);
            return build(patientId, visitId, "prom-strength", true);
        }
        if (repository.findPromByVisitId(visitId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "PROM/Strength data already exists for this visit.");
        }
        repository.insertBlank(visitId);
        return build(patientId, visitId, "prom-strength");
    }
}
