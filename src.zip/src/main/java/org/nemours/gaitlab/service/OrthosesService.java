package org.nemours.gaitlab.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.nemours.gaitlab.repository.PtEvaluationRepository;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.repository.VisitRepository.PtGeneralMdEvaluationRow;
import org.nemours.gaitlab.service.PtEvaluationForm.Field;
import org.nemours.gaitlab.service.PtEvaluationForm.FormSection;
import org.nemours.gaitlab.service.PtEvaluationForm.Option;
import org.nemours.gaitlab.service.PtEvaluationTab.Row;
import org.nemours.gaitlab.service.PtEvaluationTab.RowActions;
import org.nemours.gaitlab.service.PtEvaluationTab.Section;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

/** Ports lab/data/pt-eval-orth.jsp's orthoses list and insert_orth.jsp/modify_orth.jsp/
 * delete_orth.jsp. Unlike the other tabs, the legacy page shows no text at all when there is no
 * data - just an empty page - so emptyMessage is null here rather than a copied legacy string.
 * Each row's edit/delete icons are admin-only in legacy (same flag, not independently gated), so
 * both RowActions booleans mirror isAdmin - enforced again at the write endpoints themselves,
 * since legacy's own insert/modify/delete pages have no check beyond being on the
 * admin-restricted page in the first place.
 *
 * <p>Movement-disorder visits add a "Comments" block below the (shared) orthoses list -
 * data_pt_movement_disorder.orthoses, a free-text textarea with no admin gate on viewing/editing
 * it, only on creating the record in the first place (pt-eval-orth.jsp:206-228). It's the exact
 * same data_pt_movement_disorder row general-md/record creates, so this reuses
 * VisitRepository/PtEvaluationRepository directly rather than re-deriving that existence check. */
@Service
public class OrthosesService {
    private static final List<Option> SIDE_OPTIONS = List.of(
            new Option("Left", "Left"), new Option("Right", "Right"), new Option("Both", "Both"));
    private static final List<String> VALID_SIDES = List.of("", "Left", "Right", "Both");

    private final PtEvaluationRepository repository;
    private final VisitRepository visits;
    private final PtEvaluationRevision revision;

    public OrthosesService(PtEvaluationRepository repository, VisitRepository visits,
            PtEvaluationRevision revision) {
        this.repository = repository;
        this.visits = visits;
        this.revision = revision;
    }

    public PtEvaluationTab build(int patientId, int visitId, String tab, boolean isAdmin) {
        return build(patientId, visitId, tab, isAdmin, false);
    }

    public PtEvaluationTab build(int patientId, int visitId, String tab, boolean isAdmin,
            boolean isMovementDisorder) {
        List<Map<String, Object>> orthoses = repository.findOrthosesByVisitId(visitId);
        if (!isMovementDisorder) {
            if (orthoses.isEmpty()) {
                return PtEvaluationTab.empty(patientId, visitId, tab, null);
            }
            return PtEvaluationTab.of(patientId, visitId, tab, List.of(orthosesSection(orthoses, isAdmin)));
        }

        Optional<PtGeneralMdEvaluationRow> mdRow = findMdRow(patientId, visitId);
        if (orthoses.isEmpty() && mdRow.isEmpty()) {
            return PtEvaluationTab.empty(patientId, visitId, tab, null);
        }
        List<Section> sections = new ArrayList<>();
        if (!orthoses.isEmpty()) {
            sections.add(orthosesSection(orthoses, isAdmin));
        }
        sections.add(Section.text("Comments", mdRow.map(PtGeneralMdEvaluationRow::getOrthoses).orElse(null)));
        return PtEvaluationTab.of(patientId, visitId, tab, sections);
    }

    private Optional<PtGeneralMdEvaluationRow> findMdRow(int patientId, int visitId) {
        return visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(visitId, patientId);
    }

    private Section orthosesSection(List<Map<String, Object>> orthoses, boolean isAdmin) {
        RowActions rowActions = new RowActions(isAdmin, isAdmin);
        List<Row> rows = orthoses.stream()
                .map(o -> new Row((String) o.get("orthosis"), Arrays.asList((String) o.get("side")),
                        List.of(), (Integer) o.get("id"), rowActions))
                .toList();
        return Section.table(null, null, List.of("Orthoses", "Side"), rows, null);
    }

    /** true only for movement-disorder visits where the data_pt_movement_disorder row already
     * exists - the Comments textarea/Save is visible and editable by anyone once that's true, no
     * admin gate (pt-eval-orth.jsp:217-227). */
    public boolean commentsEditable(int patientId, int visitId) {
        return findMdRow(patientId, visitId).isPresent();
    }

    /** admin-only, and only when no data_pt_movement_disorder row exists yet - matches the
     * Create New Record button's own gate on that same block. */
    public boolean commentsCreatable(int patientId, int visitId, boolean isAdmin) {
        return isAdmin && findMdRow(patientId, visitId).isEmpty();
    }

    public PtEvaluationForm buildCommentsForm(int patientId, int visitId) {
        PtGeneralMdEvaluationRow row = findMdRow(patientId, visitId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No general record exists yet for this visit."));
        Field orthoses = Field.textarea("orthoses", "Comments", row.getOrthoses());
        return new PtEvaluationForm("orthotics", "Comments", revision.of(row.getOrthoses()),
                List.of(FormSection.stack(null, List.of(orthoses))));
    }

    @Transactional
    public PtEvaluationTab saveComments(int patientId, int visitId, String submittedRevision,
            Map<String, Object> values) {
        PtGeneralMdEvaluationRow row = findMdRow(patientId, visitId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No general record exists yet for this visit."));
        if (!revision.of(row.getOrthoses()).equals(submittedRevision)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "This data has changed since you loaded it. Reload and try again.");
        }
        Object raw = values.get("orthoses");
        String orthoses = raw == null ? null : raw.toString();
        repository.updateMovementDisorderOrthosesComment(row.getDataPtMdId(), orthoses == null || orthoses.isEmpty() ? null
                : orthoses);
        return build(patientId, visitId, "orthotics", true, true);
    }

    /** Creates the same data_pt_movement_disorder row general-md/record does - they're the same
     * row, just reached from a different tab. */
    public PtEvaluationTab createCommentsRecord(int patientId, int visitId) {
        if (findMdRow(patientId, visitId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "General data already exists for this visit.");
        }
        repository.insertBlankDataPtMovementDisorder(visitId);
        return build(patientId, visitId, "orthotics", true, true);
    }

    /** No prior state exists for a brand-new orthosis, so the revision is just a fixed marker
     * for this visit rather than a hash of real data - it still round-trips through the same
     * {revision, values} contract as every other save, it just never legitimately conflicts. */
    public PtEvaluationForm buildNewForm(int visitId) {
        Field orthosis = requiredOrthosisField(null, repository.findOrthosisOptions());
        Field side = new Field("side", "Side", "radio", null, SIDE_OPTIONS, false, null, null, null, null, null);
        FormSection section = FormSection.stack(null, List.of(orthosis, side));
        return new PtEvaluationForm("orthotics", "Add Orthosis to Visit", revision.of("new:" + visitId),
                List.of(section));
    }

    public PtEvaluationForm buildEditForm(int visitId, int id) {
        Map<String, Object> row = repository.findByIdAndVisitId(id, visitId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        Field orthosis = requiredOrthosisField((String) row.get("orthosis"), repository.findOrthosisOptions());
        Field side = new Field("side", "Side", "radio", row.get("side"), SIDE_OPTIONS, false, null, null, null,
                null, null);
        FormSection section = FormSection.stack(null, List.of(orthosis, side));
        return new PtEvaluationForm("orthotics", "Modify Patient Orthosis", revision.of(row), List.of(section));
    }

    /** required: true, since the server already 400s on a blank orthosis - legacy's select has
     * no blank option either (insert_orth.jsp/modify_orth.jsp). Includes the current value even
     * when it isn't in the lookup, the same fallback used for Motor Control/Tone's Interp
     * dropdowns, so an edit never shows a blank select for a legitimately stored value. */
    private static Field requiredOrthosisField(String currentValue, List<String> lookupValues) {
        List<Option> options = new ArrayList<>();
        for (String value : lookupValues) {
            options.add(new Option(value, value));
        }
        if (currentValue != null && !currentValue.isEmpty() && !lookupValues.contains(currentValue)) {
            options.add(new Option(currentValue, currentValue));
        }
        return new Field("orthosis", "Orthosis", "select", currentValue, options, true, null, null, null, null,
                null);
    }

    public PtEvaluationTab createOrthosis(int patientId, int visitId, boolean isAdmin, String submittedRevision,
            Map<String, Object> values) {
        if (!revision.of("new:" + visitId).equals(submittedRevision)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "This form is stale. Reload and try again.");
        }
        String orthosis = validated(values, null);
        String side = validatedSide(values);
        repository.insert(visitId, orthosis, side);
        return build(patientId, visitId, "orthotics", isAdmin);
    }

    public PtEvaluationTab updateOrthosis(int patientId, int visitId, int id, boolean isAdmin,
            String submittedRevision, Map<String, Object> values) {
        Map<String, Object> row = repository.findByIdAndVisitId(id, visitId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        if (!revision.of(row).equals(submittedRevision)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "This data has changed since you loaded it. Reload and try again.");
        }
        String orthosis = validated(values, (String) row.get("orthosis"));
        String side = validatedSide(values);
        repository.update(id, visitId, orthosis, side);
        return build(patientId, visitId, "orthotics", isAdmin);
    }

    /** Must be a real orthoses.orthosis value - legacy's select is select-only, no free text
     * (insert_orth.jsp:221, modify_orth.jsp:224). On an edit, the row's own pre-existing value is
     * also accepted even if it predates the lookup table, so an unrelated save doesn't fail on
     * data this port didn't create. */
    private String validated(Map<String, Object> values, String existingValue) {
        Object raw = values.get("orthosis");
        String orthosis = raw == null ? null : raw.toString();
        if (orthosis == null || orthosis.isBlank()) {
            throw new PtEvaluationValidationException("An orthosis is required.",
                    Map.of("orthosis", "An orthosis is required."));
        }
        if (!orthosis.equals(existingValue) && !repository.findOrthosisOptions().contains(orthosis)) {
            throw new PtEvaluationValidationException("Unknown orthosis.",
                    Map.of("orthosis", "Must be one of the listed orthoses."));
        }
        return orthosis;
    }

    private static String validatedSide(Map<String, Object> values) {
        Object raw = values.get("side");
        String side = raw == null ? "" : raw.toString();
        if (!VALID_SIDES.contains(side)) {
            throw new PtEvaluationValidationException("Invalid side.", Map.of("side", "Must be Left, Right, or Both."));
        }
        return side;
    }

    public PtEvaluationTab deleteOrthosis(int patientId, int visitId, int id, boolean isAdmin) {
        repository.findByIdAndVisitId(id, visitId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        repository.deleteByIdAndVisitId(id, visitId);
        return build(patientId, visitId, "orthotics", isAdmin);
    }
}
