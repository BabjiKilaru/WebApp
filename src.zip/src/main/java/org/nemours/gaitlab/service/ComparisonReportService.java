package org.nemours.gaitlab.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.nemours.gaitlab.repository.PtEvaluationRepository;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.repository.VisitRepository.ComparisonHeaderRow;
import org.nemours.gaitlab.repository.VisitRepository.PtGeneralEvaluationRow;
import org.nemours.gaitlab.service.ComparisonReport.HeaderEntry;
import org.nemours.gaitlab.service.PtEvaluationService.General;
import org.nemours.gaitlab.service.PtEvaluationService.GeneralEvaluation;
import org.nemours.gaitlab.service.PtEvaluationService.GmfmModule;
import org.nemours.gaitlab.service.PromStrengthService.PromField;
import org.nemours.gaitlab.service.PtEvaluationTab.ColumnGroup;
import org.nemours.gaitlab.service.PtEvaluationTab.Row;
import org.nemours.gaitlab.service.PtEvaluationTab.Section;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

/**
 * Ports lab/reports/eval-report_combined_new.jsp (+ its _p2.jsp continuation and
 * comp_report-gmfm_gmfcs.jsp include) - pt.jsp's "View Printable Comparison Report" button.
 * Up to 3 visits side by side: the current one plus two legacy sources from session state
 * (VisitComparisonDatesHelper, set by a visit-picker UI this port doesn't have access to) - here
 * exposed as the compareVisitId1/compareVisitId2 query params the write-endpoint spec asked for.
 * Gait (non-movement-disorder) visits only.
 *
 * <p>Reuses the already-ported PtEvaluationService.getGeneral() for Ambulation Scale/GMFCS/FMS/
 * Total GMFM Score (all three are exactly the same formatted strings as the General tab, just
 * read once per compared visit) rather than re-deriving that logic a second time.
 */
@Service
public class ComparisonReportService {
    private final VisitRepository visits;
    private final PtEvaluationService generalService;
    private final PtEvaluationRepository repository;

    public ComparisonReportService(VisitRepository visits, PtEvaluationService generalService,
            PtEvaluationRepository repository) {
        this.visits = visits;
        this.generalService = generalService;
        this.repository = repository;
    }

    public ComparisonReport build(int patientId, int visitId, Integer compareVisitId1, Integer compareVisitId2) {
        visits.findInterpretationVisitByIdAndPatientId(visitId, patientId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

        List<Integer> visitIds = new ArrayList<>();
        visitIds.add(visitId);
        if (compareVisitId1 != null) {
            visitIds.add(compareVisitId1);
        }
        if (compareVisitId2 != null) {
            visitIds.add(compareVisitId2);
        }

        // p1VisitDate/p2VisitDate (eval-report_combined_new.jsp lines 138-139) plus the current
        // visit's own date - the column-group label legacy prints per compared visit, not a
        // synthetic "Visit N" placeholder.
        List<String> visitLabels = visitIds.stream()
                .map(vid -> visitDateLabel(vid, patientId))
                .toList();

        List<Optional<PtGeneralEvaluationRow>> rawGeneralByVisit = visitIds.stream()
                .map(vid -> visits.findPtGeneralEvaluationByVisitIdAndPatientId(vid, patientId))
                .toList();
        // getGeneral() 404s on a compare visit that doesn't belong to this patient - the same
        // boundary this port enforces everywhere else, tighter than legacy's MRN-based match.
        List<GeneralEvaluation> generalByVisit = visitIds.stream()
                .map(vid -> generalService.getGeneral(patientId, vid))
                .toList();
        List<Optional<Map<String, Object>>> promByVisit = visitIds.stream()
                .map(repository::findPromByVisitId)
                .toList();
        List<List<Map<String, Object>>> mcByVisit = visitIds.stream()
                .map(repository::findMotorControlByVisitId)
                .toList();
        List<List<Map<String, Object>>> toneByVisit = visitIds.stream()
                .map(repository::findToneByVisitId)
                .toList();

        List<Integer> promIdx = indicesWithData(promByVisit, Optional::isPresent);
        List<Integer> mcIdx = indicesWithData(mcByVisit, list -> !list.isEmpty());
        List<Integer> toneIdx = indicesWithData(toneByVisit, list -> !list.isEmpty());
        List<Integer> generalIdx = indicesWithData(rawGeneralByVisit, Optional::isPresent);

        List<Section> sections = new ArrayList<>();
        if (!promIdx.isEmpty()) {
            sections.add(promOrStrengthSection("Passive ROM", promByVisit, promIdx, visitLabels, false));
            List<Integer> strengthIdx = promIdx; // same visits; a visit with any PROM row has the strength columns too
            sections.add(promOrStrengthSection("Strength", promByVisit, strengthIdx, visitLabels, true));
            sections.add(legLengthSection(promByVisit, promIdx, visitLabels));
            sections.add(qAngleSection(promByVisit, promIdx, visitLabels));
            sections.add(popAngleSection(promByVisit, promIdx, visitLabels));
        }
        if (!mcIdx.isEmpty()) {
            sections.add(motorControlOrToneSection("Motor Control", mcByVisit, mcIdx, visitLabels));
        }
        if (!toneIdx.isEmpty()) {
            sections.add(motorControlOrToneSection("Tone", toneByVisit, toneIdx, visitLabels));
        }
        if (!generalIdx.isEmpty()) {
            sections.add(gmfmDSection(rawGeneralByVisit, generalIdx, visitLabels));
            Section mobility = mobilityScalesSection(generalByVisit, generalIdx, visitLabels);
            if (mobility != null) {
                sections.add(mobility);
            }
        }
        if (!rawGeneralByVisit.get(0).isEmpty()) {
            sections.add(otherGmfmModulesSection(rawGeneralByVisit.get(0).get()));
        }
        sections.add(notesSection(generalByVisit.get(0).general(), rawGeneralByVisit.get(0).isPresent()));

        return new ComparisonReport("Physical Therapy Evaluation - Comparison Report",
                header(patientId, visitId, generalByVisit.get(0).general()), sections);
    }

    /** The exact "M/d/yy"-style text legacy prints for a visit date (DoDateTime(date,
     * DateFormat.SHORT, null)) - falls back to the visit id if the visit somehow has no date. */
    private String visitDateLabel(int visitId, int patientId) {
        return visits.findVideoVisitDateByIdAndPatientId(visitId, patientId)
                .map(VisitRepository.VideoVisitDate::getVisitDate)
                .filter(java.util.Objects::nonNull)
                .map(text -> formatShortDate(LocalDate.parse(text)))
                .orElse("Visit " + visitId);
    }

    private static final DateTimeFormatter SHORT_DATE = DateTimeFormatter.ofPattern("M/d/yy");

    private static String formatShortDate(LocalDate date) {
        return date == null ? null : date.format(SHORT_DATE);
    }

    private <T> List<Integer> indicesWithData(List<T> perVisit, java.util.function.Predicate<T> hasData) {
        List<Integer> indices = new ArrayList<>();
        for (int i = 0; i < perVisit.size(); i++) {
            if (hasData.test(perVisit.get(i))) {
                indices.add(i);
            }
        }
        return indices;
    }

    /** Matches eval-report_combined_new.jsp's header table (lines ~480-521) field-for-field:
     * Name, then MRN/Height/Date of Eval, DOB/Weight/Doctor(interp), Age at Eval/Gender/Therapist
     * - read left-to-right, top-to-bottom. */
    private List<ComparisonReport.HeaderEntry> header(int patientId, int visitId, General general) {
        ComparisonHeaderRow row = visits.findComparisonHeaderByVisitIdAndPatientId(visitId, patientId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        List<HeaderEntry> header = new ArrayList<>();
        header.add(new HeaderEntry("Name", join(row.getFirstName(), row.getLastName())));
        header.add(new HeaderEntry("MRN", row.getMrn()));
        header.add(new HeaderEntry("Height (cm)", numStr(general.heightCm())));
        header.add(new HeaderEntry("Date of Eval", formatShortDate(row.getVisitDate())));
        header.add(new HeaderEntry("Date of Birth", formatShortDate(row.getDob())));
        header.add(new HeaderEntry("Weight (kg)", numStr(general.weightKg())));
        header.add(new HeaderEntry("Doctor (interp)",
                join(row.getInterpretingDoctorFirstName(), row.getInterpretingDoctorLastName())));
        header.add(new HeaderEntry("Age at Eval", ageAtEval(row.getDob(), row.getVisitDate())));
        header.add(new HeaderEntry("Gender", row.getGender()));
        header.add(new HeaderEntry("Therapist", join(row.getTherapistFirstName(), row.getTherapistLastName())));
        return header;
    }

    /** Ported verbatim from the legacy page's own client-side age formula (not a true elapsed-time
     * calculation): age = (visitYear - dobYear) + (monthDiff/12) + (dayDiff/365), to 2 decimals. */
    private static String ageAtEval(LocalDate dob, LocalDate visitDate) {
        if (dob == null || visitDate == null) {
            return null;
        }
        double age = (visitDate.getYear() - dob.getYear())
                + ((visitDate.getMonthValue() - dob.getMonthValue()) / 12.0)
                + ((visitDate.getDayOfMonth() - dob.getDayOfMonth()) / 365.0);
        return String.format("%.2f", age);
    }

    private static String join(String first, String last) {
        String combined = ((first == null ? "" : first) + " " + (last == null ? "" : last)).trim();
        return combined.isEmpty() ? null : combined;
    }

    private static String numStr(Float value) {
        return value == null ? null : String.valueOf(value);
    }

    /** "999" -> "WNL", matching every cell in eval-report_combined_new.jsp's PROM/Strength
     * tables - this report never shows the interp code the way the PROM/Strength tab view does,
     * just the raw value. */
    private static String wnlCell(Object raw) {
        if (raw == null) {
            return null;
        }
        return "999".equals(raw.toString()) ? "WNL" : raw.toString();
    }

    private Section promOrStrengthSection(String title, List<Optional<Map<String, Object>>> promByVisit,
            List<Integer> visitIdx, List<String> visitLabels, boolean strength) {
        List<ColumnGroup> columnGroups = new ArrayList<>();
        List<String> columns = new ArrayList<>();
        columnGroups.add(new ColumnGroup("", 1));
        columns.add("");
        for (int i : visitIdx) {
            columnGroups.add(new ColumnGroup(visitLabels.get(i), 2));
            columns.add("Right");
            columns.add("Left");
        }

        List<Row> rows = new ArrayList<>();
        for (PromField field : PromStrengthService.PROM_FIELDS) {
            if (strength && !field.hasStrength()) {
                continue;
            }
            String suffix = strength ? "_s" : "";
            List<String> cells = new ArrayList<>();
            for (int i : visitIdx) {
                Map<String, Object> row = promByVisit.get(i).orElse(Map.of());
                cells.add(wnlCell(row.get(field.prefix() + suffix + "_r")));
                cells.add(wnlCell(row.get(field.prefix() + suffix + "_l")));
            }
            rows.add(new Row(field.label(), cells));
        }
        return Section.table(title, columnGroups, columns, rows, null);
    }

    private Section legLengthSection(List<Optional<Map<String, Object>>> promByVisit, List<Integer> visitIdx,
            List<String> visitLabels) {
        List<ColumnGroup> columnGroups = new ArrayList<>();
        List<String> columns = new ArrayList<>();
        List<String> cells = new ArrayList<>();
        columnGroups.add(new ColumnGroup("", 1));
        columns.add("");
        for (int i : visitIdx) {
            columnGroups.add(new ColumnGroup(visitLabels.get(i), 2));
            columns.add("Right");
            columns.add("Left");
            Map<String, Object> row = promByVisit.get(i).orElse(Map.of());
            cells.add(wnlCell(row.get("leg_length_r")));
            cells.add(wnlCell(row.get("leg_length_l")));
        }
        return Section.table("Leg Length (cm)", columnGroups, columns,
                List.of(new Row("Leg Length (cm)", cells)), null);
    }

    /** "{value} Valgus" (positive) / "{|value|} Varus" (negative) - the Comparison Report's own
     * wording, different from the "+"/"-" sign prefix modify_pt_prom.jsp and the PROM/Strength
     * tab use for the same q_angle_r/l columns. Ported as its own distinct format, not bent to
     * match the other two. */
    private static String qAngleCell(Object raw) {
        if (raw == null) {
            return null;
        }
        if ("999".equals(raw.toString())) {
            return "WNL";
        }
        int value = Integer.parseInt(raw.toString());
        return value > 0 ? value + " Valgus" : (value * -1) + " Varus";
    }

    private Section qAngleSection(List<Optional<Map<String, Object>>> promByVisit, List<Integer> visitIdx,
            List<String> visitLabels) {
        List<ColumnGroup> columnGroups = new ArrayList<>();
        List<String> columns = new ArrayList<>();
        List<String> cells = new ArrayList<>();
        columnGroups.add(new ColumnGroup("", 1));
        columns.add("");
        for (int i : visitIdx) {
            columnGroups.add(new ColumnGroup(visitLabels.get(i), 2));
            columns.add("Right");
            columns.add("Left");
            Map<String, Object> row = promByVisit.get(i).orElse(Map.of());
            cells.add(qAngleCell(row.get("q_angle_r")));
            cells.add(qAngleCell(row.get("q_angle_l")));
        }
        return Section.table("Knee Varus/Valgus", columnGroups, columns,
                List.of(new Row("Knee Varus/Valgus", cells)), null);
    }

    private Section popAngleSection(List<Optional<Map<String, Object>>> promByVisit, List<Integer> visitIdx,
            List<String> visitLabels) {
        List<ColumnGroup> columnGroups = new ArrayList<>();
        List<String> columns = new ArrayList<>();
        List<String> cells = new ArrayList<>();
        columnGroups.add(new ColumnGroup("", 1));
        columns.add("");
        for (int i : visitIdx) {
            columnGroups.add(new ColumnGroup(visitLabels.get(i), 2));
            columns.add("Right");
            columns.add("Left");
            Map<String, Object> row = promByVisit.get(i).orElse(Map.of());
            cells.add(rangeCell(row.get("pop_r_low"), row.get("pop_r_high")));
            cells.add(rangeCell(row.get("pop_l_low"), row.get("pop_l_high")));
        }
        return Section.table("Pop angle", columnGroups, columns, List.of(new Row("Pop angle", cells)), null);
    }

    private static String rangeCell(Object low, Object high) {
        if (low == null && high == null) {
            return null;
        }
        return wnlCell(low) + " -- " + wnlCell(high);
    }

    private Section motorControlOrToneSection(String title, List<List<Map<String, Object>>> dataByVisit,
            List<Integer> visitIdx, List<String> visitLabels) {
        List<ColumnGroup> columnGroups = new ArrayList<>();
        List<String> columns = new ArrayList<>();
        columnGroups.add(new ColumnGroup("", 1));
        columns.add("");
        for (int i : visitIdx) {
            columnGroups.add(new ColumnGroup(visitLabels.get(i), 2));
            columns.add("Right");
            columns.add("Left");
        }

        // The legacy comparison report, unlike the Motor Control/Tone tab views, does not grey
        // or hide the score for "*"-prefixed (interpretation-only) tests - it just prints
        // whatever's in score_r/score_l for every row, same as any other test.
        List<Map<String, Object>> primary = dataByVisit.get(visitIdx.get(0));
        List<Row> rows = new ArrayList<>();
        for (int rowIndex = 0; rowIndex < primary.size(); rowIndex++) {
            String test = (String) primary.get(rowIndex).get("test");
            List<String> cells = new ArrayList<>();
            for (int i : visitIdx) {
                List<Map<String, Object>> rowsForVisit = dataByVisit.get(i);
                Map<String, Object> row = rowIndex < rowsForVisit.size() ? rowsForVisit.get(rowIndex) : Map.of();
                cells.add(str(row.get("score_r")));
                cells.add(str(row.get("score_l")));
            }
            rows.add(new Row(test, cells));
        }
        return Section.table(title, columnGroups, columns, rows, null);
    }

    private static String str(Object value) {
        return value == null ? null : value.toString();
    }

    private Section gmfmDSection(List<Optional<PtGeneralEvaluationRow>> rawGeneralByVisit, List<Integer> visitIdx,
            List<String> visitLabels) {
        List<ColumnGroup> columnGroups = new ArrayList<>();
        List<String> columns = new ArrayList<>();
        columnGroups.add(new ColumnGroup("", 1));
        columns.add("");
        for (int i : visitIdx) {
            columnGroups.add(new ColumnGroup(visitLabels.get(i), 2));
            columns.add("Right");
            columns.add("Left");
        }

        record Task(String label, String rightGetter, String leftGetter) {
        }
        // Mirrors printFunctionalStrengthGMFMRow()'s own task list and labels exactly.
        List<Row> rows = new ArrayList<>();
        rows.add(gmfmDRow("Pull to stand (52)", rawGeneralByVisit, visitIdx, PtGeneralEvaluationRow::getPullStand, null));
        rows.add(gmfmDRow("Independent Standing - Arms Free (3 sec) (53)", rawGeneralByVisit, visitIdx,
                PtGeneralEvaluationRow::getIndepStand3, null));
        rows.add(gmfmDRow("Independent Standing - Arms Free (20 sec) (53)", rawGeneralByVisit, visitIdx,
                PtGeneralEvaluationRow::getIndepStand20, null));
        rows.add(gmfmDRow("One leg stance hand held - Right (54,55)", rawGeneralByVisit, visitIdx,
                PtGeneralEvaluationRow::getOneLegHandR, PtGeneralEvaluationRow::getOneLegHandL));
        rows.add(gmfmDRow("One leg stance (57,58)", rawGeneralByVisit, visitIdx, PtGeneralEvaluationRow::getOneLegR,
                PtGeneralEvaluationRow::getOneLegL));
        rows.add(gmfmDRow("Short sit to stand (59)", rawGeneralByVisit, visitIdx,
                PtGeneralEvaluationRow::getShortSitStand, null));
        rows.add(gmfmDRow("High Kneel to stand (60,61)", rawGeneralByVisit, visitIdx,
                PtGeneralEvaluationRow::getHighKneeStandR, PtGeneralEvaluationRow::getHighKneeStandL));
        rows.add(gmfmDRow("Lowers to floor (62)", rawGeneralByVisit, visitIdx, PtGeneralEvaluationRow::getLowerFloor,
                null));
        rows.add(gmfmDRow("Squats (63)", rawGeneralByVisit, visitIdx, PtGeneralEvaluationRow::getSquats, null));
        rows.add(gmfmDRow("Standing-picks pen from floor (64)", rawGeneralByVisit, visitIdx,
                PtGeneralEvaluationRow::getStandPickPen, null));
        return Section.table("Functional Strength - GMFM-D", columnGroups, columns, rows, null);
    }

    private Row gmfmDRow(String label, List<Optional<PtGeneralEvaluationRow>> rawGeneralByVisit,
            List<Integer> visitIdx, java.util.function.Function<PtGeneralEvaluationRow, Integer> right,
            java.util.function.Function<PtGeneralEvaluationRow, Integer> left) {
        List<String> cells = new ArrayList<>();
        for (int i : visitIdx) {
            PtGeneralEvaluationRow row = rawGeneralByVisit.get(i).orElse(null);
            Integer rightValue = row == null ? null : right.apply(row);
            cells.add(rightValue == null ? "--" : String.valueOf(rightValue));
            if (left != null) {
                Integer leftValue = row == null ? null : left.apply(row);
                cells.add(leftValue == null ? "--" : String.valueOf(leftValue));
            } else {
                cells.add(null);
            }
        }
        return new Row(label, cells);
    }

    private Section mobilityScalesSection(List<GeneralEvaluation> generalByVisit, List<Integer> visitIdx,
            List<String> visitLabels) {
        List<String> columns = new ArrayList<>();
        columns.add("");
        visitIdx.forEach(i -> columns.add(visitLabels.get(i)));
        List<Row> rows = new ArrayList<>();
        rows.add(scaleRow("Ambulation Scale", generalByVisit, visitIdx, General::ambulationScale));

        boolean anyGmfcs = visitIdx.stream().anyMatch(i -> generalByVisit.get(i).general().gmfcs() != null);
        if (anyGmfcs) {
            rows.add(scaleRowWithDash("GMFCS", generalByVisit, visitIdx, General::gmfcs));
        }
        addIfAny(rows, "FMS (5m)", generalByVisit, visitIdx, General::fms5m);
        addIfAny(rows, "FMS (50m)", generalByVisit, visitIdx, General::fms50m);
        addIfAny(rows, "FMS (500m)", generalByVisit, visitIdx, General::fms500m);

        List<String> totalGmfm = new ArrayList<>();
        for (int i : visitIdx) {
            GmfmModule moduleD = generalByVisit.get(i).gmfmModules().stream()
                    .filter(m -> "D".equals(m.module())).findFirst().orElse(null);
            int score = moduleD == null || moduleD.score() == null ? 0 : moduleD.score();
            totalGmfm.add(score > 0 ? score + " / 39" : "N/A");
        }
        rows.add(new Row("Total GMFM Score", totalGmfm));

        return Section.table("Mobility Scales", null, columns, rows, null);
    }

    private void addIfAny(List<Row> rows, String label, List<GeneralEvaluation> generalByVisit,
            List<Integer> visitIdx, java.util.function.Function<General, String> extractor) {
        boolean any = visitIdx.stream().anyMatch(i -> extractor.apply(generalByVisit.get(i).general()) != null);
        if (any) {
            rows.add(scaleRow(label, generalByVisit, visitIdx, extractor));
        }
    }

    private Row scaleRow(String label, List<GeneralEvaluation> generalByVisit, List<Integer> visitIdx,
            java.util.function.Function<General, String> extractor) {
        List<String> cells = visitIdx.stream().map(i -> extractor.apply(generalByVisit.get(i).general())).toList();
        return new Row(label, cells);
    }

    /** Same as scaleRow, but a visit with a null value (not CP, or CP with nothing resolved)
     * shows "--" rather than a blank cell, matching comp_report-gmfm_gmfcs.jsp's own GMFCS row -
     * every other scale row leaves a missing visit blank instead. */
    private Row scaleRowWithDash(String label, List<GeneralEvaluation> generalByVisit, List<Integer> visitIdx,
            java.util.function.Function<General, String> extractor) {
        List<String> cells = new ArrayList<>();
        for (int i : visitIdx) {
            String value = extractor.apply(generalByVisit.get(i).general());
            cells.add(value == null ? "--" : value);
        }
        return new Row(label, cells);
    }

    /** Current visit only - comp_report-gmfm_gmfcs.jsp never compares these across visits, just
     * prints the current one's Module A/B/C/E (checking only for null, not the "0 means no
     * entry" rule the General tab's own GmfmModule scoring applies - a real difference between
     * the two legacy pages, not a bug to normalize away). */
    private Section otherGmfmModulesSection(PtGeneralEvaluationRow row) {
        List<String> lines = new ArrayList<>();
        if (row.getGmfmModA() != null) {
            lines.add("Module A: " + row.getGmfmModA());
        }
        if (row.getGmfmModB() != null) {
            lines.add("Module B: " + row.getGmfmModB());
        }
        if (row.getGmfmModC() != null) {
            lines.add("Module C: " + row.getGmfmModC());
        }
        if (row.getGmfmModE() != null) {
            lines.add("Module E: " + row.getGmfmModE());
        }
        return Section.list("Other GMFM Modules", lines);
    }

    /** Current visit only, matching the legacy "Notes:" footer. */
    private Section notesSection(General general, boolean hasGeneralData) {
        String text = hasGeneralData ? general.comments() : null;
        return Section.text("Notes", hasGeneralData ? text : "No GMFM Data Recorded.");
    }
}
