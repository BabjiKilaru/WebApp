package org.nemours.gaitlab.service;

import org.springframework.security.core.Authentication;

/**
 * Button-visibility flags for the PT Evaluation tabs, mirroring the admin gating on the legacy
 * pt.jsp/pt-eval-*.jsp pages: Create New Record, Modify General and PROM/Strength "Edit Data",
 * and Add an Orthosis (and per-row Orthotics edit/delete) are admin-only; editing Motor
 * Control/Tone/Pain values once a record exists is not. report (the Comparison Report button) is
 * hidden only for movement-disorder visits, regardless of role.
 */
public record PtEvaluationActions(boolean create, boolean edit, boolean add, boolean report) {

    public static boolean isAdmin(Authentication authentication) {
        return authentication != null && authentication.getAuthorities().stream()
                .anyMatch(authority -> authority.getAuthority().equals("ROLE_ADMIN"));
    }

    /** new_visit_type.id for "Movement Disorder" - VisitType.MOVEMENT_DISORDER_ID in the legacy
     * Java source, matching pt-sections.jsp's own isMovementDisorder check. */
    public static final int MOVEMENT_DISORDER_VISIT_TYPE_ID = 11;

    public static boolean isMovementDisorder(Integer visitTypeId) {
        return visitTypeId != null && visitTypeId == MOVEMENT_DISORDER_VISIT_TYPE_ID;
    }
}
