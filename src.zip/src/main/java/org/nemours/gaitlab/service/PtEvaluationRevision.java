package org.nemours.gaitlab.service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

import org.springframework.stereotype.Component;

import tools.jackson.databind.ObjectMapper;

/**
 * Opaque optimistic-concurrency token for the PT Evaluation edit forms: a SHA-256 hash of the
 * current view, the same scheme VideoAssessmentService/QuestionnaireResponseService already use
 * elsewhere in this app. Legacy itself has no such check at all (a raw unconditional UPDATE) -
 * this is a deliberate addition per the write-endpoint spec, not a legacy behavior to match.
 */
@Component
public class PtEvaluationRevision {
    private final ObjectMapper json;

    public PtEvaluationRevision(ObjectMapper json) {
        this.json = json;
    }

    public String of(Object value) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256")
                    .digest(json.writeValueAsString(value).getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
