package org.nemours.gaitlab.service;

import java.util.List;

/** Shared response shape for the PT Evaluation edit-form endpoints (GET .../{tab}/form), matching
 * the frontend's generic form renderer contract. */
public record PtEvaluationForm(String tab, String title, String revision, List<FormSection> sections) {

    public record FormRow(String label, List<Field> fields) {
    }

    public record FormSection(String title, String layout, List<String> columns, List<FormRow> rows,
            List<Field> fields) {

        public static FormSection grid(String title, List<String> columns, List<FormRow> rows) {
            return new FormSection(title, "grid", columns, rows, null);
        }

        public static FormSection stack(String title, List<Field> fields) {
            return new FormSection(title, "stack", null, null, fields);
        }
    }

    public record Option(String value, String label) {
    }

    /** value is a String for every scalar field type, or a List<String> for multiselect. */
    public record Field(String name, String label, String type, Object value, List<Option> options,
            boolean required, Double min, Double max, Double step, Integer maxLength, String help) {

        public static Field text(String name, String label, String value) {
            return new Field(name, label, "text", value, null, false, null, null, null, null, null);
        }

        public static Field textarea(String name, String label, String value) {
            return new Field(name, label, "textarea", value, null, false, null, null, null, null, null);
        }

        public static Field select(String name, String label, String value, List<Option> options) {
            return new Field(name, label, "select", value, options, false, null, null, null, null, null);
        }

        public static Field radio(String name, String label, String value, List<Option> options) {
            return new Field(name, label, "radio", value, options, false, null, null, null, null, null);
        }
    }
}
