package org.nemours.gaitlab.service;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.nemours.gaitlab.repository.PtEvaluationRepository;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.repository.VisitRepository.GmfcsListEntry;
import org.nemours.gaitlab.repository.VisitRepository.PtGeneralEvaluationRow;
import org.nemours.gaitlab.service.PtEvaluationForm.Field;
import org.nemours.gaitlab.service.PtEvaluationForm.FormRow;
import org.nemours.gaitlab.service.PtEvaluationForm.FormSection;
import org.nemours.gaitlab.service.PtEvaluationForm.Option;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

/**
 * Ports lab/data/pt.jsp (the "General & GMFM" PT evaluation tab) for the non-movement-disorder
 * case. Movement-disorder visits (MACS/CFCS, data_pt_movement_disorder) are not covered here.
 */
@Service
public class PtEvaluationService {

    public record General(
            Float heightCm, Float weightKg, String heightZ, String weightZ,
            Float rightFootLengthCm, Float leftFootLengthCm,
            Float rightFootWidthCm, Float leftFootWidthCm,
            String ambulationScale,
            String gmfcs,
            String fms5m, String fms50m, String fms500m,
            String comments) {
    }

    public record GmfmTask(String items, String task, boolean bilateral, Integer right, Integer left) {
    }

    public record GmfmModule(String module, Integer score, Integer maxScore, Integer percent) {
    }

    public record GeneralEvaluation(
            Integer patientId, Integer visitId,
            General general,
            List<GmfmTask> gmfmD,
            List<GmfmModule> gmfmModules,
            Double meanPercent,
            PtEvaluationActions actions) {

        public GeneralEvaluation withActions(PtEvaluationActions actions) {
            return new GeneralEvaluation(patientId, visitId, general, gmfmD, gmfmModules, meanPercent, actions);
        }
    }

    private final VisitRepository visits;
    private final PtEvaluationRepository general;
    private final PtEvaluationRevision revision;

    public PtEvaluationService(VisitRepository visits, PtEvaluationRepository general, PtEvaluationRevision revision) {
        this.visits = visits;
        this.general = general;
        this.revision = revision;
    }

    public GeneralEvaluation getGeneral(int patientId, int visitId) {
        visits.findInterpretationVisitByIdAndPatientId(visitId, patientId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

        return visits.findPtGeneralEvaluationByVisitIdAndPatientId(visitId, patientId)
                .map(row -> buildEvaluation(patientId, visitId, row))
                .orElseGet(() -> emptyEvaluation(patientId, visitId));
    }

    private GeneralEvaluation emptyEvaluation(int patientId, int visitId) {
        General general = new General(
                null, null, null, null, null, null, null, null, null, null, null, null, null, null);
        return new GeneralEvaluation(patientId, visitId, general, List.of(), List.of(), null, null);
    }

    private GeneralEvaluation buildEvaluation(int patientId, int visitId, PtGeneralEvaluationRow row) {
        int pullStand = z(row.getPullStand());
        int indepStand3 = z(row.getIndepStand3());
        int indepStand20 = z(row.getIndepStand20());
        int oneLegHandR = z(row.getOneLegHandR());
        int oneLegHandL = z(row.getOneLegHandL());
        int oneLegR = z(row.getOneLegR());
        int oneLegL = z(row.getOneLegL());
        int shortSitStand = z(row.getShortSitStand());
        int highKneeStandR = z(row.getHighKneeStandR());
        int highKneeStandL = z(row.getHighKneeStandL());
        int lowerFloor = z(row.getLowerFloor());
        int squats = z(row.getSquats());
        int standPickPen = z(row.getStandPickPen());

        List<GmfmTask> gmfmD = List.of(
                new GmfmTask("52", "Pull to stand", false, pullStand, null),
                new GmfmTask("53", "Indep. Standing - Arms Free (3 sec)", false, indepStand3, null),
                new GmfmTask("56", "Indep. Standing - Arms Free (20 sec)", false, indepStand20, null),
                new GmfmTask("54,55", "One leg stance hand held - Right", true, oneLegHandR, oneLegHandL),
                new GmfmTask("57,58", "One leg stance", true, oneLegR, oneLegL),
                new GmfmTask("59", "Short sit to stand", false, shortSitStand, null),
                new GmfmTask("60,61", "High kneel to stand", true, highKneeStandR, highKneeStandL),
                new GmfmTask("62", "Lowers to floor", false, lowerFloor, null),
                new GmfmTask("63", "Squats", false, squats, null),
                new GmfmTask("64", "Standing - picks pen from floor", false, standPickPen, null));

        // Module D is always scored from the GMFM-D task total; A, B, C, E only when their raw
        // column is non-null and non-zero, matching the legacy page's "if (curr_mod)" JS check -
        // a raw score of exactly 0 is indistinguishable from "no entry" there, and this preserves
        // that quirk rather than silently fixing it.
        int moduleDTotal = pullStand + indepStand3 + indepStand20 + oneLegHandR + oneLegHandL
                + oneLegR + oneLegL + shortSitStand + highKneeStandR + highKneeStandL
                + lowerFloor + squats + standPickPen;

        General general = new General(
                row.getHeightCm(), row.getWeightKg(),
                heightZ(row.getHeightCm(), row.getGender(), row.getVisitDate(), row.getDob()),
                weightZ(row.getWeightKg(), row.getGender(), row.getVisitDate(), row.getDob()),
                row.getRightFootLengthCm(), row.getLeftFootLengthCm(),
                row.getRightFootWidthCm(), row.getLeftFootWidthCm(),
                labelDash(row.getAmbScaleId() == null ? null : String.valueOf(row.getAmbScaleId()),
                        row.getAmbulationScale()),
                gmfcsDisplay(row, pullStand, indepStand3, oneLegR, oneLegL, shortSitStand,
                        highKneeStandR, highKneeStandL, moduleDTotal),
                labelDash(row.getFms5m(), row.getFms5mDesc()),
                labelDash(row.getFms50m(), row.getFms50mDesc()),
                labelDash(row.getFms500m(), row.getFms500mDesc()),
                row.getComments());

        List<GmfmModule> gmfmModules = new ArrayList<>();
        gmfmModules.add(scoredModule("A", row.getGmfmModA(), 51));
        gmfmModules.add(scoredModule("B", row.getGmfmModB(), 60));
        gmfmModules.add(scoredModule("C", row.getGmfmModC(), 42));
        gmfmModules.add(new GmfmModule("D", moduleDTotal, 39, percentOf(moduleDTotal, 39)));
        gmfmModules.add(scoredModule("E", row.getGmfmModE(), 72));

        int runningTotal = 0;
        int enteredModules = 0;
        for (GmfmModule module : gmfmModules) {
            if (module.percent() != null) {
                runningTotal += module.percent();
                enteredModules++;
            }
        }
        Double meanPercent = enteredModules == 0 ? null : (double) runningTotal / enteredModules;

        return new GeneralEvaluation(patientId, visitId, general, gmfmD, List.copyOf(gmfmModules), meanPercent, null);
    }

    /** "{value} -- {description}", legacy's exact separator for Ambulation Scale/FMS/GMFCS -
     * " -- " with both sides blank (never null) when nothing is on file. */
    private static String labelDash(String value, String description) {
        return (value == null ? "" : value) + " -- " + (description == null ? "" : description);
    }

    private static final DecimalFormat Z_FORMAT_PATTERN = new DecimalFormat("0.0");

    private static String zFormat(double value) {
        synchronized (Z_FORMAT_PATTERN) {
            return Z_FORMAT_PATTERN.format(value);
        }
    }

    /** Ported from pt.jsp's height z-score block: growth-curve mean/std by gender, against age
     * in whole months (SQL ROUND((date - dob) / 365.0 * 12), applied before the formula, not
     * after). null when height itself isn't on file - unlike weight, an unknown/other gender
     * prints "need gender" rather than "N/A". */
    private String heightZ(Float heightCm, String gender, LocalDate visitDate, LocalDate dob) {
        if (heightCm == null) {
            return null;
        }
        if (!"Male".equals(gender) && !"Female".equals(gender)) {
            return "(z = need gender)";
        }
        if (visitDate == null || dob == null) {
            return null;
        }
        double months = ageInMonths(visitDate, dob);
        double mean;
        double std;
        if ("Male".equals(gender)) {
            mean = -260.3657 + (262.8692 - (-260.3657)) / (1.0 + 0.57774 * Math.exp(-(0.0052597 * months)));
            std = 2.02485 + (9.8984 - 2.02485) / (1.0 + 7.5227 * Math.exp(-(0.0181343 * months)));
        } else {
            mean = -82.788774 + (195.26046 - (-82.798774)) / (1.0 + 0.8455536 * Math.exp(-(0.0101596 * months)));
            std = 2.40482737 + (6.81956506 - 2.40482737) / (1.0 + 15.723074 * Math.exp(-(0.0450524084 * months)));
        }
        return "(z = " + zFormat((heightCm - mean) / std) + ")";
    }

    /** Ported from pt.jsp's weight z-score block - "N/A" (not "need gender") for an unknown or
     * other gender, matching the legacy page's inconsistency between the two fields. */
    private String weightZ(Float weightKg, String gender, LocalDate visitDate, LocalDate dob) {
        if (weightKg == null) {
            return null;
        }
        if (!"Male".equals(gender) && !"Female".equals(gender)) {
            return "(z = N/A)";
        }
        if (visitDate == null || dob == null) {
            return null;
        }
        double months = ageInMonths(visitDate, dob);
        double mean;
        double std;
        if ("Male".equals(gender)) {
            mean = 3.7 + (146.93 - 3.736) / (1.0 + 21.068 * Math.exp(-(0.013832 * months)));
            std = 0.872199 + (13.9084 - 0.872199) / (1.0 + 59.325 * Math.exp(-(0.0338 * months)));
        } else {
            mean = 6.4032907948 + (74.129378344 - 6.4032907947) / (1.0 + 19.0375155389 * Math.exp(-(0.020912892101 * months)));
            std = 1.16994385 + (12.9379166 - 1.1699438) / (1.0 + 88.52793975 * Math.exp(-(0.041292875 * months)));
        }
        return "(z = " + zFormat((weightKg - mean) / std) + ")";
    }

    /** SQL ROUND((date - dob) / 365.0 * 12) - rounded to whole months BEFORE it feeds the growth
     * formulas, matching pt.jsp's pt_age query exactly (not the unrounded day count). */
    private static double ageInMonths(LocalDate visitDate, LocalDate dob) {
        long days = ChronoUnit.DAYS.between(dob, visitDate);
        return Math.round(days / 365.0 * 12);
    }

    private GmfmModule scoredModule(String module, Integer rawScore, int maxScore) {
        if (rawScore == null || rawScore == 0) {
            return new GmfmModule(module, null, null, null);
        }
        return new GmfmModule(module, rawScore, maxScore, percentOf(rawScore, maxScore));
    }

    private int percentOf(int score, int maxScore) {
        return Math.round(score * 100f / maxScore);
    }

    private int z(Integer value) {
        return value == null ? 0 : value;
    }

    /**
     * Ports the GMFCS row shown next to Ambulation Scale: gated on the diagnosis being CP
     * (patient.gen_diag or visit.icd9), using a manually-recorded gmfcs (data_pt.gmfcs != the
     * unset-sentinel id 1) when present, otherwise the calculated GMFCS from amb_scale/age/GMFM-D
     * scores. null only when the row isn't shown at all (not CP) - every other CP-gated outcome
     * is a display string, "--" (bare, no separator) when nothing can be resolved, matching the
     * legacy page's literal " -- " cell rather than an empty value.
     */
    private String gmfcsDisplay(PtGeneralEvaluationRow row, int gmfm52, int gmfm53, int gmfm57, int gmfm58,
            int gmfm59, int gmfm60, int gmfm61, int gmfmDTotal) {
        if (!isCP(row.getGenDiag()) && !isCP(row.getIcd9())) {
            return null;
        }

        Integer gmfcsId = row.getGmfcsId();
        if (gmfcsId != null && gmfcsId != 1) {
            return gmfcsListEntries().stream()
                    .filter(entry -> gmfcsId.equals(entry.getId()))
                    .findFirst()
                    .map(entry -> labelDash(entry.getLabel(), entry.getDescription()))
                    .orElse("--");
        }

        LocalDate visitDate = row.getVisitDate();
        LocalDate dob = row.getDob();
        if (visitDate == null || dob == null || gmfmDTotal == 0) {
            return "--";
        }
        double age = ChronoUnit.DAYS.between(dob, visitDate) / 365.0;
        String calculatedLabel = calculateGMFCS(z(row.getAmbScaleId()), age, gmfm52, gmfm53, gmfm57, gmfm58, gmfm59,
                gmfm60, gmfm61);
        if (calculatedLabel.isEmpty()) {
            return "--";
        }
        return gmfcsListEntries().stream()
                .filter(entry -> calculatedLabel.equals(entry.getLabel()))
                .findFirst()
                .map(entry -> labelDash(calculatedLabel, entry.getDescription()))
                .orElse("--");
    }

    private List<GmfcsListEntry> gmfcsListEntries() {
        return visits.findAllGmfcsListEntries();
    }

    private boolean isCP(Integer icd9Id) {
        return icd9Id != null && ((icd9Id >= 13 && icd9Id <= 17) || icd9Id == 119 || icd9Id == 142);
    }

    /**
     * Ported verbatim from edu.udel.aidi.gait.questionnaire.util.GMFCSHelper#calculateGMFCS -
     * the struts app's own javadoc calls this "the most recent/correct version" of the GMFCS
     * calculation, matching the data_pt_calculated_gmfcs DB view.
     */
    private String calculateGMFCS(int ambScale, double age, int gmfm52, int gmfm53, int gmfm57, int gmfm58,
            int gmfm59, int gmfm60, int gmfm61) {
        if (ambScale == 1) {
            if ((age < 4.0) || ((age >= 4.0) && (age < 12.0) && (gmfm59 > 2) && (gmfm60 > 2) && (gmfm61 > 2))) {
                return "I";
            } else if ((age >= 4.0) && (age < 12.0) && ((gmfm59 <= 2) || (gmfm60 <= 2) || (gmfm61 <= 2))) {
                return "II";
            } else if ((age >= 12.0) && (age < 18.0) && (gmfm59 > 2) && ((gmfm60 > 2) || (gmfm61 > 2))) {
                return "I";
            } else if ((age >= 12.0) && (age < 18.0) && (gmfm59 <= 2) && (gmfm60 <= 2) && (gmfm61 <= 2)) {
                return "II";
            }
        } else if (ambScale == 2) {
            if (age < 4.0) {
                return "II";
            } else if (age >= 4.0 && age < 6.0 && gmfm59 >= 3 && gmfm60 >= 3 && gmfm61 >= 3 && gmfm57 >= 2
                    && gmfm58 >= 2) {
                return "I";
            } else if (age >= 4.0 && age < 6.0 && gmfm60 <= 2 && gmfm61 <= 2) {
                return "II";
            } else if (age >= 6.0 && age < 12.0 && gmfm59 >= 3 && (gmfm57 >= 2 || gmfm58 >= 2)) {
                return "II";
            } else if (age >= 6.0 && age < 12.0 && gmfm59 <= 2 && (gmfm57 < 2 || gmfm58 < 2)) {
                return "III";
            } else if (age >= 12.0 && gmfm60 >= 2 && gmfm61 >= 2) {
                return "II";
            } else if (age >= 12.0 && gmfm60 <= 1 && gmfm61 <= 1) {
                return "III";
            }
        } else if (ambScale == 3) {
            if (age >= 4.0 && age < 6.0) {
                return "III";
            } else if (age >= 6.0 && age < 12.0 && gmfm52 >= 3) {
                return "III";
            } else if (age >= 6.0 && age < 12.0 && gmfm52 <= 2) {
                return "IV";
            } else if (age >= 12.0 && gmfm59 >= 1 && gmfm60 >= 1 && gmfm61 >= 1) {
                return "III";
            } else if (age >= 12.0 && (gmfm60 < 1 || gmfm61 < 1)) {
                return "IV";
            }
        } else if (ambScale == 4) {
            if (gmfm59 >= 1 && gmfm52 >= 2) {
                return "III";
            } else if (gmfm59 < 1 && gmfm52 <= 1) {
                return "IV";
            }
        } else if (ambScale == 5) {
            if (gmfm52 >= 1 && gmfm53 >= 1) {
                return "IV";
            } else if (gmfm52 == 0 || gmfm53 == 0) {
                return "V";
            }
        } else if (ambScale == 6) {
            return "V";
        }
        return "";
    }

    // --- Phase 2: modify_pt.jsp (the General & GMFM edit form) ---------------------------------

    private static final List<Option> AMB_SCALE_OPTIONS = List.of(
            new Option("1", "1"), new Option("2", "2"), new Option("3", "3"),
            new Option("4", "4"), new Option("5", "5"), new Option("6", "6"));

    public PtEvaluationForm buildForm(int patientId, int visitId) {
        PtGeneralEvaluationRow row = visits.findPtGeneralEvaluationByVisitIdAndPatientId(visitId, patientId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No general record exists yet for this visit."));

        Field height = Field.text("height", "Height (cm)", numStr(row.getHeightCm()));
        Field weight = Field.text("weight", "Weight (kg)", numStr(row.getWeightKg()));
        Field rFootLength = Field.text("r_foot_length", "Right Foot Length (cm)", numStr(row.getRightFootLengthCm()));
        Field lFootLength = Field.text("l_foot_length", "Left Foot Length (cm)", numStr(row.getLeftFootLengthCm()));
        Field rFootWidth = Field.text("r_foot_width", "Right Foot Width (cm)", numStr(row.getRightFootWidthCm()));
        Field lFootWidth = Field.text("l_foot_width", "Left Foot Width (cm)", numStr(row.getLeftFootWidthCm()));
        Field ambScale = new Field("amb_scale", "Ambulation Scale", "radio", idStr(row.getAmbScaleId()),
                AMB_SCALE_OPTIONS, false, null, null, null, null, null);
        Field gmfcs = Field.select("gmfcs", "GMFCS", idStr(row.getGmfcsId()),
                toIdLabelOptions(general.findActiveGmfcsListEntries()));
        Field fms5 = Field.select("fms_5", "FMS (5m)", idStr(row.getFms5Id()),
                toIdLabelOptions(general.findActiveFmsListEntries()));
        Field fms50 = Field.select("fms_50", "FMS (50m)", idStr(row.getFms50Id()),
                toIdLabelOptions(general.findActiveFmsListEntries()));
        Field fms500 = Field.select("fms_500", "FMS (500m)", idStr(row.getFms500Id()),
                toIdLabelOptions(general.findActiveFmsListEntries()));
        Field comments = Field.textarea("comments", "Comments", row.getComments());

        FormSection generalSection = FormSection.stack("General and Marker Information", List.of(
                height, weight, rFootLength, lFootLength, rFootWidth, lFootWidth, ambScale, gmfcs, fms5, fms50,
                fms500, comments));

        FormSection gmfmDSection = FormSection.grid("Functional Strength -GMFM-D", List.of("Right", "Left"), List.of(
                bilateralRow("Pull to stand (52)", "pull_stand", row.getPullStand(), null, null),
                bilateralRow("Indep. Standing - Arms Free (3 sec) (53)", "indep_stand_3", row.getIndepStand3(),
                        null, null),
                bilateralRow("Indep. Standing - Arms Free (20 sec) (56)", "indep_stand_20", row.getIndepStand20(),
                        null, null),
                bilateralRow("One leg stance hand held - Right (54,55)", "one_leg_hand_r", row.getOneLegHandR(),
                        "one_leg_hand_l", row.getOneLegHandL()),
                bilateralRow("One leg stance (57,58)", "one_leg_r", row.getOneLegR(), "one_leg_l", row.getOneLegL()),
                bilateralRow("Short sit to stand (59)", "short_sit_stand", row.getShortSitStand(), null, null),
                bilateralRow("High kneel to stand (60,61)", "high_knee_stand_r", row.getHighKneeStandR(),
                        "high_knee_stand_l", row.getHighKneeStandL()),
                bilateralRow("Lowers to floor (62)", "lower_floor", row.getLowerFloor(), null, null),
                bilateralRow("Squats (63)", "squats", row.getSquats(), null, null),
                bilateralRow("Standing - picks pen from floor (64)", "stand_pick_pen", row.getStandPickPen(), null,
                        null)));

        FormSection modulesSection = FormSection.stack("Other GMFM Modules", List.of(
                Field.text("gmfm_mod_a", "Module A", idStr(row.getGmfmModA())),
                Field.text("gmfm_mod_b", "Module B", idStr(row.getGmfmModB())),
                Field.text("gmfm_mod_c", "Module C", idStr(row.getGmfmModC())),
                Field.text("gmfm_mod_e", "Module E", idStr(row.getGmfmModE()))));

        return new PtEvaluationForm("general", "Modify General & GMFM", revision.of(formSnapshot(row)),
                List.of(generalSection, gmfmDSection, modulesSection));
    }

    /** A row with a Right-only field (null name/value for Left) or both sides, matching the
     * GMFM-D table's mix of unilateral and bilateral tasks. */
    private static FormRow bilateralRow(String label, String nameR, Integer valueR, String nameL, Integer valueL) {
        Field right = Field.text(nameR, label + " Right", idStr(valueR));
        Field left = nameL == null ? null : Field.text(nameL, label + " Left", idStr(valueL));
        return new FormRow(label, Arrays.asList(right, left));
    }

    private static List<Option> toIdLabelOptions(List<Map<String, Object>> rows) {
        return rows.stream().map(row -> new Option(String.valueOf(row.get("id")), (String) row.get("label")))
                .toList();
    }

    private static String idStr(Integer value) {
        return value == null ? null : String.valueOf(value);
    }

    private static String numStr(Float value) {
        return value == null ? null : String.valueOf(value);
    }

    /** A stable snapshot of everything the form can edit, for the revision hash - the full
     * PtGeneralEvaluationRow also carries read-only context (dob, icd9, gender, labels) that
     * isn't part of what's being saved. */
    private static Map<String, Object> formSnapshot(PtGeneralEvaluationRow row) {
        Map<String, Object> snapshot = new java.util.LinkedHashMap<>();
        snapshot.put("heightCm", row.getHeightCm());
        snapshot.put("weightKg", row.getWeightKg());
        snapshot.put("rightFootLengthCm", row.getRightFootLengthCm());
        snapshot.put("leftFootLengthCm", row.getLeftFootLengthCm());
        snapshot.put("rightFootWidthCm", row.getRightFootWidthCm());
        snapshot.put("leftFootWidthCm", row.getLeftFootWidthCm());
        snapshot.put("ambScaleId", row.getAmbScaleId());
        snapshot.put("gmfcsId", row.getGmfcsId());
        snapshot.put("fms5Id", row.getFms5Id());
        snapshot.put("fms50Id", row.getFms50Id());
        snapshot.put("fms500Id", row.getFms500Id());
        snapshot.put("comments", row.getComments());
        snapshot.put("pullStand", row.getPullStand());
        snapshot.put("indepStand3", row.getIndepStand3());
        snapshot.put("indepStand20", row.getIndepStand20());
        snapshot.put("oneLegHandR", row.getOneLegHandR());
        snapshot.put("oneLegHandL", row.getOneLegHandL());
        snapshot.put("oneLegR", row.getOneLegR());
        snapshot.put("oneLegL", row.getOneLegL());
        snapshot.put("shortSitStand", row.getShortSitStand());
        snapshot.put("highKneeStandR", row.getHighKneeStandR());
        snapshot.put("highKneeStandL", row.getHighKneeStandL());
        snapshot.put("lowerFloor", row.getLowerFloor());
        snapshot.put("squats", row.getSquats());
        snapshot.put("standPickPen", row.getStandPickPen());
        snapshot.put("gmfmModA", row.getGmfmModA());
        snapshot.put("gmfmModB", row.getGmfmModB());
        snapshot.put("gmfmModC", row.getGmfmModC());
        snapshot.put("gmfmModE", row.getGmfmModE());
        return snapshot;
    }

    @Transactional
    public GeneralEvaluation save(int patientId, int visitId, String submittedRevision, Map<String, Object> values) {
        PtGeneralEvaluationRow row = visits.findPtGeneralEvaluationByVisitIdAndPatientId(visitId, patientId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No general record exists yet for this visit."));

        if (!revision.of(formSnapshot(row)).equals(submittedRevision)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "This data has changed since you loaded it. Reload and try again.");
        }

        Map<String, String> errors = new java.util.LinkedHashMap<>();
        Float height = resolveFloat(values, "height", row.getHeightCm(), errors);
        Float weight = resolveFloat(values, "weight", row.getWeightKg(), errors);
        Float rFootLength = resolveFloat(values, "r_foot_length", row.getRightFootLengthCm(), errors);
        Float lFootLength = resolveFloat(values, "l_foot_length", row.getLeftFootLengthCm(), errors);
        Float rFootWidth = resolveFloat(values, "r_foot_width", row.getRightFootWidthCm(), errors);
        Float lFootWidth = resolveFloat(values, "l_foot_width", row.getLeftFootWidthCm(), errors);
        Integer ambScale = resolveFromSet(values, "amb_scale", row.getAmbScaleId(),
                java.util.Set.of(1, 2, 3, 4, 5, 6), errors);
        Integer gmfcs = resolveLookupId(values, "gmfcs", row.getGmfcsId(), general::existsGmfcsListEntry, errors);
        Integer fms5 = resolveLookupId(values, "fms_5", row.getFms5Id(), general::existsFmsListEntry, errors);
        Integer fms50 = resolveLookupId(values, "fms_50", row.getFms50Id(), general::existsFmsListEntry, errors);
        Integer fms500 = resolveLookupId(values, "fms_500", row.getFms500Id(), general::existsFmsListEntry, errors);
        String comments = resolveText(values, "comments", row.getComments());
        Integer pullStand = resolveInt(values, "pull_stand", row.getPullStand(), errors);
        Integer indepStand3 = resolveInt(values, "indep_stand_3", row.getIndepStand3(), errors);
        Integer indepStand20 = resolveInt(values, "indep_stand_20", row.getIndepStand20(), errors);
        Integer oneLegHandR = resolveInt(values, "one_leg_hand_r", row.getOneLegHandR(), errors);
        Integer oneLegHandL = resolveInt(values, "one_leg_hand_l", row.getOneLegHandL(), errors);
        Integer oneLegR = resolveInt(values, "one_leg_r", row.getOneLegR(), errors);
        Integer oneLegL = resolveInt(values, "one_leg_l", row.getOneLegL(), errors);
        Integer shortSitStand = resolveInt(values, "short_sit_stand", row.getShortSitStand(), errors);
        Integer highKneeStandR = resolveInt(values, "high_knee_stand_r", row.getHighKneeStandR(), errors);
        Integer highKneeStandL = resolveInt(values, "high_knee_stand_l", row.getHighKneeStandL(), errors);
        Integer lowerFloor = resolveInt(values, "lower_floor", row.getLowerFloor(), errors);
        Integer squats = resolveInt(values, "squats", row.getSquats(), errors);
        Integer standPickPen = resolveInt(values, "stand_pick_pen", row.getStandPickPen(), errors);
        Integer gmfmModA = resolveInt(values, "gmfm_mod_a", row.getGmfmModA(), errors);
        Integer gmfmModB = resolveInt(values, "gmfm_mod_b", row.getGmfmModB(), errors);
        Integer gmfmModC = resolveInt(values, "gmfm_mod_c", row.getGmfmModC(), errors);
        Integer gmfmModE = resolveInt(values, "gmfm_mod_e", row.getGmfmModE(), errors);

        if (!errors.isEmpty()) {
            throw new PtEvaluationValidationException("Some general fields are invalid.", errors);
        }

        general.updateVisitMeasurements(visitId, height, weight, rFootLength, lFootLength, rFootWidth, lFootWidth);
        general.updateDataPt(row.getDataPtId(), ambScale, gmfcs, fms5, fms50, fms500, comments, pullStand,
                indepStand3, indepStand20, oneLegHandR, oneLegHandL, oneLegR, oneLegL, shortSitStand,
                highKneeStandR, highKneeStandL, lowerFloor, squats, standPickPen, gmfmModA, gmfmModB, gmfmModC,
                gmfmModE);

        return getGeneral(patientId, visitId);
    }

    private static String resolveText(Map<String, Object> values, String key, String currentValue) {
        if (!values.containsKey(key)) {
            return currentValue;
        }
        Object raw = values.get(key);
        String submitted = raw == null ? null : raw.toString();
        return (submitted == null || submitted.isEmpty()) ? null : submitted;
    }

    private static Float resolveFloat(Map<String, Object> values, String key, Float currentValue,
            Map<String, String> errors) {
        if (!values.containsKey(key)) {
            return currentValue;
        }
        Object raw = values.get(key);
        String submitted = raw == null ? null : raw.toString();
        if (submitted == null || submitted.isEmpty()) {
            return null;
        }
        try {
            return Float.parseFloat(submitted);
        } catch (NumberFormatException e) {
            errors.put(key, "Must be a number.");
            return currentValue;
        }
    }

    private static Integer resolveInt(Map<String, Object> values, String key, Integer currentValue,
            Map<String, String> errors) {
        if (!values.containsKey(key)) {
            return currentValue;
        }
        Object raw = values.get(key);
        String submitted = raw == null ? null : raw.toString();
        if (submitted == null || submitted.isEmpty()) {
            return null;
        }
        try {
            return Integer.parseInt(submitted);
        } catch (NumberFormatException e) {
            errors.put(key, "Must be a whole number.");
            return currentValue;
        }
    }

    private static Integer resolveFromSet(Map<String, Object> values, String key, Integer currentValue,
            java.util.Set<Integer> allowed, Map<String, String> errors) {
        Integer resolved = resolveInt(values, key, currentValue, errors);
        if (resolved != null && !allowed.contains(resolved)) {
            errors.put(key, "Invalid value.");
            return currentValue;
        }
        return resolved;
    }

    private interface IdExists {
        boolean test(int id);
    }

    private static Integer resolveLookupId(Map<String, Object> values, String key, Integer currentValue,
            IdExists exists, Map<String, String> errors) {
        Integer resolved = resolveInt(values, key, currentValue, errors);
        if (resolved != null && !exists.test(resolved)) {
            errors.put(key, "Unknown value.");
            return currentValue;
        }
        return resolved;
    }

    public GeneralEvaluation createRecord(int patientId, int visitId) {
        if (visits.findPtGeneralEvaluationByVisitIdAndPatientId(visitId, patientId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "General data already exists for this visit.");
        }
        general.insertBlankDataPt(visitId);
        return getGeneral(patientId, visitId);
    }
}
