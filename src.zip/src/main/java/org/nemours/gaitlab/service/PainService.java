package org.nemours.gaitlab.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.nemours.gaitlab.repository.PtEvaluationRepository;
import org.nemours.gaitlab.service.PtEvaluationForm.Field;
import org.nemours.gaitlab.service.PtEvaluationForm.FormSection;
import org.nemours.gaitlab.service.PtEvaluationForm.Option;
import org.nemours.gaitlab.service.PtEvaluationTab.Row;
import org.nemours.gaitlab.service.PtEvaluationTab.Section;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

/**
 * Ports lab/data/pt-eval-pain.jsp (view) and modify_pt_pain.jsp (edit), Gait visits only.
 * hasData tracks whether a data_pain row exists at all - once it does, the legacy page renders
 * every field (even if individually blank), so that's the only emptiness check, unlike the
 * GMFM-D-driven tabs.
 *
 * <p>The legacy page is genuinely one single HTML TABLE (lines 144-209) - factors/activities are
 * bullet lists rendered INSIDE that table's cells, not separate sections. Ported as one table
 * section with the list items newline-joined into their row's single cell, matching legacy's
 * exact row order and label text (including the colons on the first three rows only).
 */
@Service
public class PainService {
    static final String EMPTY_MESSAGE = "No pain data entered.";
    private static final List<String> LABEL_VALUE_COLUMNS = List.of("", "");
    private static final List<String> LEVEL_FIELDS = List.of("currentLevel", "lowestLevel", "highestLevel");

    private final PtEvaluationRepository repository;
    private final PtEvaluationRevision revision;

    public PainService(PtEvaluationRepository repository, PtEvaluationRevision revision) {
        this.repository = repository;
        this.revision = revision;
    }

    public PtEvaluationTab build(int patientId, int visitId, String tab) {
        return repository.findPainByVisitId(visitId)
                .map(row -> buildTab(patientId, visitId, tab, row))
                .orElseGet(() -> PtEvaluationTab.empty(patientId, visitId, tab, EMPTY_MESSAGE));
    }

    private PtEvaluationTab buildTab(int patientId, int visitId, String tab, Map<String, Object> row) {
        int dataPainId = (Integer) row.get("id");

        Section section = Section.table(null, null, LABEL_VALUE_COLUMNS, List.of(
                new Row("Pain assessment method:", Arrays.asList(str(row, "assessment_method"))),
                new Row("Aggravating factors:",
                        Arrays.asList(joinOrNull(repository.findFactorLabels(dataPainId)))),
                new Row("Activities impacted:",
                        Arrays.asList(joinOrNull(repository.findActivitiesImpactedLabels(dataPainId)))),
                new Row("Current Level", Arrays.asList(str(row, "current_level"))),
                new Row("Lowest Level", Arrays.asList(str(row, "lowest_level"))),
                new Row("Highest Level", Arrays.asList(str(row, "highest_level"))),
                new Row("Location of pain", Arrays.asList(str(row, "location"))),
                new Row("Frequency of pain", Arrays.asList(str(row, "frequency"))),
                new Row("Duration of pain", Arrays.asList(str(row, "duration")))), null);

        return PtEvaluationTab.of(patientId, visitId, tab, List.of(section));
    }

    /** legacy renders an empty <ul></ul> (no visible content) when there are no items - null
     * cell, not an empty string, matching every other "nothing on file" cell in this port. */
    private static String joinOrNull(List<String> items) {
        return items.isEmpty() ? null : String.join("\n", items);
    }

    private String str(Map<String, Object> row, String key) {
        Object value = row.get(key);
        return value == null ? null : value.toString();
    }

    public PtEvaluationForm buildForm(int patientId, int visitId) {
        Map<String, Object> row = repository.findPainByVisitId(visitId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No pain record exists yet for this visit."));
        int dataPainId = (Integer) row.get("id");
        return buildForm(row, dataPainId);
    }

    private PtEvaluationForm buildForm(Map<String, Object> row, int dataPainId) {
        List<Integer> factorIds = repository.findFactorIds(dataPainId);
        List<Integer> activityIds = repository.findActivitiesImpactedIds(dataPainId);

        Field assessmentMethod = Field.select("assessmentMethod", "Pain assessment method",
                str(row, "pain_assessment_method_id"), toOptions(repository.findAssessmentMethodOptions()));
        Field factors = new Field("factors", "Aggravating factors", "multiselect",
                factorIds.stream().map(String::valueOf).toList(), toOptions(repository.findFactorOptions()),
                false, null, null, null, null, null);
        Field activitiesImpacted = new Field("activitiesImpacted", "Activities impacted", "multiselect",
                activityIds.stream().map(String::valueOf).toList(),
                toOptions(repository.findActivitiesImpactedOptions()), false, null, null, null, null, null);
        Field currentLevel = levelField("currentLevel", "Current Level", str(row, "current_level"));
        Field lowestLevel = levelField("lowestLevel", "Lowest Level", str(row, "lowest_level"));
        Field highestLevel = levelField("highestLevel", "Highest Level", str(row, "highest_level"));
        Field location = Field.text("location", "Location of pain", str(row, "location"));
        Field frequency = Field.text("frequency", "Frequency of pain", str(row, "frequency"));
        Field duration = Field.text("duration", "Duration of pain", str(row, "duration"));

        FormSection section = FormSection.stack(null, List.of(assessmentMethod, factors, activitiesImpacted,
                currentLevel, lowestLevel, highestLevel, location, frequency, duration));
        return new PtEvaluationForm("pain", "Edit Pain", revision.of(snapshot(row, factorIds, activityIds)),
                List.of(section));
    }

    private static Field levelField(String name, String label, String value) {
        List<Option> options = new ArrayList<>();
        for (int i = 0; i <= 10; i++) {
            options.add(new Option(String.valueOf(i), String.valueOf(i)));
        }
        return new Field(name, label, "radio", value, options, false, 0.0, 10.0, 1.0, null, null);
    }

    private static List<Option> toOptions(List<Map<String, Object>> rows) {
        return rows.stream()
                .map(row -> new Option(String.valueOf(row.get("id")), (String) row.get("label")))
                .toList();
    }

    /** A stable, order-independent view of the editable data for the revision hash, since
     * factor/activity ids come back from two separate queries whose row order isn't otherwise
     * guaranteed to be identical between the GET and the later PUT's freshly-read copy. */
    private static Map<String, Object> snapshot(Map<String, Object> row, List<Integer> factorIds,
            List<Integer> activityIds) {
        Map<String, Object> snapshot = new LinkedHashMap<>(row);
        snapshot.put("factorIds", factorIds.stream().sorted().toList());
        snapshot.put("activityIds", activityIds.stream().sorted().toList());
        return snapshot;
    }

    @Transactional
    public PtEvaluationTab save(int patientId, int visitId, String submittedRevision, Map<String, Object> values) {
        Map<String, Object> row = repository.findPainByVisitId(visitId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No pain record exists yet for this visit."));
        int dataPainId = (Integer) row.get("id");
        List<Integer> currentFactorIds = repository.findFactorIds(dataPainId);
        List<Integer> currentActivityIds = repository.findActivitiesImpactedIds(dataPainId);

        if (!revision.of(snapshot(row, currentFactorIds, currentActivityIds)).equals(submittedRevision)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "This data has changed since you loaded it. Reload and try again.");
        }

        Map<String, String> errors = new LinkedHashMap<>();
        Integer assessmentMethodId = resolveLookupId(values, "assessmentMethod",
                (Integer) row.get("pain_assessment_method_id"), repository::existsAssessmentMethod, errors);
        Integer currentLevel = resolveLevel(values, "currentLevel", (Integer) row.get("current_level"), errors);
        Integer lowestLevel = resolveLevel(values, "lowestLevel", (Integer) row.get("lowest_level"), errors);
        Integer highestLevel = resolveLevel(values, "highestLevel", (Integer) row.get("highest_level"), errors);
        List<Integer> factorIds = resolveIdList(values, "factors", currentFactorIds, repository::existsFactor, errors);
        List<Integer> activityIds = resolveIdList(values, "activitiesImpacted", currentActivityIds,
                repository::existsActivityImpacted, errors);
        String location = resolveText(values, "location", str(row, "location"));
        String frequency = resolveText(values, "frequency", str(row, "frequency"));
        String duration = resolveText(values, "duration", str(row, "duration"));

        if (!errors.isEmpty()) {
            throw new PtEvaluationValidationException("Some pain fields are invalid.", errors);
        }

        repository.updateRecord(dataPainId, assessmentMethodId, currentLevel, lowestLevel, highestLevel, location,
                frequency, duration);
        repository.replaceFactorLinks(dataPainId, factorIds);
        repository.replaceActivitiesImpactedLinks(dataPainId, activityIds);

        return build(patientId, visitId, "pain");
    }

    private static String resolveText(Map<String, Object> values, String key, String currentValue) {
        if (!values.containsKey(key)) {
            return currentValue;
        }
        Object raw = values.get(key);
        String submitted = raw == null ? null : raw.toString();
        return (submitted == null || submitted.isEmpty()) ? null : submitted;
    }

    private static Integer resolveLevel(Map<String, Object> values, String key, Integer currentValue,
            Map<String, String> errors) {
        if (!values.containsKey(key)) {
            return currentValue;
        }
        Object raw = values.get(key);
        String submitted = raw == null ? null : raw.toString();
        if (submitted == null || submitted.isEmpty()) {
            return null;
        }
        try {
            int level = Integer.parseInt(submitted);
            if (level < 0 || level > 10) {
                errors.put(key, "Must be between 0 and 10.");
                return currentValue;
            }
            return level;
        } catch (NumberFormatException e) {
            errors.put(key, "Must be a whole number from 0 to 10.");
            return currentValue;
        }
    }

    private interface IdExists {
        boolean test(int id);
    }

    private static Integer resolveLookupId(Map<String, Object> values, String key, Integer currentValue,
            IdExists exists, Map<String, String> errors) {
        if (!values.containsKey(key)) {
            return currentValue;
        }
        Object raw = values.get(key);
        String submitted = raw == null ? null : raw.toString();
        if (submitted == null || submitted.isEmpty()) {
            return null;
        }
        try {
            int id = Integer.parseInt(submitted);
            if (!exists.test(id)) {
                errors.put(key, "Unknown value.");
                return currentValue;
            }
            return id;
        } catch (NumberFormatException e) {
            errors.put(key, "Invalid value.");
            return currentValue;
        }
    }

    private static List<Integer> resolveIdList(Map<String, Object> values, String key, List<Integer> currentIds,
            IdExists exists, Map<String, String> errors) {
        if (!values.containsKey(key)) {
            return currentIds;
        }
        Object raw = values.get(key);
        if (raw == null) {
            return List.of();
        }
        if (!(raw instanceof List<?> submitted)) {
            errors.put(key, "Must be a list of values.");
            return currentIds;
        }
        List<Integer> result = new ArrayList<>();
        for (Object item : submitted) {
            String s = item == null ? null : item.toString();
            if (s == null || s.isEmpty()) {
                continue;
            }
            try {
                int id = Integer.parseInt(s);
                if (!exists.test(id)) {
                    errors.put(key, "Contains an unknown value.");
                    continue;
                }
                result.add(id);
            } catch (NumberFormatException e) {
                errors.put(key, "Must be a list of numeric ids.");
            }
        }
        return result;
    }

    public PtEvaluationTab createRecord(int patientId, int visitId) {
        if (repository.findPainByVisitId(visitId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Pain data already exists for this visit.");
        }
        repository.insertBlankRecord(visitId);
        return build(patientId, visitId, "pain");
    }
}
