package org.nemours.gaitlab.service;

import java.util.List;

/**
 * Shared response shape for the five read-only PT evaluation tabs ported from
 * lab/data/pt-eval-{prom,orth,mc,tone,pain}.jsp (Gait / non-movement-disorder visits only).
 * Each tab's service builds the sections; a generic frontend renderer displays them.
 */
public record PtEvaluationTab(
        Integer patientId, Integer visitId, String tab,
        boolean hasData, String emptyMessage,
        List<Section> sections, PtEvaluationActions actions) {

    /** Returns a copy of this response with the given actions attached - lets the tab-dispatch
     * layer own role/movement-disorder gating without the individual tab services (which don't
     * know about the current user) needing to. */
    public PtEvaluationTab withActions(PtEvaluationActions actions) {
        return new PtEvaluationTab(patientId, visitId, tab, hasData, emptyMessage, sections, actions);
    }

    public record ColumnGroup(String label, int span) {
    }

    /** Per-row actions, currently only meaningful for Orthotics rows (edit/delete the trial). */
    public record RowActions(boolean edit, boolean delete) {
    }

    public record Row(String label, List<String> cells, List<Integer> shadedCells, Integer id, RowActions actions) {
        public Row(String label, List<String> cells) {
            this(label, cells, List.of(), null, null);
        }
    }

    public record Section(
            String kind, String title,
            List<ColumnGroup> columnGroups, List<String> columns, List<Row> rows,
            List<String> items, String text, String footnote) {

        public static Section table(String title, List<ColumnGroup> columnGroups, List<String> columns,
                List<Row> rows, String footnote) {
            return new Section("table", title, columnGroups, columns, rows, null, null, footnote);
        }

        public static Section list(String title, List<String> items) {
            return new Section("list", title, null, null, null, items, null, null);
        }

        public static Section text(String title, String text) {
            return new Section("text", title, null, null, null, null, text, null);
        }
    }

    public static PtEvaluationTab empty(Integer patientId, Integer visitId, String tab, String emptyMessage) {
        return new PtEvaluationTab(patientId, visitId, tab, false, emptyMessage, List.of(), null);
    }

    public static PtEvaluationTab of(Integer patientId, Integer visitId, String tab, List<Section> sections) {
        return new PtEvaluationTab(patientId, visitId, tab, true, null, sections, null);
    }
}
