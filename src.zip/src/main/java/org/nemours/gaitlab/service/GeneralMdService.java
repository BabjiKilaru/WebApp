package org.nemours.gaitlab.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;

import org.nemours.gaitlab.repository.PtEvaluationRepository;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.repository.VisitRepository.PtGeneralMdEvaluationRow;
import org.nemours.gaitlab.service.PtEvaluationForm.Field;
import org.nemours.gaitlab.service.PtEvaluationForm.FormSection;
import org.nemours.gaitlab.service.PtEvaluationForm.Option;
import org.nemours.gaitlab.service.PtEvaluationTab.Row;
import org.nemours.gaitlab.service.PtEvaluationTab.Section;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

/**
 * Ports lab/data/pt.jsp's isMovementDisorder branch (key "general-md" in the frontend's tab
 * contract) - the "General" tab for movement-disorder visits, backed by
 * data_pt_movement_disorder instead of data_pt. No GMFM-D task table and no Other GMFM Modules
 * section - data_pt_movement_disorder has no such columns, and pt.jsp's own MD branch never
 * renders that part of the page. GMFCS here is a plain lookup label like Ambulation Scale/FMS,
 * not the CP-diagnosis-gated calculated-vs-manual logic PtEvaluationService uses for Gait - that
 * calculation depends on GMFM-D task scores, which don't exist on this table, so there is nothing
 * to calculate from; this is a deliberate simplification, not an oversight.
 *
 * <p>Uses the same generic PtEvaluationTab (label/value row) contract as every other tab, not a
 * bespoke shape - height/weight/foot measurements, Ambulation Scale, GMFCS, FMS (5m/50m/500m),
 * MACS, CFCS and Comments all render as one row apiece, matching pt.jsp's own row order exactly
 * (lines 391-527) - height/weight/foot rows are NOT gated on isMovementDisorder in that JSP, they
 * just read from the same visits columns regardless of which table the rest of the page reads.
 */
@Service
public class GeneralMdService {
    static final String EMPTY_MESSAGE = "No general data has been entered yet for this visit.";

    private final VisitRepository visits;
    private final PtEvaluationRepository repository;
    private final PtEvaluationRevision revision;

    public GeneralMdService(VisitRepository visits, PtEvaluationRepository repository,
            PtEvaluationRevision revision) {
        this.visits = visits;
        this.repository = repository;
        this.revision = revision;
    }

    public PtEvaluationTab getGeneral(int patientId, int visitId, String tab) {
        visits.findInterpretationVisitByIdAndPatientId(visitId, patientId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

        return visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(visitId, patientId)
                .map(row -> PtEvaluationTab.of(patientId, visitId, tab, List.of(buildSection(row))))
                .orElseGet(() -> PtEvaluationTab.empty(patientId, visitId, tab, EMPTY_MESSAGE));
    }

    private Section buildSection(PtGeneralMdEvaluationRow row) {
        List<Row> rows = new java.util.ArrayList<>(List.of(
                cellRow("Height (cm)", valueWithZ(row.getHeightCm(),
                        heightZ(row.getHeightCm(), row.getGender(), row.getVisitDate(), row.getDob()))),
                cellRow("Weight (kg)", valueWithZ(row.getWeightKg(),
                        weightZ(row.getWeightKg(), row.getGender(), row.getVisitDate(), row.getDob()))),
                cellRow("Right Foot Length (cm)", numStr(row.getRightFootLengthCm())),
                cellRow("Left Foot Length (cm)", numStr(row.getLeftFootLengthCm())),
                cellRow("Right Foot Width (cm)", numStr(row.getRightFootWidthCm())),
                cellRow("Left Foot Width (cm)", numStr(row.getLeftFootWidthCm())),
                cellRow("Ambulation Scale", labelDash(
                        row.getAmbScaleId() == null ? null : String.valueOf(row.getAmbScaleId()),
                        row.getAmbulationScale()))));
        // pt.jsp wraps the entire GMFCS <TR> in the same isCP(gen_diag)||isCP(diagnosis) check for
        // BOTH the Gait and movement-disorder branches (lines 454-456) - this row isn't
        // unconditional for MD the way Ambulation Scale/FMS/MACS/CFCS are.
        if (isCP(row.getGenDiag()) || isCP(row.getIcd9())) {
            rows.add(cellRow("GMFCS", labelDash(row.getGmfcsLabel(), row.getGmfcsDesc())));
        }
        rows.add(cellRow("FMS (5m)", labelDash(row.getFms5m(), row.getFms5mDesc())));
        rows.add(cellRow("FMS (50m)", labelDash(row.getFms50m(), row.getFms50mDesc())));
        rows.add(cellRow("FMS (500m)", labelDash(row.getFms500m(), row.getFms500mDesc())));
        rows.add(cellRow("MACS", labelDash(row.getMacsLabel(), row.getMacsDesc())));
        rows.add(cellRow("CFCS", labelDash(row.getCfcsLabel(), row.getCfcsDesc())));
        rows.add(cellRow("Comments", row.getComments()));
        return Section.table("General and Marker Information", null, List.of("", ""), rows, null);
    }

    /** Same CP-diagnosis check as PtEvaluationService's own isCP - duplicated rather than shared
     * since pt.jsp itself inlines this exact condition separately in both branches. */
    private static boolean isCP(Integer icd9Id) {
        return icd9Id != null && ((icd9Id >= 13 && icd9Id <= 17) || icd9Id == 119 || icd9Id == 142);
    }

    /** A single-cell Row - List.of(cell) would NPE whenever cell is null (height/weight/foot
     * measurements and comments regularly are), so this always goes through
     * Collections.singletonList, which tolerates it. */
    private static Row cellRow(String label, String cell) {
        return new Row(label, java.util.Collections.singletonList(cell));
    }

    /** "{value} (z = {score})", matching pt.jsp's height/weight rows where the z-score sits in
     * the same cell right after the raw value - null value means no row content at all. */
    private static String valueWithZ(Float value, String z) {
        if (value == null) {
            return null;
        }
        return numStr(value) + (z == null ? "" : " " + z);
    }

    private static String labelDash(String value, String description) {
        return (value == null ? "" : value) + " -- " + (description == null ? "" : description);
    }

    private static final java.text.DecimalFormat Z_FORMAT_PATTERN = new java.text.DecimalFormat("0.0");

    private static String zFormat(double value) {
        synchronized (Z_FORMAT_PATTERN) {
            return Z_FORMAT_PATTERN.format(value);
        }
    }

    /** Same growth-curve formulas as PtEvaluationService.heightZ/weightZ - duplicated rather than
     * shared because pt.jsp itself duplicates this exact block verbatim into its own
     * isMovementDisorder branch instead of factoring it out. */
    private String heightZ(Float heightCm, String gender, LocalDate visitDate, LocalDate dob) {
        if (heightCm == null) {
            return null;
        }
        if (!"Male".equals(gender) && !"Female".equals(gender)) {
            return "(z = need gender)";
        }
        if (visitDate == null || dob == null) {
            return null;
        }
        double months = ageInMonths(visitDate, dob);
        double mean;
        double std;
        if ("Male".equals(gender)) {
            mean = -260.3657 + (262.8692 - (-260.3657)) / (1.0 + 0.57774 * Math.exp(-(0.0052597 * months)));
            std = 2.02485 + (9.8984 - 2.02485) / (1.0 + 7.5227 * Math.exp(-(0.0181343 * months)));
        } else {
            mean = -82.788774 + (195.26046 - (-82.798774)) / (1.0 + 0.8455536 * Math.exp(-(0.0101596 * months)));
            std = 2.40482737 + (6.81956506 - 2.40482737) / (1.0 + 15.723074 * Math.exp(-(0.0450524084 * months)));
        }
        return "(z = " + zFormat((heightCm - mean) / std) + ")";
    }

    private String weightZ(Float weightKg, String gender, LocalDate visitDate, LocalDate dob) {
        if (weightKg == null) {
            return null;
        }
        if (!"Male".equals(gender) && !"Female".equals(gender)) {
            return "(z = N/A)";
        }
        if (visitDate == null || dob == null) {
            return null;
        }
        double months = ageInMonths(visitDate, dob);
        double mean;
        double std;
        if ("Male".equals(gender)) {
            mean = 3.7 + (146.93 - 3.736) / (1.0 + 21.068 * Math.exp(-(0.013832 * months)));
            std = 0.872199 + (13.9084 - 0.872199) / (1.0 + 59.325 * Math.exp(-(0.0338 * months)));
        } else {
            mean = 6.4032907948 + (74.129378344 - 6.4032907947) / (1.0 + 19.0375155389 * Math.exp(-(0.020912892101 * months)));
            std = 1.16994385 + (12.9379166 - 1.1699438) / (1.0 + 88.52793975 * Math.exp(-(0.041292875 * months)));
        }
        return "(z = " + zFormat((weightKg - mean) / std) + ")";
    }

    private static double ageInMonths(LocalDate visitDate, LocalDate dob) {
        long days = ChronoUnit.DAYS.between(dob, visitDate);
        return Math.round(days / 365.0 * 12);
    }

    // --- Phase 4: modify_pt.jsp's isMovementDisorder edit-form branch --------------------------

    private static final List<Option> AMB_SCALE_OPTIONS = List.of(
            new Option("1", "1"), new Option("2", "2"), new Option("3", "3"),
            new Option("4", "4"), new Option("5", "5"), new Option("6", "6"));

    public PtEvaluationForm buildForm(int patientId, int visitId) {
        PtGeneralMdEvaluationRow row = visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(visitId, patientId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No general record exists yet for this visit."));

        Field height = Field.text("height", "Height (cm)", numStr(row.getHeightCm()));
        Field weight = Field.text("weight", "Weight (kg)", numStr(row.getWeightKg()));
        Field rFootLength = Field.text("r_foot_length", "Right Foot Length (cm)", numStr(row.getRightFootLengthCm()));
        Field lFootLength = Field.text("l_foot_length", "Left Foot Length (cm)", numStr(row.getLeftFootLengthCm()));
        Field rFootWidth = Field.text("r_foot_width", "Right Foot Width (cm)", numStr(row.getRightFootWidthCm()));
        Field lFootWidth = Field.text("l_foot_width", "Left Foot Width (cm)", numStr(row.getLeftFootWidthCm()));
        Field ambScale = new Field("amb_scale", "Ambulation Scale", "radio", idStr(row.getAmbScaleId()),
                AMB_SCALE_OPTIONS, false, null, null, null, null, null);
        Field gmfcs = Field.select("gmfcs", "GMFCS", idStr(row.getGmfcsId()), toIdLabelOptions(gmfcsListEntries()));
        Field fms5 = Field.select("fms_5", "FMS (5m)", idStr(row.getFms5Id()), toIdLabelOptions(fmsListEntries()));
        Field fms50 = Field.select("fms_50", "FMS (50m)", idStr(row.getFms50Id()), toIdLabelOptions(fmsListEntries()));
        Field fms500 = Field.select("fms_500", "FMS (500m)", idStr(row.getFms500Id()),
                toIdLabelOptions(fmsListEntries()));
        Field macs = Field.select("macs", "MACS", idStr(row.getMacsId()),
                toIdLabelOptions(repository.findActiveMacsListEntries()));
        Field cfcs = Field.select("cfcs", "CFCS", idStr(row.getCfcsId()),
                toIdLabelOptions(repository.findActiveCfcsListEntries()));
        Field comments = Field.textarea("comments", "Comments", row.getComments());

        FormSection generalSection = FormSection.stack("General and Marker Information", List.of(
                height, weight, rFootLength, lFootLength, rFootWidth, lFootWidth, ambScale, gmfcs, fms5, fms50,
                fms500, macs, cfcs, comments));

        return new PtEvaluationForm("general-md", "Modify General Data", revision.of(formSnapshot(row)),
                List.of(generalSection));
    }

    private List<Map<String, Object>> gmfcsListEntries() {
        return repository.findActiveGmfcsListEntries();
    }

    private List<Map<String, Object>> fmsListEntries() {
        return repository.findActiveFmsListEntries();
    }

    private static List<Option> toIdLabelOptions(List<Map<String, Object>> rows) {
        return rows.stream().map(row -> new Option(String.valueOf(row.get("id")), (String) row.get("label")))
                .toList();
    }

    private static String idStr(Integer value) {
        return value == null ? null : String.valueOf(value);
    }

    private static String numStr(Float value) {
        return value == null ? null : String.valueOf(value);
    }

    private static Map<String, Object> formSnapshot(PtGeneralMdEvaluationRow row) {
        Map<String, Object> snapshot = new java.util.LinkedHashMap<>();
        snapshot.put("heightCm", row.getHeightCm());
        snapshot.put("weightKg", row.getWeightKg());
        snapshot.put("rightFootLengthCm", row.getRightFootLengthCm());
        snapshot.put("leftFootLengthCm", row.getLeftFootLengthCm());
        snapshot.put("rightFootWidthCm", row.getRightFootWidthCm());
        snapshot.put("leftFootWidthCm", row.getLeftFootWidthCm());
        snapshot.put("ambScaleId", row.getAmbScaleId());
        snapshot.put("gmfcsId", row.getGmfcsId());
        snapshot.put("fms5Id", row.getFms5Id());
        snapshot.put("fms50Id", row.getFms50Id());
        snapshot.put("fms500Id", row.getFms500Id());
        snapshot.put("macsId", row.getMacsId());
        snapshot.put("cfcsId", row.getCfcsId());
        snapshot.put("comments", row.getComments());
        return snapshot;
    }

    @Transactional
    public PtEvaluationTab save(int patientId, int visitId, String submittedRevision,
            Map<String, Object> values) {
        PtGeneralMdEvaluationRow row = visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(visitId, patientId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No general record exists yet for this visit."));

        if (!revision.of(formSnapshot(row)).equals(submittedRevision)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "This data has changed since you loaded it. Reload and try again.");
        }

        Map<String, String> errors = new java.util.LinkedHashMap<>();
        Float height = resolveFloat(values, "height", row.getHeightCm(), errors);
        Float weight = resolveFloat(values, "weight", row.getWeightKg(), errors);
        Float rFootLength = resolveFloat(values, "r_foot_length", row.getRightFootLengthCm(), errors);
        Float lFootLength = resolveFloat(values, "l_foot_length", row.getLeftFootLengthCm(), errors);
        Float rFootWidth = resolveFloat(values, "r_foot_width", row.getRightFootWidthCm(), errors);
        Float lFootWidth = resolveFloat(values, "l_foot_width", row.getLeftFootWidthCm(), errors);
        Integer ambScale = resolveFromSet(values, "amb_scale", row.getAmbScaleId(),
                java.util.Set.of(1, 2, 3, 4, 5, 6), errors);
        Integer gmfcs = resolveLookupId(values, "gmfcs", row.getGmfcsId(), repository::existsGmfcsListEntry,
                errors);
        Integer fms5 = resolveLookupId(values, "fms_5", row.getFms5Id(), repository::existsFmsListEntry,
                errors);
        Integer fms50 = resolveLookupId(values, "fms_50", row.getFms50Id(), repository::existsFmsListEntry,
                errors);
        Integer fms500 = resolveLookupId(values, "fms_500", row.getFms500Id(), repository::existsFmsListEntry,
                errors);
        Integer macs = resolveLookupId(values, "macs", row.getMacsId(), repository::existsMacsListEntry, errors);
        Integer cfcs = resolveLookupId(values, "cfcs", row.getCfcsId(), repository::existsCfcsListEntry, errors);
        String comments = resolveText(values, "comments", row.getComments());

        if (!errors.isEmpty()) {
            throw new PtEvaluationValidationException("Some general fields are invalid.", errors);
        }

        repository.updateVisitMeasurements(visitId, height, weight, rFootLength, lFootLength, rFootWidth,
                lFootWidth);
        repository.updateDataPtMovementDisorder(row.getDataPtMdId(), ambScale, gmfcs, fms5, fms50, fms500, macs,
                cfcs, comments);

        return getGeneral(patientId, visitId, "general-md");
    }

    private static String resolveText(Map<String, Object> values, String key, String currentValue) {
        if (!values.containsKey(key)) {
            return currentValue;
        }
        Object raw = values.get(key);
        String submitted = raw == null ? null : raw.toString();
        return (submitted == null || submitted.isEmpty()) ? null : submitted;
    }

    private static Float resolveFloat(Map<String, Object> values, String key, Float currentValue,
            Map<String, String> errors) {
        if (!values.containsKey(key)) {
            return currentValue;
        }
        Object raw = values.get(key);
        String submitted = raw == null ? null : raw.toString();
        if (submitted == null || submitted.isEmpty()) {
            return null;
        }
        try {
            return Float.parseFloat(submitted);
        } catch (NumberFormatException e) {
            errors.put(key, "Must be a number.");
            return currentValue;
        }
    }

    private static Integer resolveInt(Map<String, Object> values, String key, Integer currentValue,
            Map<String, String> errors) {
        if (!values.containsKey(key)) {
            return currentValue;
        }
        Object raw = values.get(key);
        String submitted = raw == null ? null : raw.toString();
        if (submitted == null || submitted.isEmpty()) {
            return null;
        }
        try {
            return Integer.parseInt(submitted);
        } catch (NumberFormatException e) {
            errors.put(key, "Must be a whole number.");
            return currentValue;
        }
    }

    private static Integer resolveFromSet(Map<String, Object> values, String key, Integer currentValue,
            java.util.Set<Integer> allowed, Map<String, String> errors) {
        Integer resolved = resolveInt(values, key, currentValue, errors);
        if (resolved != null && !allowed.contains(resolved)) {
            errors.put(key, "Invalid value.");
            return currentValue;
        }
        return resolved;
    }

    private interface IdExists {
        boolean test(int id);
    }

    private static Integer resolveLookupId(Map<String, Object> values, String key, Integer currentValue,
            IdExists exists, Map<String, String> errors) {
        Integer resolved = resolveInt(values, key, currentValue, errors);
        if (resolved != null && !exists.test(resolved)) {
            errors.put(key, "Unknown value.");
            return currentValue;
        }
        return resolved;
    }

    public PtEvaluationTab createRecord(int patientId, int visitId) {
        if (visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(visitId, patientId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "General data already exists for this visit.");
        }
        repository.insertBlankDataPtMovementDisorder(visitId);
        return getGeneral(patientId, visitId, "general-md");
    }
}
