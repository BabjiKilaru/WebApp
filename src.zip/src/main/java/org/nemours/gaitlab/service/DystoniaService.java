package org.nemours.gaitlab.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.nemours.gaitlab.repository.PtEvaluationRepository;
import org.nemours.gaitlab.service.PtEvaluationForm.Field;
import org.nemours.gaitlab.service.PtEvaluationForm.FormSection;
import org.nemours.gaitlab.service.PtEvaluationForm.Option;
import org.nemours.gaitlab.service.PtEvaluationTab.Row;
import org.nemours.gaitlab.service.PtEvaluationTab.Section;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

/** Ports pt-eval-dystonia-scale.jsp/modify_pt_dystonia_scale.jsp - the Dystonia Scale tab,
 * movement-disorder visits only. One "Score" column (not Right/Left) - Eyes/Mouth/Neck/Trunk are
 * unilateral (one value per row); UE/LE are bilateral and show as "Right: ...\nLeft: ..." in that
 * SAME single cell (pt-eval-dystonia-scale.jsp:143-160 renders both as separate &lt;p&gt;s inside
 * one &lt;TD&gt;, not two columns). Row label is "{item}: {longdesc}". */
@Service
public class DystoniaService {
    private static final int UE_VALUE = 5;
    private static final int LE_VALUE = 6;

    private final PtEvaluationRepository repository;
    private final PtEvaluationRevision revision;

    public DystoniaService(PtEvaluationRepository repository, PtEvaluationRevision revision) {
        this.repository = repository;
        this.revision = revision;
    }

    public PtEvaluationTab build(int patientId, int visitId, String tab) {
        Optional<Map<String, Object>> scale = repository.findDystoniaScaleByVisitId(visitId);
        if (scale.isEmpty()) {
            return PtEvaluationTab.empty(patientId, visitId, tab, "No Dystonia scores entered.");
        }

        List<Map<String, Object>> items = repository.findDystoniaItems();
        List<Row> rows = new ArrayList<>();
        for (Map<String, Object> item : items) {
            int itemValue = (int) item.get("value");
            String label = rowLabel(item);
            String score;
            if (itemValue == UE_VALUE || itemValue == LE_VALUE) {
                Integer right = column(scale.get(), itemValue, "r");
                Integer left = column(scale.get(), itemValue, "l");
                score = "Right: " + cell(right) + "\nLeft: " + cell(left);
            } else {
                Integer value = column(scale.get(), itemValue, null);
                score = cell(value);
            }
            rows.add(new Row(label, java.util.Collections.singletonList(score)));
        }
        Section section = Section.table(null, null, List.of("", "Score"), rows, null);
        return PtEvaluationTab.of(patientId, visitId, tab, List.of(section));
    }

    private static String rowLabel(Map<String, Object> item) {
        return item.get("item") + ": " + item.get("longdesc");
    }

    private String cell(Integer selectionId) {
        return selectionId == null ? "--" : formatSelection(selectionId);
    }

    private String formatSelection(int selectionId) {
        return repository.findDystoniaSelectionById(selectionId).map(DystoniaService::selectionLabel).orElse("--");
    }

    /** "{value}={selection}", "*" for a null value ("Unable to assess...") - matches
     * modify_pt_dystonia_scale.jsp's own `hs.getValue() == null ? "*" : hs.getValue()` exactly. */
    private static String selectionLabel(Map<String, Object> selection) {
        Object value = selection.get("value");
        return (value == null ? "*" : value) + "=" + selection.get("selection");
    }

    /** item value 1-4 (Eyes/Mouth/Neck/Trunk) -> eyes/mouth/neck/trunk (side is ignored); 5 (UE)
     * -> uer/uel; 6 (LE) -> ler/lel. Matches DystoniaScale's own column layout. */
    private static Integer column(Map<String, Object> scale, int itemValue, String side) {
        String column = switch (itemValue) {
            case 1 -> "eyes";
            case 2 -> "mouth";
            case 3 -> "neck";
            case 4 -> "trunk";
            case 5 -> "r".equals(side) ? "uer" : "uel";
            case 6 -> "r".equals(side) ? "ler" : "lel";
            default -> throw new IllegalArgumentException("Unknown dystonia item value " + itemValue);
        };
        return (Integer) scale.get(column);
    }

    public PtEvaluationForm buildForm(int visitId) {
        Map<String, Object> scale = repository.findDystoniaScaleByVisitId(visitId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No Dystonia Scale record exists yet for this visit."));

        List<Map<String, Object>> items = repository.findDystoniaItems();
        List<Field> fields = new ArrayList<>();
        for (Map<String, Object> item : items) {
            int itemId = (int) item.get("id");
            int itemValue = (int) item.get("value");
            String label = rowLabel(item);
            List<Option> rawOptions = toOptions(repository.findDystoniaSelectionsForItem(itemId));
            if (itemValue == UE_VALUE || itemValue == LE_VALUE) {
                Integer right = column(scale, itemValue, "r");
                Integer left = column(scale, itemValue, "l");
                fields.add(Field.radio(columnName(itemValue, "r"), label + " Right",
                        right == null ? null : String.valueOf(right), optionsIncluding(rawOptions, right)));
                fields.add(Field.radio(columnName(itemValue, "l"), label + " Left",
                        left == null ? null : String.valueOf(left), optionsIncluding(rawOptions, left)));
            } else {
                Integer value = column(scale, itemValue, null);
                fields.add(Field.radio(columnName(itemValue, null), label,
                        value == null ? null : String.valueOf(value), optionsIncluding(rawOptions, value)));
            }
        }

        return new PtEvaluationForm("dystonia-scale", "Edit Dystonia Scale Values", revision.of(scale),
                List.of(FormSection.stack(null, fields)));
    }

    private static List<Option> toOptions(List<Map<String, Object>> selections) {
        return selections.stream()
                .map(selection -> new Option(String.valueOf(selection.get("id")), selectionLabel(selection)))
                .toList();
    }

    private static String columnName(int itemValue, String side) {
        return switch (itemValue) {
            case 1 -> "eyes";
            case 2 -> "mouth";
            case 3 -> "neck";
            case 4 -> "trunk";
            case 5 -> "r".equals(side) ? "uer" : "uel";
            case 6 -> "r".equals(side) ? "ler" : "lel";
            default -> throw new IllegalArgumentException("Unknown dystonia item value " + itemValue);
        };
    }

    private List<Option> optionsIncluding(List<Option> selections, Integer currentId) {
        List<Option> options = new ArrayList<>(selections);
        boolean hasCurrent = currentId == null
                || options.stream().anyMatch(option -> option.value().equals(String.valueOf(currentId)));
        if (!hasCurrent) {
            repository.findDystoniaSelectionById(currentId).ifPresent(selection -> options.add(0,
                    new Option(String.valueOf(currentId), selectionLabel(selection))));
        }
        return options;
    }

    @Transactional
    public PtEvaluationTab save(int patientId, int visitId, String submittedRevision, Map<String, Object> values) {
        Map<String, Object> scale = repository.findDystoniaScaleByVisitId(visitId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No Dystonia Scale record exists yet for this visit."));

        if (!revision.of(scale).equals(submittedRevision)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "This data has changed since you loaded it. Reload and try again.");
        }

        List<Map<String, Object>> items = repository.findDystoniaItems();
        Map<String, String> errors = new java.util.LinkedHashMap<>();
        Map<String, Integer> resolved = new java.util.LinkedHashMap<>();
        for (Map<String, Object> item : items) {
            int itemId = (int) item.get("id");
            int itemValue = (int) item.get("value");
            if (itemValue == UE_VALUE || itemValue == LE_VALUE) {
                for (String side : List.of("r", "l")) {
                    String key = columnName(itemValue, side);
                    Integer current = column(scale, itemValue, side);
                    resolved.put(key, resolveLookupId(values, key, current,
                            id -> repository.existsDystoniaSelectionForItem(itemId, id), errors));
                }
            } else {
                String key = columnName(itemValue, null);
                Integer current = column(scale, itemValue, null);
                resolved.put(key, resolveLookupId(values, key, current,
                        id -> repository.existsDystoniaSelectionForItem(itemId, id), errors));
            }
        }

        if (!errors.isEmpty()) {
            throw new PtEvaluationValidationException("Some Dystonia Scale values are invalid.", errors);
        }

        repository.updateDystoniaScale((int) scale.get("id"), resolved.get("eyes"), resolved.get("mouth"),
                resolved.get("neck"), resolved.get("trunk"), resolved.get("uel"), resolved.get("uer"),
                resolved.get("lel"), resolved.get("ler"));

        return build(patientId, visitId, "dystonia-scale");
    }

    private interface IdExists {
        boolean test(int id);
    }

    private static Integer resolveLookupId(Map<String, Object> values, String key, Integer currentValue,
            IdExists exists, Map<String, String> errors) {
        if (!values.containsKey(key)) {
            return currentValue;
        }
        Object raw = values.get(key);
        String submitted = raw == null ? null : raw.toString();
        if (submitted == null || submitted.isEmpty()) {
            return null;
        }
        Integer resolvedValue;
        try {
            resolvedValue = Integer.parseInt(submitted);
        } catch (NumberFormatException e) {
            errors.put(key, "Must be a whole number.");
            return currentValue;
        }
        if (!exists.test(resolvedValue)) {
            errors.put(key, "Unknown value.");
            return currentValue;
        }
        return resolvedValue;
    }

    public PtEvaluationTab createRecord(int patientId, int visitId) {
        if (repository.findDystoniaScaleByVisitId(visitId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Dystonia Scale data already exists for this visit.");
        }
        repository.insertBlankDystoniaScale(visitId);
        return build(patientId, visitId, "dystonia-scale");
    }
}
