package org.nemours.gaitlab.service;

import java.util.List;

import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.repository.VisitRepository.InterpretationVisit;
import org.nemours.gaitlab.requests.SavePtEvaluationFormRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

/** Dispatches GET/PUT/POST /api/patients/{patientId}/visits/{visitId}/pt-evaluation/{tab}(/form|
 * /record) to the right tab service, for both Gait and movement-disorder visits. Phase 2: only
 * Motor Control and Tone have form/save/create-record wired up so far for Gait - the other cases
 * 404 until their turn. */
@Service
public class PtEvaluationTabsService {
    private final VisitRepository visits;
    private final PromStrengthService promStrength;
    private final OrthosesService orthoses;
    private final MotorControlToneService motorControlTone;
    private final PainService pain;
    private final HatService hat;
    private final DystoniaService dystonia;

    public PtEvaluationTabsService(VisitRepository visits, PromStrengthService promStrength,
            OrthosesService orthoses, MotorControlToneService motorControlTone, PainService pain, HatService hat,
            DystoniaService dystonia) {
        this.visits = visits;
        this.promStrength = promStrength;
        this.orthoses = orthoses;
        this.motorControlTone = motorControlTone;
        this.pain = pain;
        this.hat = hat;
        this.dystonia = dystonia;
    }

    /** GET .../pt-evaluation/tabs - order and labels match pt-tab-header.jsp exactly. */
    public PtEvaluationTabList getTabs(int patientId, int visitId) {
        boolean movementDisorder = isMovementDisorder(patientId, visitId);
        List<PtEvaluationTabList.TabEntry> tabs = movementDisorder
                ? List.of(
                        new PtEvaluationTabList.TabEntry("general-md", "General"),
                        new PtEvaluationTabList.TabEntry("prom-strength", "PROM/Strength"),
                        new PtEvaluationTabList.TabEntry("orthotics", "Orthotics"),
                        new PtEvaluationTabList.TabEntry("tone", "Tone"),
                        new PtEvaluationTabList.TabEntry("pain", "Pain"),
                        new PtEvaluationTabList.TabEntry("hat", "HAT"),
                        new PtEvaluationTabList.TabEntry("dystonia-scale", "Dystonia Scale"))
                : List.of(
                        new PtEvaluationTabList.TabEntry("general", "General & GMFM"),
                        new PtEvaluationTabList.TabEntry("prom-strength", "PROM/Strength"),
                        new PtEvaluationTabList.TabEntry("orthotics", "Orthotics"),
                        new PtEvaluationTabList.TabEntry("motor-control", "Motor Control"),
                        new PtEvaluationTabList.TabEntry("tone", "Tone"),
                        new PtEvaluationTabList.TabEntry("pain", "Pain"));
        return new PtEvaluationTabList(movementDisorder, tabs);
    }

    private boolean isMovementDisorder(int patientId, int visitId) {
        Integer visitTypeId = requireVisit(patientId, visitId).getVisitTypeId();
        return PtEvaluationActions.isMovementDisorder(visitTypeId);
    }

    public PtEvaluationTab get(int patientId, int visitId, String tab, boolean isAdmin) {
        boolean movementDisorder = isMovementDisorder(patientId, visitId);

        PtEvaluationTab result = switch (tab) {
            case "prom-strength" -> promStrength.build(patientId, visitId, tab, movementDisorder);
            case "orthotics" -> orthoses.build(patientId, visitId, tab, isAdmin, movementDisorder);
            case "motor-control" -> motorControlTone.buildMotorControl(patientId, visitId, tab);
            case "tone" -> motorControlTone.buildTone(patientId, visitId, tab, movementDisorder);
            case "pain" -> pain.build(patientId, visitId, tab);
            case "hat" -> hat.build(patientId, visitId, tab);
            case "dystonia-scale" -> dystonia.build(patientId, visitId, tab);
            default -> throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        };
        return result.withActions(actionsFor(tab, isAdmin, movementDisorder, patientId, visitId));
    }

    public PtEvaluationForm getForm(int patientId, int visitId, String tab) {
        boolean movementDisorder = isMovementDisorder(patientId, visitId);
        return switch (tab) {
            case "motor-control" -> motorControlTone.buildMotorControlForm(visitId);
            case "tone" -> motorControlTone.buildToneForm(visitId, movementDisorder);
            case "pain" -> pain.buildForm(patientId, visitId);
            case "prom-strength" -> promStrength.buildForm(visitId, movementDisorder);
            case "hat" -> hat.buildForm(visitId);
            case "dystonia-scale" -> dystonia.buildForm(visitId);
            case "orthotics" -> movementDisorder ? orthoses.buildCommentsForm(patientId, visitId)
                    : throwNotFound();
            default -> throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        };
    }

    private static <T> T throwNotFound() {
        throw new ResponseStatusException(HttpStatus.NOT_FOUND);
    }

    /** edit is admin-only for PROM/Strength only, same as the view's actions.edit rule -
     * enforced here too since legacy's own server-side insert/update code has no such check at
     * all, this is purely this port's added guardrail. Movement-disorder Orthotics Comments is
     * deliberately NOT admin-gated here either, matching pt-eval-orth.jsp's own textarea/Save. */
    public PtEvaluationTab saveForm(int patientId, int visitId, String tab, boolean isAdmin,
            SavePtEvaluationFormRequest request) {
        boolean movementDisorder = isMovementDisorder(patientId, visitId);
        if (tab.equals("prom-strength") && !isAdmin) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        }
        PtEvaluationTab result = switch (tab) {
            case "motor-control" ->
                motorControlTone.saveMotorControl(patientId, visitId, request.revision(), request.values());
            case "tone" -> motorControlTone.saveTone(patientId, visitId, request.revision(), request.values(),
                    movementDisorder);
            case "pain" -> pain.save(patientId, visitId, request.revision(), request.values());
            case "prom-strength" -> promStrength.save(patientId, visitId, request.revision(), request.values(),
                    movementDisorder);
            case "hat" -> hat.save(patientId, visitId, request.revision(), request.values());
            case "dystonia-scale" -> dystonia.save(patientId, visitId, request.revision(), request.values());
            case "orthotics" -> movementDisorder
                    ? orthoses.saveComments(patientId, visitId, request.revision(), request.values())
                    : throwNotFound();
            default -> throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        };
        return result.withActions(actionsFor(tab, isAdmin, movementDisorder, patientId, visitId));
    }

    public PtEvaluationTab createRecord(int patientId, int visitId, String tab, boolean isAdmin) {
        boolean movementDisorder = isMovementDisorder(patientId, visitId);
        if (!isAdmin) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        }
        PtEvaluationTab result = switch (tab) {
            case "motor-control" -> motorControlTone.createMotorControlRecord(patientId, visitId);
            case "tone" -> motorControlTone.createToneRecord(patientId, visitId, movementDisorder);
            case "pain" -> pain.createRecord(patientId, visitId);
            case "prom-strength" -> promStrength.createRecord(patientId, visitId, movementDisorder);
            case "hat" -> hat.createRecord(patientId, visitId);
            case "dystonia-scale" -> dystonia.createRecord(patientId, visitId);
            case "orthotics" -> movementDisorder ? orthoses.createCommentsRecord(patientId, visitId)
                    : throwNotFound();
            default -> throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        };
        return result.withActions(actionsFor(tab, isAdmin, movementDisorder, patientId, visitId));
    }

    private InterpretationVisit requireVisit(int patientId, int visitId) {
        return visits.findInterpretationVisitByIdAndPatientId(visitId, patientId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    /**
     * create (Create New Record) is admin-only on every tab. edit is admin-only only for
     * PROM/Strength's "Edit Data" - Motor Control/Tone/Pain values are editable by any
     * authenticated user once a record exists. add (Add an Orthosis) is admin-only. report (the
     * Comparison Report button) is always false here - pt.jsp (General) is the only legacy page
     * with that button; none of these tab pages have it.
     *
     * <p>Orthotics on a movement-disorder visit is a special case: create is admin-only AND only
     * when no data_pt_movement_disorder row exists yet; edit (the Comments textarea/Save) has no
     * admin gate and is only true once that row exists - pt-eval-orth.jsp:206-228. Gait Orthotics
     * keeps its own create:false/edit:false (Add an Orthosis is a separate add-only action).
     */
    private PtEvaluationActions actionsFor(String tab, boolean isAdmin, boolean movementDisorder, int patientId,
            int visitId) {
        if (tab.equals("orthotics")) {
            if (!movementDisorder) {
                return new PtEvaluationActions(false, false, isAdmin, false);
            }
            return new PtEvaluationActions(orthoses.commentsCreatable(patientId, visitId, isAdmin),
                    orthoses.commentsEditable(patientId, visitId), isAdmin, false);
        }
        return switch (tab) {
            case "prom-strength" -> new PtEvaluationActions(isAdmin, isAdmin, false, false);
            default -> new PtEvaluationActions(isAdmin, true, false, false);
        };
    }
}
