package org.nemours.gaitlab.service;

import java.util.List;

/** Ports lab/reports/eval-report_combined_new.jsp (+ its _p2.jsp continuation and
 * comp_report-gmfm_gmfcs.jsp include) - the "View Printable Comparison Report" button on
 * pt.jsp. Reuses PtEvaluationTab's Section/Row/ColumnGroup shape, per the write-endpoint spec. */
public record ComparisonReport(String title, List<HeaderEntry> header, List<PtEvaluationTab.Section> sections) {

    public record HeaderEntry(String label, String value) {
    }
}
