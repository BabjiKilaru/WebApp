package org.nemours.gaitlab.service;

/**
 * Display-formatting rules shared by the PT evaluation tab ports (pt-eval-prom.jsp and friends).
 * Each legacy page repeats these same ternaries dozens of times; centralizing them here is the
 * only way to port them exactly without 1000 lines of copy-pasted ternaries.
 */
final class PtEvaluationFormat {
    private PtEvaluationFormat() {
    }

    private static final String WNL_SENTINEL = "999";

    /** True when a blank cell (null in the response) should be produced because neither the
     * measurement nor its interpretation has anything to show. */
    private static boolean bothBlank(Object value, String interp) {
        return value == null && isBlank(interp);
    }

    private static boolean isBlank(String s) {
        return s == null || s.isEmpty();
    }

    /** hip_flex_r / hip_flex_r_interp style cell: an integer angle, "999" => "WNL", "value [interp]". */
    static String angleCell(Integer value, String interp) {
        if (bothBlank(value, interp)) {
            return null;
        }
        String v = value == null ? "" : (value == 999 ? "WNL" : String.valueOf(value));
        return v + " [" + (interp == null ? "" : interp) + "]";
    }

    /** Strength-grade style cell: a free-text grade (e.g. "4+"), literal "999" => "WNL". */
    static String gradeCell(String value, String interp) {
        if (bothBlank(value, interp)) {
            return null;
        }
        String v = value == null ? "" : (WNL_SENTINEL.equals(value) ? "WNL" : value);
        return v + " [" + (interp == null ? "" : interp) + "]";
    }

    /** q_angle style cell: "999" => "WNL", otherwise a "+" prefix on non-negative values. */
    static String signedAngleCell(Integer value, String interp) {
        if (bothBlank(value, interp)) {
            return null;
        }
        String v;
        if (value == null) {
            v = "";
        } else if (value == 999) {
            v = "WNL";
        } else {
            v = value >= 0 ? "+" + value : String.valueOf(value);
        }
        return v + " [" + (interp == null ? "" : interp) + "]";
    }

    /** Pop angle style cell: a "low -- high [interp]" range, "999" => "WNL" on the low value only
     * (the legacy page never applies the WNL check to the high value). */
    static String rangeCell(Integer low, Integer high, String interp) {
        if (low == null && high == null && isBlank(interp)) {
            return null;
        }
        String lowStr = low == null ? "" : (low == 999 ? "WNL" : String.valueOf(low));
        String highStr = high == null ? "" : String.valueOf(high);
        return lowStr + " -- " + highStr + " [" + (interp == null ? "" : interp) + "]";
    }

    /** Leg length style cell: a plain real number, no interpretation bracket. The legacy page's
     * "999" check compares a Float's toString() ("999.0") against the literal "999" and so never
     * actually fires for this column; that's not reproduced here since it's a dead rule, not a
     * display format. */
    static String plainNumberCell(Float value) {
        if (value == null) {
            return null;
        }
        if (value == Math.floor(value) && !value.isInfinite()) {
            return String.valueOf(value.intValue());
        }
        return String.valueOf(value);
    }

    /** A plain cell with no formatting rules at all (Motor Control / Tone score and interp cells). */
    static String plainCell(String value) {
        return isBlank(value) ? null : value;
    }
}
