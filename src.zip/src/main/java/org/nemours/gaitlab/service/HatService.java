package org.nemours.gaitlab.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.nemours.gaitlab.repository.PtEvaluationRepository;
import org.nemours.gaitlab.service.PtEvaluationForm.Field;
import org.nemours.gaitlab.service.PtEvaluationForm.FormRow;
import org.nemours.gaitlab.service.PtEvaluationForm.FormSection;
import org.nemours.gaitlab.service.PtEvaluationForm.Option;
import org.nemours.gaitlab.service.PtEvaluationTab.Row;
import org.nemours.gaitlab.service.PtEvaluationTab.Section;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

/** Ports pt-eval-hat.jsp/modify_pt_hat.jsp - the HAT tab, movement-disorder visits only. Scored
 * once per limb (PtEvaluationRepository.ULLR_OPTIONS: UER, LER, UEL, LEL - that exact order, matching both
 * legacy pages' own column order), via hat_scores.ullr - aligned with production's schema in a
 * Phase 4 audit fix; see PtEvaluationRepository's HAT section javadoc. */
@Service
public class HatService {
    private final PtEvaluationRepository repository;
    private final PtEvaluationRevision revision;

    public HatService(PtEvaluationRepository repository, PtEvaluationRevision revision) {
        this.repository = repository;
        this.revision = revision;
    }

    public PtEvaluationTab build(int patientId, int visitId, String tab) {
        List<Map<String, Object>> rows = repository.findHatScoresByVisitId(visitId);
        if (rows.isEmpty()) {
            return PtEvaluationTab.empty(patientId, visitId, tab, "No HAT scores entered.");
        }
        Map<String, Map<String, Object>> byUllr = byUllr(rows);

        List<String> columns = new ArrayList<>();
        columns.add("");
        PtEvaluationRepository.ULLR_OPTIONS.forEach(ullr -> columns.add(ullr + " Score"));

        List<Row> tabRows = new ArrayList<>();
        for (Map<String, Object> item : repository.findHatItems()) {
            int itemValue = (int) item.get("value");
            List<String> cells = new ArrayList<>();
            for (String ullr : PtEvaluationRepository.ULLR_OPTIONS) {
                Map<String, Object> scores = byUllr.get(ullr);
                Integer selectionId = scores == null ? null : hatColumn(scores, itemValue);
                // Legacy prints nothing at all when unset (pt-eval-hat.jsp:153) - not "--".
                cells.add(selectionId == null ? null : formatSelection(selectionId));
            }
            tabRows.add(new Row((String) item.get("item"), cells));
        }
        Section section = Section.table(null, null, columns, tabRows, null);
        return PtEvaluationTab.of(patientId, visitId, tab, List.of(section));
    }

    private static Map<String, Map<String, Object>> byUllr(List<Map<String, Object>> rows) {
        Map<String, Map<String, Object>> byUllr = new java.util.LinkedHashMap<>();
        for (Map<String, Object> row : rows) {
            byUllr.put((String) row.get("ullr"), row);
        }
        return byUllr;
    }

    private String formatSelection(int selectionId) {
        return repository.findHatSelectionById(selectionId)
                .map(row -> row.get("value") + "=" + row.get("selection"))
                .orElse(null);
    }

    /** hat_item.value (1-7) maps 1:1 to the hatN column, matching HatScore#getSelection/
     * setSelection in the legacy Java model exactly. */
    private static Integer hatColumn(Map<String, Object> scores, int itemValue) {
        return (Integer) scores.get("hat" + itemValue);
    }

    public PtEvaluationForm buildForm(int visitId) {
        List<Map<String, Object>> rows = repository.findHatScoresByVisitId(visitId);
        if (rows.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No HAT record exists yet for this visit.");
        }
        Map<String, Map<String, Object>> byUllr = byUllr(rows);

        List<Map<String, Object>> items = repository.findHatItems();
        List<FormRow> formRows = new ArrayList<>();
        for (Map<String, Object> item : items) {
            int itemId = (int) item.get("id");
            int itemValue = (int) item.get("value");
            List<Option> options = toOptions(repository.findHatSelectionsForItem(itemId));
            List<Field> fields = new ArrayList<>();
            for (String ullr : PtEvaluationRepository.ULLR_OPTIONS) {
                Map<String, Object> scores = byUllr.get(ullr);
                Integer current = scores == null ? null : hatColumn(scores, itemValue);
                fields.add(Field.radio(fieldName(ullr, itemId), item.get("item") + " " + ullr,
                        current == null ? null : String.valueOf(current),
                        optionsIncluding(options, current)));
            }
            formRows.add(new FormRow((String) item.get("item"), fields));
        }

        FormSection section = FormSection.grid(null, PtEvaluationRepository.ULLR_OPTIONS, formRows);
        return new PtEvaluationForm("hat", "Edit HAT Values", revision.of(rows), List.of(section));
    }

    /** modify_pt_hat.jsp's own radio field naming: "hi-{ullr}-{itemId}". */
    private static String fieldName(String ullr, int itemId) {
        return "hi-" + ullr + "-" + itemId;
    }

    private static List<Option> toOptions(List<Map<String, Object>> selections) {
        return selections.stream()
                .map(selection -> new Option(String.valueOf(selection.get("id")),
                        selection.get("value") + "=" + selection.get("selection")))
                .toList();
    }

    /** Always includes the row's existing selection as an option even if it's since become
     * inactive - the same current-value-fallback fix applied to Motor Control/Tone/Orthotics
     * earlier in this port. */
    private List<Option> optionsIncluding(List<Option> selections, Integer currentId) {
        List<Option> options = new ArrayList<>(selections);
        boolean hasCurrent = currentId == null
                || options.stream().anyMatch(option -> option.value().equals(String.valueOf(currentId)));
        if (!hasCurrent) {
            repository.findHatSelectionById(currentId).ifPresent(selection -> options.add(0,
                    new Option(String.valueOf(currentId), selection.get("value") + "=" + selection.get("selection"))));
        }
        return options;
    }

    @Transactional
    public PtEvaluationTab save(int patientId, int visitId, String submittedRevision, Map<String, Object> values) {
        List<Map<String, Object>> rows = repository.findHatScoresByVisitId(visitId);
        if (rows.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No HAT record exists yet for this visit.");
        }
        if (!revision.of(rows).equals(submittedRevision)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "This data has changed since you loaded it. Reload and try again.");
        }
        Map<String, Map<String, Object>> byUllr = byUllr(rows);

        List<Map<String, Object>> items = repository.findHatItems();
        Map<String, String> errors = new java.util.LinkedHashMap<>();
        for (String ullr : PtEvaluationRepository.ULLR_OPTIONS) {
            Map<String, Object> scores = byUllr.get(ullr);
            if (scores == null) {
                continue;
            }
            Integer[] resolved = new Integer[7];
            for (Map<String, Object> item : items) {
                int itemId = (int) item.get("id");
                int itemValue = (int) item.get("value");
                String key = fieldName(ullr, itemId);
                Integer current = hatColumn(scores, itemValue);
                resolved[itemValue - 1] = resolveLookupId(values, key, current,
                        id -> repository.existsHatSelectionForItem(itemId, id), errors);
            }
            if (errors.isEmpty()) {
                repository.updateHatScores((int) scores.get("id"), resolved[0], resolved[1], resolved[2],
                        resolved[3], resolved[4], resolved[5], resolved[6]);
            }
        }

        if (!errors.isEmpty()) {
            throw new PtEvaluationValidationException("Some HAT values are invalid.", errors);
        }

        return build(patientId, visitId, "hat");
    }

    private interface IdExists {
        boolean test(int id);
    }

    private static Integer resolveLookupId(Map<String, Object> values, String key, Integer currentValue,
            IdExists exists, Map<String, String> errors) {
        if (!values.containsKey(key)) {
            return currentValue;
        }
        Object raw = values.get(key);
        String submitted = raw == null ? null : raw.toString();
        if (submitted == null || submitted.isEmpty()) {
            return null;
        }
        Integer resolved;
        try {
            resolved = Integer.parseInt(submitted);
        } catch (NumberFormatException e) {
            errors.put(key, "Must be a whole number.");
            return currentValue;
        }
        if (!exists.test(resolved)) {
            errors.put(key, "Unknown value.");
            return currentValue;
        }
        return resolved;
    }

    public PtEvaluationTab createRecord(int patientId, int visitId) {
        if (!repository.findHatScoresByVisitId(visitId).isEmpty()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "HAT data already exists for this visit.");
        }
        repository.insertBlankHatScoresForAllLimbs(visitId);
        return build(patientId, visitId, "hat");
    }
}
