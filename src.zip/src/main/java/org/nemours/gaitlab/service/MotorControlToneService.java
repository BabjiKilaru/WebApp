package org.nemours.gaitlab.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

import org.nemours.gaitlab.repository.PtEvaluationRepository;
import org.nemours.gaitlab.service.PtEvaluationForm.Field;
import org.nemours.gaitlab.service.PtEvaluationForm.FormRow;
import org.nemours.gaitlab.service.PtEvaluationForm.FormSection;
import org.nemours.gaitlab.service.PtEvaluationForm.Option;
import org.nemours.gaitlab.service.PtEvaluationTab.Row;
import org.nemours.gaitlab.service.PtEvaluationTab.Section;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

/** Ports pt-eval-mc.jsp/modify_pt_mc.jsp and pt-eval-tone.jsp/modify_pt_tone.jsp, which are
 * structurally identical pages over the same data_tone table (filtered by mc_tone='mc'/'tone'
 * and joined to a different lookup table for row order). Gait visits only.
 *
 * <p>The two tabs differ in where the R/L Interp dropdown's options come from: Motor Control
 * always reads mc_list; Tone reads the shared "interp" table for ordinary tests but tone_list
 * for "*"-prefixed (interpretation-only) ones - ported from modify_pt_tone.jsp's branch, which
 * modify_pt_mc.jsp doesn't have. All three of mc_list/tone_list/interp are empty in the current
 * seed data, so every Interp dropdown has zero options from the lookup table today (plus
 * whatever the row's own current value contributes) - flagged separately, not bent here. */
@Service
public class MotorControlToneService {
    static final String MOTOR_CONTROL_EMPTY_MESSAGE = "No motor control data has been entered yet for this visit.";
    // Legacy literally has a double space here ("tone  data") - preserved exactly.
    static final String TONE_EMPTY_MESSAGE = "No tone  data has been entered yet for this visit.";
    private static final String FOOTNOTE = "* Interpretation only";
    private static final List<String> COLUMNS = List.of("", "Right", "R Interp", "Left", "L Interp");
    private static final List<String> FORM_COLUMNS = List.of("Right", "R Interp", "Left", "L Interp");

    private final PtEvaluationRepository repository;
    private final PtEvaluationRevision revision;

    public MotorControlToneService(PtEvaluationRepository repository, PtEvaluationRevision revision) {
        this.repository = repository;
        this.revision = revision;
    }

    public PtEvaluationTab buildMotorControl(int patientId, int visitId, String tab) {
        return build(patientId, visitId, tab, repository.findMotorControlByVisitId(visitId), MOTOR_CONTROL_EMPTY_MESSAGE);
    }

    public PtEvaluationTab buildTone(int patientId, int visitId, String tab) {
        return buildTone(patientId, visitId, tab, false);
    }

    /** pt-movement-disorder-eval-tone.jsp's test list is data_tone (filtered to tone_tests.id
     * <= 16 - see findToneByVisitIdForMovementDisorder) PLUS the 6 Upper Extremity rows (pt_ue_
     * tone) appended to the SAME table, right after the tone rows - one shared section, one
     * shared "* Interpretation only" footnote, no "Upper Extremity" sub-title. Legacy's own
     * emptiness check is tones.size()==0 && ueTone==null: only "No tone data entered" when BOTH
     * are missing. */
    public PtEvaluationTab buildTone(int patientId, int visitId, String tab, boolean isMovementDisorder) {
        if (!isMovementDisorder) {
            return build(patientId, visitId, tab, repository.findToneByVisitId(visitId), TONE_EMPTY_MESSAGE);
        }

        List<Map<String, Object>> toneRows = repository.findToneByVisitIdForMovementDisorder(visitId);
        Optional<Map<String, Object>> ueTone = repository.findUeToneByVisitId(visitId);
        if (toneRows.isEmpty() && ueTone.isEmpty()) {
            return PtEvaluationTab.empty(patientId, visitId, tab, TONE_EMPTY_MESSAGE);
        }
        List<Row> rows = new ArrayList<>(toneRows.stream().map(this::toRow).toList());
        ueTone.ifPresent(tone -> rows.addAll(ueToneRows(tone)));
        Section section = Section.table(null, null, COLUMNS, rows, FOOTNOTE);
        return PtEvaluationTab.of(patientId, visitId, tab, List.of(section));
    }

    private static final List<UeToneMuscle> UE_TONE_MUSCLES = List.of(
            new UeToneMuscle("Shoulder extensors", "shoulder_extensors"),
            new UeToneMuscle("Shoulder flexors", "shoulder_flexors"),
            new UeToneMuscle("Elbow extensors", "elbow_extensors"),
            new UeToneMuscle("Elbow flexors", "elbow_flexors"),
            new UeToneMuscle("Wrist extensors", "wrist_extensors"),
            new UeToneMuscle("Wrist flexors", "wrist_flexors"));

    private record UeToneMuscle(String label, String prefix) {
    }

    private List<Row> ueToneRows(Map<String, Object> ueTone) {
        return UE_TONE_MUSCLES.stream()
                .map(muscle -> new Row(muscle.label(), Arrays.asList(
                        str(ueTone.get(muscle.prefix() + "_r")), str(ueTone.get(muscle.prefix() + "_r_interp")),
                        str(ueTone.get(muscle.prefix() + "_l")), str(ueTone.get(muscle.prefix() + "_l_interp")))))
                .toList();
    }

    private PtEvaluationTab build(int patientId, int visitId, String tab, List<Map<String, Object>> data,
            String emptyMessage) {
        if (data.isEmpty()) {
            return PtEvaluationTab.empty(patientId, visitId, tab, emptyMessage);
        }
        List<Row> rows = data.stream().map(this::toRow).toList();
        Section section = Section.table(null, null, COLUMNS, rows, FOOTNOTE);
        return PtEvaluationTab.of(patientId, visitId, tab, List.of(section));
    }

    // Right (0) and Left (2) are the two cell indexes legacy shades grey for a "*"-prefixed
    // (interpretation-only) test; the Interp columns (1, 3) stay visible.
    private static final List<Integer> INTERPRETATION_ONLY_SHADED_CELLS = List.of(0, 2);

    private Row toRow(Map<String, Object> data) {
        String test = (String) data.get("test");
        boolean interpretationOnly = test != null && test.startsWith("*");
        String scoreR = interpretationOnly ? null : PtEvaluationFormat.plainCell((String) data.get("score_r"));
        String scoreL = interpretationOnly ? null : PtEvaluationFormat.plainCell((String) data.get("score_l"));
        String interpR = PtEvaluationFormat.plainCell((String) data.get("interp_r"));
        String interpL = PtEvaluationFormat.plainCell((String) data.get("interp_l"));
        List<Integer> shadedCells = interpretationOnly ? INTERPRETATION_ONLY_SHADED_CELLS : List.of();
        return new Row(test, Arrays.asList(scoreR, interpR, scoreL, interpL), shadedCells, null, null);
    }

    // Legacy literally has a double space here ("Modify  Motor Control") - preserved exactly,
    // same as TONE_EMPTY_MESSAGE above.
    public PtEvaluationForm buildMotorControlForm(int visitId) {
        return buildForm("motor-control", "Modify  Motor Control", repository.findMotorControlByVisitId(visitId),
                test -> repository.findMcListOptions());
    }

    public PtEvaluationForm buildToneForm(int visitId) {
        return buildToneForm(visitId, false);
    }

    public PtEvaluationForm buildToneForm(int visitId, boolean isMovementDisorder) {
        Function<String, List<String>> interpOptionsForTest =
                test -> test.startsWith("*") ? repository.findToneListOptions() : repository.findInterpOptions();
        if (!isMovementDisorder) {
            // Legacy literally has a double space here ("Modify  Tone Data") - preserved
            // exactly. The movement-disorder branch below keeps its own generic "Edit Tone"
            // title - pt-movement-disorder-eval-tone.jsp's own heading is a copy-pasted
            // "PT Evaluation: Tone", not worth porting literally.
            return buildForm("tone", "Modify  Tone Data", repository.findToneByVisitId(visitId),
                    interpOptionsForTest);
        }

        List<Map<String, Object>> toneRows = repository.findToneByVisitIdForMovementDisorder(visitId);
        List<FormRow> rows = new ArrayList<>(toneRows.stream().map(row -> toFormRow(row, interpOptionsForTest))
                .toList());
        Map<String, Object> ueTone = repository.findUeToneByVisitId(visitId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No tone record exists yet for this visit."));
        rows.addAll(UE_TONE_MUSCLES.stream().map(muscle -> ueToneFormRow(ueTone, muscle)).toList());

        Map<String, Object> revisionSnapshot = new java.util.LinkedHashMap<>();
        revisionSnapshot.put("tone", toneRows);
        revisionSnapshot.put("ueTone", ueTone);
        FormSection section = FormSection.grid(null, FORM_COLUMNS, rows);
        return new PtEvaluationForm("tone", "Edit Tone", revision.of(revisionSnapshot), List.of(section));
    }

    /** Score is a plain text input (modify_pt_movement_disorder_tone.jsp's srX/slX fields);
     * Interp is a dropdown sourced from the same "interp" lookup table the regular Tone rows use
     * for non-"*" tests (its own interpSelect() helper, same options). */
    private FormRow ueToneFormRow(Map<String, Object> ueTone, UeToneMuscle muscle) {
        List<String> interpOptions = repository.findInterpOptions();
        String rInterp = str(ueTone.get(muscle.prefix() + "_r_interp"));
        String lInterp = str(ueTone.get(muscle.prefix() + "_l_interp"));
        Field right = Field.text(muscle.prefix() + "_r", muscle.label() + " Right", str(ueTone.get(muscle.prefix() + "_r")));
        Field rightInterp = Field.select(muscle.prefix() + "_r_interp", muscle.label() + " R Interp", rInterp,
                optionsIncluding(interpOptions, rInterp));
        Field left = Field.text(muscle.prefix() + "_l", muscle.label() + " Left", str(ueTone.get(muscle.prefix() + "_l")));
        Field leftInterp = Field.select(muscle.prefix() + "_l_interp", muscle.label() + " L Interp", lInterp,
                optionsIncluding(interpOptions, lInterp));
        return new FormRow(muscle.label(), Arrays.asList(right, rightInterp, left, leftInterp));
    }

    private PtEvaluationForm buildForm(String tab, String title, List<Map<String, Object>> data,
            Function<String, List<String>> interpOptionsForTest) {
        List<FormRow> rows = data.stream().map(row -> toFormRow(row, interpOptionsForTest)).toList();
        FormSection section = FormSection.grid(null, FORM_COLUMNS, rows);
        return new PtEvaluationForm(tab, title, revision.of(data), List.of(section));
    }

    private FormRow toFormRow(Map<String, Object> data, Function<String, List<String>> interpOptionsForTest) {
        String test = (String) data.get("test");
        int id = (Integer) data.get("id");
        boolean interpretationOnly = test != null && test.startsWith("*");
        String interpR = str(data.get("interp_r"));
        String interpL = str(data.get("interp_l"));
        List<String> interpOptions = interpOptionsForTest.apply(test);

        Field scoreR = interpretationOnly ? null
                : Field.text("score_r_" + id, test + " Right", str(data.get("score_r")));
        Field interpRField = Field.select("interp_r_" + id, test + " R Interp", interpR,
                optionsIncluding(interpOptions, interpR));
        Field scoreL = interpretationOnly ? null
                : Field.text("score_l_" + id, test + " Left", str(data.get("score_l")));
        Field interpLField = Field.select("interp_l_" + id, test + " L Interp", interpL,
                optionsIncluding(interpOptions, interpL));

        return new FormRow(test, Arrays.asList(scoreR, interpRField, scoreL, interpLField));
    }

    /** A leading blank option (so the field can be cleared), unless the lookup table already has
     * its own - mc_list/tone_list/interp all have one - plus the row's current value if it isn't
     * already in that list, since existing data like "mild" or "2+" predates these lookups. */
    private static List<Option> optionsIncluding(List<String> lookupValues, String currentValue) {
        List<Option> options = new ArrayList<>();
        if (!lookupValues.contains("")) {
            options.add(new Option("", ""));
        }
        for (String value : lookupValues) {
            options.add(new Option(value, value));
        }
        if (currentValue != null && !currentValue.isEmpty() && !lookupValues.contains(currentValue)) {
            options.add(new Option(currentValue, currentValue));
        }
        return Collections.unmodifiableList(options);
    }

    private static String str(Object value) {
        return value == null ? null : value.toString();
    }

    public PtEvaluationTab saveMotorControl(int patientId, int visitId, String submittedRevision,
            Map<String, Object> values) {
        return save(patientId, visitId, "motor-control", () -> buildMotorControl(patientId, visitId, "motor-control"),
                repository.findMotorControlByVisitId(visitId), submittedRevision, values);
    }

    public PtEvaluationTab saveTone(int patientId, int visitId, String submittedRevision,
            Map<String, Object> values) {
        return saveTone(patientId, visitId, submittedRevision, values, false);
    }

    public PtEvaluationTab saveTone(int patientId, int visitId, String submittedRevision,
            Map<String, Object> values, boolean isMovementDisorder) {
        if (!isMovementDisorder) {
            return save(patientId, visitId, "tone", () -> buildTone(patientId, visitId, "tone"),
                    repository.findToneByVisitId(visitId), submittedRevision, values);
        }

        List<Map<String, Object>> toneRows = repository.findToneByVisitIdForMovementDisorder(visitId);
        Map<String, Object> ueTone = repository.findUeToneByVisitId(visitId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No tone record exists yet for this visit."));
        Map<String, Object> revisionSnapshot = new java.util.LinkedHashMap<>();
        revisionSnapshot.put("tone", toneRows);
        revisionSnapshot.put("ueTone", ueTone);
        if (!revision.of(revisionSnapshot).equals(submittedRevision)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "This data has changed since you loaded it. Reload and try again.");
        }

        for (Map<String, Object> row : toneRows) {
            int id = (Integer) row.get("id");
            String test = (String) row.get("test");
            boolean interpretationOnly = test != null && test.startsWith("*");
            String interpR = resolve(values, "interp_r_" + id, str(row.get("interp_r")));
            String interpL = resolve(values, "interp_l_" + id, str(row.get("interp_l")));
            if (interpretationOnly) {
                repository.updateInterpOnly(id, interpR, interpL);
            } else {
                String scoreR = resolve(values, "score_r_" + id, str(row.get("score_r")));
                String scoreL = resolve(values, "score_l_" + id, str(row.get("score_l")));
                repository.updateScoreAndInterp(id, scoreR, interpR, scoreL, interpL);
            }
        }

        Map<String, String> ueUpdates = new java.util.LinkedHashMap<>();
        for (UeToneMuscle muscle : UE_TONE_MUSCLES) {
            for (String field : List.of("_r", "_r_interp", "_l", "_l_interp")) {
                String key = muscle.prefix() + field;
                ueUpdates.put(key, resolve(values, key, str(ueTone.get(key))));
            }
        }
        repository.updateUeTone((int) ueTone.get("id"), ueUpdates);

        return buildTone(patientId, visitId, "tone", true);
    }

    /** No revision check exists in legacy at all (a raw unconditional UPDATE) - this 409 is a
     * deliberate addition, not a ported behavior. Interpretation-only rows only ever touch
     * interp_r/interp_l: there's no score input to submit for them in the first place (legacy
     * replaces that cell with a grey filler), so an absent score field for those rows is
     * expected, not a client error. */
    private PtEvaluationTab save(int patientId, int visitId, String tab,
            java.util.function.Supplier<PtEvaluationTab> rebuild, List<Map<String, Object>> currentData,
            String submittedRevision, Map<String, Object> values) {
        if (!revision.of(currentData).equals(submittedRevision)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "This data has changed since you loaded it. Reload and try again.");
        }
        for (Map<String, Object> row : currentData) {
            int id = (Integer) row.get("id");
            String test = (String) row.get("test");
            boolean interpretationOnly = test != null && test.startsWith("*");
            String interpR = resolve(values, "interp_r_" + id, str(row.get("interp_r")));
            String interpL = resolve(values, "interp_l_" + id, str(row.get("interp_l")));
            if (interpretationOnly) {
                repository.updateInterpOnly(id, interpR, interpL);
            } else {
                String scoreR = resolve(values, "score_r_" + id, str(row.get("score_r")));
                String scoreL = resolve(values, "score_l_" + id, str(row.get("score_l")));
                repository.updateScoreAndInterp(id, scoreR, interpR, scoreL, interpL);
            }
        }
        return rebuild.get();
    }

    /** A missing key leaves the field untouched (so a client that only sends changed fields
     * still works); a present key with "" clears it; anything else is the new value. */
    private static String resolve(Map<String, Object> values, String key, String currentValue) {
        if (!values.containsKey(key)) {
            return currentValue;
        }
        String submitted = str(values.get(key));
        return (submitted == null || submitted.isEmpty()) ? null : submitted;
    }

    public PtEvaluationTab createMotorControlRecord(int patientId, int visitId) {
        if (!repository.findMotorControlByVisitId(visitId).isEmpty()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Motor Control data already exists for this visit.");
        }
        repository.findMcTestNames().forEach(test -> repository.insertBlankRow(visitId, test, "mc"));
        return buildMotorControl(patientId, visitId, "motor-control");
    }

    public PtEvaluationTab createToneRecord(int patientId, int visitId) {
        return createToneRecord(patientId, visitId, false);
    }

    public PtEvaluationTab createToneRecord(int patientId, int visitId, boolean isMovementDisorder) {
        boolean hasTone = !repository.findToneByVisitId(visitId).isEmpty();
        boolean hasUeTone = isMovementDisorder && repository.findUeToneByVisitId(visitId).isPresent();
        if (hasTone || hasUeTone) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Tone data already exists for this visit.");
        }
        repository.findToneTestNames().forEach(test -> repository.insertBlankRow(visitId, test, "tone"));
        if (isMovementDisorder) {
            repository.insertBlankUeTone(visitId);
        }
        return buildTone(patientId, visitId, "tone", isMovementDisorder);
    }
}
