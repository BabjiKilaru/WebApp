package org.nemours.gaitlab.service;

import java.util.List;

/** GET .../pt-evaluation/tabs - lets the frontend build its tab nav from the backend rather than
 * guessing visit type client-side. Order and labels match pt-tab-header.jsp exactly for both
 * variants. */
public record PtEvaluationTabList(boolean movementDisorder, List<TabEntry> tabs) {

    public record TabEntry(String key, String label) {
    }
}
