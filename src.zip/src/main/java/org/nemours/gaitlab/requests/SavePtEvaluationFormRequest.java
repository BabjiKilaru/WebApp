package org.nemours.gaitlab.requests;

import java.util.Map;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record SavePtEvaluationFormRequest(
        @NotBlank String revision,
        @NotNull Map<String, Object> values) {
}
