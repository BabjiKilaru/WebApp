package org.nemours.gaitlab.controller;

import org.nemours.gaitlab.requests.SavePtEvaluationFormRequest;
import org.nemours.gaitlab.service.OrthosesService;
import org.nemours.gaitlab.service.PtEvaluationActions;
import org.nemours.gaitlab.service.PtEvaluationForm;
import org.nemours.gaitlab.service.PtEvaluationTab;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import jakarta.validation.Valid;

/** Ports insert_orth.jsp/modify_orth.jsp/delete_orth.jsp. All three write operations are
 * admin-only in legacy (the Add/Edit/Delete controls are only rendered for admins at all). */
@RestController
@RequestMapping("/api/patients/{patientId}/visits/{visitId}/pt-evaluation/orthotics")
public class OrthosesController {
    private final OrthosesService service;

    public OrthosesController(OrthosesService service) {
        this.service = service;
    }

    @GetMapping("/new/form")
    public PtEvaluationForm newForm(@PathVariable int patientId, @PathVariable int visitId) {
        return service.buildNewForm(visitId);
    }

    @PostMapping("/new/form")
    public PtEvaluationTab create(@PathVariable int patientId, @PathVariable int visitId,
            @Valid @RequestBody SavePtEvaluationFormRequest request, Authentication authentication) {
        boolean isAdmin = PtEvaluationActions.isAdmin(authentication);
        requireAdmin(isAdmin);
        return service.createOrthosis(patientId, visitId, isAdmin, request.revision(), request.values());
    }

    @GetMapping("/{id}/form")
    public PtEvaluationForm editForm(@PathVariable int patientId, @PathVariable int visitId, @PathVariable int id) {
        return service.buildEditForm(visitId, id);
    }

    @PutMapping("/{id}/form")
    public PtEvaluationTab update(@PathVariable int patientId, @PathVariable int visitId, @PathVariable int id,
            @Valid @RequestBody SavePtEvaluationFormRequest request, Authentication authentication) {
        boolean isAdmin = PtEvaluationActions.isAdmin(authentication);
        requireAdmin(isAdmin);
        return service.updateOrthosis(patientId, visitId, id, isAdmin, request.revision(), request.values());
    }

    @DeleteMapping("/{id}")
    public PtEvaluationTab delete(@PathVariable int patientId, @PathVariable int visitId, @PathVariable int id,
            Authentication authentication) {
        boolean isAdmin = PtEvaluationActions.isAdmin(authentication);
        requireAdmin(isAdmin);
        return service.deleteOrthosis(patientId, visitId, id, isAdmin);
    }

    private static void requireAdmin(boolean isAdmin) {
        if (!isAdmin) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        }
    }
}
