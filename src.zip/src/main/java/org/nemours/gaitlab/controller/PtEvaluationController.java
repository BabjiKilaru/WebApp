package org.nemours.gaitlab.controller;

import org.nemours.gaitlab.requests.SavePtEvaluationFormRequest;
import org.nemours.gaitlab.service.ComparisonReport;
import org.nemours.gaitlab.service.ComparisonReportService;
import org.nemours.gaitlab.service.GeneralMdService;
import org.nemours.gaitlab.service.PtEvaluationActions;
import org.nemours.gaitlab.service.PtEvaluationForm;
import org.nemours.gaitlab.service.PtEvaluationService;
import org.nemours.gaitlab.service.PtEvaluationService.GeneralEvaluation;
import org.nemours.gaitlab.service.PtEvaluationTab;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/patients/{patientId}/visits/{visitId}/pt-evaluation")
public class PtEvaluationController {
    private final PtEvaluationService service;
    private final ComparisonReportService comparisonReportService;
    private final GeneralMdService generalMdService;

    public PtEvaluationController(PtEvaluationService service, ComparisonReportService comparisonReportService,
            GeneralMdService generalMdService) {
        this.service = service;
        this.comparisonReportService = comparisonReportService;
        this.generalMdService = generalMdService;
    }

    @GetMapping("/comparison-report")
    public ComparisonReport comparisonReport(@PathVariable int patientId, @PathVariable int visitId,
            @RequestParam(required = false) Integer compareVisitId1,
            @RequestParam(required = false) Integer compareVisitId2) {
        return comparisonReportService.build(patientId, visitId, compareVisitId1, compareVisitId2);
    }

    @GetMapping("/general")
    public GeneralEvaluation general(@PathVariable int patientId, @PathVariable int visitId,
            Authentication authentication) {
        boolean isAdmin = PtEvaluationActions.isAdmin(authentication);
        // Gait-only for now: movement-disorder routing (and its own hidden "report" rule) lands
        // in Phase 4, so the Comparison Report button is always shown here.
        GeneralEvaluation evaluation = service.getGeneral(patientId, visitId);
        return evaluation.withActions(new PtEvaluationActions(isAdmin, isAdmin, false, true));
    }

    @GetMapping("/general/form")
    public PtEvaluationForm generalForm(@PathVariable int patientId, @PathVariable int visitId) {
        return service.buildForm(patientId, visitId);
    }

    @PutMapping("/general/form")
    public GeneralEvaluation saveGeneralForm(@PathVariable int patientId, @PathVariable int visitId,
            @Valid @RequestBody SavePtEvaluationFormRequest request, Authentication authentication) {
        boolean isAdmin = PtEvaluationActions.isAdmin(authentication);
        if (!isAdmin) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        }
        GeneralEvaluation evaluation = service.save(patientId, visitId, request.revision(), request.values());
        return evaluation.withActions(new PtEvaluationActions(isAdmin, isAdmin, false, true));
    }

    @PostMapping("/general/record")
    public GeneralEvaluation createGeneralRecord(@PathVariable int patientId, @PathVariable int visitId,
            Authentication authentication) {
        boolean isAdmin = PtEvaluationActions.isAdmin(authentication);
        if (!isAdmin) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        }
        GeneralEvaluation evaluation = service.createRecord(patientId, visitId);
        return evaluation.withActions(new PtEvaluationActions(isAdmin, isAdmin, false, true));
    }

    // --- Phase 4: lab/data/pt.jsp's isMovementDisorder branch ("General" tab, key "general-md") -

    @GetMapping("/general-md")
    public PtEvaluationTab generalMd(@PathVariable int patientId, @PathVariable int visitId,
            Authentication authentication) {
        boolean isAdmin = PtEvaluationActions.isAdmin(authentication);
        // pt.jsp hides "View Printable Comparison Report" for movement-disorder visits outright.
        PtEvaluationTab result = generalMdService.getGeneral(patientId, visitId, "general-md");
        return result.withActions(new PtEvaluationActions(isAdmin, isAdmin, false, false));
    }

    @GetMapping("/general-md/form")
    public PtEvaluationForm generalMdForm(@PathVariable int patientId, @PathVariable int visitId) {
        return generalMdService.buildForm(patientId, visitId);
    }

    @PutMapping("/general-md/form")
    public PtEvaluationTab saveGeneralMdForm(@PathVariable int patientId, @PathVariable int visitId,
            @Valid @RequestBody SavePtEvaluationFormRequest request, Authentication authentication) {
        boolean isAdmin = PtEvaluationActions.isAdmin(authentication);
        if (!isAdmin) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        }
        PtEvaluationTab result = generalMdService.save(patientId, visitId, request.revision(), request.values());
        return result.withActions(new PtEvaluationActions(isAdmin, isAdmin, false, false));
    }

    @PostMapping("/general-md/record")
    public PtEvaluationTab createGeneralMdRecord(@PathVariable int patientId, @PathVariable int visitId,
            Authentication authentication) {
        boolean isAdmin = PtEvaluationActions.isAdmin(authentication);
        if (!isAdmin) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        }
        PtEvaluationTab result = generalMdService.createRecord(patientId, visitId);
        return result.withActions(new PtEvaluationActions(isAdmin, isAdmin, false, false));
    }
}
