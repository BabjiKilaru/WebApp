package org.nemours.gaitlab.controller;

import org.nemours.gaitlab.service.PtEvaluationValidationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/** Shared 400 response for PtEvaluationValidationException across the PT Evaluation controllers
 * (PtEvaluationController, PtEvaluationTabsController, OrthosesController), which all threw the
 * same validation exception for their respective save endpoints. */
@RestControllerAdvice
public class PtEvaluationExceptionHandler {
    @ExceptionHandler(PtEvaluationValidationException.class)
    public ResponseEntity<PtEvaluationValidationException.Response> onValidationError(
            PtEvaluationValidationException exception) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new PtEvaluationValidationException.Response(exception.getMessage(), exception.fieldErrors()));
    }
}
