package org.nemours.gaitlab.controller;
import org.nemours.gaitlab.model.Age;
import org.nemours.gaitlab.model.BodyLocation;
import org.nemours.gaitlab.model.Condition;
import org.nemours.gaitlab.model.HistoryCondition;
import org.nemours.gaitlab.model.Surgery;
import org.nemours.gaitlab.model.SeizureMedication;
import org.nemours.gaitlab.repository.AgeRepository;
import org.nemours.gaitlab.repository.BodyLocationRepository;
import org.nemours.gaitlab.repository.ConditionRepository;
import org.nemours.gaitlab.repository.FrequencyRepository;
import org.nemours.gaitlab.repository.HistoryConditionRepository;
import org.nemours.gaitlab.repository.SeizureMedicationRepository;
import org.nemours.gaitlab.repository.SurgeryRepository;
import org.nemours.gaitlab.repository.UeHistoryQuestionnaireRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reference")
public class ReferenceController {
    private final SurgeryRepository surgeryRepository;
    private final BodyLocationRepository bodyLocationRepository;
    private final AgeRepository ageRepository;
    private final ConditionRepository conditionRepository;
    private final FrequencyRepository frequencyRepository;
    private final HistoryConditionRepository historyConditionRepository;
    private final SeizureMedicationRepository seizureMedicationRepository;
    private final UeHistoryQuestionnaireRepository ueHistoryQuestionnaireRepository;

    public ReferenceController(SurgeryRepository surgeryRepository, BodyLocationRepository bodyLocationRepository, AgeRepository ageRepository, ConditionRepository conditionRepository, FrequencyRepository frequencyRepository, HistoryConditionRepository historyConditionRepository, SeizureMedicationRepository seizureMedicationRepository, UeHistoryQuestionnaireRepository ueHistoryQuestionnaireRepository) {
        this.surgeryRepository = surgeryRepository;
        this.bodyLocationRepository = bodyLocationRepository;
        this.ageRepository = ageRepository;
        this.conditionRepository = conditionRepository;
        this.frequencyRepository = frequencyRepository;
        this.historyConditionRepository = historyConditionRepository;
        this.seizureMedicationRepository = seizureMedicationRepository;
        this.ueHistoryQuestionnaireRepository = ueHistoryQuestionnaireRepository;
    }

    public record SideOption(String value, String label) {}

    @GetMapping("/surgeries")
    public List<Surgery> getSurgeries() {
        return surgeryRepository.findAllByOrderByNameAsc();
    }

    @GetMapping("surgery-sides")
    public List<SideOption> getSurgerySides() {
        return List.of(
            new SideOption("L", "Left"),
            new SideOption("R", "Right"),
            new SideOption("Both", "Both"),
            new SideOption("NA", "N/A")
        );
    }

    @GetMapping("/body-locations")
    public Object getBodyLocations(@RequestParam(required = false) String language) {
        if (language == null) {
            return bodyLocationRepository.findAllByOrderByLocationAsc().stream().map(BodyLocation::getLocation).toList();
        }
        return bodyLocationRepository.findAllWithSpanish().stream().map(row -> localized((String) row[0], (String) row[1], language)).toList();
    }

    @GetMapping("/botox-sides")
    public List<SideOption> getBotoxSides() {
        return List.of(
            new SideOption("L", "Left"),
            new SideOption("R", "Right"),
            new SideOption("Both", "Both")
        );
    }

    @GetMapping("/history-conditions")
    public Object getHistoryConditions(@RequestParam(required = false) String language) {
        if (language == null) {
            return historyConditionRepository.findAllByOrderByConditionAsc();
        }
        return historyConditionRepository.findAllWithSpanish().stream().map(row -> Map.of("code", (String) row[0], "name", labelOf((String) row[1], (String) row[2], language))).toList();
    }

    @GetMapping("/ages")
    public Object getAges(@RequestParam(required = false) String language) {
        if (language == null) {
            return ageRepository.findAllByOrderByChronAsc().stream().map(Age::getAge).toList();
        }
        return ageRepository.findAllWithSpanish().stream().map(row -> localized((String) row[0], (String) row[1], language)).toList();
    }

    @GetMapping("/conditions")
    public Object getConditions(@RequestParam(required = false) String language) {
        if (language == null) {
            return conditionRepository.findAllByOrderByConditionAsc();
        }
        return conditionRepository.findAllWithSpanish().stream().map(row -> Map.of("code", (String) row[0], "name", labelOf((String) row[1], (String) row[2], language))).toList();
    }

    @GetMapping("/frequencies")
    public List<Map<String, Object>> getFrequencies(@RequestParam(required = false) String language) {
        return frequencyRepository.findAllOrderByCodeDesc().stream().map(row -> {
            Map<String, Object> result = new LinkedHashMap<>();
            result.put("value", String.valueOf(row.get("code")));
            result.put("label", labelOf((String) row.get("freq"), (String) row.get("il8n_sp"), language));
            return result;
        })
        .toList();
    }

    @GetMapping("/seizure-meds")
    public Object getSeizureMedications(@RequestParam(required = false) String language) {
        List<SeizureMedication> medications = seizureMedicationRepository.findAllByOrderByMedAsc().stream().filter(medication -> medication.getMed() != null && !medication.getMed().isBlank()).toList();
        if (language == null) {
            return medications.stream().map(SeizureMedication::getMed).toList();
        }
        return medications.stream().map(medication -> Map.of("value", medication.getMed(), "label", medication.getMed())).toList();
    }

    @GetMapping("/ue-history-questions")
    public Map<String, Object> getUeHistoryQuestions() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("handlesObjects", ueHistoryQuestionnaireRepository.findQuestionBundle(54));
        result.put("dresses", ueHistoryQuestionnaireRepository.findQuestionBundle(55));
        result.put("bathes", ueHistoryQuestionnaireRepository.findQuestionBundle(56));
        result.put("toilets", ueHistoryQuestionnaireRepository.findQuestionBundle(57));
        result.put("armHandConcerns", ueHistoryQuestionnaireRepository.findQuestionBundle(58));
        return result;
    }

    private String labelOf(String english, String spanish, String language) {
        if ("sp".equalsIgnoreCase(language) && spanish != null && !spanish.isBlank()) {
            return spanish;
        }
        return english;
    }

    private Map<String, Object> localized(String value, String spanish, String language) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("value", value);
        result.put("label", labelOf(value, spanish, language));
        return result;
    }
}
