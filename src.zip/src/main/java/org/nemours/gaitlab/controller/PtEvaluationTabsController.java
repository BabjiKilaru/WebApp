package org.nemours.gaitlab.controller;

import org.nemours.gaitlab.requests.SavePtEvaluationFormRequest;
import org.nemours.gaitlab.service.PtEvaluationActions;
import org.nemours.gaitlab.service.PtEvaluationForm;
import org.nemours.gaitlab.service.PtEvaluationTab;
import org.nemours.gaitlab.service.PtEvaluationTabList;
import org.nemours.gaitlab.service.PtEvaluationTabsService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/patients/{patientId}/visits/{visitId}/pt-evaluation")
public class PtEvaluationTabsController {
    private final PtEvaluationTabsService service;

    public PtEvaluationTabsController(PtEvaluationTabsService service) {
        this.service = service;
    }

    @GetMapping("/tabs")
    public PtEvaluationTabList tabs(@PathVariable int patientId, @PathVariable int visitId) {
        return service.getTabs(patientId, visitId);
    }

    @GetMapping("/{tab}")
    public PtEvaluationTab tab(@PathVariable int patientId, @PathVariable int visitId, @PathVariable String tab,
            Authentication authentication) {
        return service.get(patientId, visitId, tab, PtEvaluationActions.isAdmin(authentication));
    }

    @GetMapping("/{tab}/form")
    public PtEvaluationForm form(@PathVariable int patientId, @PathVariable int visitId, @PathVariable String tab) {
        return service.getForm(patientId, visitId, tab);
    }

    @PutMapping("/{tab}/form")
    public PtEvaluationTab saveForm(@PathVariable int patientId, @PathVariable int visitId,
            @PathVariable String tab, @Valid @RequestBody SavePtEvaluationFormRequest request,
            Authentication authentication) {
        return service.saveForm(patientId, visitId, tab, PtEvaluationActions.isAdmin(authentication), request);
    }

    @PostMapping("/{tab}/record")
    public PtEvaluationTab createRecord(@PathVariable int patientId, @PathVariable int visitId,
            @PathVariable String tab, Authentication authentication) {
        return service.createRecord(patientId, visitId, tab, PtEvaluationActions.isAdmin(authentication));
    }
}
