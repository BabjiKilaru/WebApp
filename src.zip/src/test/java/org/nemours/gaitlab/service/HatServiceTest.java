package org.nemours.gaitlab.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.nemours.gaitlab.repository.PtEvaluationRepository;
import org.nemours.gaitlab.service.PtEvaluationTab.Row;
import org.nemours.gaitlab.service.PtEvaluationTab.Section;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import tools.jackson.databind.ObjectMapper;

/** HAT is scored once per limb (hat_scores.ullr: UER/LER/UEL/LEL, matching production's actual
 * schema and PtEvaluationRepository.ULLR_OPTIONS' order) - a Phase 4 audit correction from an earlier,
 * single-scale version of this port that didn't have the ullr column available locally. */
class HatServiceTest {
    private final PtEvaluationRepository repository = mock(PtEvaluationRepository.class);
    private final PtEvaluationRevision revision = new PtEvaluationRevision(new ObjectMapper());
    private final HatService service = new HatService(repository, revision);

    private static Map<String, Object> item(int id, String name, int value) {
        return Map.of("id", id, "item", name, "value", value);
    }

    private final List<Map<String, Object>> items = List.of(
            item(1, "Item one", 1), item(2, "Item two", 2));

    private static Map<String, Object> scoreRow(int id, String ullr, Integer hat1, Integer hat2) {
        Map<String, Object> row = new HashMap<>();
        row.put("id", id);
        row.put("ullr", ullr);
        row.put("hat1", hat1);
        row.put("hat2", hat2);
        return row;
    }

    @Test
    void noScoresYetReturnsEmptyTab() {
        when(repository.findHatScoresByVisitId(7)).thenReturn(List.of());

        PtEvaluationTab result = service.build(42, 7, "hat");

        assertFalse(result.hasData());
        assertEquals("No HAT scores entered.", result.emptyMessage());
    }

    @Test
    void columnsAreTheFourLimbsInUllrOptionsOrder() {
        when(repository.findHatScoresByVisitId(7)).thenReturn(List.of(scoreRow(1, "UER", 10, null)));
        when(repository.findHatItems()).thenReturn(items);
        when(repository.findHatSelectionById(10)).thenReturn(Optional.of(Map.of("value", 0, "selection", "No signs")));

        PtEvaluationTab result = service.build(42, 7, "hat");

        Section section = result.sections().get(0);
        assertEquals(List.of("", "UER Score", "LER Score", "UEL Score", "LEL Score"), section.columns());
    }

    /** Legacy prints nothing at all for an unset cell (pt-eval-hat.jsp:153) - not "--" the way
     * Dystonia does. A limb with no row at all behaves the same as a limb whose row exists but
     * doesn't have that particular item scored. */
    @Test
    void unsetCellsAreNullNotDash() {
        when(repository.findHatScoresByVisitId(7)).thenReturn(List.of(scoreRow(1, "UER", 10, null)));
        when(repository.findHatItems()).thenReturn(items);
        when(repository.findHatSelectionById(10)).thenReturn(Optional.of(Map.of("value", 0, "selection", "No signs")));

        PtEvaluationTab result = service.build(42, 7, "hat");

        Row itemOne = result.sections().get(0).rows().get(0);
        assertEquals("0=No signs", itemOne.cells().get(0)); // UER
        assertNull(itemOne.cells().get(1)); // LER - no row for this limb at all
        assertNull(itemOne.cells().get(2)); // UEL
        Row itemTwo = result.sections().get(0).rows().get(1);
        assertNull(itemTwo.cells().get(0)); // UER row exists but hat2 is unset
    }

    @Test
    void saveRejectsASelectionThatBelongsToADifferentItem() {
        Map<String, Object> uer = scoreRow(5, "UER", 10, 20);
        when(repository.findHatScoresByVisitId(7)).thenReturn(List.of(uer));
        when(repository.findHatItems()).thenReturn(items);
        String currentRevision = revision.of(List.of(uer));
        when(repository.existsHatSelectionForItem(1, 999)).thenReturn(false);

        assertThrows(PtEvaluationValidationException.class,
                () -> service.save(42, 7, currentRevision, Map.of("hi-UER-1", "999")));
    }

    @Test
    void saveUpdatesOnlyTheSubmittedLimbsSelectionsAndRebuilds() {
        Map<String, Object> uer = scoreRow(5, "UER", 10, 20);
        Map<String, Object> ler = scoreRow(6, "LER", 30, 40);
        when(repository.findHatScoresByVisitId(7)).thenReturn(List.of(uer, ler));
        when(repository.findHatItems()).thenReturn(items);
        String currentRevision = revision.of(List.of(uer, ler));
        when(repository.existsHatSelectionForItem(1, 11)).thenReturn(true);

        service.save(42, 7, currentRevision, Map.of("hi-UER-1", "11"));

        verify(repository).updateHatScores(5, 11, 20, null, null, null, null, null);
        verify(repository).updateHatScores(6, 30, 40, null, null, null, null, null); // unchanged, still rewritten
    }

    @Test
    void createRecordConflictsWhenAnyLimbAlreadyHasScores() {
        when(repository.findHatScoresByVisitId(7)).thenReturn(List.of(scoreRow(1, "UER", null, null)));
        assertEquals(HttpStatus.CONFLICT,
                assertThrows(ResponseStatusException.class, () -> service.createRecord(42, 7)).getStatusCode());
    }

    @Test
    void createRecordInsertsAllFourLimbsAtOnce() {
        when(repository.findHatScoresByVisitId(7)).thenReturn(List.of());

        service.createRecord(42, 7);

        verify(repository).insertBlankHatScoresForAllLimbs(7);
    }
}
