package org.nemours.gaitlab.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.nemours.gaitlab.repository.PtEvaluationRepository;
import org.nemours.gaitlab.service.PtEvaluationTab.Row;
import org.nemours.gaitlab.service.PtEvaluationTab.Section;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import tools.jackson.databind.ObjectMapper;

class PromStrengthServiceTest {
    private final PtEvaluationRepository repository = mock(PtEvaluationRepository.class);
    private final PtEvaluationRevision revision = new PtEvaluationRevision(new ObjectMapper());
    private final PromStrengthService service = new PromStrengthService(repository, revision);

    @Test
    void returnsEmptyMessageWhenNoDataPromRowExists() {
        when(repository.findPromByVisitId(7)).thenReturn(Optional.empty());

        PtEvaluationTab result = service.build(42, 7, "prom-strength");

        assertFalse(result.hasData());
        assertEquals(PromStrengthService.EMPTY_MESSAGE, result.emptyMessage());
        assertTrue(result.sections().isEmpty());
    }

    @Test
    void wnlSentinelAndSignPrefixAndRangeFormattingMatchLegacyExactly() {
        Map<String, Object> row = new HashMap<>();
        row.put("hip_flex_r", 999);
        row.put("hip_flex_r_interp", "N");
        row.put("hip_flex_l", 120);
        row.put("hip_flex_l_interp", "D");
        row.put("hip_flex_s_r", "999"); // text column, literal "999" => WNL
        row.put("hip_flex_s_r_interp", "N");
        row.put("hip_flex_s_l", "4+");
        row.put("hip_flex_s_l_interp", "D");
        row.put("q_angle_r", 5);
        row.put("q_angle_r_interp", "N");
        row.put("q_angle_l", -3);
        row.put("q_angle_l_interp", null);
        row.put("pop_r_low", 999);
        row.put("pop_r_high", 50);
        row.put("pop_r_interp", "N");
        row.put("leg_length_r", 35.5f);
        row.put("leg_length_l", 36.0f);
        when(repository.findPromByVisitId(7)).thenReturn(Optional.of(row));

        PtEvaluationTab result = service.build(42, 7, "prom-strength");

        assertTrue(result.hasData());
        Section section = result.sections().get(0);
        Row hipFlex = findRow(section, "Hip Flex");
        assertEquals("WNL [N]", hipFlex.cells().get(0));
        assertEquals("120 [D]", hipFlex.cells().get(1));
        assertEquals("WNL [N]", hipFlex.cells().get(2));
        assertEquals("4+ [D]", hipFlex.cells().get(3));

        Row kneeVarus = findRow(section, "Knee Varus/Valgus");
        assertEquals("+5 [N]", kneeVarus.cells().get(0));
        assertEquals("-3 []", kneeVarus.cells().get(1));

        Row popAngle = findRow(section, "Pop angle");
        assertEquals("WNL -- 50 [N]", popAngle.cells().get(0));
        assertNull(popAngle.cells().get(1)); // left side entirely blank -> null, not "--  []"

        Row legLength = findRow(section, "Leg Length (cm)");
        assertEquals("35.5", legLength.cells().get(0));
        assertEquals("36", legLength.cells().get(1)); // whole numbers drop the trailing .0
    }

    @Test
    void rowsWithNoStrengthColumnsLeaveThoseCellsNull() {
        Map<String, Object> row = new HashMap<>();
        row.put("hip_int_rot_r", 10);
        row.put("hip_int_rot_r_interp", "N");
        when(repository.findPromByVisitId(7)).thenReturn(Optional.of(row));

        Row hipIntRot = findRow(service.build(42, 7, "prom-strength").sections().get(0), "Hip Int Rot");
        assertEquals("10 [N]", hipIntRot.cells().get(0));
        assertNull(hipIntRot.cells().get(2));
        assertNull(hipIntRot.cells().get(3));
    }

    private Row findRow(Section section, String label) {
        return section.rows().stream().filter(r -> r.label().equals(label)).findFirst().orElseThrow();
    }

    private static PtEvaluationForm.FormRow findFormRow(PtEvaluationForm.FormSection section, String label) {
        return section.rows().stream().filter(r -> r.label().equals(label)).findFirst().orElseThrow();
    }

    @Test
    void buildFormHasSeparatePromAndStrengthGridsPlusTheThreeSpecialSections() {
        Map<String, Object> row = new HashMap<>();
        row.put("id", 99);
        row.put("hip_flex_r", 20);
        row.put("hip_flex_r_interp", "N");
        row.put("hip_int_rot_r", 10); // no strength pair
        row.put("tma_r", "cavus"); // free text, not numeric
        row.put("q_angle_r", 5);
        row.put("pop_r_low", 10);
        row.put("leg_length_r", 35.5f);
        when(repository.findPromByVisitId(7)).thenReturn(Optional.of(row));
        when(repository.findNormalsForVisit(7)).thenReturn(Optional.empty());

        PtEvaluationForm form = service.buildForm(7);

        assertEquals("prom-strength", form.tab());
        var promSection = form.sections().get(0);
        assertEquals("PROM", promSection.title());
        assertEquals(21, promSection.rows().size()); // PROM_FIELDS, excluding pop/leg_length/q_angle
        assertEquals("20", findFormRow(promSection, "Hip Flex").fields().get(0).value());
        assertEquals("number", findFormRow(promSection, "Hip Flex").fields().get(0).type());
        assertEquals("cavus", findFormRow(promSection, "TMA").fields().get(0).value());
        assertEquals("text", findFormRow(promSection, "TMA").fields().get(0).type());

        var strengthSection = form.sections().get(1);
        assertEquals("Strength", strengthSection.title());
        assertEquals(9, strengthSection.rows().size()); // only fields with hasStrength=true
        assertTrue(strengthSection.rows().stream().anyMatch(r -> r.label().equals("Hip Flex")));
        assertTrue(strengthSection.rows().stream().noneMatch(r -> r.label().equals("Hip Int Rot")));

        var popSection = form.sections().stream().filter(s -> "Pop angle".equals(s.title())).findFirst().orElseThrow();
        assertEquals("10", popSection.fields().get(0).value());

        var legLengthSection = form.sections().stream()
                .filter(s -> "Leg Length (cm)".equals(s.title())).findFirst().orElseThrow();
        assertEquals("35.5", legLengthSection.fields().get(0).value());

        var qAngleSection = form.sections().stream()
                .filter(s -> "Knee Varus/Valgus".equals(s.title())).findFirst().orElseThrow();
        assertEquals("+5", qAngleSection.rows().get(0).fields().get(0).value());
    }

    @Test
    void saveRejectsAStaleRevisionWithoutWritingAnything() {
        Map<String, Object> row = new HashMap<>();
        row.put("id", 99);
        when(repository.findPromByVisitId(7)).thenReturn(Optional.of(row));

        var exception = assertThrows(ResponseStatusException.class,
                () -> service.save(42, 7, "stale", Map.of()));

        assertEquals(HttpStatus.CONFLICT, exception.getStatusCode());
        verify(repository, never()).update(anyInt(), any());
    }

    @Test
    void saveValidatesNumericFieldsButLeavesTextFieldsLikeTmaUnconstrained() {
        Map<String, Object> row = new HashMap<>();
        row.put("id", 99);
        String currentRevision = revision.of(row);

        when(repository.findPromByVisitId(7)).thenReturn(Optional.of(row));

        Map<String, Object> values = new HashMap<>();
        values.put("hip_flex_r", "not-a-number");
        values.put("tma_r", "anything goes"); // text column, no numeric constraint

        var exception = assertThrows(PtEvaluationValidationException.class,
                () -> service.save(42, 7, currentRevision, values));

        assertTrue(exception.fieldErrors().containsKey("hip_flex_r"));
        assertFalse(exception.fieldErrors().containsKey("tma_r"));
        verify(repository, never()).update(anyInt(), any());
    }

    @Test
    void saveWritesTheResolvedColumnMapWhenTheRevisionMatches() {
        Map<String, Object> row = new HashMap<>();
        row.put("id", 99);
        String currentRevision = revision.of(row);
        when(repository.findPromByVisitId(7)).thenReturn(Optional.of(row));

        Map<String, Object> values = new HashMap<>();
        values.put("hip_flex_r", "25");
        values.put("tma_r", "cavus");
        values.put("leg_length_r", "35.5");
        values.put("q_angle_r", "+5");

        service.save(42, 7, currentRevision, values);

        @SuppressWarnings("unchecked")
        var columnsCaptor = org.mockito.ArgumentCaptor.forClass(Map.class);
        verify(repository).update(eq(99), columnsCaptor.capture());
        Map<String, Object> columns = columnsCaptor.getValue();
        assertEquals(25, columns.get("hip_flex_r"));
        assertEquals("cavus", columns.get("tma_r"));
        assertEquals(35.5f, columns.get("leg_length_r"));
        assertEquals(5, columns.get("q_angle_r")); // "+5" parses fine via Integer.parseInt
    }

    @Test
    void createRecordInsertsABlankRowAndRejectsWhenOneAlreadyExists() {
        when(repository.findPromByVisitId(7)).thenReturn(Optional.empty());

        service.createRecord(42, 7);
        verify(repository).insertBlank(7);

        when(repository.findPromByVisitId(7)).thenReturn(Optional.of(Map.of("id", 1)));
        assertThrows(ResponseStatusException.class, () -> service.createRecord(42, 7));
    }

    // --- Phase 4: pt-sections.jsp's mainPromTable swap for movement-disorder visits -------------

    @Test
    void movementDisorderBuildReadsTheMdTableAndUsesTheNarrowerFieldSet() {
        Map<String, Object> row = new HashMap<>();
        row.put("hip_abd_r", 40);
        row.put("shoulder_abduction_r", 150);
        when(repository.findMdByVisitId(7)).thenReturn(Optional.of(row));

        PtEvaluationTab result = service.build(42, 7, "prom-strength", true);

        Section section = result.sections().get(0);
        assertTrue(section.rows().stream().anyMatch(r -> r.label().equals("Hip Abd")));
        assertTrue(section.rows().stream().anyMatch(r -> r.label().equals("Shoulder Abduction")));
        assertTrue(section.rows().stream().noneMatch(r -> r.label().equals("Hip Flex"))); // Gait-only field
        verify(repository, never()).findPromByVisitId(anyInt());
    }

    @Test
    void movementDisorderSaveWritesToTheMdTableAndRejectsGaitOnlyColumnsImplicitly() {
        Map<String, Object> row = new HashMap<>();
        row.put("id", 55);
        row.put("hip_abd_r", 40);
        String currentRevision = revision.of(row);
        when(repository.findMdByVisitId(7)).thenReturn(Optional.of(row));

        service.save(42, 7, currentRevision, Map.of("hip_abd_r", "45"), true);

        var columnsCaptor = org.mockito.ArgumentCaptor.forClass(Map.class);
        verify(repository).updateMd(eq(55), columnsCaptor.capture());
        Map<String, Object> columns = columnsCaptor.getValue();
        assertEquals(45, columns.get("hip_abd_r"));
        assertFalse(columns.containsKey("hip_flex_r")); // not part of MD_PROM_FIELDS at all
        verify(repository, never()).update(anyInt(), any());
    }

    @Test
    void movementDisorderCreateRecordInsertsIntoTheMdTable() {
        when(repository.findMdByVisitId(7)).thenReturn(Optional.empty());

        service.createRecord(42, 7, true);

        verify(repository).insertBlankMd(7);
        verify(repository, never()).insertBlank(anyInt());
    }
}
