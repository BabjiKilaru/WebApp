package org.nemours.gaitlab.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.nemours.gaitlab.repository.PtEvaluationRepository;
import org.nemours.gaitlab.service.PtEvaluationTab.Row;
import org.nemours.gaitlab.service.PtEvaluationTab.Section;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import tools.jackson.databind.ObjectMapper;

class DystoniaServiceTest {
    private final PtEvaluationRepository repository = mock(PtEvaluationRepository.class);
    private final PtEvaluationRevision revision = new PtEvaluationRevision(new ObjectMapper());
    private final DystoniaService service = new DystoniaService(repository, revision);

    private static Map<String, Object> item(int id, String name, int value) {
        return Map.of("id", id, "item", name, "longdesc", name + " description", "value", value);
    }

    // Eyes (unilateral, value 1) and UE (bilateral, value 5) - enough to exercise both branches.
    private final List<Map<String, Object>> items = List.of(
            item(1, "Eyes", 1), item(5, "UE", 5));

    @Test
    void noScaleYetReturnsEmptyTab() {
        when(repository.findDystoniaScaleByVisitId(7)).thenReturn(Optional.empty());

        PtEvaluationTab result = service.build(42, 7, "dystonia-scale");

        assertFalse(result.hasData());
        assertEquals("No Dystonia scores entered.", result.emptyMessage());
    }

    /** pt-eval-dystonia-scale.jsp:143-160: one "Score" column; unilateral items show their plain
     * value in that single cell, bilateral items show "Right: ...\nLeft: ..." in the SAME cell -
     * not two separate Right/Left columns. Row label is "{item}: {longdesc}". */
    @Test
    void unilateralRowIsOneCellAndBilateralRowIsRightNewlineLeftInTheSameCell() {
        Map<String, Object> scale = new HashMap<>(Map.of("id", 9, "eyes", 10, "uer", 20, "uel", 21));
        when(repository.findDystoniaScaleByVisitId(7)).thenReturn(Optional.of(scale));
        when(repository.findDystoniaItems()).thenReturn(items);
        when(repository.findDystoniaSelectionById(10)).thenReturn(Optional.of(Map.of("value", 0, "selection", "Absence")));
        when(repository.findDystoniaSelectionById(20)).thenReturn(Optional.of(Map.of("value", 1, "selection", "Slight")));
        when(repository.findDystoniaSelectionById(21)).thenReturn(Optional.of(Map.of("value", 2, "selection", "Mild")));

        PtEvaluationTab result = service.build(42, 7, "dystonia-scale");

        Section section = result.sections().get(0);
        assertEquals(List.of("", "Score"), section.columns());
        Row eyes = section.rows().get(0);
        assertEquals("Eyes: Eyes description", eyes.label());
        assertEquals(1, eyes.cells().size());
        assertEquals("0=Absence", eyes.cells().get(0));
        Row ue = section.rows().get(1);
        assertEquals("UE: UE description", ue.label());
        assertEquals(1, ue.cells().size());
        assertEquals("Right: 1=Slight\nLeft: 2=Mild", ue.cells().get(0));
    }

    @Test
    void aNullValueSelectionRendersWithAnAsteriskNotTheWordNull() {
        Map<String, Object> scale = new HashMap<>(Map.of("id", 9, "eyes", 30));
        when(repository.findDystoniaScaleByVisitId(7)).thenReturn(Optional.of(scale));
        when(repository.findDystoniaItems()).thenReturn(List.of(item(1, "Eyes", 1)));
        when(repository.findDystoniaSelectionById(30))
                .thenReturn(Optional.of(Map.of("selection", "Unable to assess eye movements")));

        PtEvaluationTab result = service.build(42, 7, "dystonia-scale");

        assertEquals("*=Unable to assess eye movements",
                result.sections().get(0).rows().get(0).cells().get(0));
    }

    @Test
    void saveUpdatesBilateralColumnsSeparately() {
        Map<String, Object> scale = new HashMap<>(Map.of("id", 9, "uer", 20, "uel", 21));
        when(repository.findDystoniaScaleByVisitId(7)).thenReturn(Optional.of(scale));
        when(repository.findDystoniaItems()).thenReturn(List.of(item(5, "UE", 5)));
        String currentRevision = revision.of(scale);
        when(repository.existsDystoniaSelectionForItem(5, 22)).thenReturn(true);

        service.save(42, 7, currentRevision, Map.of("uer", "22"));

        // eyes/mouth/neck/trunk/lel/ler aren't in `items` for this test so stay null; uel is
        // untouched by `values` and keeps its current 21.
        verify(repository).updateDystoniaScale(9, null, null, null, null, 21, 22, null, null);
    }

    @Test
    void createRecordConflictsWhenScaleAlreadyExists() {
        when(repository.findDystoniaScaleByVisitId(7)).thenReturn(Optional.of(Map.of("id", 1)));
        assertEquals(HttpStatus.CONFLICT,
                assertThrows(ResponseStatusException.class, () -> service.createRecord(42, 7)).getStatusCode());
    }
}
