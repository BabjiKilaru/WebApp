package org.nemours.gaitlab.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.nemours.gaitlab.repository.PtEvaluationRepository;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.repository.VisitRepository.PtGeneralMdEvaluationRow;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import tools.jackson.databind.ObjectMapper;

class OrthosesServiceTest {
    private final PtEvaluationRepository repository = mock(PtEvaluationRepository.class);
    private final VisitRepository visits = mock(VisitRepository.class);
    private final PtEvaluationRevision revision = new PtEvaluationRevision(new ObjectMapper());
    private final OrthosesService service =
            new OrthosesService(repository, visits, revision);

    @Test
    void hasNoEmptyMessageUnlikeTheOtherTabsSinceLegacyShowsNoTextAtAll() {
        when(repository.findOrthosesByVisitId(7)).thenReturn(List.of());

        PtEvaluationTab result = service.build(42, 7, "orthotics", true);

        assertFalse(result.hasData());
        assertNull(result.emptyMessage());
    }

    @Test
    void listsOrthosesWithSideAsRows() {
        Map<String, Object> noSide = new HashMap<>();
        noSide.put("id", 2);
        noSide.put("orthosis", "SMO");
        noSide.put("side", null);
        when(repository.findOrthosesByVisitId(7)).thenReturn(List.of(
                Map.of("id", 1, "orthosis", "AFO", "side", "Right"),
                noSide));

        PtEvaluationTab result = service.build(42, 7, "orthotics", true);

        assertTrue(result.hasData());
        var rows = result.sections().get(0).rows();
        assertEquals("AFO", rows.get(0).label());
        assertEquals("Right", rows.get(0).cells().get(0));
        assertEquals(1, rows.get(0).id());
        assertEquals("SMO", rows.get(1).label());
        assertNull(rows.get(1).cells().get(0));
        assertEquals(2, rows.get(1).id());
    }

    @Test
    void rowActionsMirrorIsAdminSinceLegacyGatesEditAndDeleteByTheSameFlag() {
        when(repository.findOrthosesByVisitId(7)).thenReturn(List.of(Map.of("id", 1, "orthosis", "AFO", "side", "Right")));

        var adminRow = service.build(42, 7, "orthotics", true).sections().get(0).rows().get(0);
        assertTrue(adminRow.actions().edit());
        assertTrue(adminRow.actions().delete());

        var nonAdminRow = service.build(42, 7, "orthotics", false).sections().get(0).rows().get(0);
        assertFalse(nonAdminRow.actions().edit());
        assertFalse(nonAdminRow.actions().delete());
    }

    @Test
    void newFormOffersOrthosisOptionsAndNoPriorSelection() {
        when(repository.findOrthosisOptions()).thenReturn(List.of("AFO", "SMO"));

        PtEvaluationForm form = service.buildNewForm(7);

        assertEquals("orthotics", form.tab());
        assertEquals("Add Orthosis to Visit", form.title()); // insert_orth.jsp's own heading
        var fields = form.sections().get(0).fields();
        assertNull(fields.get(0).value());
        assertTrue(fields.get(0).required());
        assertEquals(List.of("AFO", "SMO"),
                fields.get(0).options().stream().map(PtEvaluationForm.Option::value).toList());
        assertEquals(3, fields.get(1).options().size()); // Left/Right/Both
    }

    @Test
    void editFormPreFillsTheExistingRowAnd404sForAnotherVisitsOrthosis() {
        when(repository.findByIdAndVisitId(5, 7)).thenReturn(Optional.of(Map.of("id", 5, "orthosis", "AFO", "side", "Left")));
        when(repository.findOrthosisOptions()).thenReturn(List.of("AFO"));

        PtEvaluationForm form = service.buildEditForm(7, 5);
        assertEquals("Modify Patient Orthosis", form.title()); // modify_orth.jsp's own heading
        assertEquals("AFO", form.sections().get(0).fields().get(0).value());
        assertEquals("Left", form.sections().get(0).fields().get(1).value());

        when(repository.findByIdAndVisitId(5, 99)).thenReturn(Optional.empty());
        assertEquals(HttpStatus.NOT_FOUND,
                assertThrows(ResponseStatusException.class, () -> service.buildEditForm(99, 5)).getStatusCode());
    }

    @Test
    void editFormIncludesTheCurrentValueEvenWhenItPredatesTheLookupTable() {
        when(repository.findByIdAndVisitId(5, 7))
                .thenReturn(Optional.of(Map.of("id", 5, "orthosis", "LegacyOnlyBrace", "side", "Left")));
        when(repository.findOrthosisOptions()).thenReturn(List.of("AFO", "SMO"));

        PtEvaluationForm form = service.buildEditForm(7, 5);

        var orthosisField = form.sections().get(0).fields().get(0);
        assertEquals("LegacyOnlyBrace", orthosisField.value());
        assertTrue(orthosisField.options().stream().anyMatch(o -> o.value().equals("LegacyOnlyBrace")));
    }

    @Test
    void createRejectsAMissingOrUnknownOrthosisAndAnInvalidSideBeforeInserting() {
        String newFormRevision = revision.of("new:7");

        var missingOrthosis = assertThrows(PtEvaluationValidationException.class,
                () -> service.createOrthosis(42, 7, true, newFormRevision, Map.of("side", "Left")));
        assertTrue(missingOrthosis.fieldErrors().containsKey("orthosis"));

        when(repository.findOrthosisOptions()).thenReturn(List.of("AFO"));

        var unknownOrthosis = assertThrows(PtEvaluationValidationException.class,
                () -> service.createOrthosis(42, 7, true, newFormRevision, Map.of("orthosis", "NotARealBrace")));
        assertTrue(unknownOrthosis.fieldErrors().containsKey("orthosis"));

        var badSide = assertThrows(PtEvaluationValidationException.class,
                () -> service.createOrthosis(42, 7, true, newFormRevision,
                        Map.of("orthosis", "AFO", "side", "Sideways")));
        assertTrue(badSide.fieldErrors().containsKey("side"));

        verify(repository, never()).insert(anyInt(), any(), any());
    }

    @Test
    void createInsertsAndReturnsTheOrthoticsViewOnSuccess() {
        String newFormRevision = revision.of("new:7");
        when(repository.findOrthosisOptions()).thenReturn(List.of("AFO"));
        when(repository.findOrthosesByVisitId(7)).thenReturn(List.of(Map.of("id", 1, "orthosis", "AFO", "side", "Right")));

        PtEvaluationTab result = service.createOrthosis(42, 7, true, newFormRevision,
                Map.of("orthosis", "AFO", "side", "Right"));

        verify(repository).insert(7, "AFO", "Right");
        assertEquals("orthotics", result.tab());
    }

    @Test
    void updateRejectsAStaleRevisionAndA404ForAnotherVisit() {
        Map<String, Object> row = Map.of("id", 5, "orthosis", "AFO", "side", "Left");
        when(repository.findByIdAndVisitId(5, 7)).thenReturn(Optional.of(row));

        assertEquals(HttpStatus.CONFLICT,
                assertThrows(ResponseStatusException.class,
                        () -> service.updateOrthosis(42, 7, 5, true, "stale", Map.of("orthosis", "SMO")))
                        .getStatusCode());

        when(repository.findByIdAndVisitId(5, 7)).thenReturn(Optional.empty());
        assertEquals(HttpStatus.NOT_FOUND,
                assertThrows(ResponseStatusException.class,
                        () -> service.updateOrthosis(42, 7, 5, true, "anything", Map.of("orthosis", "SMO")))
                        .getStatusCode());
        verify(repository, never()).update(anyInt(), anyInt(), any(), any());
    }

    @Test
    void updateWritesTheNewValuesWhenTheRevisionMatches() {
        Map<String, Object> row = Map.of("id", 5, "orthosis", "AFO", "side", "Left");
        when(repository.findByIdAndVisitId(5, 7)).thenReturn(Optional.of(row));
        when(repository.findOrthosisOptions()).thenReturn(List.of("AFO", "SMO"));
        when(repository.findOrthosesByVisitId(7)).thenReturn(List.of(Map.of("id", 5, "orthosis", "SMO", "side", "Right")));
        String currentRevision = revision.of(row);

        service.updateOrthosis(42, 7, 5, true, currentRevision, Map.of("orthosis", "SMO", "side", "Right"));

        verify(repository).update(5, 7, "SMO", "Right");
    }

    @Test
    void updateKeepsAnExistingOutOfLookupValueEvenThoughItIsNotInTheLookup() {
        Map<String, Object> row = Map.of("id", 5, "orthosis", "LegacyOnlyBrace", "side", "Left");
        when(repository.findByIdAndVisitId(5, 7)).thenReturn(Optional.of(row));
        when(repository.findOrthosisOptions()).thenReturn(List.of("AFO", "SMO"));
        when(repository.findOrthosesByVisitId(7))
                .thenReturn(List.of(Map.of("id", 5, "orthosis", "LegacyOnlyBrace", "side", "Right")));
        String currentRevision = revision.of(row);

        // orthosis unchanged, only side changes - must not be rejected just because
        // "LegacyOnlyBrace" isn't in the (now-seeded) lookup.
        service.updateOrthosis(42, 7, 5, true, currentRevision, Map.of("orthosis", "LegacyOnlyBrace", "side", "Right"));

        verify(repository).update(5, 7, "LegacyOnlyBrace", "Right");
    }

    @Test
    void deleteRemovesTheRowAnd404sIfItBelongsToAnotherVisit() {
        when(repository.findByIdAndVisitId(5, 7)).thenReturn(Optional.of(Map.of("id", 5, "orthosis", "AFO", "side", "Left")));
        when(repository.findOrthosesByVisitId(7)).thenReturn(List.of());

        service.deleteOrthosis(42, 7, 5, true);
        verify(repository).deleteByIdAndVisitId(5, 7);

        when(repository.findByIdAndVisitId(5, 7)).thenReturn(Optional.empty());
        assertEquals(HttpStatus.NOT_FOUND,
                assertThrows(ResponseStatusException.class, () -> service.deleteOrthosis(42, 7, 5, true))
                        .getStatusCode());
    }

    // --- Phase 4 audit: pt-eval-orth.jsp:206-228's movement-disorder-only Comments block -------

    private PtGeneralMdEvaluationRow mdRow(Integer dataPtMdId, String orthoses) {
        PtGeneralMdEvaluationRow row = mock(PtGeneralMdEvaluationRow.class);
        when(row.getDataPtMdId()).thenReturn(dataPtMdId);
        when(row.getOrthoses()).thenReturn(orthoses);
        return row;
    }

    @Test
    void movementDisorderHasDataWhenOnlyTheMdRowExistsEvenWithNoOrthoses() {
        when(repository.findOrthosesByVisitId(7)).thenReturn(List.of());
        PtGeneralMdEvaluationRow row = mdRow(9, null);
        when(visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(row));

        PtEvaluationTab result = service.build(42, 7, "orthotics", true, true);

        assertTrue(result.hasData());
        assertEquals(1, result.sections().size());
        assertEquals("text", result.sections().get(0).kind());
        assertEquals("Comments", result.sections().get(0).title());
        assertNull(result.sections().get(0).text());
    }

    @Test
    void movementDisorderIsEmptyOnlyWhenBothOrthosesAndMdRowAreMissing() {
        when(repository.findOrthosesByVisitId(7)).thenReturn(List.of());
        when(visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.empty());

        PtEvaluationTab result = service.build(42, 7, "orthotics", true, true);

        assertFalse(result.hasData());
    }

    @Test
    void movementDisorderShowsBothTheOrthosesTableAndTheCommentsSection() {
        when(repository.findOrthosesByVisitId(7)).thenReturn(List.of(Map.of("id", 1, "orthosis", "AFO", "side", "Right")));
        PtGeneralMdEvaluationRow row = mdRow(9, "Fits well");
        when(visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(row));

        PtEvaluationTab result = service.build(42, 7, "orthotics", true, true);

        assertEquals(2, result.sections().size());
        assertEquals("table", result.sections().get(0).kind());
        assertEquals("Comments", result.sections().get(1).title());
        assertEquals("Fits well", result.sections().get(1).text());
    }

    @Test
    void commentsFormAndSaveRoundTripThroughTheMdRow() {
        PtGeneralMdEvaluationRow row = mdRow(9, "Old comment");
        when(visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(row));

        PtEvaluationForm form = service.buildCommentsForm(42, 7);
        assertEquals("Old comment", form.sections().get(0).fields().get(0).value());
        assertEquals("textarea", form.sections().get(0).fields().get(0).type());

        when(repository.findOrthosesByVisitId(7)).thenReturn(List.of());
        service.saveComments(42, 7, form.revision(), Map.of("orthoses", "New comment"));

        verify(repository).updateMovementDisorderOrthosesComment(9, "New comment");
    }

    @Test
    void commentsEditableOnlyWhenTheMdRowExistsNoAdminGate() {
        PtGeneralMdEvaluationRow row = mdRow(9, null);
        when(visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(row));
        assertTrue(service.commentsEditable(42, 7));

        when(visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.empty());
        assertFalse(service.commentsEditable(42, 7));
    }

    @Test
    void commentsCreatableOnlyForAdminsWithNoMdRowYet() {
        when(visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.empty());
        assertTrue(service.commentsCreatable(42, 7, true));
        assertFalse(service.commentsCreatable(42, 7, false));

        PtGeneralMdEvaluationRow row = mdRow(9, null);
        when(visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(row));
        assertFalse(service.commentsCreatable(42, 7, true));
    }

    @Test
    void createCommentsRecordConflictsWhenTheMdRowAlreadyExists() {
        PtGeneralMdEvaluationRow row = mdRow(9, null);
        when(visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(row));

        assertEquals(HttpStatus.CONFLICT,
                assertThrows(ResponseStatusException.class, () -> service.createCommentsRecord(42, 7))
                        .getStatusCode());
    }

    @Test
    void createCommentsRecordInsertsTheSameRowGeneralMdRecordCreates() {
        when(visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.empty());
        when(repository.findOrthosesByVisitId(7)).thenReturn(List.of());

        service.createCommentsRecord(42, 7);

        verify(repository).insertBlankDataPtMovementDisorder(7);
    }
}
