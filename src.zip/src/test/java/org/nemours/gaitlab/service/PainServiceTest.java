package org.nemours.gaitlab.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.nemours.gaitlab.repository.PtEvaluationRepository;
import tools.jackson.databind.ObjectMapper;

class PainServiceTest {
    private final PtEvaluationRepository repository = mock(PtEvaluationRepository.class);
    private final PtEvaluationRevision revision = new PtEvaluationRevision(new ObjectMapper());
    private final PainService service = new PainService(repository, revision);

    @Test
    void noPainRowAtAllMeansNoDataEvenThoughLegacyWouldStillShowTheButtonToCreateOne() {
        when(repository.findPainByVisitId(7)).thenReturn(Optional.empty());

        PtEvaluationTab result = service.build(42, 7, "pain");

        assertFalse(result.hasData());
        assertEquals("No pain data entered.", result.emptyMessage());
    }

    @Test
    void anExistingRowWithAllBlankFieldsStillCountsAsHavingData() {
        Map<String, Object> row = new HashMap<>();
        row.put("id", 99);
        when(repository.findPainByVisitId(7)).thenReturn(Optional.of(row));
        when(repository.findFactorLabels(99)).thenReturn(List.of());
        when(repository.findActivitiesImpactedLabels(99)).thenReturn(List.of());

        PtEvaluationTab result = service.build(42, 7, "pain");

        assertTrue(result.hasData());
        assertEquals(1, result.sections().size());
        assertNull(result.sections().get(0).rows().get(0).cells().get(0));
    }

    /** Legacy's pt-eval-pain.jsp is genuinely one single HTML TABLE (not separate blocks) - the
     * two bullet lists are rendered inside that table's own cells, newline-joined here rather
     * than split into separate list sections. */
    @Test
    void isOneTableSectionInLegacyOrderWithBulletListsJoinedIntoTheirCell() {
        Map<String, Object> row = new HashMap<>();
        row.put("id", 99);
        row.put("assessment_method", "Numerical");
        row.put("current_level", 3);
        row.put("lowest_level", 0);
        row.put("highest_level", 7);
        row.put("location", "Right knee");
        row.put("frequency", "Daily");
        row.put("duration", "Minutes");
        when(repository.findPainByVisitId(7)).thenReturn(Optional.of(row));
        when(repository.findFactorLabels(99)).thenReturn(List.of("weightbearing", "walking"));
        when(repository.findActivitiesImpactedLabels(99)).thenReturn(List.of("sleep", "school"));

        PtEvaluationTab result = service.build(42, 7, "pain");

        assertEquals(1, result.sections().size());
        var rows = result.sections().get(0).rows();
        assertEquals("Pain assessment method:", rows.get(0).label());
        assertEquals("Numerical", rows.get(0).cells().get(0));
        assertEquals("Aggravating factors:", rows.get(1).label());
        assertEquals("weightbearing\nwalking", rows.get(1).cells().get(0));
        assertEquals("Activities impacted:", rows.get(2).label());
        assertEquals("sleep\nschool", rows.get(2).cells().get(0));
        assertEquals("Current Level", rows.get(3).label());
        assertEquals("3", rows.get(3).cells().get(0));
        assertEquals("Lowest Level", rows.get(4).label());
        assertEquals("0", rows.get(4).cells().get(0));
        assertEquals("Highest Level", rows.get(5).label());
        assertEquals("7", rows.get(5).cells().get(0));
        assertEquals("Location of pain", rows.get(6).label());
        assertEquals("Right knee", rows.get(6).cells().get(0));
        assertEquals("Frequency of pain", rows.get(7).label());
        assertEquals("Duration of pain", rows.get(8).label());
    }

    private static Map<String, Object> painRow(int id, Integer assessmentMethodId, Integer currentLevel,
            Integer lowestLevel, Integer highestLevel, String location, String frequency, String duration) {
        Map<String, Object> row = new HashMap<>();
        row.put("id", id);
        row.put("pain_assessment_method_id", assessmentMethodId);
        row.put("current_level", currentLevel);
        row.put("lowest_level", lowestLevel);
        row.put("highest_level", highestLevel);
        row.put("location", location);
        row.put("frequency", frequency);
        row.put("duration", duration);
        return row;
    }

    @Test
    void formIncludesCurrentFactorAndActivitySelectionsAndAllLookupOptions() {
        when(repository.findPainByVisitId(7)).thenReturn(
                Optional.of(painRow(99, 1, 3, 0, 7, "Right knee", "Daily", "Minutes")));
        when(repository.findFactorIds(99)).thenReturn(List.of(5, 2));
        when(repository.findActivitiesImpactedIds(99)).thenReturn(List.of(3));
        when(repository.findAssessmentMethodOptions())
                .thenReturn(List.of(Map.of("id", 1, "label", "Numerical")));
        when(repository.findFactorOptions()).thenReturn(
                List.of(Map.of("id", 2, "label", "walking"), Map.of("id", 5, "label", "weightbearing")));
        when(repository.findActivitiesImpactedOptions()).thenReturn(List.of(Map.of("id", 3, "label", "sleep")));

        PtEvaluationForm form = service.buildForm(42, 7);

        assertEquals("pain", form.tab());
        var fields = form.sections().get(0).fields();
        assertEquals("1", fields.get(0).value()); // assessmentMethod
        assertEquals(List.of("5", "2"), fields.get(1).value()); // factors, in stored order
        assertEquals(List.of("3"), fields.get(2).value()); // activitiesImpacted
        assertEquals("3", fields.get(3).value()); // currentLevel
        assertEquals(11, fields.get(3).options().size()); // 0..10
    }

    @Test
    void saveRejectsAStaleRevision() {
        when(repository.findPainByVisitId(7)).thenReturn(Optional.of(painRow(99, null, null, null, null, null, null, null)));
        when(repository.findFactorIds(99)).thenReturn(List.of());
        when(repository.findActivitiesImpactedIds(99)).thenReturn(List.of());

        var exception = assertThrows(org.springframework.web.server.ResponseStatusException.class,
                () -> service.save(42, 7, "stale", Map.of()));

        assertEquals(org.springframework.http.HttpStatus.CONFLICT, exception.getStatusCode());
        verify(repository, never()).updateRecord(anyInt(), any(), any(), any(), any(), any(), any(), any());
    }

    @Test
    void saveValidatesLevelsAndLookupIdsBeforeWritingAnything() {
        Map<String, Object> row = painRow(99, null, null, null, null, null, null, null);
        when(repository.findPainByVisitId(7)).thenReturn(Optional.of(row));
        when(repository.findFactorIds(99)).thenReturn(List.of());
        when(repository.findActivitiesImpactedIds(99)).thenReturn(List.of());
        String currentRevision = revisionOfSnapshot(row);

        Map<String, Object> values = new HashMap<>();
        values.put("currentLevel", "15"); // out of range
        values.put("assessmentMethod", "999"); // doesn't exist
        when(repository.existsAssessmentMethod(999)).thenReturn(false);

        var exception = assertThrows(PtEvaluationValidationException.class,
                () -> service.save(42, 7, currentRevision, values));

        assertTrue(exception.fieldErrors().containsKey("currentLevel"));
        assertTrue(exception.fieldErrors().containsKey("assessmentMethod"));
        verify(repository, never()).updateRecord(anyInt(), any(), any(), any(), any(), any(), any(), any());
    }

    @Test
    void saveReplacesFactorAndActivityLinksAndUpdatesScalarFields() {
        Map<String, Object> row = painRow(99, null, 3, null, null, "knee", null, null);
        when(repository.findPainByVisitId(7)).thenReturn(Optional.of(row));
        when(repository.findFactorIds(99)).thenReturn(List.of(2));
        when(repository.findActivitiesImpactedIds(99)).thenReturn(List.of());
        when(repository.existsFactor(5)).thenReturn(true);
        when(repository.existsActivityImpacted(3)).thenReturn(true);
        String currentRevision = revisionOfSnapshot(row, List.of(2), List.of());

        Map<String, Object> values = new HashMap<>();
        values.put("factors", List.of("5"));
        values.put("activitiesImpacted", List.of("3"));
        values.put("currentLevel", "7");
        values.put("location", ""); // "" clears

        service.save(42, 7, currentRevision, values);

        verify(repository).updateRecord(99, null, 7, null, null, null, null, null);
        verify(repository).replaceFactorLinks(99, List.of(5));
        verify(repository).replaceActivitiesImpactedLinks(99, List.of(3));
    }

    @Test
    void createRecordInsertsABlankRowAndRejectsWhenOneAlreadyExists() {
        when(repository.findPainByVisitId(7)).thenReturn(Optional.empty());

        service.createRecord(42, 7);

        verify(repository).insertBlankRecord(7);

        when(repository.findPainByVisitId(7)).thenReturn(Optional.of(painRow(1, null, null, null, null, null, null, null)));
        assertThrows(org.springframework.web.server.ResponseStatusException.class,
                () -> service.createRecord(42, 7));
    }

    private String revisionOfSnapshot(Map<String, Object> row) {
        return revisionOfSnapshot(row, List.of(), List.of());
    }

    private String revisionOfSnapshot(Map<String, Object> row, List<Integer> factorIds, List<Integer> activityIds) {
        Map<String, Object> snapshot = new java.util.LinkedHashMap<>(row);
        snapshot.put("factorIds", factorIds.stream().sorted().toList());
        snapshot.put("activityIds", activityIds.stream().sorted().toList());
        return revision.of(snapshot);
    }
}
