package org.nemours.gaitlab.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.nemours.gaitlab.repository.PtEvaluationRepository;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.repository.VisitRepository.ComparisonHeaderRow;
import org.nemours.gaitlab.repository.VisitRepository.PtGeneralEvaluationRow;
import org.nemours.gaitlab.repository.VisitRepository.VideoVisitDate;
import org.nemours.gaitlab.service.PtEvaluationService.General;
import org.nemours.gaitlab.service.PtEvaluationService.GeneralEvaluation;
import org.nemours.gaitlab.service.PtEvaluationService.GmfmModule;
import org.nemours.gaitlab.service.PtEvaluationTab.Row;
import org.nemours.gaitlab.service.PtEvaluationTab.Section;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

class ComparisonReportServiceTest {
    private final VisitRepository visits = mock(VisitRepository.class);
    private final PtEvaluationService generalService = mock(PtEvaluationService.class);
    private final PtEvaluationRepository repository = mock(PtEvaluationRepository.class);
    private final ComparisonReportService service =
            new ComparisonReportService(visits, generalService, repository);

    private void visit() {
        VisitRepository.InterpretationVisit visit = () -> 1;
        when(visits.findInterpretationVisitByIdAndPatientId(7, 42)).thenReturn(Optional.of(visit));
        stubVisitDate(7, "2024-03-15");
    }

    private void stubVisitDate(int visitId, String isoDate) {
        VideoVisitDate videoVisitDate = new VideoVisitDate() {
            public Integer getId() { return visitId; }
            public String getVisitDate() { return isoDate; }
        };
        when(visits.findVideoVisitDateByIdAndPatientId(visitId, 42)).thenReturn(Optional.of(videoVisitDate));
    }

    private void noData(int visitId) {
        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(visitId, 42)).thenReturn(Optional.empty());
        when(generalService.getGeneral(42, visitId)).thenReturn(emptyEvaluation(visitId));
        when(repository.findPromByVisitId(visitId)).thenReturn(Optional.empty());
        when(repository.findMotorControlByVisitId(visitId)).thenReturn(List.of());
        when(repository.findToneByVisitId(visitId)).thenReturn(List.of());
    }

    private static GeneralEvaluation emptyEvaluation(int visitId) {
        General general = new General(null, null, null, null, null, null, null, null, null, null, null, null, null, null);
        return new GeneralEvaluation(42, visitId, general, List.of(), List.of(), null, null);
    }

    private Section findSection(ComparisonReport report, String title) {
        return report.sections().stream().filter(s -> title.equals(s.title())).findFirst().orElseThrow();
    }

    private Row findRow(Section section, String label) {
        return section.rows().stream().filter(r -> label.equals(r.label())).findFirst().orElseThrow();
    }

    @Test
    void missingCurrentVisitIs404BeforeQueryingAnything() {
        assertEquals(HttpStatus.NOT_FOUND,
                assertThrows(ResponseStatusException.class, () -> service.build(42, 7, null, null))
                        .getStatusCode());
        verifyNoInteractions(generalService, repository);
    }

    @Test
    void headerUsesPatientNameMrnAndCurrentVisitHeightWeight() {
        visit();
        ComparisonHeaderRow headerRow = mock(ComparisonHeaderRow.class);
        when(headerRow.getFirstName()).thenReturn("Jane");
        when(headerRow.getLastName()).thenReturn("Doe");
        when(headerRow.getMrn()).thenReturn("12345");
        when(headerRow.getTherapistFirstName()).thenReturn("Pat");
        when(headerRow.getTherapistLastName()).thenReturn("Smith");
        when(headerRow.getInterpretingDoctorFirstName()).thenReturn(null);
        when(headerRow.getInterpretingDoctorLastName()).thenReturn(null);
        when(headerRow.getDob()).thenReturn(LocalDate.of(2016, 3, 15));
        when(headerRow.getGender()).thenReturn("F");
        when(headerRow.getVisitDate()).thenReturn(LocalDate.of(2024, 3, 15));
        when(visits.findComparisonHeaderByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(headerRow));

        General general = new General(138.5f, 32.4f, null, null, null, null, null, null, null, null, null, null,
                null, null);
        when(generalService.getGeneral(42, 7)).thenReturn(new GeneralEvaluation(42, 7, general, List.of(), List.of(),
                null, null));
        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.empty());
        when(repository.findPromByVisitId(7)).thenReturn(Optional.empty());
        when(repository.findMotorControlByVisitId(7)).thenReturn(List.of());
        when(repository.findToneByVisitId(7)).thenReturn(List.of());

        ComparisonReport report = service.build(42, 7, null, null);

        assertEquals("Physical Therapy Evaluation - Comparison Report", report.title());
        var header = report.header();
        assertTrue(header.stream().anyMatch(h -> h.label().equals("Name") && h.value().equals("Jane Doe")));
        assertTrue(header.stream().anyMatch(h -> h.label().equals("MRN") && h.value().equals("12345")));
        assertTrue(header.stream().anyMatch(h -> h.label().equals("Height (cm)") && h.value().equals("138.5")));
        assertTrue(header.stream().anyMatch(h -> h.label().equals("Therapist") && h.value().equals("Pat Smith")));
        assertTrue(header.stream().anyMatch(h -> h.label().equals("Doctor (interp)") && h.value() == null));
        assertTrue(header.stream().anyMatch(h -> h.label().equals("Date of Eval") && h.value().equals("3/15/24")));
        assertTrue(header.stream().anyMatch(h -> h.label().equals("Date of Birth") && h.value().equals("3/15/16")));
        assertTrue(header.stream().anyMatch(h -> h.label().equals("Age at Eval") && h.value().equals("8.00")));
        assertTrue(header.stream().anyMatch(h -> h.label().equals("Gender") && h.value().equals("F")));
    }

    @Test
    void promSectionConvertsWnlAndOnlyIncludesVisitsWithPromData() {
        visit();
        when(visits.findComparisonHeaderByVisitIdAndPatientId(7, 42))
                .thenReturn(Optional.of(mock(ComparisonHeaderRow.class)));
        noData(7);
        noData(5);

        Map<String, Object> promRow7 = new HashMap<>();
        promRow7.put("hip_flex_r", 999);
        promRow7.put("hip_flex_l", 110);
        when(repository.findPromByVisitId(7)).thenReturn(Optional.of(promRow7));
        // visit 5 (compareVisitId1) has no PROM data at all - must be excluded from the section's columns.

        ComparisonReport report = service.build(42, 7, 5, null);

        Section prom = findSection(report, "Passive ROM");
        // leading "" label column, plus only visit 7's Right/Left - visit 5 excluded
        assertEquals(List.of("", "Right", "Left"), prom.columns());
        assertEquals("", prom.columnGroups().get(0).label());
        assertEquals(1, prom.columnGroups().get(0).span());
        assertEquals("3/15/24", prom.columnGroups().get(1).label()); // visit 7's own date, not "Visit 1"
        Row hipFlex = findRow(prom, "Hip Flex");
        assertEquals("WNL", hipFlex.cells().get(0));
        assertEquals("110", hipFlex.cells().get(1));
    }

    @Test
    void strengthSectionOnlyIncludesFieldsWithAStrengthPair() {
        visit();
        when(visits.findComparisonHeaderByVisitIdAndPatientId(7, 42))
                .thenReturn(Optional.of(mock(ComparisonHeaderRow.class)));
        noData(7);
        Map<String, Object> promRow = new HashMap<>();
        promRow.put("hip_flex_s_r", "4+");
        when(repository.findPromByVisitId(7)).thenReturn(Optional.of(promRow));

        ComparisonReport report = service.build(42, 7, null, null);

        Section strength = findSection(report, "Strength");
        assertTrue(strength.rows().stream().anyMatch(r -> r.label().equals("Hip Flex")));
        assertTrue(strength.rows().stream().noneMatch(r -> r.label().equals("Hip Int Rot"))); // no strength pair
        assertEquals("4+", findRow(strength, "Hip Flex").cells().get(0));
    }

    @Test
    void legLengthPopAngleAndQAngleUseTheirOwnFormats() {
        visit();
        when(visits.findComparisonHeaderByVisitIdAndPatientId(7, 42))
                .thenReturn(Optional.of(mock(ComparisonHeaderRow.class)));
        noData(7);
        Map<String, Object> promRow = new HashMap<>();
        promRow.put("leg_length_r", 35.5f);
        promRow.put("pop_r_low", 10);
        promRow.put("pop_r_high", 50);
        promRow.put("q_angle_r", 5);
        promRow.put("q_angle_l", -3);
        when(repository.findPromByVisitId(7)).thenReturn(Optional.of(promRow));

        ComparisonReport report = service.build(42, 7, null, null);

        assertEquals("35.5", findRow(findSection(report, "Leg Length (cm)"), "Leg Length (cm)").cells().get(0));
        assertEquals("10 -- 50", findRow(findSection(report, "Pop angle"), "Pop angle").cells().get(0));
        var qAngle = findRow(findSection(report, "Knee Varus/Valgus"), "Knee Varus/Valgus");
        assertEquals("5 Valgus", qAngle.cells().get(0));
        assertEquals("3 Varus", qAngle.cells().get(1));
    }

    @Test
    void visitWithNullDateColumnFallsBackToVisitIdLabelInsteadOfThrowing() {
        visit();
        when(visits.findComparisonHeaderByVisitIdAndPatientId(7, 42))
                .thenReturn(Optional.of(mock(ComparisonHeaderRow.class)));
        noData(7);
        noData(5);
        // A real schema case: the visits row exists (and belongs to this patient) but its date
        // column is NULL - v.date::text then yields a present VideoVisitDate with a null
        // visitDate string, not an absent Optional. Caught via live testing (visit 13/14 in the
        // seed data have no date at all).
        VideoVisitDate nullDate = new VideoVisitDate() {
            public Integer getId() { return 5; }
            public String getVisitDate() { return null; }
        };
        when(visits.findVideoVisitDateByIdAndPatientId(5, 42)).thenReturn(Optional.of(nullDate));

        Map<String, Object> promRow7 = new HashMap<>();
        promRow7.put("hip_flex_r", 100);
        when(repository.findPromByVisitId(7)).thenReturn(Optional.of(promRow7));
        Map<String, Object> promRow5 = new HashMap<>();
        promRow5.put("hip_flex_r", 95);
        when(repository.findPromByVisitId(5)).thenReturn(Optional.of(promRow5));

        ComparisonReport report = service.build(42, 7, 5, null);

        Section prom = findSection(report, "Passive ROM");
        assertEquals("", prom.columnGroups().get(0).label());
        assertEquals("3/15/24", prom.columnGroups().get(1).label());
        assertEquals("Visit 5", prom.columnGroups().get(2).label());
    }

    @Test
    void motorControlAlignsRowsByIndexAcrossVisitsAndDoesNotShadeStarredTests() {
        visit();
        when(visits.findComparisonHeaderByVisitIdAndPatientId(7, 42))
                .thenReturn(Optional.of(mock(ComparisonHeaderRow.class)));
        noData(7);
        noData(5);
        when(repository.findPromByVisitId(7)).thenReturn(Optional.empty());
        when(repository.findPromByVisitId(5)).thenReturn(Optional.empty());
        when(repository.findMotorControlByVisitId(7)).thenReturn(List.of(
                Map.of("test", "*Selective Control Notes", "score_r", "2", "score_l", "3")));
        when(repository.findMotorControlByVisitId(5)).thenReturn(List.of(
                Map.of("test", "*Selective Control Notes", "score_r", "1", "score_l", "1")));

        ComparisonReport report = service.build(42, 7, 5, null);

        Section mc = findSection(report, "Motor Control");
        assertEquals(5, mc.columns().size()); // leading "" label column + Right/Left x 2 visits
        Row starred = findRow(mc, "*Selective Control Notes");
        // Score is NOT suppressed/shaded for "*" tests in the comparison report, unlike the tab view.
        assertEquals(List.of("2", "3", "1", "1"), starred.cells());
    }

    @Test
    void gmfmDUsesDashForMissingValuesNotZero() {
        visit();
        when(visits.findComparisonHeaderByVisitIdAndPatientId(7, 42))
                .thenReturn(Optional.of(mock(ComparisonHeaderRow.class)));
        when(repository.findPromByVisitId(7)).thenReturn(Optional.empty());
        when(repository.findMotorControlByVisitId(7)).thenReturn(List.of());
        when(repository.findToneByVisitId(7)).thenReturn(List.of());

        PtGeneralEvaluationRow row = generalRow(3, null);
        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(row));
        General general = new General(null, null, null, null, null, null, null, null, "1 -- desc", null, null,
                null, null, null);
        when(generalService.getGeneral(42, 7)).thenReturn(new GeneralEvaluation(42, 7, general, List.of(),
                List.of(new GmfmModule("D", 3, 39, 8)), null, null));

        ComparisonReport report = service.build(42, 7, null, null);

        Section gmfmD = findSection(report, "Functional Strength - GMFM-D");
        Row pullToStand = findRow(gmfmD, "Pull to stand (52)");
        assertEquals("3", pullToStand.cells().get(0));
        Row oneLeg = findRow(gmfmD, "One leg stance (57,58)");
        assertEquals("--", oneLeg.cells().get(0)); // null, not 0
    }

    @Test
    void mobilityScalesShowsAmbulationAlwaysAndGmfcsDashWhenUnresolvedButOmitsUngatedFms() {
        visit();
        when(visits.findComparisonHeaderByVisitIdAndPatientId(7, 42))
                .thenReturn(Optional.of(mock(ComparisonHeaderRow.class)));
        when(repository.findPromByVisitId(7)).thenReturn(Optional.empty());
        when(repository.findMotorControlByVisitId(7)).thenReturn(List.of());
        when(repository.findToneByVisitId(7)).thenReturn(List.of());
        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(7, 42))
                .thenReturn(Optional.of(generalRow(0, null)));

        General general = new General(null, null, null, null, null, null, null, null, "1 -- Independent", "--",
                null, null, null, null);
        when(generalService.getGeneral(42, 7))
                .thenReturn(new GeneralEvaluation(42, 7, general, List.of(), List.of(new GmfmModule("D", 0, 39, 0)),
                        null, null));

        ComparisonReport report = service.build(42, 7, null, null);

        Section mobility = findSection(report, "Mobility Scales");
        assertEquals("1 -- Independent", findRow(mobility, "Ambulation Scale").cells().get(0));
        assertEquals("--", findRow(mobility, "GMFCS").cells().get(0));
        assertEquals("N/A", findRow(mobility, "Total GMFM Score").cells().get(0));
        assertTrue(mobility.rows().stream().noneMatch(r -> r.label().equals("FMS (5m)"))); // no visit has a value
    }

    @Test
    void otherGmfmModulesShowsAZeroScoreUnlikeTheGeneralTabsViewWhichTreatsZeroAsNoEntry() {
        visit();
        when(visits.findComparisonHeaderByVisitIdAndPatientId(7, 42))
                .thenReturn(Optional.of(mock(ComparisonHeaderRow.class)));
        when(repository.findPromByVisitId(7)).thenReturn(Optional.empty());
        when(repository.findMotorControlByVisitId(7)).thenReturn(List.of());
        when(repository.findToneByVisitId(7)).thenReturn(List.of());
        PtGeneralEvaluationRow row = generalRow(0, 0);
        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(row));
        when(generalService.getGeneral(42, 7)).thenReturn(emptyEvaluation(7));

        ComparisonReport report = service.build(42, 7, null, null);

        Section modules = findSection(report, "Other GMFM Modules");
        assertTrue(modules.items().contains("Module A: 0"));
    }

    @Test
    void notesIsCurrentVisitCommentsOnly() {
        visit();
        when(visits.findComparisonHeaderByVisitIdAndPatientId(7, 42))
                .thenReturn(Optional.of(mock(ComparisonHeaderRow.class)));
        when(repository.findPromByVisitId(7)).thenReturn(Optional.empty());
        when(repository.findMotorControlByVisitId(7)).thenReturn(List.of());
        when(repository.findToneByVisitId(7)).thenReturn(List.of());
        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(7, 42))
                .thenReturn(Optional.of(generalRow(null, null)));
        General general = new General(null, null, null, null, null, null, null, null, null, null, null, null, null,
                "Doing well");
        when(generalService.getGeneral(42, 7)).thenReturn(new GeneralEvaluation(42, 7, general, List.of(), List.of(),
                null, null));

        ComparisonReport report = service.build(42, 7, null, null);

        assertEquals("Doing well", findSection(report, "Notes").text());
    }

    /** Minimal PtGeneralEvaluationRow stub - only the getters the test under test actually
     * reads (GMFM-D task fields + module A) are wired; everything else is null. */
    private static PtGeneralEvaluationRow generalRow(Integer pullStand, Integer gmfmModA) {
        return new PtGeneralEvaluationRow() {
            public Integer getDataPtId() { return 1; }
            public java.time.LocalDate getVisitDate() { return null; }
            public Integer getIcd9() { return null; }
            public java.time.LocalDate getDob() { return null; }
            public String getGender() { return null; }
            public Integer getGenDiag() { return null; }
            public Float getHeightCm() { return null; }
            public Float getWeightKg() { return null; }
            public Float getRightFootLengthCm() { return null; }
            public Float getLeftFootLengthCm() { return null; }
            public Float getRightFootWidthCm() { return null; }
            public Float getLeftFootWidthCm() { return null; }
            public Integer getAmbScaleId() { return null; }
            public String getAmbulationScale() { return null; }
            public Integer getGmfcsId() { return null; }
            public Integer getFms5Id() { return null; }
            public String getFms5m() { return null; }
            public String getFms5mDesc() { return null; }
            public Integer getFms50Id() { return null; }
            public String getFms50m() { return null; }
            public String getFms50mDesc() { return null; }
            public Integer getFms500Id() { return null; }
            public String getFms500m() { return null; }
            public String getFms500mDesc() { return null; }
            public String getComments() { return null; }
            public Integer getPullStand() { return pullStand; }
            public Integer getIndepStand3() { return null; }
            public Integer getIndepStand20() { return null; }
            public Integer getOneLegHandR() { return null; }
            public Integer getOneLegHandL() { return null; }
            public Integer getOneLegR() { return null; }
            public Integer getOneLegL() { return null; }
            public Integer getShortSitStand() { return null; }
            public Integer getHighKneeStandR() { return null; }
            public Integer getHighKneeStandL() { return null; }
            public Integer getLowerFloor() { return null; }
            public Integer getSquats() { return null; }
            public Integer getStandPickPen() { return null; }
            public Integer getGmfmModA() { return gmfmModA; }
            public Integer getGmfmModB() { return null; }
            public Integer getGmfmModC() { return null; }
            public Integer getGmfmModE() { return null; }
        };
    }
}
