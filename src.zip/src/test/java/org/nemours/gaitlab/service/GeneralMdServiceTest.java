package org.nemours.gaitlab.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.nemours.gaitlab.repository.PtEvaluationRepository;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.repository.VisitRepository.PtGeneralMdEvaluationRow;
import org.nemours.gaitlab.service.PtEvaluationTab.Row;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import tools.jackson.databind.ObjectMapper;

class GeneralMdServiceTest {
    private final VisitRepository visits = mock(VisitRepository.class);
    private final PtEvaluationRepository repository = mock(PtEvaluationRepository.class);
    private final PtEvaluationRevision revision = new PtEvaluationRevision(new ObjectMapper());
    private final GeneralMdService service =
            new GeneralMdService(visits, repository, revision);

    private void visit() {
        VisitRepository.InterpretationVisit visit = () -> 11;
        when(visits.findInterpretationVisitByIdAndPatientId(7, 42)).thenReturn(Optional.of(visit));
    }

    private PtGeneralMdEvaluationRow row() {
        PtGeneralMdEvaluationRow row = mock(PtGeneralMdEvaluationRow.class);
        when(row.getDataPtMdId()).thenReturn(99);
        when(row.getGenDiag()).thenReturn(15); // isCP range (13-17) - GMFCS row is CP-gated
        when(row.getAmbulationScale()).thenReturn("Household");
        when(row.getAmbScaleId()).thenReturn(3);
        when(row.getGmfcsLabel()).thenReturn("II");
        when(row.getGmfcsDesc()).thenReturn("Walks with limitations");
        when(row.getMacsLabel()).thenReturn("I");
        when(row.getMacsDesc()).thenReturn("Handles objects easily");
        when(row.getCfcsLabel()).thenReturn("I");
        when(row.getCfcsDesc()).thenReturn("Effective Sender");
        when(row.getComments()).thenReturn("Looks good");
        return row;
    }

    private static Row findRow(PtEvaluationTab result, String label) {
        return result.sections().get(0).rows().stream()
                .filter(r -> label.equals(r.label())).findFirst().orElseThrow();
    }

    @Test
    void missingVisitIs404() {
        assertEquals(HttpStatus.NOT_FOUND,
                assertThrows(ResponseStatusException.class,
                        () -> service.getGeneral(42, 7, "general-md")).getStatusCode());
    }

    @Test
    void noDataYetReturnsTheGenericEmptyTabShape() {
        visit();
        when(visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.empty());

        PtEvaluationTab result = service.getGeneral(42, 7, "general-md");

        assertEquals("general-md", result.tab());
        assertFalse(result.hasData());
        assertEquals(GeneralMdService.EMPTY_MESSAGE, result.emptyMessage());
    }

    /** Regression test for the frontend's actual contract: the view must be the generic
     * {tab, hasData, sections:[{columns, rows}]} shape, not a bespoke {general:{...}} object -
     * the frontend's renderer picks on 'gmfmD' in view and renders an empty page otherwise. */
    @Test
    void buildsLabelDashRowsFromTheMdLookupJoinsAsAGenericTabSection() {
        visit();
        PtGeneralMdEvaluationRow row = row();
        when(visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(row));

        PtEvaluationTab result = service.getGeneral(42, 7, "general-md");

        assertEquals("general-md", result.tab());
        assertTrue(result.hasData());
        assertEquals(List.of("", ""), result.sections().get(0).columns());
        assertEquals("3 -- Household", findRow(result, "Ambulation Scale").cells().get(0));
        assertEquals("II -- Walks with limitations", findRow(result, "GMFCS").cells().get(0));
        assertEquals("I -- Handles objects easily", findRow(result, "MACS").cells().get(0));
        assertEquals("I -- Effective Sender", findRow(result, "CFCS").cells().get(0));
        assertEquals("Looks good", findRow(result, "Comments").cells().get(0));
        assertEquals("General and Marker Information", result.sections().get(0).title());
    }

    /** pt.jsp wraps the ENTIRE GMFCS <TR> in the same isCP(gen_diag)||isCP(diagnosis) check for
     * the movement-disorder branch as it does for Gait - this row isn't unconditional like
     * Ambulation Scale/FMS/MACS/CFCS. */
    @Test
    void gmfcsRowIsOmittedWhenNeitherDiagnosisIsCP() {
        visit();
        PtGeneralMdEvaluationRow row = row();
        when(row.getGenDiag()).thenReturn(5); // not in the CP range (13-17, 119, 142)
        when(row.getIcd9()).thenReturn(5);
        when(visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(row));

        PtEvaluationTab result = service.getGeneral(42, 7, "general-md");

        assertTrue(result.sections().get(0).rows().stream().noneMatch(r -> "GMFCS".equals(r.label())));
    }

    @Test
    void heightAndWeightRowsIncludeTheZScoreInTheSameCell() {
        visit();
        PtGeneralMdEvaluationRow row = row();
        when(row.getHeightCm()).thenReturn(138.5f);
        when(row.getWeightKg()).thenReturn(32.4f);
        when(row.getGender()).thenReturn("Female");
        when(row.getVisitDate()).thenReturn(java.time.LocalDate.of(2024, 9, 16));
        when(row.getDob()).thenReturn(java.time.LocalDate.of(2015, 6, 12));
        when(visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(row));

        PtEvaluationTab result = service.getGeneral(42, 7, "general-md");

        String heightCell = findRow(result, "Height (cm)").cells().get(0);
        assertTrue(heightCell.startsWith("138.5 (z ="), heightCell);
        String weightCell = findRow(result, "Weight (kg)").cells().get(0);
        assertTrue(weightCell.startsWith("32.4 (z ="), weightCell);
    }

    @Test
    void heightRowIsOmittedFromDisplayWhenNoHeightIsOnFile() {
        visit();
        PtGeneralMdEvaluationRow row = row();
        // Mockito's default for an unstubbed Float-returning method is 0.0f, not null - stub it
        // explicitly so this test actually exercises the "nothing on file" path.
        when(row.getHeightCm()).thenReturn(null);
        when(visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(row));

        PtEvaluationTab result = service.getGeneral(42, 7, "general-md");

        assertNull(findRow(result, "Height (cm)").cells().get(0));
    }

    @Test
    void buildFormIncludesMacsAndCfcsSelectsButNotOrthoses() {
        visit();
        PtGeneralMdEvaluationRow row = row();
        when(row.getMacsId()).thenReturn(3);
        when(row.getCfcsId()).thenReturn(2);
        when(visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(row));
        when(repository.findActiveMacsListEntries()).thenReturn(List.of(Map.of("id", 3, "label", "I")));
        when(repository.findActiveCfcsListEntries()).thenReturn(List.of(Map.of("id", 2, "label", "I")));
        when(repository.findActiveGmfcsListEntries()).thenReturn(List.of());
        when(repository.findActiveFmsListEntries()).thenReturn(List.of());

        PtEvaluationForm form = service.buildForm(42, 7);

        assertEquals("Modify General Data", form.title());
        List<String> fieldNames = form.sections().get(0).fields().stream()
                .map(PtEvaluationForm.Field::name).toList();
        assertTrue(fieldNames.contains("macs"));
        assertTrue(fieldNames.contains("cfcs"));
        assertFalse(fieldNames.contains("orthoses")); // not in modify_pt.jsp's MD field list
        assertFalse(fieldNames.contains("pull_stand")); // no GMFM-D fields for MD at all
    }

    @Test
    void saveRejectsAUnknownMacsIdAndKeepsTheCurrentValue() {
        visit();
        PtGeneralMdEvaluationRow row = row();
        when(row.getMacsId()).thenReturn(3);
        when(visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(row));
        // buildForm() computes the real revision token off the same row - read it through there
        // rather than re-deriving the snapshot shape by hand.
        when(repository.findActiveGmfcsListEntries()).thenReturn(List.of());
        when(repository.findActiveFmsListEntries()).thenReturn(List.of());
        when(repository.findActiveMacsListEntries()).thenReturn(List.of());
        when(repository.findActiveCfcsListEntries()).thenReturn(List.of());
        String actualRevision = service.buildForm(42, 7).revision();

        when(repository.existsMacsListEntry(999)).thenReturn(false);

        assertThrows(PtEvaluationValidationException.class,
                () -> service.save(42, 7, actualRevision, Map.of("macs", "999")));
    }

    @Test
    void createRecordConflictsIfOneAlreadyExists() {
        PtGeneralMdEvaluationRow row = row();
        when(visits.findPtGeneralMdEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(row));
        assertEquals(HttpStatus.CONFLICT,
                assertThrows(ResponseStatusException.class, () -> service.createRecord(42, 7)).getStatusCode());
    }
}
