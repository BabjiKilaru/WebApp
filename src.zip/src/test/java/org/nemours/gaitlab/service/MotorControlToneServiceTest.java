package org.nemours.gaitlab.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.nemours.gaitlab.repository.PtEvaluationRepository;
import org.nemours.gaitlab.service.PtEvaluationForm.Field;
import org.nemours.gaitlab.service.PtEvaluationTab.Section;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import tools.jackson.databind.ObjectMapper;

class MotorControlToneServiceTest {
    private final PtEvaluationRepository repository = mock(PtEvaluationRepository.class);
    private final PtEvaluationRevision revision = new PtEvaluationRevision(new ObjectMapper());
    private final MotorControlToneService service = new MotorControlToneService(repository, revision);

    private static Map<String, Object> row(int id, String test, String scoreR, String interpR, String scoreL,
            String interpL) {
        Map<String, Object> data = new HashMap<>();
        data.put("id", id);
        data.put("test", test);
        data.put("score_r", scoreR);
        data.put("interp_r", interpR);
        data.put("score_l", scoreL);
        data.put("interp_l", interpL);
        return data;
    }

    @Test
    void motorControlEmptyMessageMatchesLegacyExactly() {
        when(repository.findMotorControlByVisitId(7)).thenReturn(List.of());

        PtEvaluationTab result = service.buildMotorControl(42, 7, "motor-control");

        assertFalse(result.hasData());
        assertEquals("No motor control data has been entered yet for this visit.", result.emptyMessage());
    }

    @Test
    void toneEmptyMessagePreservesLegacyDoubleSpaceTypo() {
        when(repository.findToneByVisitId(7)).thenReturn(List.of());

        PtEvaluationTab result = service.buildTone(42, 7, "tone");

        assertEquals("No tone  data has been entered yet for this visit.", result.emptyMessage());
    }

    @Test
    void asteriskPrefixedTestsHideTheirScoreCellsButKeepTheLabelAndInterp() {
        when(repository.findMotorControlByVisitId(7)).thenReturn(List.of(
                Map.of("test", "Iliopsoas", "score_r", "2", "interp_r", "mild", "score_l", "3", "interp_l", "mod"),
                Map.of("test", "*Proximal Muscle Control", "interp_r", "fair", "interp_l", "good")));

        PtEvaluationTab result = service.buildMotorControl(42, 7, "motor-control");

        assertTrue(result.hasData());
        Section section = result.sections().get(0);
        assertEquals("* Interpretation only", section.footnote());

        var normal = section.rows().get(0);
        assertEquals(List.of("2", "mild", "3", "mod"), normal.cells());

        var starred = section.rows().get(1);
        assertEquals("*Proximal Muscle Control", starred.label());
        assertNull(starred.cells().get(0)); // score cells hidden for interpretation-only tests
        assertEquals("fair", starred.cells().get(1));
        assertNull(starred.cells().get(2));
        assertEquals("good", starred.cells().get(3));
    }

    @Test
    void formHidesScoreFieldsForInterpretationOnlyRowsAndIncludesCurrentInterpValueInOptions() {
        when(repository.findMotorControlByVisitId(7)).thenReturn(List.of(
                row(1, "Iliopsoas", "2", "mild", "3", "normal"),
                row(2, "*Proximal Muscle Control", null, "fair", null, "good")));
        when(repository.findMcListOptions()).thenReturn(List.of());

        PtEvaluationForm form = service.buildMotorControlForm(7);

        assertEquals("motor-control", form.tab());
        assertEquals("Modify  Motor Control", form.title()); // legacy's own literal double space
        assertNotNull(form.revision());
        var rows = form.sections().get(0).rows();

        var normal = rows.get(0);
        assertEquals("score_r_1", normal.fields().get(0).name());
        assertEquals("2", normal.fields().get(0).value());
        assertTrue(normal.fields().get(1).options().stream().anyMatch(o -> o.value().equals("mild")));

        var starred = rows.get(1);
        assertNull(starred.fields().get(0)); // no score field at all for a "*" test
        assertEquals("interp_r_2", starred.fields().get(1).name());
        assertEquals("fair", starred.fields().get(1).value());
        // "fair" isn't in the (empty) mc_list lookup, but must still appear so it isn't lost.
        assertTrue(starred.fields().get(1).options().stream().anyMatch(o -> o.value().equals("fair")));
        assertNull(starred.fields().get(2));
    }

    @Test
    void saveRejectsAStaleRevisionWithoutWritingAnything() {
        when(repository.findMotorControlByVisitId(7)).thenReturn(List.of(row(1, "Iliopsoas", "2", "mild", "3", "normal")));

        var exception = assertThrows(ResponseStatusException.class,
                () -> service.saveMotorControl(42, 7, "stale-revision", Map.of()));

        assertEquals(HttpStatus.CONFLICT, exception.getStatusCode());
        verify(repository, never()).updateScoreAndInterp(anyInt(), any(), any(), any(), any());
    }

    @Test
    void saveUpdatesScoreAndInterpForOrdinaryRowsAndOnlyInterpForStarredOnes() {
        List<Map<String, Object>> current = List.of(
                row(1, "Iliopsoas", "2", "mild", "3", "normal"),
                row(2, "*Proximal Muscle Control", null, "fair", null, "good"));
        when(repository.findMotorControlByVisitId(7)).thenReturn(current);
        String currentRevision = revision.of(current);

        Map<String, Object> values = new HashMap<>();
        values.put("score_r_1", "3+");
        values.put("interp_r_1", "mild");
        values.put("score_l_1", ""); // "" clears
        values.put("interp_l_1", "normal");
        values.put("interp_r_2", "excellent");
        // interp_l_2 omitted entirely - must be left unchanged, not cleared.

        service.saveMotorControl(42, 7, currentRevision, values);

        verify(repository).updateScoreAndInterp(1, "3+", "mild", null, "normal");
        verify(repository).updateInterpOnly(2, "excellent", "good");
        verify(repository, never()).updateInterpOnly(eq(1), any(), any());
        verify(repository, never()).updateScoreAndInterp(eq(2), any(), any(), any(), any());
    }

    @Test
    void createRecordInsertsABlankRowPerLookupTestAndRejectsWhenDataAlreadyExists() {
        when(repository.findMotorControlByVisitId(7)).thenReturn(List.of());
        when(repository.findMcTestNames()).thenReturn(List.of("Iliopsoas", "Glute Med"));

        service.createMotorControlRecord(42, 7);

        verify(repository).insertBlankRow(7, "Iliopsoas", "mc");
        verify(repository).insertBlankRow(7, "Glute Med", "mc");

        when(repository.findMotorControlByVisitId(7)).thenReturn(List.of(row(1, "Iliopsoas", null, null, null, null)));
        assertThrows(ResponseStatusException.class, () -> service.createMotorControlRecord(42, 7));
    }

    // --- Phase 4: pt-movement-disorder-eval-tone.jsp's Upper Extremity section -----------------

    @Test
    void gaitToneIgnoresUeToneEvenIfSomehowPresent() {
        when(repository.findToneByVisitId(7)).thenReturn(List.of(row(1, "Iliopsoas", "2", null, "2", null)));

        PtEvaluationTab result = service.buildTone(42, 7, "tone", false);

        assertEquals(1, result.sections().size());
        verify(repository, never()).findUeToneByVisitId(anyInt());
    }

    @Test
    void movementDisorderToneIsEmptyOnlyWhenBothToneAndUeToneAreMissing() {
        when(repository.findToneByVisitIdForMovementDisorder(7)).thenReturn(List.of());
        when(repository.findUeToneByVisitId(7)).thenReturn(java.util.Optional.empty());

        PtEvaluationTab result = service.buildTone(42, 7, "tone", true);

        assertFalse(result.hasData());
        assertEquals("No tone  data has been entered yet for this visit.", result.emptyMessage());
    }

    /** The UE rows land in the SAME table, right after the tone rows - no separate "Upper
     * Extremity" section/title (a peer-review correction: an earlier version of this port put
     * them in their own section, which doesn't match pt-movement-disorder-eval-tone.jsp's single
     * TABLE). */
    @Test
    void movementDisorderToneAppendsUpperExtremityRowsToTheSameTable() {
        when(repository.findToneByVisitIdForMovementDisorder(7))
                .thenReturn(List.of(row(1, "Iliopsoas", "2", null, "2", null)));
        Map<String, Object> ueTone = new HashMap<>();
        ueTone.put("id", 5);
        ueTone.put("shoulder_extensors_r", "3");
        ueTone.put("shoulder_extensors_l", "3+");
        when(repository.findUeToneByVisitId(7)).thenReturn(java.util.Optional.of(ueTone));

        PtEvaluationTab result = service.buildTone(42, 7, "tone", true);

        assertEquals(1, result.sections().size());
        Section section = result.sections().get(0);
        assertNull(section.title());
        assertEquals("Iliopsoas", section.rows().get(0).label());
        assertEquals("Shoulder extensors", section.rows().get(1).label());
        assertEquals(java.util.Arrays.asList("3", null, "3+", null), section.rows().get(1).cells());
    }

    /** Only tone_tests.id <= 16 shows for MD - Proximal/Distal Muscle Tone (100/101) and
     * *Clonus Severity Notes (102) are Gait-Tone-only. */
    @Test
    void movementDisorderToneUsesTheFilteredRepositoryMethodNotTheGaitOne() {
        when(repository.findToneByVisitIdForMovementDisorder(7)).thenReturn(List.of());
        when(repository.findUeToneByVisitId(7)).thenReturn(java.util.Optional.empty());

        service.buildTone(42, 7, "tone", true);

        verify(repository, never()).findToneByVisitId(anyInt());
    }

    @Test
    void createToneRecordAlsoInsertsTheUeToneRowForMovementDisorderVisits() {
        when(repository.findToneByVisitId(7)).thenReturn(List.of());
        when(repository.findUeToneByVisitId(7)).thenReturn(java.util.Optional.empty());
        when(repository.findToneTestNames()).thenReturn(List.of("Iliopsoas"));

        service.createToneRecord(42, 7, true);

        verify(repository).insertBlankRow(7, "Iliopsoas", "tone");
        verify(repository).insertBlankUeTone(7);
    }

    @Test
    void movementDisorderToneFormUsesTheFilteredRepositoryMethodNotTheGaitOne() {
        when(repository.findToneByVisitIdForMovementDisorder(7)).thenReturn(List.of());
        Map<String, Object> ueTone = new HashMap<>();
        ueTone.put("id", 5);
        when(repository.findUeToneByVisitId(7)).thenReturn(java.util.Optional.of(ueTone));

        service.buildToneForm(7, true);

        verify(repository, never()).findToneByVisitId(anyInt());
    }

    /** Gait gets legacy's own literal-double-space heading; MD keeps the generic "Edit Tone" -
     * pt-movement-disorder-eval-tone.jsp's heading is a copy-pasted "PT Evaluation: Tone", not
     * worth porting literally (a follow-up from frontend-master-03's audit). */
    @Test
    void gaitToneFormUsesLegacysOwnHeadingButMdKeepsTheGenericOne() {
        when(repository.findToneByVisitId(7)).thenReturn(List.of());
        assertEquals("Modify  Tone Data", service.buildToneForm(7, false).title());

        when(repository.findToneByVisitIdForMovementDisorder(7)).thenReturn(List.of());
        Map<String, Object> ueTone = new HashMap<>();
        ueTone.put("id", 5);
        when(repository.findUeToneByVisitId(7)).thenReturn(java.util.Optional.of(ueTone));
        assertEquals("Edit Tone", service.buildToneForm(7, true).title());
    }

    @Test
    void saveToneUpdatesUeToneColumnsFromTheFormValues() {
        when(repository.findToneByVisitIdForMovementDisorder(7)).thenReturn(List.of());
        Map<String, Object> ueTone = new HashMap<>();
        ueTone.put("id", 5);
        ueTone.put("shoulder_extensors_r", "2");
        when(repository.findUeToneByVisitId(7)).thenReturn(java.util.Optional.of(ueTone));
        Map<String, Object> revisionSnapshot = new java.util.LinkedHashMap<>();
        revisionSnapshot.put("tone", List.of());
        revisionSnapshot.put("ueTone", ueTone);
        String currentRevision = revision.of(revisionSnapshot);

        service.saveTone(42, 7, currentRevision, Map.of("shoulder_extensors_r", "4"), true);

        verify(repository).updateUeTone(eq(5), argThat(cols -> "4".equals(cols.get("shoulder_extensors_r"))));
    }
}
