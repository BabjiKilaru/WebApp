package org.nemours.gaitlab.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.nemours.gaitlab.repository.PtEvaluationRepository;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.repository.VisitRepository.GmfcsListEntry;
import org.nemours.gaitlab.repository.VisitRepository.PtGeneralEvaluationRow;
import org.nemours.gaitlab.service.PtEvaluationService.GeneralEvaluation;
import org.nemours.gaitlab.service.PtEvaluationService.GmfmModule;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import tools.jackson.databind.ObjectMapper;

class PtEvaluationServiceTest {
    private final VisitRepository visits = mock(VisitRepository.class);
    private final PtEvaluationRepository generalRepository = mock(PtEvaluationRepository.class);
    private final PtEvaluationRevision revision = new PtEvaluationRevision(new ObjectMapper());
    private final PtEvaluationService service = new PtEvaluationService(visits, generalRepository, revision);

    private void visit() {
        VisitRepository.InterpretationVisit visit = () -> 1;
        when(visits.findInterpretationVisitByIdAndPatientId(7, 42)).thenReturn(Optional.of(visit));
    }

    private PtGeneralEvaluationRow row(Integer pullStand, Integer indepStand3, Integer indepStand20,
            Integer oneLegHandR, Integer oneLegHandL, Integer oneLegR, Integer oneLegL,
            Integer shortSitStand, Integer highKneeStandR, Integer highKneeStandL,
            Integer lowerFloor, Integer squats, Integer standPickPen,
            Integer gmfmModA, Integer gmfmModB, Integer gmfmModC, Integer gmfmModE) {
        // Not CP (genDiag/icd9 null) by default, so these tests' gmfcs is always null and
        // unaffected by the fields the GMFCS row needs.
        return gmfcsRow(null, null, null, null, null, null,
                pullStand, indepStand3, indepStand20, oneLegHandR, oneLegHandL, oneLegR, oneLegL,
                shortSitStand, highKneeStandR, highKneeStandL, lowerFloor, squats, standPickPen,
                gmfmModA, gmfmModB, gmfmModC, gmfmModE);
    }

    private PtGeneralEvaluationRow gmfcsRow(Integer genDiag, Integer icd9, Integer gmfcsId, Integer ambScaleId,
            LocalDate dob, LocalDate visitDate,
            Integer pullStand, Integer indepStand3, Integer indepStand20,
            Integer oneLegHandR, Integer oneLegHandL, Integer oneLegR, Integer oneLegL,
            Integer shortSitStand, Integer highKneeStandR, Integer highKneeStandL,
            Integer lowerFloor, Integer squats, Integer standPickPen,
            Integer gmfmModA, Integer gmfmModB, Integer gmfmModC, Integer gmfmModE) {
        return new PtGeneralEvaluationRow() {
            public Integer getDataPtId() { return 1; }
            public LocalDate getVisitDate() { return visitDate; }
            public Integer getIcd9() { return icd9; }
            public LocalDate getDob() { return dob; }
            public String getGender() { return null; }
            public Integer getGenDiag() { return genDiag; }
            public Float getHeightCm() { return 120.5f; }
            public Float getWeightKg() { return null; }
            public Float getRightFootLengthCm() { return null; }
            public Float getLeftFootLengthCm() { return null; }
            public Float getRightFootWidthCm() { return null; }
            public Float getLeftFootWidthCm() { return null; }
            public Integer getAmbScaleId() { return ambScaleId; }
            public String getAmbulationScale() { return null; }
            public Integer getGmfcsId() { return gmfcsId; }
            public Integer getFms5Id() { return 8; }
            public String getFms5m() { return "6"; }
            public String getFms5mDesc() { return "Independent on all surfaces"; }
            public Integer getFms50Id() { return null; }
            public String getFms50m() { return null; }
            public String getFms50mDesc() { return null; }
            public Integer getFms500Id() { return null; }
            public String getFms500m() { return null; }
            public String getFms500mDesc() { return null; }
            public String getComments() { return null; }
            public Integer getPullStand() { return pullStand; }
            public Integer getIndepStand3() { return indepStand3; }
            public Integer getIndepStand20() { return indepStand20; }
            public Integer getOneLegHandR() { return oneLegHandR; }
            public Integer getOneLegHandL() { return oneLegHandL; }
            public Integer getOneLegR() { return oneLegR; }
            public Integer getOneLegL() { return oneLegL; }
            public Integer getShortSitStand() { return shortSitStand; }
            public Integer getHighKneeStandR() { return highKneeStandR; }
            public Integer getHighKneeStandL() { return highKneeStandL; }
            public Integer getLowerFloor() { return lowerFloor; }
            public Integer getSquats() { return squats; }
            public Integer getStandPickPen() { return standPickPen; }
            public Integer getGmfmModA() { return gmfmModA; }
            public Integer getGmfmModB() { return gmfmModB; }
            public Integer getGmfmModC() { return gmfmModC; }
            public Integer getGmfmModE() { return gmfmModE; }
        };
    }

    @Test
    void matchesScreenshotTestCaseWithAllZeroScoresAndNoModuleEntries() {
        visit();
        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(
                row(null, null, null, null, null, null, null, null, null, null, null, null, null,
                        null, null, null, null)));

        GeneralEvaluation result = service.getGeneral(42, 7);

        assertEquals(10, result.gmfmD().size());
        assertTrue(result.gmfmD().stream().allMatch(task -> task.right() == 0
                && (!task.bilateral() || task.left() == 0)));

        GmfmModule moduleD = result.gmfmModules().get(3);
        assertEquals("D", moduleD.module());
        assertEquals(0, moduleD.score());
        assertEquals(39, moduleD.maxScore());
        assertEquals(0, moduleD.percent());

        assertTrue(result.gmfmModules().stream().filter(m -> !m.module().equals("D"))
                .allMatch(m -> m.score() == null && m.maxScore() == null && m.percent() == null));

        assertEquals(0.0, result.meanPercent());
    }

    @Test
    void portsModulePercentAndMeanFormulaExactly() {
        visit();
        // pull_stand=5 (gmfm52), indep_stand_3=4 -> moduleD total contributes; module A=51 (full), B=null, C=30, E=72
        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(
                row(5, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 51, null, 30, 72)));

        GeneralEvaluation result = service.getGeneral(42, 7);

        // Module A: 51/51 = 100%, Module C: 30/42 = round(71.43) = 71%, Module D: 9/39 = round(23.08) = 23%,
        // Module E: 72/72 = 100%. Module B has no entry (null).
        assertEquals(100, result.gmfmModules().get(0).percent()); // A
        assertNull(result.gmfmModules().get(1).percent()); // B: no entry
        assertEquals(71, result.gmfmModules().get(2).percent()); // C
        assertEquals(23, result.gmfmModules().get(3).percent()); // D
        assertEquals(100, result.gmfmModules().get(4).percent()); // E

        // mean of the 4 entered modules' rounded percents: (100 + 71 + 23 + 100) / 4 = 73.5
        assertEquals(73.5, result.meanPercent());
    }

    @Test
    void returnsNullsAndEmptyListsWhenNoDataPtRowExistsForTheVisit() {
        visit();
        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.empty());

        GeneralEvaluation result = service.getGeneral(42, 7);

        assertNull(result.general().heightCm());
        assertTrue(result.gmfmD().isEmpty());
        assertTrue(result.gmfmModules().isEmpty());
        assertNull(result.meanPercent());
    }

    @Test
    void gmfcsIsNullWhenDiagnosisIsNotCP() {
        visit();
        // icd9=5 is not a CP code (CP range is 13-17, 119, 142); ambScale/age would otherwise calculate "I"
        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(
                gmfcsRow(null, 5, 1, 1, LocalDate.of(2000, 1, 1), LocalDate.of(2003, 7, 15),
                        0, 0, 0, 0, 0, 3, 3, 3, 3, 3, 0, 0, 0, null, null, null, null)));

        assertNull(service.getGeneral(42, 7).general().gmfcs());
        verify(visits, never()).findAllGmfcsListEntries();
    }

    @Test
    void gmfcsUsesCalculatedValueWhenNotManuallyRecorded() {
        visit();
        // icd9=13 is a CP code. amb_scale=1, age ~3.5 (< 4.0) => calculated "I" per GMFCSHelper.
        // gmfcsId=1 is the "unset" sentinel, so the calculated value is used.
        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(
                gmfcsRow(13, null, 1, 1, LocalDate.of(2000, 1, 1), LocalDate.of(2003, 7, 15),
                        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, null, null, null, null)));
        when(visits.findAllGmfcsListEntries()).thenReturn(
                List.of(gmfcsListEntry(1, "I", "Walks without limitations")));

        assertEquals("I -- Walks without limitations", service.getGeneral(42, 7).general().gmfcs());
    }

    @Test
    void gmfcsUsesManuallyRecordedValueOverCalculatedOne() {
        visit();
        // gmfcsId=3 overrides the calculated "I" from the amb_scale/age/GMFM-D inputs below.
        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(
                gmfcsRow(13, null, 3, 1, LocalDate.of(2000, 1, 1), LocalDate.of(2003, 7, 15),
                        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, null, null, null, null)));
        when(visits.findAllGmfcsListEntries()).thenReturn(List.of(
                gmfcsListEntry(1, "I", "Walks without limitations"),
                gmfcsListEntry(3, "II", "Walks with limitations")));

        assertEquals("II -- Walks with limitations", service.getGeneral(42, 7).general().gmfcs());
    }

    @Test
    void gmfcsIsDashesWhenCalculatedLabelIsBlankOrGmfmDTotalIsZero() {
        visit();
        // CP diagnosis, unset gmfcsId, but every GMFM-D task is 0 => gmfmDTotal is 0 => legacy's
        // literal "--" cell (not null - the row is still shown, just nothing resolved).
        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(
                gmfcsRow(13, null, 1, 1, LocalDate.of(2000, 1, 1), LocalDate.of(2003, 7, 15),
                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, null, null, null, null)));

        assertEquals("--", service.getGeneral(42, 7).general().gmfcs());
    }

    private GmfcsListEntry gmfcsListEntry(Integer id, String label, String description) {
        return new GmfcsListEntry() {
            public Integer getId() { return id; }
            public String getLabel() { return label; }
            public String getDescription() { return description; }
        };
    }

    @Test
    void rejectsAnotherPatientsVisitBeforeQueryingClinicalData() {
        visit();
        assertEquals(HttpStatus.NOT_FOUND,
                assertThrows(ResponseStatusException.class, () -> service.getGeneral(43, 7)).getStatusCode());
        verify(visits, never()).findPtGeneralEvaluationByVisitIdAndPatientId(anyInt(), anyInt());
    }

    @Test
    void buildFormExposesEditableFieldsAcrossThreeSections() {
        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(
                row(3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, null, null, null, null)));
        when(generalRepository.findActiveGmfcsListEntries()).thenReturn(List.of());
        when(generalRepository.findActiveFmsListEntries()).thenReturn(List.of());

        PtEvaluationForm form = service.buildForm(42, 7);

        assertEquals("general", form.tab());
        assertEquals(3, form.sections().size());
        var generalFields = form.sections().get(0).fields();
        assertEquals("height", generalFields.get(0).name());
        var gmfmRows = form.sections().get(1).rows();
        assertEquals(10, gmfmRows.size());
        assertEquals("3", gmfmRows.get(0).fields().get(0).value()); // pull_stand
        assertNull(gmfmRows.get(0).fields().get(1)); // right-only task: no Left field at all
    }

    @Test
    void saveRejectsAStaleRevisionWithoutWritingAnything() {
        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(
                row(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, null, null, null, null)));

        var exception = assertThrows(ResponseStatusException.class,
                () -> service.save(42, 7, "stale", java.util.Map.of()));

        assertEquals(HttpStatus.CONFLICT, exception.getStatusCode());
        verify(generalRepository, never()).updateDataPt(anyInt(), any(), any(), any(), any(), any(), any(), any(),
                any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(),
                any(), any());
    }

    @Test
    void saveValidatesAmbScaleAndUnknownLookupIdsBeforeWritingAnything() {
        PtGeneralEvaluationRow currentRow = row(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, null, null, null, null);
        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(currentRow));
        when(generalRepository.existsGmfcsListEntry(99)).thenReturn(false);
        String currentRevision = revision.of(formSnapshotFor(currentRow));

        java.util.Map<String, Object> values = new java.util.HashMap<>();
        values.put("amb_scale", "7"); // not in 1..6
        values.put("gmfcs", "99"); // doesn't exist

        var exception = assertThrows(PtEvaluationValidationException.class,
                () -> service.save(42, 7, currentRevision, values));

        assertTrue(exception.fieldErrors().containsKey("amb_scale"));
        assertTrue(exception.fieldErrors().containsKey("gmfcs"));
        verify(generalRepository, never()).updateDataPt(anyInt(), any(), any(), any(), any(), any(), any(), any(),
                any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(),
                any(), any());
    }

    @Test
    void saveWritesVisitMeasurementsAndDataPtWhenTheRevisionMatches() {
        visit();
        PtGeneralEvaluationRow currentRow = row(3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, null, null, null, null);
        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(currentRow));
        when(generalRepository.existsFmsListEntry(9)).thenReturn(true);
        String currentRevision = revision.of(formSnapshotFor(currentRow));

        java.util.Map<String, Object> values = new java.util.HashMap<>();
        values.put("height", "130.5");
        values.put("fms_5", "9");
        values.put("pull_stand", "4");

        service.save(42, 7, currentRevision, values);

        verify(generalRepository).updateVisitMeasurements(7, 130.5f, null, null, null, null, null);
        verify(generalRepository).updateDataPt(1, null, null, 9, null, null, null, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, null, null, null, null);
    }

    @Test
    void createRecordInsertsABlankRowAndRejectsWhenOneAlreadyExists() {
        visit();
        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.empty());

        service.createRecord(42, 7);
        verify(generalRepository).insertBlankDataPt(7);

        when(visits.findPtGeneralEvaluationByVisitIdAndPatientId(7, 42)).thenReturn(Optional.of(
                row(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, null, null, null, null)));
        assertThrows(ResponseStatusException.class, () -> service.createRecord(42, 7));
    }

    /** Mirrors PtEvaluationService's own private formSnapshot(), since the test needs the exact
     * revision the service will independently compute for the same row. */
    private static java.util.Map<String, Object> formSnapshotFor(PtGeneralEvaluationRow row) {
        java.util.Map<String, Object> snapshot = new java.util.LinkedHashMap<>();
        snapshot.put("heightCm", row.getHeightCm());
        snapshot.put("weightKg", row.getWeightKg());
        snapshot.put("rightFootLengthCm", row.getRightFootLengthCm());
        snapshot.put("leftFootLengthCm", row.getLeftFootLengthCm());
        snapshot.put("rightFootWidthCm", row.getRightFootWidthCm());
        snapshot.put("leftFootWidthCm", row.getLeftFootWidthCm());
        snapshot.put("ambScaleId", row.getAmbScaleId());
        snapshot.put("gmfcsId", row.getGmfcsId());
        snapshot.put("fms5Id", row.getFms5Id());
        snapshot.put("fms50Id", row.getFms50Id());
        snapshot.put("fms500Id", row.getFms500Id());
        snapshot.put("comments", row.getComments());
        snapshot.put("pullStand", row.getPullStand());
        snapshot.put("indepStand3", row.getIndepStand3());
        snapshot.put("indepStand20", row.getIndepStand20());
        snapshot.put("oneLegHandR", row.getOneLegHandR());
        snapshot.put("oneLegHandL", row.getOneLegHandL());
        snapshot.put("oneLegR", row.getOneLegR());
        snapshot.put("oneLegL", row.getOneLegL());
        snapshot.put("shortSitStand", row.getShortSitStand());
        snapshot.put("highKneeStandR", row.getHighKneeStandR());
        snapshot.put("highKneeStandL", row.getHighKneeStandL());
        snapshot.put("lowerFloor", row.getLowerFloor());
        snapshot.put("squats", row.getSquats());
        snapshot.put("standPickPen", row.getStandPickPen());
        snapshot.put("gmfmModA", row.getGmfmModA());
        snapshot.put("gmfmModB", row.getGmfmModB());
        snapshot.put("gmfmModC", row.getGmfmModC());
        snapshot.put("gmfmModE", row.getGmfmModE());
        return snapshot;
    }
}
