package org.nemours.gaitlab.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.nemours.gaitlab.repository.VisitRepository;
import org.nemours.gaitlab.requests.SavePtEvaluationFormRequest;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

class PtEvaluationTabsServiceTest {
    private final VisitRepository visits = mock(VisitRepository.class);
    private final PromStrengthService promStrength = mock(PromStrengthService.class);
    private final OrthosesService orthoses = mock(OrthosesService.class);
    private final MotorControlToneService motorControlTone = mock(MotorControlToneService.class);
    private final PainService pain = mock(PainService.class);
    private final HatService hat = mock(HatService.class);
    private final DystoniaService dystonia = mock(DystoniaService.class);
    private final PtEvaluationTabsService service =
            new PtEvaluationTabsService(visits, promStrength, orthoses, motorControlTone, pain, hat, dystonia);

    private void visit() {
        VisitRepository.InterpretationVisit visit = () -> 1;
        when(visits.findInterpretationVisitByIdAndPatientId(7, 42)).thenReturn(Optional.of(visit));
    }

    private void movementDisorderVisit() {
        VisitRepository.InterpretationVisit visit = () -> 11;
        when(visits.findInterpretationVisitByIdAndPatientId(7, 42)).thenReturn(Optional.of(visit));
    }

    @Test
    void unknownTabIs404EvenForAValidVisit() {
        visit();
        assertEquals(HttpStatus.NOT_FOUND,
                assertThrows(ResponseStatusException.class, () -> service.get(42, 7, "nonsense", false))
                        .getStatusCode());
    }

    @Test
    void missingVisitIs404BeforeDispatchingToAnyTabService() {
        assertEquals(HttpStatus.NOT_FOUND,
                assertThrows(ResponseStatusException.class, () -> service.get(42, 7, "pain", false))
                        .getStatusCode());
        verifyNoInteractions(promStrength, orthoses, motorControlTone, pain, hat, dystonia);
    }

    @Test
    void dispatchesEachTabNameToItsOwnService() {
        visit();
        PtEvaluationTab expected = PtEvaluationTab.empty(42, 7, "pain", "x");
        when(pain.build(42, 7, "pain")).thenReturn(expected);
        when(motorControlTone.buildMotorControl(42, 7, "motor-control"))
                .thenReturn(PtEvaluationTab.empty(42, 7, "motor-control", "x"));
        when(motorControlTone.buildTone(42, 7, "tone", false)).thenReturn(PtEvaluationTab.empty(42, 7, "tone", "x"));
        when(orthoses.build(42, 7, "orthotics", true, false))
                .thenReturn(PtEvaluationTab.empty(42, 7, "orthotics", null));
        when(promStrength.build(42, 7, "prom-strength", false))
                .thenReturn(PtEvaluationTab.empty(42, 7, "prom-strength", "x"));

        PtEvaluationTab painResult = service.get(42, 7, "pain", false);
        assertEquals("pain", painResult.tab());
        assertFalse(painResult.hasData());
        verify(motorControlTone, never()).buildMotorControl(anyInt(), anyInt(), any());

        service.get(42, 7, "motor-control", false);
        verify(motorControlTone).buildMotorControl(42, 7, "motor-control");

        service.get(42, 7, "tone", false);
        verify(motorControlTone).buildTone(42, 7, "tone", false);

        service.get(42, 7, "orthotics", true);
        verify(orthoses).build(42, 7, "orthotics", true, false);

        service.get(42, 7, "prom-strength", false);
        verify(promStrength).build(42, 7, "prom-strength", false);
    }

    @Test
    void attachesActionsMatchingLegacysAdminGatingPerTab() {
        visit();
        when(pain.build(42, 7, "pain")).thenReturn(PtEvaluationTab.empty(42, 7, "pain", "x"));
        when(motorControlTone.buildTone(42, 7, "tone", false)).thenReturn(PtEvaluationTab.empty(42, 7, "tone", "x"));
        when(orthoses.build(42, 7, "orthotics", true, false))
                .thenReturn(PtEvaluationTab.empty(42, 7, "orthotics", null));
        when(promStrength.build(42, 7, "prom-strength", false))
                .thenReturn(PtEvaluationTab.empty(42, 7, "prom-strength", "x"));

        // Pain/Tone: create is admin-only, edit is not; report is false everywhere but General.
        PtEvaluationActions painActions = service.get(42, 7, "pain", false).actions();
        assertFalse(painActions.create());
        assertTrue(painActions.edit());
        assertFalse(painActions.report());

        // Orthotics: add is admin-gated; create/edit don't apply.
        PtEvaluationActions orthoticsActions = service.get(42, 7, "orthotics", true).actions();
        assertFalse(orthoticsActions.create());
        assertFalse(orthoticsActions.edit());
        assertTrue(orthoticsActions.add());
        assertFalse(orthoticsActions.report());

        // PROM/Strength: both create and edit are admin-only.
        PtEvaluationActions promActions = service.get(42, 7, "prom-strength", false).actions();
        assertFalse(promActions.create());
        assertFalse(promActions.edit());
    }

    @Test
    void getFormDispatchesMotorControlTonePainAndPromStrengthAnd404sForUnsupportedTabs() {
        visit();
        PtEvaluationForm mcForm = new PtEvaluationForm("motor-control", "Edit Motor Control", "rev", java.util.List.of());
        when(motorControlTone.buildMotorControlForm(7)).thenReturn(mcForm);
        PtEvaluationForm painForm = new PtEvaluationForm("pain", "Edit Pain", "rev", java.util.List.of());
        when(pain.buildForm(42, 7)).thenReturn(painForm);
        PtEvaluationForm promForm = new PtEvaluationForm("prom-strength", "Modify PROM & Strength", "rev",
                java.util.List.of());
        when(promStrength.buildForm(7, false)).thenReturn(promForm);

        assertSame(mcForm, service.getForm(42, 7, "motor-control"));
        assertSame(painForm, service.getForm(42, 7, "pain"));
        assertSame(promForm, service.getForm(42, 7, "prom-strength"));

        assertEquals(HttpStatus.NOT_FOUND,
                assertThrows(ResponseStatusException.class, () -> service.getForm(42, 7, "orthotics"))
                        .getStatusCode());
    }

    @Test
    void saveFormAndCreateRecordRouteToPromStrengthAndRequireAdmin() {
        visit();
        SavePtEvaluationFormRequest request = new SavePtEvaluationFormRequest("rev", Map.of("hip_flex_r", "20"));
        when(promStrength.save(42, 7, "rev", request.values(), false))
                .thenReturn(PtEvaluationTab.empty(42, 7, "prom-strength", null));

        assertEquals(HttpStatus.FORBIDDEN,
                assertThrows(ResponseStatusException.class,
                        () -> service.saveForm(42, 7, "prom-strength", false, request)).getStatusCode());

        assertEquals("prom-strength", service.saveForm(42, 7, "prom-strength", true, request).tab());
        verify(promStrength).save(42, 7, "rev", request.values(), false);

        when(promStrength.createRecord(42, 7, false)).thenReturn(PtEvaluationTab.empty(42, 7, "prom-strength", null));
        assertEquals(HttpStatus.FORBIDDEN,
                assertThrows(ResponseStatusException.class,
                        () -> service.createRecord(42, 7, "prom-strength", false)).getStatusCode());
        service.createRecord(42, 7, "prom-strength", true);
        verify(promStrength).createRecord(42, 7, false);
    }

    @Test
    void saveFormAndCreateRecordRouteToPain() {
        visit();
        SavePtEvaluationFormRequest request = new SavePtEvaluationFormRequest("rev", Map.of("currentLevel", "4"));
        when(pain.save(42, 7, "rev", request.values())).thenReturn(PtEvaluationTab.empty(42, 7, "pain", null));
        when(pain.createRecord(42, 7)).thenReturn(PtEvaluationTab.empty(42, 7, "pain", null));

        assertEquals("pain", service.saveForm(42, 7, "pain", false, request).tab());
        verify(pain).save(42, 7, "rev", request.values());

        assertEquals(HttpStatus.FORBIDDEN,
                assertThrows(ResponseStatusException.class, () -> service.createRecord(42, 7, "pain", false))
                        .getStatusCode());
        PtEvaluationTab created = service.createRecord(42, 7, "pain", true);
        assertTrue(created.actions().create());
        verify(pain).createRecord(42, 7);
    }

    @Test
    void saveFormRoutesToMotorControlAndToneWithoutRequiringAdmin() {
        visit();
        SavePtEvaluationFormRequest request = new SavePtEvaluationFormRequest("rev", Map.of("score_r_1", "3"));
        when(motorControlTone.saveMotorControl(42, 7, "rev", request.values()))
                .thenReturn(PtEvaluationTab.empty(42, 7, "motor-control", null));

        PtEvaluationTab result = service.saveForm(42, 7, "motor-control", false, request);

        assertEquals("motor-control", result.tab());
        verify(motorControlTone).saveMotorControl(42, 7, "rev", request.values());
    }

    @Test
    void saveFormForbidsPromStrengthForNonAdmins() {
        visit();
        SavePtEvaluationFormRequest request = new SavePtEvaluationFormRequest("rev", Map.of());

        assertEquals(HttpStatus.FORBIDDEN,
                assertThrows(ResponseStatusException.class,
                        () -> service.saveForm(42, 7, "prom-strength", false, request)).getStatusCode());
        verifyNoInteractions(promStrength);
    }

    @Test
    void createRecordIsForbiddenForNonAdminsAndRoutesCorrectlyForAdmins() {
        visit();

        assertEquals(HttpStatus.FORBIDDEN,
                assertThrows(ResponseStatusException.class, () -> service.createRecord(42, 7, "tone", false))
                        .getStatusCode());
        verifyNoInteractions(motorControlTone);

        when(motorControlTone.createToneRecord(42, 7, false)).thenReturn(PtEvaluationTab.empty(42, 7, "tone", null));
        PtEvaluationTab result = service.createRecord(42, 7, "tone", true);
        assertTrue(result.actions().create());
        verify(motorControlTone).createToneRecord(42, 7, false);
    }

    // --- Phase 4 audit: movement-disorder Orthotics Comments route through the generic dispatcher

    @Test
    void gaitOrthoticsFormIs404SinceOnlyMovementDisorderHasTheCommentsBlock() {
        visit();
        assertEquals(HttpStatus.NOT_FOUND,
                assertThrows(ResponseStatusException.class, () -> service.getForm(42, 7, "orthotics"))
                        .getStatusCode());
    }

    @Test
    void movementDisorderOrthoticsFormDispatchesToOrthosesService() {
        movementDisorderVisit();
        PtEvaluationForm form = new PtEvaluationForm("orthotics", "Comments", "rev", java.util.List.of());
        when(orthoses.buildCommentsForm(42, 7)).thenReturn(form);

        assertSame(form, service.getForm(42, 7, "orthotics"));
    }

    @Test
    void movementDisorderOrthoticsSaveIsNotAdminGated() {
        movementDisorderVisit();
        SavePtEvaluationFormRequest request = new SavePtEvaluationFormRequest("rev", Map.of("orthoses", "Fits well"));
        when(orthoses.saveComments(42, 7, "rev", request.values()))
                .thenReturn(PtEvaluationTab.empty(42, 7, "orthotics", null));

        PtEvaluationTab result = service.saveForm(42, 7, "orthotics", false, request);

        assertEquals("orthotics", result.tab());
        verify(orthoses).saveComments(42, 7, "rev", request.values());
    }

    @Test
    void movementDisorderOrthoticsCreateRecordIsAdminOnlyAndDispatchesToOrthosesService() {
        movementDisorderVisit();
        assertEquals(HttpStatus.FORBIDDEN,
                assertThrows(ResponseStatusException.class, () -> service.createRecord(42, 7, "orthotics", false))
                        .getStatusCode());

        when(orthoses.createCommentsRecord(42, 7)).thenReturn(PtEvaluationTab.empty(42, 7, "orthotics", null));
        service.createRecord(42, 7, "orthotics", true);
        verify(orthoses).createCommentsRecord(42, 7);
    }
}
