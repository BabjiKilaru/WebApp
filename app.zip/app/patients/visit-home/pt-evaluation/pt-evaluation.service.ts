import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, catchError, map, of, throwError } from 'rxjs';
import { Visit } from '../../visits/visits';

// The backend ports the legacy clinconn PT pages (pt.jsp, pt-eval-*.jsp, modify_*.jsp) and returns
// display strings already formatted the legacy way, so the page renders them verbatim.

// Which buttons legacy shows for the signed-in user's role; the backend enforces the same rules.
export interface PtEvaluationActions {
    create: boolean;
    edit: boolean;
    add: boolean;
    report: boolean;
}

export const NO_ACTIONS: PtEvaluationActions = { create: false, edit: false, add: false, report: false };

// A visit with no PT record comes back with empty gmfmD/gmfmModules and every general value null.
export interface PtGeneralInfo {
    heightCm: number | null;
    heightZ?: string | null;
    weightKg: number | null;
    weightZ?: string | null;
    rightFootLengthCm: number | null;
    leftFootLengthCm: number | null;
    rightFootWidthCm: number | null;
    leftFootWidthCm: number | null;
    ambulationScale: string | null;
    // Legacy shows GMFCS beside the ambulation scale only for CP diagnoses; null otherwise.
    gmfcs: string | null;
    fms5m: string | null;
    fms50m: string | null;
    fms500m: string | null;
    comments: string | null;
}

export interface GmfmTask {
    items: string;
    task: string;
    bilateral: boolean;
    right: number | null;
    left: number | null;
}

export interface GmfmModuleScore {
    module: 'A' | 'B' | 'C' | 'D' | 'E';
    score: number | null;
    maxScore: number | null;
    percent: number | null;
}

export interface PtEvaluationGeneralResponse {
    patientId: number;
    visitId: number;
    general: PtGeneralInfo;
    gmfmD: GmfmTask[];
    gmfmModules: GmfmModuleScore[];
    meanPercent: number | null;
    actions?: PtEvaluationActions;
}

export type PtEvaluationTabKey =
    | 'general' | 'general-md' | 'prom-strength' | 'orthotics' | 'motor-control' | 'tone' | 'pain'
    | 'hat' | 'dystonia-scale';

export interface PtEvaluationTab {
    key: PtEvaluationTabKey;
    label: string;
}

export interface PtEvaluationTabsResponse {
    movementDisorder: boolean;
    tabs: PtEvaluationTab[];
}

// Used until the backend serves the per-visit tab list; matches pt-tab-header.jsp for gait visits.
export const GAIT_TABS: PtEvaluationTabsResponse = {
    movementDisorder: false,
    tabs: [
        { key: 'general', label: 'General & GMFM' },
        { key: 'prom-strength', label: 'PROM/Strength' },
        { key: 'orthotics', label: 'Orthotics' },
        { key: 'motor-control', label: 'Motor Control' },
        { key: 'tone', label: 'Tone' },
        { key: 'pain', label: 'Pain' }
    ]
};

export interface PtEvaluationTableRow {
    label: string;
    cells: (string | null)[];
    // Cell indexes legacy greys out (e.g. score cells of "*" interpretation-only tests).
    shadedCells?: number[];
    // Present on rows that can be edited or deleted on their own (Orthotics).
    id?: number;
    actions?: { edit: boolean; delete: boolean };
}

export interface PtEvaluationSection {
    kind: 'table' | 'list' | 'text';
    title: string | null;
    columnGroups: { label: string; span: number }[] | null;
    columns: string[] | null;
    rows: PtEvaluationTableRow[] | null;
    items: string[] | null;
    text: string | null;
    footnote: string | null;
}

export interface PtEvaluationTabResponse {
    patientId: number;
    visitId: number;
    tab: PtEvaluationTabKey;
    hasData: boolean;
    emptyMessage: string | null;
    sections: PtEvaluationSection[];
    actions?: PtEvaluationActions;
}

export type PtEvaluationView = PtEvaluationGeneralResponse | PtEvaluationTabResponse;

export interface PtFormOption {
    value: string;
    label: string;
}

export interface PtFormField {
    name: string;
    label: string;
    type: 'number' | 'text' | 'textarea' | 'select' | 'radio' | 'checkbox' | 'multiselect';
    value: string | string[] | null;
    options: PtFormOption[] | null;
    required: boolean;
    min: number | null;
    max: number | null;
    step: number | null;
    maxLength: number | null;
    help: string | null;
}

export interface PtFormSection {
    title: string | null;
    layout: 'grid' | 'stack';
    columns?: string[] | null;
    rows?: { label: string; fields: (PtFormField | null)[] }[] | null;
    fields?: PtFormField[] | null;
}

export interface PtFormResponse {
    tab: PtEvaluationTabKey;
    title: string;
    revision: string;
    sections: PtFormSection[];
}

export type PtFormValues = Record<string, string | string[]>;

export interface PtFormSaveRequest {
    revision: string;
    values: PtFormValues;
}

export interface PtReportResponse {
    title: string;
    header: { label: string; value: string | null }[];
    sections: PtEvaluationSection[];
}

// The orthotics form is per orthosis: "new" for Add an Orthosis, or the orthosis id.
export type PtFormTarget = { tab: PtEvaluationTabKey } | { tab: 'orthotics'; orthosis: number | 'new' };

@Injectable({
    providedIn: 'root'
})
export class PtEvaluationService {
    constructor(private readonly http: HttpClient) {}

    getTabs(patientId: number, visitId: number): Observable<PtEvaluationTabsResponse> {
        return this.http.get<PtEvaluationTabsResponse>(`${this.base(patientId, visitId)}/tabs`).pipe(
            catchError(error => error?.status === 404 ? of(GAIT_TABS) : throwError(() => error))
        );
    }

    getGeneral(patientId: number, visitId: number): Observable<PtEvaluationGeneralResponse> {
        return this.http.get<PtEvaluationGeneralResponse>(`${this.base(patientId, visitId)}/general`);
    }

    getTab(patientId: number, visitId: number, tab: PtEvaluationTabKey): Observable<PtEvaluationTabResponse> {
        return this.http.get<PtEvaluationTabResponse>(`${this.base(patientId, visitId)}/${tab}`);
    }

    createRecord(patientId: number, visitId: number, tab: PtEvaluationTabKey): Observable<PtEvaluationView> {
        return this.http.post<PtEvaluationView>(`${this.base(patientId, visitId)}/${tab}/record`, {});
    }

    getForm(patientId: number, visitId: number, target: PtFormTarget): Observable<PtFormResponse> {
        return this.http.get<PtFormResponse>(this.formUrl(patientId, visitId, target));
    }

    saveForm(
        patientId: number, visitId: number, target: PtFormTarget, request: PtFormSaveRequest
    ): Observable<PtEvaluationView> {
        const url = this.formUrl(patientId, visitId, target);
        return 'orthosis' in target && target.orthosis === 'new'
            ? this.http.post<PtEvaluationView>(url, request)
            : this.http.put<PtEvaluationView>(url, request);
    }

    deleteOrthosis(patientId: number, visitId: number, orthosisId: number): Observable<PtEvaluationTabResponse> {
        return this.http.delete<PtEvaluationTabResponse>(`${this.base(patientId, visitId)}/orthotics/${orthosisId}`);
    }

    // Legacy took up to two comparison visits from the session's "Set Comparison Dates"; here they are passed explicitly.
    getComparisonReport(patientId: number, visitId: number, compareVisitIds: number[] = []): Observable<PtReportResponse> {
        let params = new HttpParams();
        compareVisitIds.slice(0, 2).forEach((id, index) => {
            params = params.set(`compareVisitId${index + 1}`, id);
        });
        return this.http.get<PtReportResponse>(`${this.base(patientId, visitId)}/comparison-report`, { params });
    }

    // Dated, attended visits of the patient other than the current one; legacy's Set Comparison Dates picks by date.
    getComparisonVisits(patientId: number, visitId: number): Observable<Visit[]> {
        return this.http.get<Visit[]>(`/api/patients/${patientId}/visits`).pipe(
            map(visits => visits.filter(visit => {
                const attendance = visit.attendance?.trim().toLowerCase() ?? '';
                return visit.id !== visitId && visit.patientId === patientId && !!visit.date
                    && (attendance === '' || attendance === 'yes');
            }))
        );
    }

    private formUrl(patientId: number, visitId: number, target: PtFormTarget): string {
        return 'orthosis' in target
            ? `${this.base(patientId, visitId)}/orthotics/${target.orthosis}/form`
            : `${this.base(patientId, visitId)}/${target.tab}/form`;
    }

    private base(patientId: number, visitId: number): string {
        return `/api/patients/${patientId}/visits/${visitId}/pt-evaluation`;
    }
}
