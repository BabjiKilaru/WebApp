import { DatePipe, DecimalPipe, NgTemplateOutlet } from '@angular/common';
import {
    ChangeDetectorRef, Component, HostListener, Input, OnChanges, OnDestroy, SimpleChanges, ViewChild
} from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Observable, Subscription } from 'rxjs';
import { PtEvaluationForm } from './pt-evaluation-form/pt-evaluation-form';
import {
    GAIT_TABS, NO_ACTIONS, PtEvaluationActions, PtEvaluationGeneralResponse, PtEvaluationService,
    PtEvaluationTabKey, PtEvaluationTabResponse, PtEvaluationTabsResponse, PtEvaluationView,
    PtFormResponse, PtFormTarget, PtFormValues, PtReportResponse
} from './pt-evaluation.service';
import { Visit } from '../../visits/visits';

// Button labels from the legacy pages (pt.jsp, pt-eval-*.jsp).
const EDIT_LABELS: Partial<Record<PtEvaluationTabKey, string>> = {
    'prom-strength': 'Edit Data',
    'motor-control': 'Edit Motor Control Values',
    'tone': 'Edit Tone Values',
    'pain': 'Edit Pain Values',
    'hat': 'Edit HAT Scores',
    'dystonia-scale': 'Edit Dystonia Scores',
    // Movement disorder visits only: legacy edits data_pt_movement_disorder.orthoses as "Comments" on this tab.
    'orthotics': 'Edit Comments'
};

export interface PendingOrthosisDelete {
    id: number;
    orthosis: string;
    side: string;
}

type Mode = 'view' | 'form' | 'report';

@Component({
    selector: 'app-pt-evaluation',
    standalone: true,
    imports: [DatePipe, DecimalPipe, NgTemplateOutlet, PtEvaluationForm],
    templateUrl: './pt-evaluation.html',
    styleUrls: ['./pt-evaluation.css']
})
export class PtEvaluation implements OnChanges, OnDestroy {
    @Input({ required: true }) patientId!: number;
    @Input({ required: true }) visitId!: number;
    @ViewChild(PtEvaluationForm) private formComponent?: PtEvaluationForm;

    tabs: PtEvaluationTabsResponse = GAIT_TABS;
    activeTab: PtEvaluationTabKey = 'general';
    mode: Mode = 'view';

    evaluation: PtEvaluationGeneralResponse | null = null;
    tabData: PtEvaluationTabResponse | null = null;
    loading = false;
    errorMessage = '';
    actionError = '';
    busy = false;

    formTarget: PtFormTarget | null = null;
    form: PtFormResponse | null = null;
    saving = false;
    saveError = '';
    serverFieldErrors: Record<string, string> = {};
    conflict = false;

    report: PtReportResponse | null = null;
    pendingDelete: PendingOrthosisDelete | null = null;
    comparisonVisits: Visit[] = [];
    compareVisitIds: (number | null)[] = [null, null];

    private subscription?: Subscription;
    private actionSubscription?: Subscription;
    private comparisonSubscription?: Subscription;

    constructor(
        private readonly service: PtEvaluationService,
        private readonly cdr: ChangeDetectorRef
    ) {}

    get activeLabel(): string {
        return this.tabs.tabs.find(tab => tab.key === this.activeTab)?.label ?? '';
    }

    get isGeneral(): boolean {
        return this.activeTab === 'general';
    }

    get actions(): PtEvaluationActions {
        return (this.isGeneral ? this.evaluation?.actions : this.tabData?.actions) ?? NO_ACTIONS;
    }

    get hasRecord(): boolean {
        return this.isGeneral ? !!this.evaluation?.gmfmD.length : !!this.tabData?.hasData;
    }

    get editLabel(): string {
        if (this.isGeneral || this.activeTab === 'general-md') {
            return this.tabs.movementDisorder ? 'Modify General Data' : 'Modify General or GMFM Data';
        }
        return EDIT_LABELS[this.activeTab] ?? 'Edit Data';
    }

    // Label/value blocks come as tables whose columns are all blank; those render without a header row.
    hasColumnLabels(columns: string[] | null): boolean {
        return !!columns?.some(column => column.trim() !== '');
    }

    hasRowActions(sections: PtEvaluationTabResponse['sections']): boolean {
        return sections.some(section => section.rows?.some(row => row.actions?.edit || row.actions?.delete));
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes['patientId'] || changes['visitId']) {
            this.resetEditing();
            this.mode = 'view';
            this.loadTabs();
        }
    }

    ngOnDestroy(): void {
        this.subscription?.unsubscribe();
        this.actionSubscription?.unsubscribe();
        this.comparisonSubscription?.unsubscribe();
    }

    @HostListener('window:beforeunload', ['$event'])
    onBeforeUnload(event: BeforeUnloadEvent): void {
        if (this.hasUnsavedChanges || this.saving) {
            event.preventDefault();
            event.returnValue = '';
        }
    }

    get hasUnsavedChanges(): boolean {
        return this.mode === 'form' && !!this.formComponent?.hasChanges;
    }

    canLeave(): boolean {
        if (this.saving) {
            window.alert('Please wait for the save to finish before leaving.');
            return false;
        }
        return !this.hasUnsavedChanges || window.confirm('Discard unsaved PT evaluation changes?');
    }

    selectTab(key: PtEvaluationTabKey): void {
        if (key === this.activeTab && this.mode === 'view') {
            return;
        }
        if (!this.canLeave()) {
            return;
        }
        this.resetEditing();
        this.mode = 'view';
        this.activeTab = key;
        this.loadView();
    }

    loadTabs(): void {
        if (!this.validIds()) {
            this.subscription?.unsubscribe();
            this.loading = false;
            this.errorMessage = 'Select a valid patient and visit.';
            return;
        }
        this.subscription?.unsubscribe();
        this.loading = true;
        this.errorMessage = '';
        this.subscription = this.service.getTabs(this.patientId, this.visitId).subscribe({
            next: tabs => {
                this.tabs = tabs.tabs.length ? tabs : GAIT_TABS;
                if (!this.tabs.tabs.some(tab => tab.key === this.activeTab)) {
                    this.activeTab = this.tabs.tabs[0].key;
                }
                this.loadView();
            },
            error: error => this.fail(error)
        });
    }

    loadView(): void {
        this.subscription?.unsubscribe();
        this.evaluation = null;
        this.tabData = null;
        this.errorMessage = '';
        this.actionError = '';
        if (!this.validIds()) {
            this.loading = false;
            this.errorMessage = 'Select a valid patient and visit.';
            return;
        }
        this.loading = true;
        const request: Observable<PtEvaluationView> = this.isGeneral
            ? this.service.getGeneral(this.patientId, this.visitId)
            : this.service.getTab(this.patientId, this.visitId, this.activeTab);
        this.subscription = request.subscribe({
            next: view => {
                this.applyView(view);
                this.loading = false;
                this.cdr.markForCheck();
            },
            error: error => this.fail(error)
        });
    }

    createRecord(): void {
        this.runAction(this.service.createRecord(this.patientId, this.visitId, this.activeTab), view => {
            this.applyView(view);
        }, 'Unable to create the record. Please try again.');
    }

    openEdit(): void {
        this.openForm({ tab: this.activeTab });
    }

    openOrthosis(orthosis: number | 'new'): void {
        this.openForm({ tab: 'orthotics', orthosis });
    }

    // Legacy delete_orth.jsp asks on its own page, showing the orthosis and side, before deleting.
    deleteOrthosis(id: number, orthosis: string, side: string | null): void {
        this.actionError = '';
        this.pendingDelete = { id, orthosis, side: side ?? '' };
    }

    confirmDelete(): void {
        if (!this.pendingDelete) {
            return;
        }
        const id = this.pendingDelete.id;
        this.runAction(this.service.deleteOrthosis(this.patientId, this.visitId, id), view => {
            this.pendingDelete = null;
            this.applyView(view);
        }, 'Unable to delete the orthosis. Please try again.');
    }

    cancelDelete(): void {
        this.pendingDelete = null;
        this.actionError = '';
    }

    // Button wording from the legacy modify/insert pages.
    get submitLabel(): string {
        const target = this.formTarget;
        if (target && 'orthosis' in target) {
            return target.orthosis === 'new' ? 'Insert Orthosis' : 'Save Changes';
        }
        return target?.tab === 'general' || target?.tab === 'general-md' ? 'Save All Changes' : 'Save Changes';
    }

    saveForm(values: PtFormValues): void {
        if (!this.form || !this.formTarget || this.saving) {
            return;
        }
        this.saving = true;
        this.saveError = '';
        this.serverFieldErrors = {};
        this.actionSubscription?.unsubscribe();
        this.actionSubscription = this.service.saveForm(this.patientId, this.visitId, this.formTarget, {
            revision: this.form.revision, values
        }).subscribe({
            next: view => {
                this.saving = false;
                this.resetEditing();
                this.mode = 'view';
                this.applyView(view);
                this.cdr.markForCheck();
            },
            error: (error: HttpErrorResponse) => {
                console.error('PT evaluation save failed:', error);
                this.saving = false;
                this.conflict = error.status === 409;
                this.serverFieldErrors = error.status === 400 ? error.error?.fieldErrors ?? {} : {};
                this.saveError = this.conflict
                    ? 'This record was changed by someone else. Reload to see the latest values.'
                    : error.status === 400 ? error.error?.message || 'Please correct the highlighted fields.'
                    : error.status === 403 ? 'You do not have permission to change this record.'
                    : 'Unable to save. Please try again.';
                this.cdr.markForCheck();
            }
        });
    }

    cancelForm(): void {
        if (!this.canLeave()) {
            return;
        }
        this.resetEditing();
        this.mode = 'view';
    }

    reloadForm(): void {
        if (this.formTarget) {
            this.openForm(this.formTarget);
        }
    }

    openReport(): void {
        if (!this.canLeave()) {
            return;
        }
        this.resetEditing();
        this.mode = 'report';
        this.compareVisitIds = [null, null];
        this.comparisonVisits = [];
        this.comparisonSubscription?.unsubscribe();
        // Without other visits the report still works for the current visit alone, so a failure here only hides the picker.
        this.comparisonSubscription = this.service.getComparisonVisits(this.patientId, this.visitId).subscribe({
            next: visits => {
                this.comparisonVisits = visits;
                this.cdr.markForCheck();
            },
            error: error => console.error('Unable to load comparison visits:', error)
        });
        this.loadReport();
    }

    loadReport(): void {
        this.report = null;
        const compareIds = this.compareVisitIds.filter((id): id is number => id !== null);
        this.runAction(this.service.getComparisonReport(this.patientId, this.visitId, compareIds), report => {
            this.report = report;
        }, 'Unable to load the comparison report. Please try again.');
    }

    setCompareVisit(index: 0 | 1, value: string): void {
        const id = value ? Number(value) : null;
        const next = [...this.compareVisitIds];
        next[index] = id;
        if (next[0] === null || next[0] === next[1]) {
            next[1] = null;
        }
        this.compareVisitIds = next;
        this.loadReport();
    }

    comparisonOptions(index: 0 | 1): Visit[] {
        return index === 0
            ? this.comparisonVisits
            : this.comparisonVisits.filter(visit => visit.id !== this.compareVisitIds[0]);
    }

    closeReport(): void {
        this.comparisonSubscription?.unsubscribe();
        this.mode = 'view';
        this.report = null;
        this.comparisonVisits = [];
        this.compareVisitIds = [null, null];
        this.actionError = '';
    }

    print(): void {
        window.print();
    }

    private openForm(target: PtFormTarget): void {
        this.resetEditing();
        this.mode = 'form';
        this.formTarget = target;
        this.runAction(this.service.getForm(this.patientId, this.visitId, target), form => {
            this.form = form;
        }, 'Unable to load the form. Please try again.');
    }

    private runAction<T>(request: Observable<T>, apply: (value: T) => void, message: string): void {
        this.actionSubscription?.unsubscribe();
        this.busy = true;
        this.actionError = '';
        this.actionSubscription = request.subscribe({
            next: value => {
                apply(value);
                this.busy = false;
                this.cdr.markForCheck();
            },
            error: (error: HttpErrorResponse) => {
                console.error('PT evaluation action failed:', error);
                this.busy = false;
                this.actionError = error.status === 403 ? 'You do not have permission to do this.' : message;
                this.cdr.markForCheck();
            }
        });
    }

    private applyView(view: PtEvaluationView): void {
        if ('gmfmD' in view) {
            this.evaluation = view;
            this.tabData = null;
        } else {
            this.tabData = view;
            this.evaluation = null;
        }
    }

    private resetEditing(): void {
        this.actionSubscription?.unsubscribe();
        this.pendingDelete = null;
        this.formTarget = null;
        this.form = null;
        this.saving = false;
        this.busy = false;
        this.saveError = '';
        this.serverFieldErrors = {};
        this.conflict = false;
        this.actionError = '';
    }

    private fail(error: HttpErrorResponse): void {
        console.error('PT evaluation load failed:', error);
        this.errorMessage = 'Unable to load the PT evaluation. Please try again.';
        this.loading = false;
        this.cdr.markForCheck();
    }

    private validIds(): boolean {
        return Number.isInteger(this.patientId) && this.patientId > 0
            && Number.isInteger(this.visitId) && this.visitId > 0;
    }
}
