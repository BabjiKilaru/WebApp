import { NgTemplateOutlet } from '@angular/common';
import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { PtFormField, PtFormResponse, PtFormValues } from '../pt-evaluation.service';

// Renders a legacy modify_*.jsp form described by the backend; validation mirrors the field rules it sends.
@Component({
    selector: 'app-pt-evaluation-form',
    standalone: true,
    imports: [NgTemplateOutlet],
    templateUrl: './pt-evaluation-form.html',
    styleUrls: ['./pt-evaluation-form.css']
})
export class PtEvaluationForm implements OnChanges {
    @Input({ required: true }) form!: PtFormResponse;
    @Input() saving = false;
    @Input() errorMessage = '';
    @Input() serverFieldErrors: Record<string, string> = {};
    @Input() conflict = false;
    @Input() submitLabel = 'Save Changes';

    @Output() save = new EventEmitter<PtFormValues>();
    @Output() cancel = new EventEmitter<void>();
    @Output() reload = new EventEmitter<void>();

    values: PtFormValues = {};
    fieldErrors: Record<string, string> = {};
    private initial = '';

    ngOnChanges(changes: SimpleChanges): void {
        if (changes['form']) {
            this.values = {};
            for (const field of this.allFields()) {
                this.values[field.name] = field.type === 'multiselect'
                    ? [...(Array.isArray(field.value) ? field.value : [])]
                    : (Array.isArray(field.value) ? field.value.join(',') : field.value ?? '');
            }
            this.initial = JSON.stringify(this.values);
            this.fieldErrors = {};
        }
        if (changes['serverFieldErrors']) {
            this.fieldErrors = { ...this.serverFieldErrors };
        }
    }

    get hasChanges(): boolean {
        return JSON.stringify(this.values) !== this.initial;
    }

    text(field: PtFormField): string {
        const value = this.values[field.name];
        return Array.isArray(value) ? value.join(',') : value ?? '';
    }

    isChecked(field: PtFormField): boolean {
        const checkedValue = field.options?.[0]?.value ?? 'true';
        return this.values[field.name] === checkedValue;
    }

    isSelected(field: PtFormField, option: string): boolean {
        const value = this.values[field.name];
        return Array.isArray(value) && value.includes(option);
    }

    setValue(field: PtFormField, value: string): void {
        this.values[field.name] = value;
        delete this.fieldErrors[field.name];
    }

    setChecked(field: PtFormField, checked: boolean): void {
        this.setValue(field, checked ? field.options?.[0]?.value ?? 'true' : '');
    }

    toggleOption(field: PtFormField, option: string, selected: boolean): void {
        const current = Array.isArray(this.values[field.name]) ? this.values[field.name] as string[] : [];
        this.values[field.name] = selected
            ? [...current.filter(value => value !== option), option]
            : current.filter(value => value !== option);
        delete this.fieldErrors[field.name];
    }

    submit(): void {
        this.fieldErrors = {};
        for (const field of this.allFields()) {
            const error = this.validate(field);
            if (error) {
                this.fieldErrors[field.name] = error;
            }
        }
        if (Object.keys(this.fieldErrors).length === 0) {
            this.save.emit(structuredClone(this.values));
        }
    }

    private validate(field: PtFormField): string | null {
        const value = this.values[field.name];
        const empty = Array.isArray(value) ? value.length === 0 : (value ?? '').trim() === '';
        if (empty) {
            return field.required ? `${field.label} is required.` : null;
        }
        if (Array.isArray(value)) {
            return null;
        }
        if (field.type === 'number') {
            const number = Number(value);
            if (!Number.isFinite(number)) {
                return `${field.label} must be a number.`;
            }
            if (field.min !== null && number < field.min) {
                return `${field.label} must be at least ${field.min}.`;
            }
            if (field.max !== null && number > field.max) {
                return `${field.label} must be at most ${field.max}.`;
            }
        }
        if (field.maxLength !== null && value.length > field.maxLength) {
            return `${field.label} must be ${field.maxLength} characters or fewer.`;
        }
        return null;
    }

    private allFields(): PtFormField[] {
        return this.form.sections.flatMap(section => [
            ...(section.fields ?? []),
            ...(section.rows ?? []).flatMap(row => row.fields.filter((field): field is PtFormField => field !== null))
        ]);
    }
}
