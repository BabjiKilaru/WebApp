import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { vi } from 'vitest';
import { PtEvaluation } from './pt-evaluation';
import {
    PtEvaluationActions, PtEvaluationGeneralResponse, PtEvaluationTabResponse, PtFormField, PtFormResponse,
    PtReportResponse
} from './pt-evaluation.service';

describe('PtEvaluation', () => {
    let fixture: ComponentFixture<PtEvaluation>;
    let http: HttpTestingController;
    const base = '/api/patients/42/visits/7/pt-evaluation';
    const allActions: PtEvaluationActions = { create: true, edit: true, add: true, report: true };

    function general(overrides: Partial<PtEvaluationGeneralResponse> = {}): PtEvaluationGeneralResponse {
        return {
            patientId: 42, visitId: 7,
            general: {
                heightCm: 120.5, heightZ: '(z = 0.42)', weightKg: null, weightZ: null,
                rightFootLengthCm: null, leftFootLengthCm: null, rightFootWidthCm: null, leftFootWidthCm: null,
                ambulationScale: '1 -- Independent ambulation all environments', gmfcs: null,
                fms5m: '6 -- Independent on all surfaces', fms50m: ' -- ', fms500m: ' -- ', comments: null
            },
            gmfmD: [
                { items: '52', task: 'Pull to stand', bilateral: false, right: 0, left: null },
                { items: '54,55', task: 'One leg stance hand held - Right', bilateral: true, right: 0, left: 2 }
            ],
            gmfmModules: [
                { module: 'A', score: null, maxScore: null, percent: null },
                { module: 'D', score: 0, maxScore: 39, percent: 0 }
            ],
            meanPercent: 0,
            actions: allActions,
            ...overrides
        };
    }

    function tab(overrides: Partial<PtEvaluationTabResponse> = {}): PtEvaluationTabResponse {
        return {
            patientId: 42, visitId: 7, tab: 'prom-strength', hasData: true, emptyMessage: null,
            actions: allActions,
            sections: [
                {
                    kind: 'table', title: null,
                    columnGroups: [{ label: '', span: 1 }, { label: 'PROM', span: 2 }, { label: 'Strength', span: 2 }],
                    columns: ['', 'Right', 'Left', 'Right', 'Left'],
                    rows: [
                        { label: 'Hip Flex', cells: ['+120 [N]', 'WNL []', '4+ [N]', null] },
                        { label: '*Clonus', cells: [null, 'present', null, 'absent'], shadedCells: [0, 2] }
                    ],
                    items: null, text: null, footnote: '* Interpretation only'
                },
                {
                    kind: 'table', title: 'Levels', columnGroups: null, columns: ['', ''],
                    rows: [{ label: 'Current Level', cells: ['3'] }], items: null, text: null, footnote: null
                },
                {
                    kind: 'list', title: 'Activities impacted:', columnGroups: null, columns: null, rows: null,
                    items: ['Running', 'Stairs'], text: null, footnote: null
                },
                {
                    kind: 'list', title: 'Aggravating factors:', columnGroups: null, columns: null, rows: null,
                    items: [], text: null, footnote: null
                },
                {
                    kind: 'text', title: 'Comments', columnGroups: null, columns: null, rows: null,
                    items: null, text: 'Tight hamstrings', footnote: null
                }
            ],
            ...overrides
        };
    }

    function orthotics(overrides: Partial<PtEvaluationTabResponse> = {}): PtEvaluationTabResponse {
        return tab({
            tab: 'orthotics',
            sections: [{
                kind: 'table', title: null, columnGroups: null, columns: ['Orthoses', 'Side'],
                rows: [{ label: 'AFO', cells: ['Right'], id: 5, actions: { edit: true, delete: true } }],
                items: null, text: null, footnote: null
            }],
            ...overrides
        });
    }

    function field(name: string, overrides: Partial<PtFormField> = {}): PtFormField {
        return {
            name, label: name, type: 'number', value: null, options: null, required: false,
            min: null, max: null, step: null, maxLength: null, help: null, ...overrides
        };
    }

    function promForm(): PtFormResponse {
        return {
            tab: 'prom-strength', title: 'Edit PROM/Strength', revision: 'r1',
            sections: [
                {
                    title: 'PROM', layout: 'grid', columns: ['Right', 'R Interp'],
                    rows: [{
                        label: 'Hip Flex',
                        fields: [
                            field('hip_flex_r', { label: 'Hip Flex Right', value: '120', min: -90, max: 180 }),
                            field('hip_flex_r_interp', {
                                label: 'Hip Flex Right Interp', type: 'select', value: 'N',
                                options: [{ value: 'N', label: 'N' }, { value: 'D', label: 'D' }]
                            })
                        ]
                    }]
                },
                {
                    title: 'Pain', layout: 'stack', fields: [
                        field('factors', {
                            label: 'Aggravating factors', type: 'multiselect', value: ['1'],
                            options: [{ value: '1', label: 'walking' }, { value: '2', label: 'running' }]
                        }),
                        field('comments', { label: 'Comments', type: 'textarea', value: 'old', maxLength: 10 })
                    ]
                }
            ]
        };
    }

    function page(): HTMLElement {
        return fixture.nativeElement as HTMLElement;
    }

    function text(element: Element | null): string {
        return element?.textContent?.replace(/\s+/g, ' ').trim() ?? '';
    }

    function cells(row: Element): string[] {
        return Array.from(row.querySelectorAll('th, td')).map(text);
    }

    function button(label: string): HTMLButtonElement {
        const match = (Array.from(page().querySelectorAll('button')) as HTMLButtonElement[])
            .find(item => text(item) === label);
        expect(match, `Expected button "${label}"`).toBeDefined();
        return match!;
    }

    function click(label: string): void {
        button(label).click();
        fixture.detectChanges();
    }

    function input(name: string): HTMLInputElement {
        return page().querySelector(`#pt-${name}`) as HTMLInputElement;
    }

    function type(name: string, value: string): void {
        const element = input(name);
        element.value = value;
        element.dispatchEvent(new Event('input'));
        fixture.detectChanges();
    }

    function load(body = general(), tabs: unknown = null): void {
        fixture.componentRef.setInput('patientId', 42);
        fixture.componentRef.setInput('visitId', 7);
        fixture.detectChanges();
        const tabsRequest = http.expectOne(`${base}/tabs`);
        if (tabs) {
            tabsRequest.flush(tabs);
        } else {
            tabsRequest.flush('', { status: 404, statusText: 'Not Found' });
        }
        http.expectOne(`${base}/general`).flush(body);
        fixture.detectChanges();
    }

    function openTab(label: string, url: string, body: PtEvaluationTabResponse): void {
        click(label);
        http.expectOne(url).flush(body);
        fixture.detectChanges();
    }

    function generalRows(): Map<string, string[]> {
        const rows = Array.from(page().querySelectorAll('.general-table tr'));
        return new Map(rows.map(cells).map(row => [row[0], row]));
    }

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [PtEvaluation],
            providers: [provideHttpClient(), provideHttpClientTesting()]
        }).compileComponents();
        fixture = TestBed.createComponent(PtEvaluation);
        http = TestBed.inject(HttpTestingController);
        vi.spyOn(console, 'error').mockImplementation(() => {});
    });

    afterEach(() => {
        http.verify();
        vi.restoreAllMocks();
    });

    describe('General & GMFM view', () => {
        it('renders the legacy display strings verbatim, including z-scores', () => {
            load();
            const rows = generalRows();
            expect(rows.get('Height (cm)')).toEqual(['Height (cm)', '120.5 (z = 0.42)', 'Weight (kg)', '']);
            expect(rows.get('Ambulation Scale')).toEqual(['Ambulation Scale', '1 -- Independent ambulation all environments']);
            expect(rows.get('FMS (5m)')).toEqual(['FMS (5m)', '6 -- Independent on all surfaces']);
            expect(rows.get('FMS (50m)')).toEqual(['FMS (50m)', '--']);
        });

        it('shows GMFCS only when the backend provides it', () => {
            const body = general();
            body.general.gmfcs = 'I (Calculated) -- Walks without limitations';
            load(body);
            expect(generalRows().get('GMFCS')).toEqual(['GMFCS', 'I (Calculated) -- Walks without limitations']);
        });

        it('renders GMFM-D tasks with Left values only for bilateral items, and module scores', () => {
            load();
            expect(Array.from(page().querySelectorAll('.gmfm-table tbody tr')).map(cells)).toEqual([
                ['Pull to stand (52)', '0', ''],
                ['One leg stance hand held - Right (54,55)', '0', '2']
            ]);
            expect(Array.from(page().querySelectorAll('.module-list li')).map(text))
                .toEqual(['No entry for Module A', 'Module D: 0 / 39 = 0 %']);
            expect(text(page().querySelector('.mean-percentage'))).toBe('Mean Percentage: 0 %');
        });

        it('shows the legacy General button labels and the comparison report button', () => {
            load();
            expect(button('Modify General or GMFM Data')).toBeTruthy();
            expect(button('View Printable Comparison Report')).toBeTruthy();
        });

        it('hides buttons the user is not allowed to use', () => {
            load(general({ actions: { create: false, edit: false, add: false, report: false } }));
            expect(page().querySelector('.toolbar')).toBeNull();
        });
    });

    describe('general editing', () => {
        it('uses the legacy modify_pt.jsp button wording', () => {
            load();
            click('Modify General or GMFM Data');
            http.expectOne(`${base}/general/form`).flush({ ...promForm(), tab: 'general' });
            fixture.detectChanges();
            expect(button('Save All Changes')).toBeTruthy();
            expect(button('Return without Saving Changes')).toBeTruthy();
        });
    });

    describe('empty records', () => {
        it('offers Create New Record when there is no PT record and replaces the view with the result', () => {
            load(general({ gmfmD: [], gmfmModules: [], meanPercent: null }));
            expect(text(page().querySelector('.empty-state p'))).toBe('No general data has been entered yet for this visit.');
            click('Create New Record');
            const request = http.expectOne(`${base}/general/record`);
            expect(request.request.method).toBe('POST');
            request.flush(general());
            fixture.detectChanges();
            expect(page().querySelector('.general-table')).not.toBeNull();
        });

        it('hides Create New Record without the create permission', () => {
            load(general({ gmfmD: [], gmfmModules: [], meanPercent: null, actions: { ...allActions, create: false } }));
            expect(text(page().querySelector('.empty-state'))).not.toContain('Create New Record');
        });

        it('shows the tab empty message, or nothing when legacy shows nothing', () => {
            load();
            openTab('Pain', `${base}/pain`, tab({ tab: 'pain', hasData: false, emptyMessage: 'No pain data entered.', sections: [] }));
            expect(text(page().querySelector('.empty-state p'))).toBe('No pain data entered.');
            openTab('Orthotics', `${base}/orthotics`, tab({ tab: 'orthotics', hasData: false, emptyMessage: null, sections: [],
                actions: { ...allActions, create: false } }));
            expect(page().querySelector('.empty-state p')).toBeNull();
        });
    });

    describe('generic tabs', () => {
        it('renders server-formatted cells, grouped headers, shaded cells and footnotes', () => {
            load();
            openTab('PROM/Strength', `${base}/prom-strength`, tab());
            expect(text(page().querySelector('h2'))).toBe('PT Evaluation: PROM/Strength');
            const table = page().querySelector('.tab-table')!;
            const headerRows = Array.from(table.querySelectorAll('thead tr'));
            expect(headerRows.map(cells)).toEqual([['', 'PROM', 'Strength'], ['', 'Right', 'Left', 'Right', 'Left']]);
            expect(headerRows[0].children[1].getAttribute('colspan')).toBe('2');
            const bodyRows = Array.from(table.querySelectorAll('tbody tr'));
            expect(bodyRows.map(cells)).toEqual([
                ['Hip Flex', '+120 [N]', 'WNL []', '4+ [N]', ''],
                ['*Clonus', '', 'present', '', 'absent']
            ]);
            expect(Array.from(bodyRows[1].querySelectorAll('td')).map(cell => cell.classList.contains('shaded')))
                .toEqual([true, false, true, false]);
            expect(text(page().querySelector('.footnote'))).toBe('* Interpretation only');
            expect(button('Edit Data')).toBeTruthy();
        });

        it('renders label/value tables without headers, lists, empty lists as nothing, and text', () => {
            load();
            openTab('PROM/Strength', `${base}/prom-strength`, tab());
            const levels = page().querySelectorAll('.tab-table')[1];
            expect(levels.querySelector('thead')).toBeNull();
            expect(Array.from(page().querySelectorAll('.item-list li')).map(text)).toEqual(['Running', 'Stairs']);
            expect(page().querySelectorAll('.item-list').length).toBe(1);
            expect(text(page().querySelector('.comments'))).toBe('Tight hamstrings');
        });

        it('uses the legacy edit button label per tab', () => {
            load();
            openTab('Motor Control', `${base}/motor-control`, tab({ tab: 'motor-control' }));
            expect(button('Edit Motor Control Values')).toBeTruthy();
            openTab('Tone', `${base}/tone`, tab({ tab: 'tone' }));
            expect(button('Edit Tone Values')).toBeTruthy();
            openTab('Pain', `${base}/pain`, tab({ tab: 'pain' }));
            expect(button('Edit Pain Values')).toBeTruthy();
        });

        it('reloads the tab list and active tab when the visit changes', () => {
            load();
            openTab('Tone', `${base}/tone`, tab({ tab: 'tone' }));
            fixture.componentRef.setInput('visitId', 8);
            fixture.detectChanges();
            http.expectOne('/api/patients/42/visits/8/pt-evaluation/tabs').flush('', { status: 404, statusText: 'Not Found' });
            http.expectOne('/api/patients/42/visits/8/pt-evaluation/tone').flush(tab({ tab: 'tone', visitId: 8 }));
        });
    });

    describe('editing', () => {
        function openEditor(): void {
            load();
            openTab('PROM/Strength', `${base}/prom-strength`, tab());
            click('Edit Data');
            http.expectOne(`${base}/prom-strength/form`).flush(promForm());
            fixture.detectChanges();
        }

        it('renders grid and stacked fields with their current values', () => {
            openEditor();
            expect(text(page().querySelector('.form-title'))).toBe('Edit PROM/Strength');
            expect(input('hip_flex_r').value).toBe('120');
            expect(input('hip_flex_r').getAttribute('aria-label')).toBe('Hip Flex Right');
            expect((input('hip_flex_r_interp') as unknown as HTMLSelectElement).value).toBe('N');
            const factors = Array.from(page().querySelectorAll('[aria-label="Aggravating factors"] input')) as HTMLInputElement[];
            expect(factors.map(box => box.checked)).toEqual([true, false]);
            expect(input('comments').value).toBe('old');
        });

        it('blocks saving out-of-range values with the field rules', () => {
            openEditor();
            type('hip_flex_r', '500');
            click('Save Changes');
            http.expectNone(`${base}/prom-strength/form`);
            expect(text(page().querySelector('#pt-hip_flex_r-error'))).toBe('Hip Flex Right must be at most 180.');
            expect(input('hip_flex_r').getAttribute('aria-invalid')).toBe('true');
        });

        it('saves with the revision and returns to the updated view', () => {
            openEditor();
            type('hip_flex_r', '110');
            (page().querySelectorAll('[aria-label="Aggravating factors"] input')[1] as HTMLInputElement).click();
            fixture.detectChanges();
            click('Save Changes');
            const request = http.expectOne(`${base}/prom-strength/form`);
            expect(request.request.method).toBe('PUT');
            expect(request.request.body).toEqual({
                revision: 'r1',
                values: { hip_flex_r: '110', hip_flex_r_interp: 'N', factors: ['1', '2'], comments: 'old' }
            });
            request.flush(tab());
            fixture.detectChanges();
            expect(page().querySelector('app-pt-evaluation-form')).toBeNull();
            expect(page().querySelector('.tab-table')).not.toBeNull();
        });

        it('shows server field errors from a 400', () => {
            openEditor();
            click('Save Changes');
            http.expectOne(`${base}/prom-strength/form`).flush(
                { message: 'Please fix the errors.', fieldErrors: { hip_flex_r: 'Must be between -90 and 180' } },
                { status: 400, statusText: 'Bad Request' });
            fixture.detectChanges();
            expect(text(page().querySelector('.form-error'))).toContain('Please fix the errors.');
            expect(text(page().querySelector('#pt-hip_flex_r-error'))).toBe('Must be between -90 and 180');
        });

        it('handles a revision conflict by offering to reload the form', () => {
            openEditor();
            click('Save Changes');
            http.expectOne(`${base}/prom-strength/form`).flush('', { status: 409, statusText: 'Conflict' });
            fixture.detectChanges();
            expect(button('Save Changes').disabled).toBe(true);
            click('Discard changes and reload');
            http.expectOne(`${base}/prom-strength/form`).flush(promForm());
        });

        it('asks before discarding unsaved changes on cancel or tab switch', () => {
            openEditor();
            type('comments', 'new note');
            const confirm = vi.spyOn(window, 'confirm').mockReturnValue(false);
            click('Return without Saving Changes');
            click('Tone');
            expect(confirm).toHaveBeenCalledTimes(2);
            expect(page().querySelector('app-pt-evaluation-form')).not.toBeNull();
            expect(fixture.componentInstance.canLeave()).toBe(false);

            confirm.mockReturnValue(true);
            click('Return without Saving Changes');
            expect(page().querySelector('app-pt-evaluation-form')).toBeNull();
        });
    });

    describe('orthotics', () => {
        it('adds, edits and deletes orthoses through their own endpoints', () => {
            load();
            openTab('Orthotics', `${base}/orthotics`, orthotics());

            click('Add an Orthosis');
            http.expectOne(`${base}/orthotics/new/form`).flush({ ...promForm(), tab: 'orthotics', title: 'Add an Orthosis' });
            fixture.detectChanges();
            click('Insert Orthosis');
            const add = http.expectOne(`${base}/orthotics/new/form`);
            expect(add.request.method).toBe('POST');
            add.flush(orthotics());
            fixture.detectChanges();

            (page().querySelector('[aria-label="Edit AFO"]') as HTMLButtonElement).click();
            fixture.detectChanges();
            http.expectOne(`${base}/orthotics/5/form`).flush({ ...promForm(), tab: 'orthotics' });
            fixture.detectChanges();
            click('Save Changes');
            const edit = http.expectOne(`${base}/orthotics/5/form`);
            expect(edit.request.method).toBe('PUT');
            edit.flush(orthotics());
            fixture.detectChanges();

            (page().querySelector('[aria-label="Delete AFO"]') as HTMLButtonElement).click();
            fixture.detectChanges();
            http.expectNone(`${base}/orthotics/5`);
            const confirmation = page().querySelector('.delete-confirm')!;
            expect(text(confirmation.querySelector('h3'))).toBe('Delete Orthosis');
            expect(Array.from(confirmation.querySelectorAll('td')).map(text)).toEqual(['AFO', 'Right']);
            click('Yes - Delete this Orthosis');
            const remove = http.expectOne(`${base}/orthotics/5`);
            expect(remove.request.method).toBe('DELETE');
            remove.flush(tab({ tab: 'orthotics', hasData: false, emptyMessage: null, sections: [] }));
        });

        it('does not delete when the confirmation is declined', () => {
            load();
            openTab('Orthotics', `${base}/orthotics`, orthotics());
            (page().querySelector('[aria-label="Delete AFO"]') as HTMLButtonElement).click();
            fixture.detectChanges();
            click('Return without Deleting');
            http.expectNone(`${base}/orthotics/5`);
            expect(page().querySelector('.delete-confirm')).toBeNull();
            expect(page().querySelector('[aria-label="Delete AFO"]')).not.toBeNull();
        });

        it('creates and edits the movement disorder comments next to the orthoses list', () => {
            fixture.componentRef.setInput('patientId', 42);
            fixture.componentRef.setInput('visitId', 7);
            fixture.detectChanges();
            http.expectOne(`${base}/tabs`).flush({
                movementDisorder: true,
                tabs: [{ key: 'general-md', label: 'General' }, { key: 'orthotics', label: 'Orthotics' }]
            });
            http.expectOne(`${base}/general-md`).flush(tab({ tab: 'general-md' }));
            fixture.detectChanges();
            openTab('Orthotics', `${base}/orthotics`, orthotics({ actions: { ...allActions, edit: false, create: true } }));
            expect(page().querySelector('[aria-label="Delete AFO"]')).not.toBeNull();
            click('Create New Record');
            const create = http.expectOne(`${base}/orthotics/record`);
            expect(create.request.method).toBe('POST');
            create.flush(orthotics({ actions: { ...allActions, create: false } }));
            fixture.detectChanges();
            expect((Array.from(page().querySelectorAll('button')) as HTMLButtonElement[])
                .some(item => text(item) === 'Create New Record')).toBe(false);
            click('Edit Comments');
            http.expectOne(`${base}/orthotics/form`).flush({ ...promForm(), tab: 'orthotics' });
            fixture.detectChanges();
            expect(button('Save Changes')).toBeTruthy();
            expect(button('Return without Saving Changes')).toBeTruthy();
        });
    });

    describe('comparison report', () => {
        it('loads the report, prints it, and returns to the evaluation', () => {
            load();
            click('View Printable Comparison Report');
            const report: PtReportResponse = {
                title: 'PT Evaluation Comparison', header: [{ label: 'Patient', value: 'Test Patient' }],
                sections: tab().sections
            };
            http.expectOne('/api/patients/42/visits').flush([]);
            http.expectOne(`${base}/comparison-report`).flush(report);
            fixture.detectChanges();
            expect(page().querySelector('.compare-picker')).toBeNull();
            expect(text(page().querySelector('.report-title'))).toBe('PT Evaluation Comparison');
            expect(text(page().querySelector('.report-header dt'))).toBe('Patient');
            expect(text(page().querySelector('.report-header dd'))).toBe('Test Patient');

            const print = vi.spyOn(window, 'print').mockImplementation(() => {});
            click('Print');
            expect(print).toHaveBeenCalled();

            click('Back to PT Evaluation');
            expect(page().querySelector('.general-table')).not.toBeNull();
        });

        it('reloads the report with up to two comparison visits of the same patient', () => {
            load();
            click('View Printable Comparison Report');
            const report: PtReportResponse = { title: 'PT Evaluation Comparison', header: [], sections: [] };
            http.expectOne('/api/patients/42/visits').flush([
                { id: 7, patientId: 42, attendance: 'Yes', date: '2026-09-16', visitType: 'Gait', visitSubType: null },
                { id: 5, patientId: 42, attendance: 'Yes', date: '2025-03-02', visitType: 'Gait', visitSubType: null },
                { id: 3, patientId: 42, attendance: null, date: '2024-01-10', visitType: null, visitSubType: null },
                { id: 2, patientId: 42, attendance: 'No', date: '2023-05-05', visitType: 'Gait', visitSubType: null },
                { id: 9, patientId: 42, attendance: null, date: null, visitType: null, visitSubType: null }
            ]);
            http.expectOne(`${base}/comparison-report`).flush(report);
            fixture.detectChanges();

            const selects = (): HTMLSelectElement[] => Array.from(page().querySelectorAll('.compare-picker select'));
            const optionValues = (select: HTMLSelectElement) => Array.from(select.options).map(option => option.value);
            expect(optionValues(selects()[0])).toEqual(['', '5', '3']);
            expect(selects()[1].disabled).toBe(true);

            selects()[0].value = '5';
            selects()[0].dispatchEvent(new Event('change'));
            http.expectOne(request => request.url === `${base}/comparison-report`
                && request.params.get('compareVisitId1') === '5' && !request.params.has('compareVisitId2')).flush(report);
            fixture.detectChanges();
            expect(selects()[1].disabled).toBe(false);
            expect(optionValues(selects()[1])).toEqual(['', '3']);

            selects()[1].value = '3';
            selects()[1].dispatchEvent(new Event('change'));
            http.expectOne(request => request.params.get('compareVisitId1') === '5'
                && request.params.get('compareVisitId2') === '3').flush(report);
            fixture.detectChanges();

            selects()[0].value = '';
            selects()[0].dispatchEvent(new Event('change'));
            http.expectOne(request => request.url === `${base}/comparison-report` && request.params.keys().length === 0)
                .flush(report);
        });
    });

    describe('movement disorder visits', () => {
        it('uses the tab list from the backend and loads MD tabs generically', () => {
            fixture.componentRef.setInput('patientId', 42);
            fixture.componentRef.setInput('visitId', 7);
            fixture.detectChanges();
            http.expectOne(`${base}/tabs`).flush({
                movementDisorder: true,
                tabs: [
                    { key: 'general-md', label: 'General' }, { key: 'prom-strength', label: 'PROM/Strength' },
                    { key: 'orthotics', label: 'Orthotics' }, { key: 'tone', label: 'Tone' }, { key: 'pain', label: 'Pain' },
                    { key: 'hat', label: 'HAT' }, { key: 'dystonia-scale', label: 'Dystonia Scale' }
                ]
            });
            http.expectOne(`${base}/general-md`).flush(tab({ tab: 'general-md' }));
            fixture.detectChanges();

            expect(Array.from(page().querySelectorAll('.tab')).map(text))
                .toEqual(['General', 'PROM/Strength', 'Orthotics', 'Tone', 'Pain', 'HAT', 'Dystonia Scale']);
            expect(button('Modify General Data')).toBeTruthy();
            openTab('Dystonia Scale', `${base}/dystonia-scale`, tab({ tab: 'dystonia-scale' }));
            expect(text(page().querySelector('h2'))).toBe('PT Evaluation: Dystonia Scale');
        });
    });

    it('shows an error with a retry that reloads', () => {
        fixture.componentRef.setInput('patientId', 42);
        fixture.componentRef.setInput('visitId', 7);
        fixture.detectChanges();
        http.expectOne(`${base}/tabs`).flush('boom', { status: 500, statusText: 'Server Error' });
        fixture.detectChanges();
        expect(text(page().querySelector('[role="alert"]'))).toContain('Unable to load the PT evaluation.');
        click('Try Again');
        http.expectOne(`${base}/tabs`).flush('', { status: 404, statusText: 'Not Found' });
        http.expectOne(`${base}/general`).flush(general());
    });

    it('does not call the API for an invalid visit', () => {
        fixture.componentRef.setInput('patientId', 42);
        fixture.componentRef.setInput('visitId', 0);
        fixture.detectChanges();
        http.expectNone(`${base}/tabs`);
        expect(text(page())).toContain('Select a valid patient and visit.');
    });
});
