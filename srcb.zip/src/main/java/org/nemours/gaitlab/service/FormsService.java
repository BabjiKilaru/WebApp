package org.nemours.gaitlab.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import org.nemours.gaitlab.controller.FormsResponse;
import org.nemours.gaitlab.repository.FormsRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class FormsService {

    private static final Set<String> SUPPORTED_FORMS =
        Set.of(
            "patientform",
            "analysisform",
            "ptevalform",
            "engineerform",
            "footstudysurvey",
            "shueeform",
            "ueengineerform",
            "runningengineerform",
            "ptueform"
        );

    private final FormsRepository formsRepository;

    public FormsService(FormsRepository formsRepository) {
        this.formsRepository = formsRepository;
    }

    @Transactional(readOnly = true)
    public List<FormsResponse>
            getScheduledPatients(LocalDate visitDate) {

        return formsRepository
            .findScheduledPatients(visitDate)
            .stream()
            .map(patient -> new FormsResponse(
                patient.visitId(),
                patient.patientId(),
                patient.mrn(),
                patient.firstName(),
                patient.lastName(),
                patient.visitType(),
                patient.visitSubType(),
                patient.visitDate(),
                patient.appointmentTime(),
                getRecommendedForms(patient.testGroupId())
            ))
            .toList();
    }

    private List<String> getRecommendedForms(
            Integer testGroupId) {

        return formsRepository
            .findRecommendedForms(testGroupId)
            .stream()
            .filter(SUPPORTED_FORMS::contains)
            .distinct()
            .toList();
    }
}