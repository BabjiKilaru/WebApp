package org.nemours.gaitlab.controller;

import java.util.List;
import java.util.Map;
import java.time.LocalDate;
import java.util.HashMap;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;

import org.nemours.gaitlab.model.Patient;
import org.nemours.gaitlab.repository.PatientRepository;
import org.nemours.gaitlab.repository.VisitRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PostMapping;

@RestController
@RequestMapping("/api/patients")
public class PatientController {

    private final PatientRepository patientRepository;
    private final VisitRepository visitRepository;

    public PatientController(PatientRepository patientRepository, VisitRepository visitRepository) {
        this.patientRepository = patientRepository;
        this.visitRepository = visitRepository;
    }

    @GetMapping
    public List<Patient> getPatients(@RequestParam(required = false) String lastName) {
        List<Patient> patients;
        if (lastName != null && !lastName.isBlank()) {
            patients = patientRepository.findByLastNameContainingIgnoreCase(lastName);
        } else {
            patients = patientRepository.findAll();
        }

        patients.forEach(this::loadDiagnosis);

        return patients;
    }

    @GetMapping("/{id:\\d+}")
    public ResponseEntity<Patient> getPatientById(@PathVariable Integer id) {
        return patientRepository
                .findById(id)
                .map(patient -> {
                    loadDiagnosis(patient);
                    return ResponseEntity.ok(patient);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    private void loadDiagnosis(Patient patient) {
        List<Object[]> rows = patientRepository.findDiagnosisByPatientId(patient.getId());

        if (!rows.isEmpty()) {
            Object[] row = rows.get(0);
            patient.setIcd9Code(row[2] != null ? row[2].toString() : null);

            patient.setGeneralDiagnosis(row[3] != null ? row[3].toString() : null);

            patient.setLearningDescription(row[4] != null ? row[4].toString() : null);
        } else {
            patient.setIcd9Code(null);
            patient.setGeneralDiagnosis(null);
            patient.setLearningDescription(null);
        }
    }

    @GetMapping("/mrn/{mrn}")
    public ResponseEntity<Patient> getPatientByMrn(@PathVariable String mrn) {
        return patientRepository
                .findByMrn(mrn)
                .map(patient -> {
                    loadDiagnosis(patient);
                    return ResponseEntity.ok(patient);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/search")
    public List<Patient> searchPatients(@RequestParam("query") String query) {
        if (query == null || query.trim().length() < 2) {
            return List.of();
        }

        List<Patient> patients = patientRepository.searchPatients(query.trim());

        patients.forEach(this::loadDiagnosis);

        return patients;
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updatePatient(@PathVariable Integer id, @RequestBody Patient request) {
        Patient patient = patientRepository.findById(id).orElse(null);

        if (patient == null) {
            return ResponseEntity.notFound().build();
        }

        String mrn = request.getMrn() == null ? "" : request.getMrn().trim();

        if (mrn.isBlank()) {
            return ResponseEntity.badRequest().body("MRN is required.");
        }

        Patient existingPatient = patientRepository.findByMrn(mrn).orElse(null);

        if (existingPatient != null && !existingPatient.getId().equals(id)) {
            return ResponseEntity.badRequest().body("A patient with this MRN already exists.");
        }

        patient.setMrn(mrn);
        patient.setFirstName(request.getFirstName());
        patient.setLastName(request.getLastName());
        patient.setOldLastName(request.getOldLastName());
        patient.setNickname(request.getNickname());
        patient.setDateOfBirth(request.getDateOfBirth());
        patient.setGender(request.getGender());
        patient.setGeneralDiagnosisCode(request.getGeneralDiagnosisCode());
        patient.setComment(request.getComment());

        Patient savedPatient = patientRepository.save(patient);
        loadDiagnosis(savedPatient);
        return ResponseEntity.ok(savedPatient);
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<String> handleDataIntegrityViolation(
            DataIntegrityViolationException exception) {
        Throwable cause = exception;

        while (cause != null) {
            if (cause instanceof org.hibernate.exception.ConstraintViolationException violation) {
                if ("23505".equals(violation.getSQLState()) && "mrn_index".equals(violation.getConstraintName())) {
                    return ResponseEntity.status(HttpStatus.CONFLICT).body("A patient with this MRN already exists.");
                }
            }
            cause = cause.getCause();
        }
        throw exception;
    }

    @GetMapping("/general-diagnoses")
    public List<Map<String, Object>> getGeneralDiagnoses() {
        return patientRepository.findAllGeneralDiagnoses().stream().map(row -> {
            Map<String, Object> diagnosis = new HashMap<>();
            diagnosis.put("id", row[0]);
            diagnosis.put("code", row[1]);
            diagnosis.put("diagnosis", row[2]);

            return diagnosis;
        })
                .toList();
    }

    @PostMapping
    public ResponseEntity<?> createPatient(@RequestBody Patient request) {
        if (request.getFirstName() == null || request.getFirstName().isBlank()) {
            return ResponseEntity.badRequest().body("First Name is required.");
        }

        if (request.getLastName() == null || request.getLastName().isBlank()) {
            return ResponseEntity.badRequest().body("Last Name is required.");
        }

        if (request.getMrn() == null || request.getMrn().isBlank()) {
            return ResponseEntity.badRequest().body("MRN is required.");
        }

        if (request.getDateOfBirth() == null) {
            return ResponseEntity.badRequest().body("Date of Birth is required.");
        }

        if (patientRepository.findByMrn(request.getMrn()).isPresent()) {
            return ResponseEntity.badRequest().body("A patient with this MRN already exists.");
        }

        Patient patient = new Patient();

        patient.setMrn(request.getMrn().trim());
        patient.setFirstName(request.getFirstName().trim());
        patient.setLastName(request.getLastName().trim());
        patient.setNickname(request.getNickname());
        patient.setDateOfBirth(request.getDateOfBirth());
        patient.setGender(request.getGender());
        patient.setGeneralDiagnosisCode(request.getGeneralDiagnosisCode());
        patient.setComment(request.getComment());

        patient.setLabel(false);

        Patient savedPatient = patientRepository.save(patient);

        loadDiagnosis(savedPatient);

        return ResponseEntity.ok(savedPatient);
    }


    @GetMapping("/scheduled")
    public List<ScheduledVisitOption> getScheduledPatients(@RequestParam("date") LocalDate date) {
        return visitRepository.findScheduledVisitsByDate(date).stream().map(row ->
            new ScheduledVisitOption(
                (Integer) row[0],
                (Integer) row[1],
                (String) row[2],
                (String) row[3],
                row[4] != null ? row[4].toString() : null,
                row[5] != null ? row[5].toString() : null,
                row[6] != null ? row[6].toString() : null
            )
        )
        .toList();
    }
}
