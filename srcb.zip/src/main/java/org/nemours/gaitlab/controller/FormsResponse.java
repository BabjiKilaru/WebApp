package org.nemours.gaitlab.controller;

import java.time.LocalDate;
import java.util.List;

public record FormsResponse(
    Integer visitId,
    Integer patientId,
    String mrn,
    String firstName,
    String lastName,
    String visitType,
    String visitSubType,
    LocalDate visitDate,
    String appointmentTime,
    List<String> recommendedForms
) {}