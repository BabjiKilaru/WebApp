package org.nemours.gaitlab.controller;

public record ScheduledVisitOption(
    Integer visitId,
    Integer patientId,
    String firstName,
    String lastName,
    String mrn,
    String visitType,
    String visitSubType
) {
    
}
